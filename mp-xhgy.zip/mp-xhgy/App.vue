<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
			var that = this;
			// #ifdef MP-WEIXIN
			uni.login({
				success(res) {
					console.log(res)
					that.wxLogin(res.code);
				}
			})
			// #endif
		},
		onShow: function() {
			console.log('页面被展示')
		},
		onHide: function() {
			console.log('页面被隐藏')
		},
		globalData:{
			token:null,
		},
		methods:{
			wxLogin:function(code){
				var that = this;
				//调用wxlogin接口，获取默认登陆用户
				that.$cloudApi.call({
					name: 'wxlogin',
					data: {
						code:code
					},
					success: res => {
						console.log('登陆结果',res)
						that.globalData.token = res.token;
						that.globalData.userInfo = res;
						if(that.globalData.canIUseGetUserProfile){
							that.globalData.canIUseGetUserProfile(res)
						}
					}
				});
			}
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import "uview-ui/index.scss";
</style>
