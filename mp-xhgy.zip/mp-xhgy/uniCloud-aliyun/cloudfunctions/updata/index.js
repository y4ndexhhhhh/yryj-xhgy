'use strict';
const db = uniCloud.database()
exports.main = async (event, context) => {
	const collection = db.collection('lover-list');
	//event为客户端上传的参数
	// context包含了调用信息和运行状态，每次调用的上下文
	// 增加
	let res = await collection.add({
		time: event.time,    //时间
		wx_openid:event.wx_openid,    //发起人id
		title:event.title,    //标题
		intro:event.intro,    //简介
		fileID:event.fileID,    //图片
		name:event.name,    //姓名
		phone:event.phone,    //手机号
		region:event.region,    //所在地区
		idcard:event.idcard,    //身份证号码
		target:event.target,    //预计爱心数量
		bank: event.bank,    //银行卡号
		finish:0,    //收到的爱心数量
		progress:0,    //项目百分比
		state:0,     //项目状态，0正在审核，1审核通过，2审核不通过
		states:true    //项目状态，true正在进行，false已结束
	}) 

	console.log(JSON.stringify(res)) // 转为字符串 
	
  return {
		code:200,
		msg:"成功",
		data:res.data
	}
};