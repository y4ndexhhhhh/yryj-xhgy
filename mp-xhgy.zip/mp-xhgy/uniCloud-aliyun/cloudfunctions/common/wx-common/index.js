const jwt = require("jsonwebtoken"); //webjsontoken
const appId = 'wx7a6c5e8f320f76f1';
const appSecret = '53b77508a676b4277d93a9a8371e4684';
//生成token
function getToken(openid) {
	// sign(加密数据，加密辅助，过期时间(单位/s))
	return jwt.sign({
		openid
	}, appSecret, {
		expiresIn: 60 * 60 * 24 * 30
	});
}
//解密token
function verifyToken(token) {
	return jwt.verify(token, appSecret, (err, decode) => {
		return decode
	})
}

module.exports = {
	getToken,
	verifyToken,
	appId,
	appSecret
}
