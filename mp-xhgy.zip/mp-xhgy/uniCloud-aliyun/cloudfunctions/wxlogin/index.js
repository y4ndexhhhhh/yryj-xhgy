'use strict';
const {
	appId,
	appSecret,
	getToken,
	verifyToken
} = require("wx-common");
const db = uniCloud.database();
exports.main = async (event, context) => {
	//event为客户端上传的参数
	console.log('event : ', event)
	let code = event.code;
	const res = await uniCloud.httpclient.request(
		`https://api.weixin.qq.com/sns/jscode2session?appid=${appId}&secret=${appSecret}&js_code=${code}&grant_type=authorization_code`, {
			dataType: "json"
		}
	)
	console.log('code解析',res.data)
	// 往user表添加用户信息
	const userData = {
		wx_openid: res.data.openid
	}
	console.log('查询参数',userData)
	let userinfo = {};
	let result = await db.collection("users").where(userData).get();
	console.log('userinfo',result)
	if(result.affectedDocs > 0){
		console.log('用户已存在')
		userinfo = result.data[0];
	}else{
		console.log('用户不存在')
		userinfo = await db.collection("users").add(userData);
	}
	console.log(userinfo)
	userinfo.token = getToken(userinfo.id?userinfo.id:userinfo._id)
	//返回数据给客户端
	return {
		code: 200,
		msg: '登录成功',
		data: userinfo
	}
};
