'use strict';
const {
	verifyToken
} = require("wx-common");
const db = uniCloud.database();
exports.main = async (event, context) => {
	//event为客户端上传的参数
	console.log('event : ', event)

	const {
		nickName,
		avatarUrl,
		token
	} = event;
	console.log('用户token', verifyToken(token))
	let id = verifyToken(token).openid;
	console.log('用户ID', id)
	//此代码未验证

	let result = await db.collection('users').where({
		_id: id
	}).update({
		nickName,
		avatarUrl
	});
	result = await db.collection('users').where({'_id': id}).get();
	let userInfo = result.data[0]
	//返回数据给客户端
	return {
		code: 200,
		msg: '更新成功',
		data: userInfo
	}
};
