'use strict';
const db = uniCloud.database()
exports.main = async (event, context) => {
	const collection = db.collection('lover-onto');
	//event为客户端上传的参数
	let res = await collection.add({
		time:event.time,    //时间戳
		wx_openid:event.wx_openid,    //微信id
		listid:event.listid,    //项目id
		title:event.title,    //标题
		intro:event.intro,   //简介
		fileID:event.fileID,    //图片
		value:event.value    //赞助的数量
	})
	
	console.log(JSON.stringify(res))    //转换为字符串
	/* 此函数为支持功能的提交函数 */
	
	//返回数据给客户端
	return {
		code:200,
		msg:'上传成功',
		data:res.data
	}
};
