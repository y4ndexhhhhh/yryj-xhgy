// #ifndef VUE3
import Vue from 'vue'
import App from './App'
// import store from './store'
// import * as util from '@/common/oyyl-js/util.js'
// Vue.prototype.$util = util
// Vue.prototype.$store = store
Vue.config.productionTip = false
App.mpType = 'app'
const app = new Vue({
	...App
})
app.$mount()

//跳转相关的封装
import * as navTo from '@/utils/navTo'
Vue.prototype.$navTo = navTo;

// 全局分享相关
import share from  './common/share/share.js'
Vue.mixin(share);

// 授权登录相关
import cloudApi from './common/cloudApi.js'
Vue.prototype.$cloudApi = cloudApi;
// #endif

// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
// #endif

// Uview的封装
import uView from 'uview-ui';
Vue.use(uView);
