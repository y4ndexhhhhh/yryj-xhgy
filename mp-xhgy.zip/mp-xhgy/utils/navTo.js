/**
 *Created By 乐道研发 on 2020/4/20
 */
const togo = function(url, data) {
	console.log("togo")
	url += (url.indexOf('?') < 0 ? '?' : '&') + param(data)
	console.log(url)
    uni.navigateTo({
		url
	})
}
const redirectTo = function(url, data) {
	url += (url.indexOf('?') < 0 ? '?' : '&') + param(data)
	uni.redirectTo({
		url
	})
}
const switchTab = function(url, data) {
	url += (url.indexOf('?') < 0 ? '?' : '&') + param(data)
	uni.switchTab({
		url
	})
}

export function param(data) {
	let url = ''
	for (var k in data) {
		let value = data[k] !== undefined ? data[k] : ''
		url += '&' + k + '=' + encodeURIComponent(value)
	}
	return url ? url.substring(1) : ''
}
export {
	togo,
	redirectTo,
	switchTab
}
