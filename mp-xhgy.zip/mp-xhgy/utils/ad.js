const rewarded = {
  load(id, e) {
    if (uni.createRewardedVideoAd) {
      videoAd = uni.createRewardedVideoAd({
        adUnitId: id
      })
      videoAd.onError(err => {console.log('激励视频 加载失败')})
      videoAd.onClose((status) => {
        if (status && status.isEnded || status === undefined) {
          e()
        } else {}
      })
    }
  },
  show() {
    if (videoAd) {
      videoAd.show().catch(() => {
        // 失败重试
        videoAd.load()
          .then(() => videoAd.show())
          .catch(err => {
            console.log('激励视频 广告显示失败')
          })
      })
    }
  }
}

module.exports = {
  rewarded
};