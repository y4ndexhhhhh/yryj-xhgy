// time  传入时间戳，与当前时间戳进行计算得出相差多久
// time1  传入时间戳，进行换算得出正常日期

  
const time = (timer) => {
	var arrTimestamp = (timer + '').split('');
	for (var start = 0; start < 13; start++) {
		if (!arrTimestamp[start]) {
			arrTimestamp[start] = '0';
		}
	}
	timer = arrTimestamp.join('') * 1;

	var minute = 1000 * 60;
	var hour = minute * 60;
	var now = new Date().getTime();    //当前时间
	var diffValue = now - timer;

	// 如果本地时间反而小于变量时间
	if (diffValue < 0) {
		return '不久前';
	}

	// 计算差异时间的量级
	var hourC = diffValue / hour;

	// 数值补0方法
	var zero = function(value) {
		if (value < 10) {
			return '0' + value;
		}
		return value;
	};

	// 使用
	if (hourC >= 0) {
		return parseInt(hourC);
	}
	return '25';
}

const time1 = (timer) => {
	var arrTimestamp = (timer + '').split('');
	for (var start = 0; start < 13; start++) {
		if (!arrTimestamp[start]) {
			arrTimestamp[start] = '0';
		}
	}
	var Etime = arrTimestamp.join('') * 1; //参数时间
	var Etimer = new Date(Etime)

	var Eyear = Etimer.getFullYear(); //取得4位数的年份
	var Emonth = Etimer.getMonth() + 1 < 10 ? '0' + (Etimer.getMonth() + 1) : Etimer.getMonth() + 1; //取得日期中的月份，其中0表示1月，11表示12月
	var Edate = Etimer.getDate()< 10 ? '0' + Etimer.getDate() : Etimer.getDate(); //返回日期月份中的天数（1到31）
	var Ehour = Etimer.getHours() < 10 ? '0' + Etimer.getHours() : Etimer.getHours(); //返回日期中的小时数（0到23）
	var Eminute = Etimer.getMinutes() < 10 ? '0' + Etimer.getMinutes() : Etimer.getMinutes(); //返回日期中的分钟数（0到59）

	return Eyear + "年" + Emonth + "月" + Edate + " " + Ehour + ":" + Eminute
}


module.exports = {
	time,
	time1
}
