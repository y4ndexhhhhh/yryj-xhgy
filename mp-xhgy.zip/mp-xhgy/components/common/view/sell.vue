<template>
	<view class="sell-box" :class="show?'show':''">
		
		<!--标题栏-->
		<bar-title bgColor='bg-white' :isBack="false">
			<block slot="content">直播</block>
		</bar-title>
		
		<!--占位的-->
		<view class="seat-height"></view>
		
		<!--中间内容区域-->
		<view class="view-content">
			<!--直播列表-->
			<view class="text-black text-lg text-bold padding-sm">直播列表</view>
			<live-list :list_data="liveData"/>
			
			<!--视频列表-->
			<view class="text-black text-lg text-bold padding-sm">小视频</view>
			<video-list :list_data="videoData"/>
		</view>
	</view>
</template>

<script>
	import typeList from '@/components/common/list/type-list';
	import liveList from '@/components/common/list/live-list';
	import videoList from '@/components/common/list/video-list';
	import barTitle from '@/components/common/basics/bar-title';
	import _home_data from '@/static/wine/data/home.js'; //虚拟数据
	import _sell_data from '@/static/wine/data/sell.js';	//虚拟数据
	import _tool from '@/static/wine/util/tools.js';	//工具函数
	
	export default {
		name: 'sell',
		components: {
			barTitle,
			typeList,
			liveList,
			videoList
		},
		data() {
			return {
				typeListData: [],
				liveData: [],
				videoData: [],
			}
		},
		props: {
			show: {
				type: Boolean,
				default: true
			},
			scrollY: {
				type: Number,
				default: 0
			},
			scrollBottom: {
				type: Number,
				default: 0
			}
		},
		watch: {
			scrollY() {
				
				this.setPageScroll(this.scrollY);
			},
			scrollBottom() {
				if(this.scrollBottom != 0) {
					//通知他妈的触底了
					this.setReachBottom();
				}
			},
		},
		created() {
			//加载虚拟数据
			this.typeListData = _sell_data.typeListData();
			this.liveData = _home_data.liveData();
			this.videoData = _home_data.videoData();
		},
		mounted() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			//页面被滚动
			setPageScroll(scrollTop) {
				//console.log(scrollTop);
			},
			//触底了
			setReachBottom() {
				console.log('触底了');
			},
			closeTap() {
				this.$emit('closeTap');
			},
			typeListTap(e) {
				console.log(e);
			}
		}
	}
</script>

<style lang="scss" scoped>
	.sell-box {
		background: #FAFAFA;
		position: relative;
		min-height: 100vh;
		z-index: 99999;
		width: 100%;
		display: none;
		.bar-view-box {
			position: fixed;
			top: 0;
			width: 100%;
			z-index: 999999;
			background: #FAFAFA;
			
			padding: var(--status-bar-height) 27.27rpx 0 27.27rpx;
			align-items: center;
			.bar-box {
				position: relative;
				width: 100%;
				align-items: center;
				line-height: 99.99rpx;
				.close {
					position: absolute;
					right: 27.27rpx;
					font-size: 40rpx;
					bottom: 9.09rpx;
				}
			}
		}
		
		.seat-height {
			width: 100%;
		}
		.view-content {
			padding: 0 27.27rpx 27.27rpx;
		}
	}
	.sell-box.show {
		display: block;
	}
</style>
