<template>
	<view class="box">
		<!-- 审核中 -->
		<view style="height: 100vh;width: 100%;">
			<view style="height: 500rpx;width: 500rpx;position: absolute;top: 100rpx;margin-left: -250rpx;left: 50%;">
				<view style="height: 100%;width: 100%;position: relative;">
					<image src="/static/image/my/default/linear.svg" style="height: 100%;width: 100%;"></image>
					<view class="state-text">提交成功，正在审核中...</view>
				</view>
			</view>
			<view class="state-text-s">稍后可在&nbsp;&nbsp;我的&nbsp;&nbsp;-&nbsp;&nbsp;我发起的&nbsp;&nbsp;里面查看</view>

			<!-- 按钮 -->
			<view class="button" @click="back"><view class="button-text">回到首页</view></view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	methods: {
		back() {
			console.log('回到首页');
			uni.switchTab({
				url: '/pages/index/index'
			});
		}
	}
};
</script>

<style>
.box {
	height: 100vh;
	width: 100%;
}

.state-text {
	position: absolute;
	text-align: center;
	bottom: 0;
	width: 100%;
	height: 50rpx;
	line-height: 50rpx;
	font-size: 30rpx;
	font-weight: bold;
}

.state-text-s {
	position: absolute;
	text-align: center;
	top: 600rpx;
	height: 100rpx;
	width: 100%;
	line-height: 100rpx;
	font-size: 25rpx;
}

.button {
	position: absolute;
	left: 50%;
	bottom: 150rpx;
	margin-left: -100rpx;
	width: 200rpx;
	height: 60rpx;
	border: 1px solid #000000;
	border-radius: 15rpx;
}

.button-text {
	text-align: center;
	width: 100%;
	font-size: 30rpx;
	line-height: 60rpx;
	color: #000000;
}
</style>
