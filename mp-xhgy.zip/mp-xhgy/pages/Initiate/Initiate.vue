<template>
	<view class="box">
		<view class="box-sizing">
			<view class="title">求助信息</view>
			<view class="form">
				<scroll-view scroll-y="true" style="height: 950rpx;width: 100%;">
					<!-- 此处放置表单 -->
					<view class="wrap">
						<u-form :model="model" :rules="rules" ref="uForm" :errorType="errorType">
							<u-form-item :label-position="labelPosition" label="姓名" prop="name">
								<u-input :border="border" placeholder="请输入姓名" v-model="model.name" type="text"></u-input>
							</u-form-item>

							<u-form-item :label-position="labelPosition" label="所在地区" prop="region" label-width="150">
								<u-input
									:border="border"
									type="select"
									:select-open="pickerShow"
									v-model="model.region"
									placeholder="请选择地区"
									@click="pickerShow = true"
								></u-input>
							</u-form-item>

							<u-form-item :label-position="labelPosition" label="身份证号" prop="idcard" label-width="150">
								<u-input :border="border" placeholder="请输入身份证号" v-model="model.idcard" type="number"></u-input>
							</u-form-item>

							<u-form-item :label-position="labelPosition" label="手机号码" prop="phone" label-width="150">
								<u-input :border="border" placeholder="请输入手机号" v-model="model.phone" type="number"></u-input>
							</u-form-item>

							<u-form-item :label-position="labelPosition" label="求助标题" prop="title">
								<u-input type="textarea" :border="border" placeholder="请简单填写您的求助标题" v-model="model.title" />
							</u-form-item>

							<u-form-item :label-position="labelPosition" label="求助说明" prop="intro">
								<u-input type="textarea" :border="border" placeholder="请填写您的说明" v-model="model.intro" />
							</u-form-item>

							<u-form-item :label-position="labelPosition" label="需要筹集的金额" prop="target">
								<u-input type="number" :border="border" placeholder="所填金额必须小于医疗费自费部分" v-model="model.target" />
							</u-form-item>
							
							<u-form-item :label-position="labelPosition" label="银行卡号" prop="bank">
								<u-input type="number" :border="border" placeholder="请填写您的银行卡号" v-model="model.bank" />
							</u-form-item>

							<u-form-item :label-position="labelPosition" label=" " prop="photo" label-width="150">
								<uni-file-picker
									v-model="object"
									title="上传图片(确诊病例等)"
									limit="9"
									file-mediatype="image"
									:auto-upload="false"
									ref="files"
									@select="select"
									@progress="progress"
									@success="success"
									@fail="fail"
								></uni-file-picker>
							</u-form-item>
						</u-form>
						<view class="agreement">
							<u-checkbox v-model="check" @change="checkboxChange"></u-checkbox>
							<!-- <view class="agreement-text" @click="agreement">勾选代表同意星火公益的使用协议</view> -->
							<view class="agreement-text">
								勾选代表同意星火公益的
								<text style="font-weight: bold;" @click="agreementuse">使用协议</text>
								和
								<text style="font-weight: bold;" @click="agreementpri">隐私协议</text>
							</view>
						</view>
						<!-- 地区 -->
						<u-picker mode="region" v-model="pickerShow" @confirm="regionConfirm"></u-picker>
						<u-verification-code seconds="60" ref="uCode" @change="codeChange"></u-verification-code>
					</view>

					<!--  表单END -->
				</scroll-view>
			</view>
		</view>
		
		<view class="buttom" v-if="userInfo.nickName" @click="submit"><view class="buttom-text">提&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;交</view></view>
		<view class="buttom" @click="getUserProfile" v-else><view class="buttom-text">提&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;交</view></view>
	</view>
</template>

<script>
const app = getApp({
	allowDefault: true
});
export default {
	data() {
		let that = this;
		return {
			userInfo:'',
			model: {
				wx_openid:'',    //微信id
				title: '', //求助标题
				intro: '', //简介
				name: '', //姓名
				region: '', //地区
				idcard: '', //身份证号
				phone: '', //手机号
				fileID: '', //图片
				target: '' ,//预计爱心数量
				time:'',   //时间
				bank:'',    //银行卡号
			},
			rules: {
				name: [
					{
						required: true,
						message: '请输入姓名',
						trigger: 'blur'
					},
					{
						min: 2,
						max: 10,
						message: '姓名长度在3到5个字符',
						trigger: ['change', 'blur']
					},
					{
						// 此为同步验证，可以直接返回true或者false，如果是异步验证，稍微不同，见下方说明
						validator: (rule, value, callback) => {
							// 调用uView自带的js验证规则，详见：https://www.uviewui.com/js/test.html
							return this.$u.test.chinese(value);
						},
						message: '姓名必须为中文',
						// 触发器可以同时用blur和change，二者之间用英文逗号隔开
						trigger: ['change', 'blur']
					}
				],
				title: [
					{
						required: true,
						message: '请填写标题'
					},
					{
						min: 5,
						message: '标题不能少于5个字',
						trigger: 'change'
					}
				],
				intro: [
					{
						required: true,
						message: '请填写简介'
					},
					{
						min: 5,
						message: '简介不能少于5个字',
						trigger: 'change'
					}
				],
				target: [
					{
						required: true,
						message: '请输入数量',
						trigger: ['change', 'blur']
					},
					{
						min: 3,
						message: '不得低于100',
						trigger: ['change', 'blur']
					},
					{
						validator: (rule, value, callback) => {
							// 调用uView自带的js验证规则，详见：https://www.uviewui.com/js/test.html
							return this.$u.test.enOrNum(value);
						},
						message: '请输入数字',
						// 触发器可以同时用blur和change，二者之间用英文逗号隔开
						trigger: ['change', 'blur']
					}
				],
				bank: [
					{
						required: true,
						message:'请输入您的银行卡号',
						trigger: ['change', 'blur']
					}
				],
				region: [
					{
						required: true,
						message: '请选择地区',
						trigger: 'change'
					}
				],
				idcard: [
					{
						required: true,
						message: '请输入身份证号',
						trigger: ['change', 'blur']
					},
					{
						validator: (rule, value, callback) => {
							// 调用uView自带的js验证规则，详见：https://www.uviewui.com/js/test.html
							return this.$u.test.idCard(value);
						},
						message: '身份证号不正确',
						// 触发器可以同时用blur和change，二者之间用英文逗号隔开
						trigger: ['change', 'blur']
					}
				],
				phone: [
					{
						required: true,
						message: '请输入手机号',
						trigger: ['change', 'blur']
					},
					{
						validator: (rule, value, callback) => {
							// 调用uView自带的js验证规则，详见：https://www.uviewui.com/js/test.html
							return this.$u.test.mobile(value);
						},
						message: '手机号码不正确',
						// 触发器可以同时用blur和change，二者之间用英文逗号隔开
						trigger: ['change', 'blur']
					}
				],
				password: [
					{
						required: true,
						message: '请输入密码',
						trigger: ['change', 'blur']
					},
					{
						// 正则不能含有两边的引号
						pattern: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]+\S{5,12}$/,
						message: '需同时含有字母和数字，长度在6-12之间',
						trigger: ['change', 'blur']
					}
				],
				rePassword: [
					{
						required: true,
						message: '请重新输入密码',
						trigger: ['change', 'blur']
					},
					{
						validator: (rule, value, callback) => {
							return value === this.model.password;
						},
						message: '两次输入的密码不相等',
						trigger: ['change', 'blur']
					}
				]
			},
			border: false, //所有输入框的边框
			check: false,
			selectStatus: 'close',
			pickerShow: false, //地址的弹窗
			radioCheckWidth: 'auto', //自适应
			radioCheckWrap: false, //自适应
			labelPosition: 'top', //label对齐方式
			codeTips: '',
			errorType: ['message']
		};
	},
	onShow() {
		console.log('进入表单填写页面');
	},
	onLoad() {
		console.log(app.globalData.userInfo)
		this.userInfo = app.globalData.userInfo;
	},
	computed: {
		borderCurrent() {
			return this.border ? 0 : 1;
		}
	},
	onReady() {
		this.$refs.uForm.setRules(this.rules);
	},
	methods: {
		// 跳转至协议页面
		agreementuse() {
			uni.navigateTo({
				url: '/pages/agreement/use'
			});
		},

		agreementpri() {
			uni.navigateTo({
				url: '/pages/agreement/privacy'
			});
		},

		// 检测授权登录
		submit() {
			this.model.wx_openid = app.globalData.userInfo.wx_openid;
			console.log(this.model.wx_openid)
			console.log('您已登录');
			this.$refs.uForm.validate(valid => {
				if (valid) {
					if (!this.model.agreement) return this.$u.toast('请勾选协议');
					console.log('验证通过');
					this.upload();
				} else {
					console.log('验证失败');
				}
			});
		},

		upload() {
			console.log('执行图片上传函数');
			this.$refs.files.upload();
		},
		// 获取上传状态
		select(e) {},
		// 获取上传进度
		progress(e) {},
		// 上传成功
		success(e) {
			console.log('上传成功');
			this.model.fileID = e.tempFilePaths;
			console.log(this.object);
			this.updata();
			this.navgetTo();
		},
		// 上传失败
		fail(e) {
			console.log('上传失败：', e);
		},
		navgetTo(){
			uni.navigateTo({
				url:'/pages/Initiate/feedbackdetill'
			})
		},

		updata() {
			this.gettime();
			console.log('开始运行updata函数');
			uniCloud.callFunction({
				name: 'updata',
				data: this.model,
				success(res) {
					console.log(res);
				},
				fail(e) {
					console.log(e)
				}
			});
		},
		
		getUserProfile: function() {
			var that = this;
			uni.getUserProfile({
				desc: '用户信息，拿来吧你！',
				lang: 'zh_CN',
				success: res => {
					console.log(res);
					that.$cloudApi.call({
						name: 'member-update',
						data: res.userInfo,
						success: res => {
							console.log('更新结果', res);
							app.globalData.userInfo = res;
							that.userInfo = res;
						}
					});
				}
			});
		},
		
		gettime(){
			console.log('正在获取时间')
			this.model.time = new Date().getTime();
			console.log(this.model.time)
		},

		// 勾选版权协议
		checkboxChange(e) {
			this.model.agreement = e.value;
		},
		// 选择地区回调
		regionConfirm(e) {
			this.model.region = e.province.label + '-' + e.city.label + '-' + e.area.label;
		},
		codeChange(text) {
			this.codeTips = text;
		}
	}
};
</script>

<style>
.box {
	width: 100%;
	height: 100vh;
	background-color: #18b566;
}

.box-sizing {
	position: absolute;
	margin-top: 60rpx;
	margin-left: -325rpx;
	left: 50%;
	width: 650rpx;
	height: 1050rpx;
	background: #ffffff;
	border-radius: 30rpx;
}

.title {
	width: 100%;
	height: 100rpx;
	font-size: 50rpx;
	text-align: center;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #000000;
}

.form {
	width: 100%;
	height: 950rpx;
	border-radius: 0 0 30rpx 30rpx;
}

.buttom {
	position: absolute;
	left: 50%;
	bottom: 45rpx;
	margin-left: -300rpx;
	width: 600rpx;
	height: 100rpx;
	background: #ffffff;
	border-radius: 50rpx;
}

.buttom-text {
	text-align: center;
	width: 100%;
	line-height: 100rpx;
	font-size: 50rpx;
	font-family: Adobe Heiti Std;
	color: #656363;
}

/* 表单 */
.wrap {
	padding: 30rpx;
}

.agreement {
	display: flex;
	align-items: center;
}

.agreement-text {
	color: $u-tips-color;
}
</style>
