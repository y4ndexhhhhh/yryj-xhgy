<template>
	<view class="box">
		<!-- 审核中 -->
		<view style="height: 100vh;width: 100%;" v-if="state == 0">
			<view style="height: 500rpx;width: 500rpx;position: absolute;top: 100rpx;margin-left: -250rpx;left: 50%;">
				<view style="height: 100%;width: 100%;position: relative;">
					<image src="/static/image/my/default/linear.svg" style="height: 100%;width: 100%;"></image>
					<view class="state-text">提交成功，正在审核中...</view>
				</view>
			</view>
			<view class="state-text-s">稍后可在&nbsp;&nbsp;我的&nbsp;&nbsp;-&nbsp;&nbsp;我发起的&nbsp;&nbsp;里面查看</view>

			<!-- 按钮 -->
			<view class="button" @click="back"><view class="button-text">回到首页</view></view>
		</view>

		<!-- 审核成功 -->
		<view style="height: 100vh;width: 100%;" v-if="state == 1">
			<view style="height: 500rpx;width: 500rpx;position: absolute;top: 100rpx;margin-left: -250rpx;left: 50%;">
				<view style="height: 100%;width: 100%;position: relative;">
					<image src="/static/image/my/default/good.svg" style="height: 100%;width: 100%;"></image>
					<view class="state-text">审核成功</view>
				</view>
			</view>
			<view class="state-text-s">您的求助已经审核成功，快去筹爱心吧</view>

			<!-- 按钮 -->
			<view class="button" @click="back"><view class="button-text">去筹爱心</view></view>
		</view>

		<!-- 审核失败 -->
		<view style="height: 100vh;width: 100%;" v-if="state == 2">
			<view style="height: 500rpx;width: 500rpx;position: absolute;top: 100rpx;margin-left: -250rpx;left: 50%;">
				<view style="height: 100%;width: 100%;position: relative;">
					<image src="/static/image/my/default/error.svg" style="height: 100%;width: 100%;"></image>
					<view class="state-text">审核失败</view>
				</view>
			</view>
			<view class="state-text-s">{{ whyshare }}</view>

			<!-- 按钮 -->
			<view class="button" @click="Initiate"><view class="button-text">发起求助</view></view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			id: 0,
			state: 0 ,//项目审核状态，0正在审核，1审核通过，2审核不通过
			whyshare:'',    //原因
		};
	},
	onLoad(e) {
		console.log('进入反馈页面');
		uni.showLoading({
			title:'查询中'
		});
		let _this = this;
		_this.id = e.id;
		console.log(_this.id);
		_this.detail();
	},
	methods: {
		detail(){
			let _this = this;
			console.log('开始查询');
			uniCloud.callFunction({
				name:'datail',
				data: {
					_id: this.id
				},
				success(res) {
					var obj = res.result.data[0];
					for (var index in obj) {
						// console.log('key=' + index, 'value=' + obj[index]);
						if (index == 'state') {
							_this.state = obj[index];
						} if (index == 'whyshare') {
							_this.whyshare = obj[index];
						}
					}
					console.log(_this.whyshare)
					console.log(_this.state);
					uni.hideLoading()
				},
				fail(e) {
					console.log(e);
				}
			})
		},
		back() {
			console.log('回到首页');
			uni.switchTab({
				url: '/pages/index/index'
			});
		},

		Initiate() {
			console.log('重新发起');
			uni.switchTab({
				url: '/pages/Initiate/Initiate'
			});
		}
	}
};
</script>

<style lang="scss">
.box {
	height: 100vh;
	width: 100%;
}

.state-text {
	position: absolute;
	text-align: center;
	bottom: 0;
	width: 100%;
	height: 50rpx;
	line-height: 50rpx;
	font-size: 30rpx;
	font-weight: bold;
}

.state-text-s {
	position: absolute;
	text-align: center;
	top: 600rpx;
	height: 100rpx;
	width: 100%;
	line-height: 100rpx;
	font-size: 25rpx;
}

.button {
	position: absolute;
	left: 50%;
	bottom: 150rpx;
	margin-left: -100rpx;
	width: 200rpx;
	height: 60rpx;
	border: 1px solid #000000;
	border-radius: 15rpx;
}

.button-text {
	text-align: center;
	width: 100%;
	font-size: 30rpx;
	line-height: 60rpx;
	color: #000000;
}
</style>
