<template>
	<view>
		<!-- 缺省提示 -->
		<view style="height: 100vh;width: 100%;" v-if="size == 0">
			<view style="height: 500rpx;width: 500rpx;position: absolute;top: 100rpx;margin-left: -250rpx;left: 50%;">
				<view style="height: 100%;width: 100%;position: relative;">
					<image src="/static/image/my/default/kong.svg" style="height: 100%;width: 100%;"></image>
					<view class="state-text">欸？你怎么没有支援记录呢？</view>
				</view>
			</view>

			<view class="button" @click="gohome"><view class="button-text">去支援</view></view>
		</view>

		<view v-if="size >= 1">
			<view v-for="(item, index) in lover" :key="index">
				<view class="timebox">{{ item.time }}</view>
				<view class="box">
					<!-- 左侧图片区域 -->
					<view class="left">
						<view style="width: 100%; height: 200rpx; margin-top: 25rpx;" v-for="(item1, index1) in item.fileID.slice(0, 1)" :key="index1">
							<image :src="item1" style="width: 100%;height: 100%;border-radius: 10rpx;"></image>
						</view>
					</view>

					<!-- 右侧信息区域 -->
					<view class="right">
						<view class="right-title">{{ item.title }}</view>
						<view class="righ-introduction">{{ item.intro }}</view>
						<view style="height: 80rpx;width: 100%;">
							<view style="height: 100%;width: 253rpx;float: left;">
								<view style="width: 100%;line-height: 80rpx;color: #f62c39;text-align: center;">
									<text>
										支持了
										<text style="font-weight: bold;">{{ item.value }}</text>
										个
									</text>
								</view>
							</view>
							<view class="buttom" @click="notices(item.listid)"><view class="buttom-text">去查看 ></view></view>
					</view>
						</view>
				</view>
			</view>

			<!-- 底部提示 -->
			<view style="height: 100rpx;width: 100%;margin-top: 30rpx;">
				<u-divider bg-color="#f3f3f3">{{ divider }}</u-divider>
			</view>
		</view>
	</view>
</template>

<script>
import SOtime from '@/utils/SOtime.js';
const app = getApp({
	allowDefault: true
});
export default {
	data() {
		return {
			userInfo:'',
			wx_openid: '', //微信id
			pageNum: 1,
			pageSize: 10,
			size: '',
			lover: [],
			divider: '我可是有底线的'
		};
	},
	onLoad() {
		console.log(app.globalData.userInfo)
		this.userInfo = app.globalData.userInfo.nickName;
		uni.showLoading({
			title: '加载中'
		});
		var that = this;
		if (this.userInfo) {
			this.wx_openid = app.globalData.userInfo.wx_openid;
			console.log(this.wx_openid);
			this.getonto();
		} else {
			console.log('未登陆');
			uni.navigateBack({
				
			})
			uni.showToast({
				title:'请先登录',
				 duration: 2000,
				 icon:'none'
			})
		}
	},
	onPullDownRefresh() {
		uni.showLoading({
			title: '加载中'
		});
		console.log('开始刷新');
		this.pageNum = 1;
		this.getonto();
	},
	onReachBottom() {
		console.log('到底了');
		uni.showLoading({
			title: '加载中'
		});
		this.pageNum = this.pageNum + 1;
		console.log('接下来需要请求的页面' + this.pageNum);
		this.getonto1();
	},
	methods: {
		getonto() {
			var _this = this;
			console.log('执行getonto函数');
			uniCloud.callFunction({
				name: 'get-onto',
				data: {
					wx_openid: this.wx_openid, //传入微信id
					pageNum: this.pageNum,
					pageSize: this.pageSize
				},
				success(res) {
					let data = res.result.data;
					data.forEach((item, index) => {
						item.time = SOtime.time1(item.time);
					});
					console.log('修改后的时间');
					console.log(data);
					_this.lover = data;
					_this.size = data.length;
					console.log(_this.lover);
					uni.hideLoading();
				},
				fail(e) {
					console.log(e);
				}
			});
			uni.stopPullDownRefresh();
		},
		getonto1() {
			var _this = this;
			console.log('执行getonto函数');
			uniCloud.callFunction({
				name: 'get-onto',
				data: {
					wx_openid: this.wx_openid, //传入微信id
					pageNum: this.pageNum,
					pageSize: this.pageSize
				},
				success(res) {
					let data = res.result.data;
					data.forEach((item, index) => {
						item.time = SOtime.time1(item.time);
					});
					console.log('修改后的时间');
					console.log(data);
					_this.lover = _this.lover.concat(data);
					_this.size = data.length + 1;
					console.log(_this.lover);
					uni.hideLoading();
				},
				fail(e) {
					console.log(e);
				}
			});
			uni.stopPullDownRefresh();
		},
		notices: function(idParam) {
			console.log('点击的页面id为' + idParam);
			this.$navTo.togo('/pages/index/detaill', { id: idParam });
		},
		gohome() {
			console.log('去支援');
			uni.switchTab({
				url: '/pages/index/index'
			});
		}
	}
};
</script>

<style>
page {
	background-color: #f3f3f3;
}
</style>

<style lang="scss">
.timebox {
	width: 700rpx;
	margin-left: 25rpx;
	margin-top: 25rpx;
	text-align: left;
	color: #3e3e3e;
}

.box {
	width: 700rpx;
	height: 250rpx;
	margin-left: 25rpx;
	border-radius: 10px;
	background-color: #fff;
}

.left {
	float: left;
	margin-left: 30rpx;
	width: 200rpx;
	height: 100%;
}

.right {
	float: left;
	margin-left: 25rpx;
	width: 445rpx;
	height: 100%;
}

.right-title {
	margin-top: 30rpx;
	width: 400rpx;
	font-size: 30rpx;
	font-family: Microsoft YaHei;
	font-weight: bold;
	color: #000;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

.righ-introduction {
	width: 406rpx;
	height: 60rpx;
	margin-top: 22rpx;
	font-size: 25rpx;
	font-family: Microsoft YaHei;
	color: #686868;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

// 查看按钮
.buttom {
	margin-top: 27rpx;
	margin-right: 25rpx;
	float: right;
	width: 102rpx;
	height: 37rpx;
	background: #ffffff;
	border: 2rpx solid #2abe5b;
	border-radius: 17rpx;
}

.buttom-text {
	width: 100%;
	font-size: 20rpx;
	text-align: center;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #4d4d4d;
}

.state-text {
	position: absolute;
	text-align: center;
	bottom: 0;
	width: 100%;
	height: 50rpx;
	line-height: 50rpx;
	font-size: 30rpx;
	font-weight: bold;
}

.button {
	position: absolute;
	left: 50%;
	bottom: 150rpx;
	margin-left: -100rpx;
	width: 200rpx;
	height: 60rpx;
	border: 1px solid #000000;
	border-radius: 15rpx;
}

.button-text {
	text-align: center;
	width: 100%;
	font-size: 30rpx;
	line-height: 60rpx;
	color: #000000;
}
</style>
