<template>
	<view class="content">
		<view class="head-bg">
			<view class="head-img">
				<image :src="userInfo.avatarUrl" v-if="userInfo.nickName" style="height: 100%;width: 100%;border-radius: 50%;"></image>
				<image :src="img" v-if="!userInfo.nickName" style="height: 100%;width: 100%;"></image>
			</view>
			<view class="head-title">
				<text v-show="!userInfo.nickName">请先登录</text>
				<text v-show="userInfo.nickName">{{ userInfo.nickName }}</text>
			</view>
		</view>

		<view class="functionsif">
			<view class="functionsif-left" @click="left">
				<view class="left-icon"><image src="/static/image/my/left.png" style="width: 100%;height: 100%;"></image></view>
				<view class="left-title">我发起的</view>
			</view>
			<view class="functionsif-right" @click="right">
				<view class="right-icon"><image src="/static/image/my/right.png" style="height: 100%;width: 100%;"></image></view>
				<view class="right-title">我参与的</view>
			</view>
		</view>

			<view class="buttom" v-show="!userInfo.nickName" @click="getUserProfile"><view class="buttom-text">一键登录</view></view>

		<!-- <image class="logo" v-if="userInfo.nickName" :src="userInfo.avatarUrl"></image> -->
		<!-- <view class="text-area"><view class="" v-else @click="getUserProfile">授权登陆</view></view> -->
	</view>
</template>

<script>
import logo from '@/static/image/logo/logo.png';
const app = getApp({
	allowDefault: true
});
export default {
	data() {
		return {
			userInfo: undefined,
			img: logo
		};
	},
	onLoad() {
		var that = this;

		if (app.globalData.token) {
			console.log('已登陆');
			that.userInfo = app.globalData.userInfo;
		} else {
			console.log('未登陆，等待');
			app.globalData.canIUseGetUserProfile = res => {
				console.log('已登陆');
				that.userInfo = app.globalData.userInfo;
			};
		}
	},
	methods: {
		left(){
			uni.navigateTo({
				url:'/pages/my/Initiate'
			})
		},
		right(){
			uni.navigateTo({
				url:'/pages/my/onto'
			})
		},
		getUserProfile: function() {
			var that = this;
			uni.getUserProfile({
				desc: '用户信息，拿来吧你！',
				lang: 'zh_CN',
				success: res => {
					console.log(res);
					that.$cloudApi.call({
						name: 'member-update',
						data: res.userInfo,
						success: res => {
							console.log('更新结果', res);
							app.globalData.userInfo = res;
							that.userInfo = res;
						}
					});
				}
			});
		}
	}
};
</script>

<style>
.content {
	width: 100%;
	height: 100vh;
	background-color: #efefef;
}

/* .logo {
	height: 200rpx;
	width: 200rpx;
	margin-top: 200rpx;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 50rpx;
}

.text-area {
	display: flex;
	justify-content: center;
}

.title {
	font-size: 36rpx;
	color: #8f8f94;
}
 */

.head-bg {
	position: relative;
	width: 100%;
	height: 463rpx;
	background-image: url(../../static/image/my/head.png);
	background-size: 100%;
}

.head-img {
	position: absolute;
	top: 50rpx;
	left: 50%;
	margin-left: -100rpx;
	height: 200rpx;
	width: 200rpx;
}

.head-title {
	position: absolute;
	text-align: center;
	top: 280rpx;
	width: 100%;
	height: 42rpx;
	font-size: 45rpx;
	font-family: Adobe Heiti Std;
	font-weight: bold;
	color: #000000;
}

.functionsif {
	position: absolute;
	left: 50%;
	width: 700rpx;
	height: 200rpx;
	margin-top: -116rpx;
	margin-left: -350rpx;
	background: #ffffff;
	box-shadow: 4rpx 5rpx 26rpx 1rpx rgba(0, 0, 0, 0.35);
	border-radius: 25rpx;
}

.functionsif-left {
	position: relative;
	float: left;
	width: 350rpx;
	height: 200rpx;
}

.functionsif-right {
	position: relative;
	float: right;
	width: 350rpx;
}

.left-icon {
	position: absolute;
	top: 42rpx;
	left: 50%;
	width: 72rpx;
	height: 83rpx;
	margin-left: -36rpx;
}

.right-icon {
	position: absolute;
	top: 42rpx;
	left: 50%;
	width: 75rpx;
	height: 83rpx;
	margin-left: -37.5rpx;
}

.left-title {
	text-align: center;
	margin-top: 142rpx;
	width: 100%;
	height: 23rpx;
	font-size: 25rpx;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #000000;
}

.right-title {
	text-align: center;
	margin-top: 142rpx;
	width: 100%;
	height: 23rpx;
	font-size: 25rpx;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #000000;
}

/* 按钮 */
.buttom {
	position: absolute;
	bottom: 450rpx;
	left: 50%;
	width: 500rpx;
	height: 80rpx;
	background: #07c160;
	margin-left: -250rpx;
	border: 1rpx solid #6b6b6b;
	border-radius: 40rpx;
}

.buttom-text {
	text-align: center;
	width: 100%;
	line-height: 80rpx;
	font-size: 35rpx;
	font-family: Adobe Heiti Std;
	font-weight: bold;
	color: #ffffff;
}
</style>
