<template>
	<view class="box">
		<!-- 头部区域 -->
		<view class="head-bg">
			<view class="logo"><image src="../../static/image/logo/logo.png" style="width: 100%;height: 100%;"></image></view>
			<view class="head">
				<view style="width: 100%;height: 100%;position: relative;">
					<view class="head-title">医疗费资助平台</view>
					<view class="head-titles">集爱心就能获得资助</view>
					<view class="head-botton"><view class="head-botton-text" @click="togo">立即求助</view></view>
				</view>
			</view>
		</view>
		<!-- 爱心收集 -->
		<view style="height: 150rpx;"></view>
		<view class="collect">
			<view class="collect-left">爱心收集</view>
			<view class="collect-right">集够一定数量的爱心即可获得平台资助</view>
		</view>
		<view class="line"></view>
		<!-- 收集中列表区域 -->
		<view class="love" v-for="(item, index) in lover" :key="index">
			<view style="width: 100%;height: 250rpx;">
				<view class="love-left">
					<view style="width: 100%;height: 200rpx;margin-top: 25rpx;" v-for="(item1, index1) in item.fileID.slice(0, 1)" :key="index1">
						<image :src="item1" style="width: 100%;height: 100%;border-radius: 10rpx;"></image>
					</view>
				</view>

				<view class="love-right">
					<view class="right-title">{{ item.title }}</view>
					<view class="righ-introduction">{{ item.intro }}</view>

					<view style="width: 100%;height: 80rpx;">
						<!-- 目标区域 -->
						<view style="height: 80rpx;width: 253rpx;float: left;">
							<!-- 已收 -->
							<view style="width: 125rpx;height: 100%;float: left;">
								<table style="width: 100%;height: 100%;text-align: center;color: #595858;padding-top: 21rpx;">
									<tr><td style="font-size: 20rpx;">已&nbsp;&nbsp;&nbsp;收</td></tr>
									<tr><td style="height: 9rpx"></td></tr>
									<tr>
										<td style="font-size: 15rpx;">
											<text style="color: #000;width: 100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{{ item.finish }}</text>
											爱心
										</td>
									</tr>
								</table>
							</view>
							<!-- 已收END -->

							<!-- 分割线 -->
							<view style="width: 3rpx;height: 50rpx;background: #757575;border-radius: 2rpx;float: left;margin-top: 20rpx;"></view>
							<!-- 目标 -->
							<view style="width: 125rpx;height: 100%;float: left;">
								<table style="width: 100%;height: 100%;text-align: center;color: #595858;padding-top: 21rpx;">
									<tr><td style="font-size: 20rpx;">目&nbsp;&nbsp;&nbsp;标</td></tr>
									<tr><td style="height: 9rpx"></td></tr>
									<tr>
										<td style="font-size: 15rpx;">
											<text style="color: #000;width: 100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{{ item.targets }}</text>
											爱心
										</td>
									</tr>
								</table>
							</view>
							<!-- 目标END -->
							<!-- 目标区域END -->
						</view>
						<!-- 进入按钮 -->
						<view class="buttom"><view class="button-text" @click="notices(item._id)">送爱心 ></view></view>
						<!-- 进入按钮END -->
					</view>
				</view>
			</view>
			<!-- 分割线 -->
			<view style="width: 100%;height: 3rpx;"><view class="line"></view></view>
		</view>

		<!-- 查看更多 -->
		<view class="more"><view class="more-text" @click="list">查看更多 >></view></view>
		<!-- 查看更多END -->
		<view style="height: 60rpx;"></view>

		<view class="swiper" @click="navtopro"><u-swiper :list="swiper" :effect3d="false" bg-color="#fff" @click="navtopro"></u-swiper></view>

		<!-- 平台须知 -->
		<view class="notices">
			<view class="collect"><view class="notices-text">为什么选择我们?</view></view>
			<view class="notices-title">求助人只需收集爱心，资金由平台资助</view>
			<view class="notices-title">参与者只需送爱心，无需捐赠资金</view>
			<view class="notices-title">筹款更简单，更绿色，更高效</view>
			<view class="line" style="margin-top: 15rpx;"></view>
		</view>

		<view style="height: 40rpx;"></view>
	</view>
</template>

<script>
const app = getApp({
	allowDefault: true
});
export default {
	data() {
		return {
			userInfo: '',
			state: 1,
			states: true,
			static: true,
			swiper: [
				{
					image: '../../../static/image/index/swiper1.png'
				}
			],
			lover: [],
			bar: '0'
		};
	},
	onLoad() {
		this.Inquire();
		// this.swiper = home.swiper();
	},
	onPullDownRefresh() {
		uni.showLoading({
			title: '加载中'
		});
		console.log('开始刷新');
		this.Inquire();
	},
	methods: {
		navtopro() {
			uni.navigateToMiniProgram({
				appId: 'wx27fda63830219aa1',
				path: '',
				success() {
					console.log('打开成功');
				},
				fail(e) {
					console.log(e);
				}
			});
		},
		Inquire() {
			var _this = this;
			console.log('开始查询');
			uniCloud.callFunction({
				name: 'Inquire',
				// 传输的数据
				data: {
					pageNum: 1,
					pageSize: 3,
					state: this.state,
					states: this.states
				},
				// 成功
				success(res) {
					_this.lover = res.result.data;
					console.log(_this.lover);
					uni.hideLoading();
				},
				// 失败
				fail(e) {
					console.log(e);
				}
			});
			uni.stopPullDownRefresh();
		},
		togo: function() {
			uni.switchTab({
				url: '/pages/Initiate/Initiate'
			});
		},
		list: function() {
			console.log('进入列表页面');
			uni.navigateTo({
				url: 'list'
			});
		},
		notices: function(idParam) {
			console.log('点击的页面id为' + idParam);
			this.$navTo.togo('/pages/index/detaill', { id: idParam });
			// uni.navigateTo({
			// 	url:'../notices/notices'
			// })
		}
	}
};
</script>

<style>
::-webkit-scrollbar * {
	height: 0;
	width: 0;
}

.box {
	width: 100%;
	height: 100vh;
}

.head-bg {
	position: relative;
	width: 100%;
	height: 295rpx;
	background: #31d368;
	border-radius: 0px 0px 150rpx 150rpx;
}

.logo {
	position: absolute;
	top: 13rpx;
	left: 50%;
	margin-left: -39rpx;
	width: 78rpx;
	height: 84rpx;
}

.head {
	position: absolute;
	top: 117rpx;
	left: 25rpx;
	width: 700rpx;
	height: 300rpx;
	background-image: url(../../static/image/index/head.png);
	background-size: 700rpx 300rpx;
	box-shadow: 0px 10rpx 29rpx 3rpx rgba(0, 0, 0, 0.35);
	border-radius: 25rpx;
}

.head-title {
	position: absolute;
	top: 50rpx;
	text-align: center;
	width: 700rpx;
	height: 44rpx;
	font-size: 45rpx;
	font-family: Microsoft YaHei;
	font-weight: 400;
	color: #ffffff;
}

.head-titles {
	position: absolute;
	text-align: center;
	top: 133rpx;
	width: 700rpx;
	height: 24rpx;
	font-size: 25rpx;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #ffffff;
}

.head-botton {
	position: absolute;
	left: 190rpx;
	bottom: 50rpx;
	width: 320rpx;
	height: 64rpx;
	background: #dee0e6;
	box-shadow: 7rpx 8rpx 21rpx 0px rgba(0, 0, 0, 0.35);
	border-radius: 32rpx;
}

.head-botton-text {
	text-align: center;
	padding-top: 15rpx;
	width: 321rpx;
	height: 64rpx;
	font-size: 32rpx;
	font-family: Microsoft YaHei;
	font-weight: 400;
	color: #219648;
}

/* 爱心收集 */
.collect {
	width: 100%;
	height: 80rpx;
}

.collect-left {
	padding-top: 21rpx;
	margin-left: 30rpx;
	width: auto;
	height: 38rpx;
	font-size: 40rpx;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #000000;
}

.collect-right {
	float: right;
	margin-right: 30rpx;
	width: auto;
	height: 20rpx;
	font-size: 20rpx;
	font-family: Microsoft YaHei;
	font-weight: 400;
	color: #656363;
}

/* 分割线 */
.line {
	width: 100%;
	height: 3rpx;
	background: #efefef;
}

.line1 {
	margin-left: 25rpx;
	width: 700rpx;
	height: 3rpx;
	background: #efefef;
	border-radius: 2rpx;
}

/* 列表循环 */
.love {
	margin-left: 25rpx;
	width: 700rpx;
	height: 250rpx;
	border-radius: 10px;
}

.love-left {
	float: left;
	margin-left: 30rpx;
	width: 200rpx;
	height: 100%;
}

.love-right {
	float: left;
	margin-left: 25rpx;
	width: 445rpx;
	height: 100%;
}

.right-title {
	margin-top: 30rpx;
	width: 400rpx;
	font-size: 30rpx;
	font-family: Microsoft YaHei;
	font-weight: bold;
	color: #000;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

.righ-introduction {
	width: 412rpx;
	height: 43rpx;
	margin-top: 22rpx;
	font-size: 20rpx;
	font-family: Microsoft YaHei;
	color: #686868;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

/* 进入按钮 */
.buttom {
	margin-top: 27rpx;
	margin-right: 19rpx;
	float: right;
	width: 102rpx;
	height: 37rpx;
	background: #ffffff;
	border: 2rpx solid #2abe5b;
	border-radius: 17rpx;
}

.button-text {
	width: 100%;
	line-height: 37rpx;
	font-size: 20rpx;
	text-align: center;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #4d4d4d;
}

/* 查看更多 */
.more {
	position: absolute;
	left: 50%;
	margin-left: -100rpx;
	width: 200rpx;
	height: 30rpx;
	background: #efefef;
	border-radius: 0px 0px 15rpx 15rpx;
}

.more-text {
	width: 200rpx;
	height: 19rpx;
	color: #595858;
	font-size: 20rpx;
	text-align: center;
	font-weight: normal;
	font-family: Adobe Heiti Std;
}

/* 轮播图 */
.swiper {
	margin-left: 25rpx;
	width: 700rpx;
	height: 292rpx;
}

.notices {
	width: 90%;
	height: auto;
	margin-left: 5%;
	background-color: #f3f3f3;
	border-radius: 25rpx;
}

.notices-title {
	margin-top: 15rpx;
	text-indent: 2em;
	text-align: center;
	width: 100%;
	font-size: 25rpx;
	font-family: Microsoft YaHei;
	color: #000000;
}

.notices-text {
	padding-top: 21rpx;
	text-align: center;
	width: 100%;
	height: 38rpx;
	font-size: 30rpx;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #000000;
}
</style>
