<template>
	<view class="box">
		<!-- 列表 -->
		<view class="love" v-for="(item, index) in lover" :key="index">
			<view style="width: 100%;height: 250rpx;">
				<!-- 图片区域 -->
				<view class="love-left">
					<view style="width: 100%; height: 200rpx; margin-top: 25rpx;" v-for="(item1, index1) in item.fileID.slice(0, 1)" :key="index1">
						<image :src="item1" style="width: 100%;height: 100%;border-radius: 10rpx;"></image>
					</view>
				</view>

				<!-- 信息区域 -->
				<view class="love-right">
					<view class="right-title">{{ item.title }}</view>
					<view class="righ-introduction">{{ item.intro }}</view>
					<!-- <view style="width: 400rpx; margin-left: 10rpx;">
						<u-line-progress active-color="#31d368" :percent="((tem.finish / item.target) * 100)" :striped-active="true" :striped="true" :show-percent="false" height="15"></u-line-progress>
					</view> -->

					<view style="width: 100%;height: 80rpx;">
						<!-- 目标区域 -->
						<view style="height: 80rpx;width: 253rpx;float: left;">
							<!-- 已收 -->
							<view style="width: 125rpx;height: 100%;float: left;">
								<table style="width: 100%;height: 100%;text-align: center;color: #595858;padding-top: 21rpx;">
									<tr><td style="font-size: 20rpx;">已&nbsp;&nbsp;&nbsp;收</td></tr>
									<tr><td style="height: 9rpx"></td></tr>
									<tr>
										<td style="font-size: 15rpx;">
											<text style="color: #000;width: 100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{{ item.finish }}</text>
											爱心
										</td>
									</tr>
								</table>
							</view>
							<!-- 已收end -->
							<!-- 分割线 -->
							<view style="width: 3rpx;height: 50rpx;background: #757575;border-radius: 2rpx;float: left;margin-top: 20rpx;"></view>
							<!-- 目标 -->
							<view style="width: 125rpx;height: 100%;float: left;">
								<table style="width: 100%;height: 100%;text-align: center;color: #595858;padding-top: 21rpx;">
									<tr><td style="font-size: 20rpx;">目&nbsp;&nbsp;&nbsp;标</td></tr>
									<tr><td style="height: 9rpx"></td></tr>
									<tr>
										<td style="font-size: 15rpx;">
											<text style="color: #000;width: 100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{{ item.target }}</text>
											爱心
										</td>
									</tr>
								</table>
							</view>
							<!-- 目标END -->
						</view>
						<!-- 进入按钮 -->
						<view class="buttom" @click="notices(item._id)"><view class="button-text">送爱心 ></view></view>
						<!-- 进入按钮END -->
					</view>
				</view>
			</view>
			<!-- 分割线 -->
			<view style="width: 100%;height: 3rpx;"><view class="line"></view></view>
		</view>
		<!-- 列表END -->
		<!-- 到底了 -->
		<view style="height: 100rpx;width: 100%;margin-top: 30rpx;">
			<u-divider>{{ divider }}</u-divider>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			state: 1,
			lover: [],
			states: true,
			divider: '就这么多了',
			pageNum: 1, //页码
			pageSize: 10 //每页数据
		};
	},
	onLoad() {
		uni.showLoading({
			title: '加载中'
		});
		this.Inquire();
	},
	onPullDownRefresh() {
		uni.showLoading({
			title: '加载中'
		});
		console.log('开始刷新');
		this.pageNum = 1;
		this.Inquire();
	},
	onReachBottom() {
		console.log('到底了');
		uni.showLoading({
			title: '加载中'
		});
		this.pageNum = this.pageNum + 1;
		console.log('接下来需要请求的页码' + this.pageNum);
		this.getInquire();
	},
	methods: {
		Inquire() {
			var _this = this;
			console.log('开始查询');
			uniCloud.callFunction({
				name: 'Inquire',
				// 传输的数据
				data: {
					pageNum: this.pageNum,
					pageSize: this.pageSize,
					state: this.state,
					states: this.states
				},
				// 成功
				success(res) {
					_this.lover = res.result.data;
					console.log(_this.lover);
					uni.hideLoading();
				},
				// 失败
				fail(e) {
					console.log(e);
				}
			});
			uni.stopPullDownRefresh();
		},
		getInquire() {
			var _this = this;
			console.log('开始查询');
			uniCloud.callFunction({
				name: 'Inquire',
				// 传输的数据
				data: {
					pageNum: this.pageNum,
					pageSize: this.pageSize,
					state: this.state,
					states: this.states
				},
				// 成功
				success(res) {
					_this.lover = _this.lover.concat(res.result.data);
					console.log(_this.lover);
					uni.hideLoading();
				},
				// 失败
				fail(e) {
					console.log(e);
				}
			});
			uni.stopPullDownRefresh();
		},
		notices: function(idParam) {
			console.log('点击的页面id为' + idParam);
			this.$navTo.togo('/pages/index/detaill', { id: idParam });
			// uni.navigateTo({
			// 	url:'../notices/notices'
			// })
		}
	}
};
</script>

<style lang="scss">
.box {
	width: 100%;
	height: auto;
}

// 分割线
.line {
	width: 100%;
	height: 3rpx;
	background: #efefef;
}

/* 列表循环 */
.love {
	margin-left: 25rpx;
	width: 700rpx;
	height: 250rpx;
	border-radius: 10px;
}

.love-left {
	float: left;
	margin-left: 30rpx;
	width: 200rpx;
	height: 100%;
}

.love-right {
	float: left;
	margin-left: 25rpx;
	width: 445rpx;
	height: 100%;
}

.right-title {
	margin-top: 30rpx;
	width: 400rpx;
	font-size: 30rpx;
	font-family: Microsoft YaHei;
	font-weight: bold;
	color: #000;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

.righ-introduction {
	width: 412rpx;
	height: 43rpx;
	margin-top: 22rpx;
	font-size: 20rpx;
	font-family: Microsoft YaHei;
	color: #686868;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

/* 进入按钮 */
.buttom {
	margin-top: 27rpx;
	margin-right: 19rpx;
	float: right;
	width: 102rpx;
	height: 37rpx;
	background: #ffffff;
	border: 2rpx solid #2abe5b;
	border-radius: 17rpx;
}

.button-text {
	width: 100%;
	font-size: 20rpx;
	text-align: center;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #4d4d4d;
}

/* 查看更多 */
.more {
	position: absolute;
	left: 50%;
	margin-left: -100rpx;
	width: 200rpx;
	height: 30rpx;
	background: #efefef;
	border-radius: 0px 0px 15rpx 15rpx;
}

.more-text {
	width: 200rpx;
	height: 19rpx;
	color: #595858;
	font-size: 20rpx;
	text-align: center;
	font-weight: normal;
	font-family: Adobe Heiti Std;
}
</style>
