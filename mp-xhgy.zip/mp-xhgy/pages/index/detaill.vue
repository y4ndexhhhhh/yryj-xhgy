<template>
	<view class="box">
		<view style="width: 100%;height: auto;">
			<!-- 顶部提示 -->
			<u-top-tips ref="uTips"></u-top-tips>

			<view class="title">{{ detaills.title }}</view>
			
			<!-- 轮播图 -->
			<view class="swiper"><u-swiper :list="detaills.fileID" mode="rect" height="500"></u-swiper></view>
			
			<view class="avatar">
				<view class="avatar-img">
					<u-avatar :src="avatarurl" size="mini"></u-avatar>
				</view>
				<view class="avatar-name">由<text style="font-weight: bold;margin-left: 10rpx;margin-right: 10rpx;">{{ detaills.name }}</text>发起</view>
			</view>

			<!-- 项目详情 -->
			<view class="collect">
				<view class="content-title">项目进度</view>
				<view class="line"></view>
				<view class="spaper">
					<view style="width: 100%;height: 220rpx;">
						<view style="width: 100%;line-height: 50rpx;height: 50rpx;">
							<view style="width: 20%;height: 100%;text-align: center;font-weight: bold;float: left;text-align: left;">已筹</view>
							<view style="width: 80%;height: 100%;text-align: center;font-weight: bold;float: right;">{{ detaills.finish }}个</view>
						</view>
						<view style="width: 100%;line-height: 50rpx;height: 50rpx;">
							<view style="width: 20%;height: 100%;text-align: center;font-weight: bold;float: left;text-align: left;">目标</view>
							<view style="width: 80%;height: 100%;text-align: center;font-weight: bold;float: right;">{{ detaills.target }}个</view>
						</view>
						<view style="width: 100%;line-height: 50rpx;height: 50rpx;">
							<view style="width: 20%;height: 100%;text-align: center;font-weight: bold;float: left;text-align: left;">进度</view>
							<view style="width: 80%;height: 100%;float: right;">
								<u-line-progress active-color="#31D368" :percent="detaills.progress" :striped-active="true" :striped="true" :show-percent="false"></u-line-progress>
							</view>
						</view>
						<view style="width: 100%;line-height: 50rpx;text-align: center;margin-top: 20rpx;">
							集够目标爱心，患者医疗费由平台提供资助
						</view>
					</view>
				</view>
			</view>

			<!-- 信息栏目 -->
			<view class="collect">
				<view class="content-title">项目详情</view>
				<view class="line"></view>
				<view class="content">{{ detaills.intro }}</view>
			</view>
			
			<view class="collect">
				<view class="content-title">平台已核实</view>
				<view class="line"></view>
				<view class="content1"><u-icon name="checkmark-circle" color="#31D368"></u-icon><text style="margin-left: 10rpx;">身份信息已核实</text></view>
				<view class="content1"><u-icon name="checkmark-circle" color="#31D368"></u-icon><text style="margin-left: 10rpx;">病例真实性以核实</text></view>
				<view class="content1"><u-icon name="checkmark-circle" color="#31D368"></u-icon><text style="margin-left: 10rpx;">治疗费已核实</text></view>
			</view>

			<!-- <view style="width: 90%;margin-top: 50rpx;margin-left: 5%;background-color: #FFFFFF;border-radius: 15rpx;">
				<view style="width: 100%;text-align: center;line-height: 80rpx;font-weight: bold;color: #9c9c9c;">由亿人一家赞助</view>
				<view style="width: 60%;height: 3rpx;background: #efefef;margin-left: 20%;"></view>
				<view style="height: 20rpx;"></view>
			</view> -->
			<view style="height: 150rpx;width: 100%;"></view>

			<!-- 底部 -->
			<view class="boxInfo-mine">
				<view style="width: 30%;height: 120rpx;">
					<u-grid col="1" :border="false" @click="share">
						<u-grid-item bg-color="#FFFFFF">
							<u-icon name="share" :size="40"></u-icon>
							<view class="grid-text">转发</view>
						</u-grid-item>
					</u-grid>
				</view>
				
				<!-- 弹窗 -->
				<u-popup v-model="modeal" mode="center" border-radius="15" width="70%" height="15%">
					<view class="popup">
						<view class="popup-title">送爱心</view>
						<view class="line"></view>
						<view style="height: 80rpx;width: 240rpx;position: absolute;left: 50%;margin-left: -120rpx;padding-top: 15rpx;">
							<u-number-box v-model="value" @change="valChange" :min="10" :max="10" :input-height="80" :input-width="120"></u-number-box>
						</view>
					</view>
					<view v-if="userInfo">
						<view class="popup-button" @click="detection"><view class="button-text">确认支援</view></view>
					</view>
					<view v-else>
						<view class="popup-button" @click="getUserProfile"><view class="button-text">确认支援</view></view>
					</view>
				</u-popup>
				<view v-if="hearts > 0" class="buttom" @click="showmodeal"><button class="buttom-right">送爱心</button></view>
				<view v-else class="buttom" @click="addhearts"><button class="buttom-right">观看视频获取爱心</button></view>
				<!-- <view class="buttom" @click="getUserProfile" v-else><button class="buttom-right">立即支援</button></view> -->
			</view>
		</view>
	</view>
</template>

<script>
import SOtime from '@/utils/SOtime.js';
import AD from '@/utils/ad.js';
const app = getApp({
	allowDefault: true
});
export default {
	data() {
		return {
			id: 0,
			hearts: 0,
			userInfo: '',
			avatarurl:'',
			value: 10, //步进器
			modeal: false, //模态框
			wx_openid: '', //微信id
			wx_openid1:'',
			time: '', //时间戳
			stime: '',
			Stime: '',
			show: false,
			detaills: {
				name:'',
				title: '加载中......', //标题
				intro: '加载中......', //简介
				fileID: [], //轮播图
				finish: '0', //以获取
				target: '0', //目标
				progress: 0 //项目进度
			},
			finish: ''
		};
	},
	onLoad(e) {
		uni.showLoading({
			title: '加载中'
		});
		let _this = this;
		AD.rewarded.load('adunit-a59c63146b16c309', () => {
		    this.hearts = 10;
			uni.showToast({
				icon:'none',
				title:'获得10个爱心奖励'
			})
		});
		_this.id = e.id;
		console.log(_this.id);
		this.detail();
		this.gettime();
		// this.getavatarurl();
	},
	onPullDownRefresh() {
		uni.showLoading({
			title: '加载中'
		});
		console.log('开始刷新');
		this.detail();
		this.gettime();
		this.getavatarurl();
	},
	methods: {
		addhearts: function(){
			AD.rewarded.show();
		},
		getUserProfile: function() {
			uni.showLoading({
				title: '加载中'
			});
			var that = this;
			uni.getUserProfile({
				desc: '用户信息，拿来吧你！',
				lang: 'zh_CN',
				success: res => {
					console.log(res);
					that.$cloudApi.call({
						name: 'member-update',
						data: res.userInfo,
						success: res => {
							console.log('更新结果', res);
							app.globalData.userInfo = res;
							that.userInfo = res;
							uni.hideLoading();
						}
					});
				}
			});
		},
		valChange(e) {
			console.log('你选择的值为: ' + e.value);
		},
		gettime() {
			uni.showLoading({
				title:'请稍后'
			})
			let _this = this;
			this.wx_openid1 = app.globalData.userInfo.wx_openid;
			console.log(this.wx_openid);
			console.log('您已登录');
			console.log('开始查询');
			uniCloud.callFunction({
				name: 'detaile-time',
				data: {
					wx_openid: this.wx_openid1,
					listid: this.id
				},
				success(res) {
					console.log(res.result.data);
					var obj = res.result.data[0];
					for (var index in obj) {
						console.log('key=' + index, 'value=' + obj[index]);
						if (index == 'time') {
							this.stime = obj[index];
						}
					}
					_this.Stime = SOtime.time(this.stime);
					console.log('相隔的时间是' + _this.Stime);
					// if (_this.Stime >= 24) {
					// 	_this.show = true;
					// }
					// if (_this.Stime < 24) {
					// 	_this.show = false;
					// }
					if(_this.hearts>0){
						_this.show = true;
					}else{
						_this.show = false;
					}
					console.log('是否展示' + _this.show);
					uni.hideLoading()
				},
				fail(e) {
					console.log(e);
				}
			});
		},
		getavatarurl(){
			// let _this = this;
			console.log('开始查询项目用户的头像')
			console.log('项目发起人的id' + this.wx_openid)
			var _this = this;
			uniCloud.callFunction({
				name:'getavatarurl',
				data:{
					wx_openid:this.wx_openid
				},
				success(res) {
					console.log(res.result)
					var obj = res.result.data[0];
					for (var index in obj) {
						console.log('key=' + index, 'value=' + obj[index]);
						if (index == 'avatarUrl') {
							_this.avatarurl = obj[index];
						}
					}
					console.log(_this)
					console.log(_this.avatarurl)
					uni.hideLoading();
				},
				fail(e) {
					console.log(e)
				}
			})
		},
		share() {
			this.$refs.uTips.show({
				title: '请点击右上角的“···”进行分享',
				type: 'error',
				duration: '2300'
			});
		},
		detail() {
			let _this = this; //指向
			console.log('开始查询');
			uniCloud.callFunction({
				name: 'datail',
				// 传输的数据
				data: {
					_id: this.id
				},
				// 成功
				success(res) {
					console.log(res)
					var obj = res.result.data[0];
					for (var index in obj) {
						console.log('key=' + index, 'value=' + obj[index]);
						if (index == 'title') {
							_this.detaills.title = obj[index];
						}
						if (index == 'intro') {
							_this.detaills.intro = obj[index];
						}
						if (index == 'fileID') {
							console.log(_this.detaills);
							_this.detaills.fileID = obj[index];
						}
						if (index == 'finish') {
							_this.detaills.finish = obj[index];
						}
						if (index == 'targets') {
							_this.detaills.target = obj[index];
						}
						if (index == 'name') {
							_this.detaills.name = obj[index];
						}
						if (index == 'wx_openid') {
							_this.wx_openid = obj[index];
						}
					}
					console.log('微信id是' +  _this.wx_openid)
					var r1 = _this.detaills.target; //目标金额
					var r2 = _this.detaills.finish; //以达到的金额
					var r3 = (r2 / r1) * 100;
					_this.detaills.progress = Math.round(r3); //进度
					_this.getavatarurl()
					console.log(_this.detaills.progress);
				},
				// 失败
				fail(e) {
					console.log(e);
				}
			});
			uni.stopPullDownRefresh();
		},
		// 点击支援
		detection() {
			this.time = new Date().getTime();
			this.updata();
		},
		// 运行提交函数进行更新
		updata() {
			var r1 = this.detaills.finish;
			var r2 = this.value;
			this.finish = r1 + r2;
			console.log('开始更新数据');
			let _this = this;
			uni.showLoading({
				title: '请稍后'
			});
			uniCloud.callFunction({
				name: 'updata-finish',
				data: {
					_id: _this.id,
					finish: _this.finish
				},
				success(res) {
					console.log(res);
					_this.hearts = 0;
					_this.onto();
				},
				fail(e) {
					console.log(e);
				}
			});
		},
		// 提交参与记录
		onto() {
			let _this = this;
			console.log('开始提交参与记录');
			this.modeal = false;
			uniCloud.callFunction({
				name: 'data-onto',
				data: {
					time: this.time, //当前时间戳
					wx_openid: this.wx_openid1, //微信id
					listid: this.id, //项目id
					title: this.detaills.title, //项目标题
					intro: this.detaills.intro, //项目内容
					fileID: this.detaills.fileID, //项目图片
					value: this.value //赞助的数量
				},
				success(res) {
					console.log(res);
					uni.hideLoading();
					uni.showToast({
						title: '谢谢您的支援',
						duration: 2000
					});
					console.log('开始刷新');
					_this.f5();
				},
				fail(e) {
					console.log(e);
				}
			});
		},
		f5() {
			uni.showLoading({
				title: '加载中'
			});
			console.log('开始刷新');
			this.detail();
			this.gettime();
			this.getavatarurl();
		},
		showmodeal() {
			this.modeal = true;
			this.userInfo = app.globalData.userInfo.nickName;
			console.log( '用户信息' + this.userInfo)
		}
	}
};
</script>

<style>
page {
	background-color: #f3f3f3;
}
</style>

<style lang="scss">
.box {
	width: 750rpx;
	// height: 100vh;
	// background-color: #f3f3f3;
}

.title {
	width: 650rpx;
	line-height: 100rpx;
	padding-top: 30rpx;
	margin-left: 50rpx;
	font-size: 45rpx;
	font-weight: bold;
}

.avatar {
	width: 90%;
	height: 90rpx;
	margin-left: 5%;
	margin-top: 25rpx;
	background-color: #fff;
	border-radius: 15rpx;
}

.avatar-img {
	float: left;
	width: 80rpx;
	height: 80rpx;
	margin-top: 10rpx;
	margin-left: 30rpx;
}

.avatar-name {
	float: left;
	width: 50%;
	font-size: 30rpx;
	line-height: 80rpx;
	margin-left: 30rpx;
}

// 轮播图
.swiper {
	width: 92%;
	height: 500rpx;
	margin-left: 4%;
	margin-top: 25rpx;
	border-radius: 15rpx;
}

// 内容区域
.collect {
	width: 92%;
	border-radius: 15rpx;
	margin-top: 25rpx;
	margin-left: 4%;
	background: #fff;
}

.content-title {
	margin-left: 25rpx;
	line-height: 80rpx;
	font-weight: bold;
	font-size: 30rpx;
}

// 分割线
.line {
	width: 100%;
	height: 3rpx;
	background: #efefef;
}

// 正文
.content {
	width: 90%;
	height: auto;
	margin-top: 15rpx;
	margin-left: 5%;
	padding-bottom: 15rpx;
	text-indent: 2em;
	font-size: 35rpx;
	line-height: 50rpx;
}

.content1 {
	width: 90%;
	margin-top: 15rpx;
	margin-left: 5%;
	line-height: 50rpx;
	font-size: 30rpx;
}

// 进度
.spaper {
	width: 90%;
	margin-left: 5%;
	margin-top: 15rpx;
	padding-bottom: 15rpx;
}

.boxInfo-mine {
	display: flex;
	position: fixed;
	bottom: 0;
	left: 0;
	justify-content: space-between;
	width: 750rpx;
	height: 120rpx;
	background-color: #ffffff;
}

.buttom {
	width: 60%;
	height: 120rpx;
	display: flex;
	margin-right: 10%;
	justify-content: space-between;
	align-items: center;
}

.buttom-right {
	width: 100%;
	height: 90rpx;
	background-color: #f62c39;
	color: #ffffff;
	font-size: 28rpx;
	font-weight: bold;
	display: flex;
	align-items: center;
	justify-content: center;
	border-radius: 25rpx;
}

// 弹窗
.popup {
	position: relative;
	height: 70%;
	width: 90%;
	margin-left: 5%;
}

.popup-title {
	padding-top: 10rpx;
	margin-bottom: 10rpx;
	text-align: center;
	font-size: 30rpx;
	color: #000000;
}

.popup-button {
	position: absolute;
	bottom: 10rpx;
	width: 60%;
	height: 50rpx;
	margin-left: 20%;
	background-color: #f62c39;
	border-radius: 10rpx;
}

.popup-button1 {
	position: absolute;
	bottom: 10rpx;
	width: 80%;
	height: 50rpx;
	margin-left: 10%;
	background-color: #616161;
	border-radius: 10rpx;
}

.button-text {
	width: 100%;
	line-height: 50rpx;
	text-align: center;
	color: #ffffff;
}
</style>
