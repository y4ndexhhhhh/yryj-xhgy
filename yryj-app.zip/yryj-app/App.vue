<script>
var sha_1 = require("./utils/sha_1.js");
var zjSDKModule = uni.requireNativePlugin("ZjSDKModule");
// zj_11120200724056
export default {
  onLaunch: function () {
	  plus.runtime.quit = function() {
	       zjSDKModule.killAppProcess();
	   };
	 // zjSDKModule.initWithAppId('zj_11120200724056')

    var logs = uni.getStorageSync('logs') || [];
    logs.unshift(Date.now());
    uni.setStorageSync('logs', logs); // 小程序更新机制 
    // #ifdef APP-PLUS 
    plus.runtime.getProperty(plus.runtime.appid, function(widgetInfo) { 
		 const phoneType = uni.getSystemInfoSync();
		 let types = '0';
		 if(phoneType.platform == 'android'){
			  let types = '0';
		 }else{
			  let types = '1';
		 }
		let that = this;
		var data = {};
		data["version"] = widgetInfo.version;
		data["type"] = types;
		var arr = {
			"data": data
		};
		var jsonStr = JSON.stringify(arr);
		var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: 'https://app01.wysyt.com/xcxapi/'+'theme_config/update', 
        data: { 
          data: aesData 
        }, 
		method:'get',
        success: (result) => {
		   var data = result.data;
          if (data.code == '1' && data.data != '') {
			  plus.downloader.createDownload( data.data.inc_download_url, {filename:"_doc/update/"}, function(d,status){  
			      if ( status == 200 ) {
			          installWgt(d.filename); // 安装wgt包
			      } else {  
			          // 
			          plus.nativeUI.alert("下载wgt失败！");  
			      }  
			      plus.nativeUI.closeWaiting();  
			  }).start();  
          } 
        },fail(err) {
        	console.log(err)
        }
      }); 
    }); 
	function installWgt(path){
			  plus.runtime.install(path,{},()=>{  
				  plus.nativeUI.closeWaiting();  
				  plus.nativeUI.alert("应用资源更新完成！",function(){
					  plus.runtime.restart();  
				  });  
			  },(e)=>{  
				  plus.nativeUI.closeWaiting();  
				  // plus.nativeUI.alert("安装wgt文件失败["+e.code+"]："+e.message);
			  });  
	 }
    // #endif

    if (uni.canIUse('getUpdateManager')) {
      const updateManager = uni.getUpdateManager();
      updateManager.onCheckForUpdate(function (res) {
        if (res.hasUpdate) {
          // 请求完新版本信息的回调
          updateManager.onUpdateReady(function () {
            uni.showModal({
              title: '启奏陛下',
              content: '新版本已经准备好了，是否重启应用？',
              success: function (res) {
                if (res.confirm) {
                  updateManager.applyUpdate();
                }
              }
            });
          });
          updateManager.onUpdateFailed(function () 
		  {
            uni.showModal({
              // 新的版本下载失败
              title: '启奏陛下',
              content: '新版本已经上线啦，请陛下删除当前小程序，重新搜索进入哟'
            });
          });
        }
      });
    } else {
      uni.showModal({
        // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      }); 
    }
  },
  onShow: function (e) {
    let scene = e.scene;
    this.globalData.scene = scene;
  },
  globalData: {
    version_code: '2.0.0.12',
    scene: '',
    // url: "http://app.yjgj.ahbsh.top/xcxapi/",//本地
    // api_url: "http://app.yjgj.ahbsh.top/xcxapi/",//本地
   
    //线上
	api_url: "https://app01.wysyt.com/",
    url:'https://app01.wysyt.com/xcxapi/',
    //快递邮寄签名的图片路径
    autograph: '',
    //协议签名的图片路径
    autograph_signtreaty: ''
  },
  methods: {
	
  }
};

</script>
<style lang="scss" scoped>
	 
/**app.wxss**/
/* #ifdef APP-PLUS */
 /* @import url("/static/css/animate.css"); */
.container {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  padding: 200rpx 0;
  /* #ifndef APP-NVUE */  
   box-sizing: border-box;
    /* #endif */
  background: #F8F9FF;
} 

image {
/* #ifndef APP-NVUE */
 width: 100%;
  /* #endif */
 
}
/* #endif */

</style>