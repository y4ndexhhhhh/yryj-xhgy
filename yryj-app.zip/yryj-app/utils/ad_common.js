// 视频
export const adVideo = (rewardModule,modal) => {
	 let codes = false;
	rewardModule.create("zjad_241286");
	rewardModule.onZjAdLoaded((info) => {
		console.log('onZjAdLoaded event', info)
		// rewardModule.showAd()
	})
	rewardModule.onZjAdVideoCached((info) => {
		console.log('onZjAdVideoCached event', info)
		uni.hideLoading();
		rewardModule.showAd()
	})
	rewardModule.onZjAdShow((info) => {
		console.log('onZjAdShow event', info)
	})
	
	// 广告被点击
	rewardModule.onZjAdClick((info) => {
		console.log('onZjAdClick event', info)
		codes = true;
	})
	// 观看完成
	rewardModule.onZjAdReward((info) => {
		console.log('onZjAdReward event', info)
		codes = true
		// uni.showToast({
		// 	title: '激励',
		// 	duration: 2000
		// });
	})
	// 广告关闭
	rewardModule.onZjAdClose((info) => {
		console.log('onZjAdClose event', info)
		codes = true
		return codes;
	})
	// 广告错误
	rewardModule.onZjAdError((info) => {
		console.log('onZjAdError event', info)
		uni.showToast({
			title: info,
			duration: 2000
		});
	})
	uni.showLoading({
		title: '加载中'
	});
	
}

// banner
export const adBanner = (res) => {
	
	rewardModule.create("zjad_241286");
	rewardModule.onZjAdLoaded((info) => {
		console.log('onZjAdLoaded event', info)
		// rewardModule.showAd()
	})
	rewardModule.onZjAdVideoCached((info) => {
		console.log('onZjAdVideoCached event', info)
		uni.hideLoading();
		rewardModule.showAd()
	})
	rewardModule.onZjAdShow((info) => {
		console.log('onZjAdShow event', info)
	})
	rewardModule.onZjAdClick((info) => {
		console.log('onZjAdClick event', info)
	})
	rewardModule.onZjAdReward((info) => {
		console.log('onZjAdReward event', info)
		uni.showToast({
			title: '激励',
			duration: 2000
		});
	})
	rewardModule.onZjAdClose((info) => {
		console.log('onZjAdClose event', info)
	})
	rewardModule.onZjAdError((info) => {
		console.log('onZjAdError event', info)
		uni.showToast({
			title: info,
			duration: 2000
		});
	})
	uni.showLoading({
		title: '加载中'
	});
}

// 开屏
export const adIndex = (res) => {
	
	rewardModule.create("zjad_241286");
	rewardModule.onZjAdLoaded((info) => {
		console.log('onZjAdLoaded event', info)
		// rewardModule.showAd()
	})
	rewardModule.onZjAdVideoCached((info) => {
		console.log('onZjAdVideoCached event', info)
		uni.hideLoading();
		rewardModule.showAd()
	})
	rewardModule.onZjAdShow((info) => {
		console.log('onZjAdShow event', info)
	})
	rewardModule.onZjAdClick((info) => {
		console.log('onZjAdClick event', info)
	})
	rewardModule.onZjAdReward((info) => {
		console.log('onZjAdReward event', info)
		uni.showToast({
			title: '激励',
			duration: 2000
		});
	})
	rewardModule.onZjAdClose((info) => {
		console.log('onZjAdClose event', info)
	})
	rewardModule.onZjAdError((info) => {
		console.log('onZjAdError event', info)
		uni.showToast({
			title: info,
			duration: 2000
		});
	})
	uni.showLoading({
		title: '加载中'
	});
}