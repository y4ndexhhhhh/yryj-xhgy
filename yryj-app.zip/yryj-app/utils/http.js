/**
 *   封装http  请求方法
 */

const apiUrl = 'https://app01.wysyt.com/xcxapi/';
// const apiUrl = 'http://app.yjgj.ahbsh.top/xcxapi/';
export const http = (params) => {
	let portUrl = params.url;
	let re = /https/;
	if (!re.test(portUrl)) {
		portUrl = apiUrl + params.url
	}
	// console.log("request url:" + portUrl + "\t param:"+ JSON.stringify(params.data))
	return new Promise((resolve, reject) => {
		uni.getNetworkType({
			success: res => {
				let network = res.networkType;
				if (network == '4g' || network == '3g' || network == 'wifi' || network == '2g') {
					uni.request({
						url: portUrl,
						data: params.data,
						header: params.header || {
							'Content-Type': 'application/json',
							"X-Access-Token": wx.getStorageSync("token")
						},
						method: params.method || "POST", //默认post 请求  
						success: res => {
							if (res.statusCode == 200) {
								resolve(res)
							} else {
								// uni.clearStorageSync();
								uni.navigateTo({
									url: '/pages/login/login.vue'
								});
							}
							// console.log("request url:" + portUrl + "\t respond:"+ JSON.stringify(res))
							uni.hideLoading();
						},
						fail: function(e) {
							// console.log("request url:" + portUrl + "\t respond:"+ e)
							reject(e);
							uni.hideLoading();
						}
					})
				} else {
					resolve({
						data: {
							"code": 404,
							"message": "网络飞走啦~"
						}
					});
				}
			},
			fail: function(err) {
				// console.log("request url:" + portUrl + "\t respond:"+ err)
				resolve({
					data: {
						"code": 404,
						"message": "检测网络异常,请稍后重试~"
					}
				});
			}
		})
	})
}

// 单次上传图片
export const httpAvater = (params) => {
	return new Promise((resolve, reject) => {
		uni.getNetworkType({
			success: res => {
				let network = res.networkType;
				if (network == '4g' || network == '3g' || network == 'wifi' || network == '2g') {
					uni.showLoading();
					uni.uploadFile({
						url:apiUrl + params.url,
						filePath:params.data,
						name: 'file',
						formData: {
							biz: params.type
						},
						success: (res) => {
							uni.hideLoading();
							if(res.statusCode == 200){
								// console.log(res)
								let str = res.data;
								let obj = JSON.parse(str);
								// console.log(obj)
								let filUrl = obj.message
								resolve(filUrl);
								
							}else{
								
							}
							
						},
						fail: function(e) {
							reject(e);
							uni.hideLoading();
						}
					})
				} else {
                   resolve({
                   	data: {
                   		"code": 404,
                   		"message": "网络飞走啦~"
                   	}
                   });
				}
			},
			fail: function(err) {
				resolve({
					data: {
						"code": 404,
						"message": "检测网络异常,请稍后重试~"
					}
				});
			}
		})
	})
}
