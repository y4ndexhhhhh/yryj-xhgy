// 验证姓名信息是否正确
export const validChinesName = n => {
  let phonerule = /^[\u4E00-\u9FA5]{2,4}$/;

  if (!phonerule.test(n)) {
    uni.showToast({
      title: '请输入正确的姓名',
      icon: 'none'
    });
  }
}; // 验证手机号信息是否正确

export const validphoneNum = n => {
  let phonerule = /^1[3456789]\d{9}$/;

  if (!phonerule.test(n)) {
    uni.showToast({
      title: '请输入正确的手机号',
      icon: 'none'
    });
    return false;
  }

  return true;
}; // 验证身份证信息是否正确

export const validChineseIdCard = n => {
  let id = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;

  if (!id.test(n)) {
    uni.showToast({
      title: '请输入正确的身份证号',
      icon: 'none'
    });
  }
};