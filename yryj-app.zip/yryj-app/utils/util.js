function formatTime(date) {
	// console.log()
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  var second = date.getSeconds();
  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':');
}
/** 
 * 时间戳 转化为 2020年9月9日
 * number: 传入时间戳 
 * format：返回格式，支持自定义
 */


function formatDate(date) {
  var year = date.getFullYear() + '年';
  var month = date.getMonth() + 1 + '月';
  var day = date.getDate() + '日';
  return [year, month, day].map(formatNumber).join('');
}
/**
 * 时间戳 转化为 2020年9月9日
 * number: 传入时间戳
 * format：返回格式，支持自定义
 */


function newformatDate(date) {
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  return [year, month, day].map(formatNumber).join('');
}

function formatNumber(n) {
  n = n.toString();
  return n[1] ? n : '0' + n;
}
/** 
 * 时间戳转化为年 月 日 时 分 秒 
 * number: 传入时间戳 
 * format：返回格式，支持自定义，但参数必须与formateArr里保持一致 
*/


function formatTimeTwo(number, format) {
  var formateArr = ['Y', 'M', 'D', 'h', 'm', 's'];
  var returnArr = [];
  var date = new Date(number * 1000);
  returnArr.push(date.getFullYear());
  returnArr.push(formatNumber(date.getMonth() + 1));
  returnArr.push(formatNumber(date.getDate()));
  returnArr.push(formatNumber(date.getHours()));
  returnArr.push(formatNumber(date.getMinutes()));
  returnArr.push(formatNumber(date.getSeconds()));

  for (var i in returnArr) {
    format = format.replace(formateArr[i], returnArr[i]);
  }

  return format;
}

function throttle(fn, gapTime) {
  if (gapTime == null || gapTime == undefined) {
    gapTime = 1500;
  }

  let _lastTime = null; // 返回新的函数

  return function () {
    let _nowTime = +new Date();

    if (_nowTime - _lastTime > gapTime || !_lastTime) {
      fn.apply(this, arguments); //将this和参数传给原函数

      _lastTime = _nowTime;
    }
  };
}

 function newsformatTime(number, format) {
  var date = new Date(number*1000);
  var y = date.getFullYear();
  var M = (date.getMonth() + 1) > 9 ? (date.getMonth() + 1) : '0'+(date.getMonth()+1);
  var d = (date.getDate()) > 9 ? date.getDate() : '0'+date.getDate();
  var h = (date.getHours()) > 9 ? date.getHours() : '0'+date.getHours();
  var m = (date.getMinutes()) > 9 ? date.getMinutes() : '0'+date.getMinutes();
  return y +'-'+M+'-'+d+' '+h + ':' + m;
}

module.exports = {
  formatTime: formatTime,
  formatDate: formatDate,
  formatTimeTwo: formatTimeTwo,
  newformatDate: newformatDate,
  throttle: throttle,
  newsformatTime:newsformatTime
};