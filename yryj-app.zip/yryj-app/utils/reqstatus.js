const app = getApp();

function reqstatu(callback) {
  var that = this;
  uni.request({
    url: app.globalData.url + 'shield/getShield',
    method: "POSt",
    success: res => {
      callback(res);
    }
  });
}

module.exports = {
  reqstatu: reqstatu
};