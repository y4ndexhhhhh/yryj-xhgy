<template>
	<view class="content">
		<view class="popcover">
			<view class="mycontent1" v-if="type == 1">
				<image src="" mode="" class="imgBg"></image>
			</view>
			<view class="mycontent2" v-if="type == 2">
				
			</view>
		</view>
	</view>
</template>

<script>
	export default {
         props:{
			 type:{
				 type:[Number],
				 default:1
			 }
		 }
	}
</script>

<style lang="scss" scoped>
	/* #ifndef APP-NVUE */
	.content {
		width: 100%;
		height: 100vh;
		display: flex;
		justify-content: center;
		align-items: center;
		position: relative;
        opacity: 0.5;
		.popcover {
			width: 100%;
			height: 100vh;
			background:rgba(0,0,0,.56);
			opacity: 0.3;
			position: absolute;
			left: 0;
			top: 0;
			z-index: 999;
			display: flex;
			justify-content: center;
			align-items: center;
			.mycontent1 {
				width: 648rpx;
				height: 664rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				.imgBg {
					width: 648rpx;
					height: 664rpx;
					background-color: #F40;
				}
			}
		    .mycontent2{
				width: 606rpx;
				height: 624rpx;
				background-color: #FFFFFF;
				border-radius: 8rpx;
			}
		}

	}
	 /* #endif */  
</style>
