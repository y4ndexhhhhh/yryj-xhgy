<template>
	<view class="buttom">
		 <view class="boxbtn" @click="sublimt" :style="{background:color}">
		 	<text>{{name}}</text>
		 </view>
	</view>
</template>

<script>
	export default{
		props:{
			name:{
			   type: [String],
			   default: '保存'
			},
			color:{
				type: [String],
				default: '#FFAC38'
			}
		},
		methods:{
			sublimt(){
				this.$emit('sublimt')
			}
		}
	}
</script>

<style lang="scss" scoped>
	.buttom{
		width: 100%;
		height: 160rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		position: fixed;
		bottom: 0;
		left: 0;
		.boxbtn{
			width: 686rpx;
			height: 80rpx;
			background: linear-gradient(130deg,#FF8045 0%,#FF5252 100%);
	        border-radius: 60rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			text{
				font-size: 38rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				line-height: 32rpx;
				color: #FFFFFF;
				// letter-spacing: 120px;
				opacity: 1;
			}
		}
	}
</style>
