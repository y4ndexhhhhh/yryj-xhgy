var sha_1 = require("../utils/sha_1.js");
// 插屏广告
export const InsertScreen = function(that, adpid, okCb=null) {
	// 创建插屏广告实例
	that.interstitialAd = uni.createInterstitialAd({
		adpid: adpid
	});
	// 加载插屏广告
	that.interstitialAd.onLoad(() => {
		console.log("插屏 广告加载成功");
		// 广告按钮状态
		that.isLoading = true;
	});
	// 监听插屏广告关闭事件
	that.interstitialAd.onClose(() => {
		// 用户点击了关闭或返回键(仅Android有返回键)
		if((Date.now()-that.chapingstart)/1000>15){
			okCb()
		}
		that.chapingstart = null
		console.log("插屏 广告关闭");
	});
	// 监听插屏错误
	that.interstitialAd.onError((err) => {
		// 广告按钮状态
		that.isLoading = false;
		console.log("插屏 广告加载失败");
	});
	// 广告按钮状态
	// that.isLoading = true;
};

// 显示插屏广告
export const showInsertScreen = function(that) {
	if (!that.isLoading) return;
	that.isLoading = false;
	// 显示打开插屏广告
	that.interstitialAd.show().then(() => {
		that.chapingstart = Date.now()
		that.isLoading = true;
		// 关闭加载
		uni.hideLoading();
	}).catch((err) => {
		// 关闭加载
		uni.hideLoading();
		console.log(err, "err")
	})
};

// 激励视屏广告
export const excitation = function(that, adpid, okCb=null) {
	// 广告按钮状态
	that.isLoaded = false;
	// 创建激励视频广告实例
	that.rewardedVideoAd = uni.createRewardedVideoAd({
		adpid: adpid
	});
	// 加载激励视频广告
	that.rewardedVideoAd.onLoad(() => {
		this.isLoaded = true;
		console.log('激励视频 加载成功');
		// 当激励视频被关闭时，默认预载下一条数据，加载完成时仍然触发 `onLoad` 事件
	});
	// 监听激励视频报错
	that.rewardedVideoAd.onError((err) => {
		console.log('激励视频 加载失败', err)
	});
	// 监听激励视频广告关闭事件
	that.rewardedVideoAd.onClose((res) => {
		console.log('激励视频 关闭成功', res);
		if (res.isEnded) {
			if(okCb!=null){
				okCb();
			}
		}
	});
}
