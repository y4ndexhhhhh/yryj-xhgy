<template>
	<!--pages/frinde/frinde.wxml-->
	<view class="conter">
		<view class="haed">
			<image src="/static/images/banner/backg.png" mode="widthFix"></image>
		</view>
		<view class="show_staff_list" @tap="go_staff_list">查看列表</view>
		<form @submit="formSubmit">
			<view class="wrap">
				<text>姓名:</text>
				<input type="text" placeholder="请输入姓名(必填)"  v-model="real_name" name="real_name"></input>
			</view>
			<view class="num_wrap">
				<text>身份证号:</text>
				<input type="text" placeholder="请输入身份证号(必填)" v-model="id_card" name="id_card"></input>
			</view>
			<view v-for="(item, index) in text" :key="index" class="defa">
				<view>{{item.real_name}}</view>
				<view>{{item.id_card}}</view>
				<view @tap.stop="deate" :data-key="index">解除</view>
			</view>
			<view class="btns" @tap.stop="addontinue">继续添加</view>
			<view class="misoe">
				<h1>温馨提示</h1>
				<view class="cont">
					在加入计划的一个月内，请登录个人手机端完善您的个人信息。首次登录请使用验证码登录，为了您的账号安全，登录后请立即设置登录密码。
				</view>
			</view>
			<button class="btn" @tap.stop="formSubmit" :disabled="disabled">提交</button>
		</form>
	</view>
</template>

<script>
	const app = getApp();
	var reg = require("../../utils/reg.js");

	export default {
		data() {
			return {
				stroge: {},
				real_name: '',
				text: '',
				disabled: true,
				time: '',
				id_card: '',
				list: '',
				checkpass: false
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(e) {
			this.getstroge();
		},

		onShow() {
			const text = uni.getStorageSync("mystaff");

			if (text.length == 0) {
				this.setData({
					disabled: true
				});
			} else {
				this.setData({
					disabled: false
				});
			}

			this.setData({
				text: text
			});
		},

		methods: {
			//获取本地数据
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				that.setData({
					stroge: stroge
				});
			},

			/*---获取员工姓名---*/
			real_nameOnBlur: function(e) {
				let real_name = e.detail.value;
				reg.validChinesName(real_name);
				var that = this;
				that.setData({
					real_name: real_name
				});
			},
			// 获取员工的身份证号码
			idcardOnBlur: function(e) {
				let id_card = e.detail.value;
				reg.validChineseIdCard(id_card);
				var that = this;
				that.setData({
					id_card: id_card
				});

				if (that.real_name != '') {
					that.addontinue();

					if (that.checkpass) {
						var timerTem = setTimeout(function() {
							that.setData({
								disabled: false,
								time: timerTem
							});
						}, 500);
					}
				}
			},

			/*确定*/
			addontinue() {
                 let that = this;
				var data_list = uni.getStorageSync("mystaff");
				var friend_num = data_list.length;
				if (friend_num >= 3) {
					uni.showToast({
						title: '每次只支持为3位员工加入',
						icon: 'none'
					});
					return false;
				}

				if (this.real_name == '') {
					uni.showToast({
						title: '请输入员工姓名',
						icon: 'none'
					});
					return false;
				}
				if (this.id_card == '') {

					uni.showToast({
						title: '请输入正确的身份证号~',
						icon: 'none'
					});
					return false;
				}
				uni.request({
					url: app.globalData.url + 'partner/id_cord',
					method: "POST",
					data: {
						uid: this.stroge.uid,
						id_card: this.id_card,
						real_name: this.real_name
					},
					success: res => {
						if (res.data.code == 'ok') {
							this.setData({
								checkpass: true
							});
							that.disabled=false;
							this.phens();
						} else {
							uni.showToast({
								title: res.data.msg,
								icon: 'none'
							});
							this.setData({
								checkpass: false
							});
							return false;
						}
					}
				});

			},

			/*---解除按钮---*/
			deate(e) {
				var that = this;
				const id = e.currentTarget.dataset.key;
				const list = this.text;
				const arr = list.splice(id, 1);

				if (list.length !== 0) {
					uni.setStorageSync('mystaff', list);
				} else {
					that.setData({
						disabled: true
					});
					uni.setStorageSync('mystaff', []);
				}

				// this.onShow();
			},

			/*员工信息保存本地*/
			phens() {
				var that = this;
				var data = {};
				data['id_card'] = that.id_card;
				data['real_name'] = that.real_name; // data['uid'] = that.data.stroge.uid;

				let arr = uni.getStorageSync("mystaff") || [];
				arr.unshift(data);
				const text = uni.setStorageSync("mystaff", arr);
				// this.onShow(); //员工信息保存本地成功后清空全局变量
                  that.text = arr;
				this.setData({
					id_card: '',
					real_name: ''
				});
			},

			/*---提交---*/
			formSubmit(e) {
				var timerTem = this.time;
				clearTimeout(timerTem);
				var data_list = uni.getStorageSync("mystaff");
				var friend_num = data_list.length;
				var id_card = data_list.id_card;
				var real_name = data_list.real_name;

				if (id_card == '') {
					uni.showToast({
						title: '请输入员工身份证号',
						icon: 'none'
					});
					return false;
				} else if (real_name == '') {
					uni.showToast({
						title: '请输入员工姓名',
						icon: 'none'
					});
					return false;
				} else {
					uni.navigateTo({
						url: '/pages/aplay/aplay?oid=4&friend_num=' + friend_num
					});
				}
			},

			// 查看加入的员工
			go_staff_list() {
				uni.navigateTo({
					url: '/pages/staff_list/staff_list'
				});
			}

		}
	};
</script>
<style>
	/* pages/frinde/frinde.wxss */
	.haed {
		width: 70%;
		margin: auto;
	}

	.haed image {
		width: 100%;
	}

	.wrap {
		display: flex;
		margin: auto;
		width: 80%;
		padding: 15px;
		box-shadow: 0 0 10px 0 #ccc;
		border-radius: 10px;
	}

	.wrap input {
		width: 70%;
		margin-left: 12px;
	}

	.num_wrap {
		display: flex;
		margin: auto;
		width: 80%;
		padding: 15px;
		box-shadow: 0 0 10px 0 #ccc;
		border-radius: 10px;
		margin-top: 10px;
	}

	.num_wrap input {
		width: 70%;
		margin-left: 12px;
	}

	.defa {
		width: 70%;
		margin: 15px auto;
		display: flex;
		justify-content: space-between;
		color: #333;
		font-size: 12px;
	}

	.btns {
		width: 80%;
		margin: 20rpx auto;
		text-align: center;
		line-height: 35px;
		background-color: #eeee;
		color: #107BFD;
		border-radius: 10px;
	}

	.btn {
		width: 70%;
		background-color: #107BFD;
		line-height: 35px;
		border-radius: 35px;
		color: #fff;
	}

	.misoe {
		margin: 10rpx auto 0;
		width: 80%;
		padding: 10px 10px;
	}

	.misoe h1 {
		font-size: 18px;
		font-weight: bolder;
	}

	.misoe .cont {
		font-size: 15px;
		margin-top: 14px;
		color: #7E8A9D;
		text-indent: 30px;
	}

	.show_staff_list {
		border: 1rpx solid #eee;
		border-radius: 8px;
		padding: 20rpx;
		float: right;
		color: blue;
		margin: 20rpx;
	}
</style>
