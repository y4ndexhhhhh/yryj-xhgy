<template>
<!--pages/autograph/autograph.wxml-->
<view class="wrapper">
  <view class="handBtn">
    <button class="backBtn" @tap="backBtn">返回</button>
    <button @tap.stop="cleardraw" class="delBtn">清空</button>
    <button @tap.stop="getimg" class="subBtn">完成</button>
  </view>
  <view class="handCenter">
    <canvas class="canvas" :style="'height:' + (cvsHeight=='100%'?cvsHeight:cvsHeight+'px')" id="canvas" canvas-id="canvas" disable-scroll="true" @touchstart="canvasStart" @touchmove="canvasMove" @touchend="canvasEnd" touchcancel="canvasEnd" @error="canvasIdErrorCallback"></canvas>
  </view>
  <view class="handRight">
    <view class="handTitle">签名板</view>
  </view>
</view>
</template>

<script>
// pages/autograph/autograph.js
var context = null; // 使用 wx.createContext 获取绘图上下文 context
// 使用 wx.createContext 获取绘图上下文 context
var arrx = []; //所有点的X轴集合
//所有点的X轴集合
var arry = []; //所有点的Y轴集合
//所有点的Y轴集合
var canvasw = 300; //画布的宽
//画布的宽 
var canvash = 750; //画布的高
//画布的高
var app = getApp();

export default {
  data() {
    return {
      src: "",
      cvsHeight: '100%',
      flag: 1
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    if (e.flag == 2) {
      this.setData({
        flag: 2
      });
    }

    uni.showLoading({
      title: '加载中...',
      mask: true
    }); // 使用 wx.createContext 获取绘图上下文 context

    context = uni.createCanvasContext('canvas');
    context.beginPath();
    uni.hideLoading();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},
  methods: {
    canvasIdErrorCallback: function (e) {},
    //绘制之前
    canvasStart: function (event) {
      arrx.push(event.changedTouches[0].x);
      arry.push(event.changedTouches[0].y); //就算点击之后手指没有移动,那么下次要移动之前还是必定会先触发这个
    },
    //手指移动过程
    canvasMove: function (event) {
      context.moveTo(arrx[arrx.length - 1], arry[arrx.length - 1]);
      arrx.push(event.changedTouches[0].x);
      arry.push(event.changedTouches[0].y);
      context.lineTo(event.changedTouches[0].x, event.changedTouches[0].y);
      context.setLineWidth(4); //设置线条的宽度

      context.setLineCap('round'); //设置结束时 点的样式

      context.stroke(); //画线

      context.draw(true); //设置为true时，会保留上一次画出的图像，false则会清空
    },
    //手指离开
    canvasEnd: function (event) {},
    cleardraw: function () {
      //清除画布
      arrx = [];
      arry = []; // arrz = [];

      context.clearRect(0, 0, canvasw, canvash);
      context.draw(false);
      this.setData({
        cvsHeight: "50%",
        src: ''
      });
    },
    //导出图片
    getimg: function () {
      if (arrx.length == 0) {
        uni.showModal({
          title: '提示',
          content: '签名内容不能为空！',
          showCancel: false
        });
        return false;
      }

      ;
      uni.showLoading({
        title: '签名生成中..',
        mask: true
      });
      let that = this; //先拿到竖着的地址给image,挡住下面的操作!

      uni.canvasToTempFilePath({
        canvasId: 'canvas',
        // width: canvasw,
        // height: canvash,
        // destWidth: canvasw,
        // destHeight: canvasw * canvasw / canvash,
        success: function (res) {
          //把当前的图片放上去挡住,接着操作下面的canvas
          that.setData({
            src: res.tempFilePath,
            cvsHeight: canvasw * canvasw / canvash
          });
          context.clearRect(0, 0, canvasw, canvash);
          context.translate(0, canvasw / 2.4);
          context.rotate(270 * Math.PI / 180);
          context.drawImage(res.tempFilePath, 0, 0, canvasw * canvasw / canvash, canvasw, 0, 0);
          context.draw(false, setTimeout(function () {
            uni.canvasToTempFilePath({
              canvasId: 'canvas',
              success: result => {
                var src = result.tempFilePath;

                if (src) {
                  //全局变量,用于返回显示
                  if (that.flag == 1) {
                    app.globalData.autograph = result.tempFilePath;
                  } else {
                    app.globalData.autograph_signtreaty = result.tempFilePath;
                  }

                  uni.navigateBack({
                    delta: 1
                  });
                }

                uni.hideLoading();
              }
            }, this);
          }, 100));
        }
      });
    },

    // 返回上一页
    backBtn() {
      uni.navigateBack({
        delta: 1
      });
    }

  }
};
</script>
<style>
page {
  background: #fbfbfb;
  height: auto;
  overflow: hidden;
}

canvas {
  width: 100%;
  /* height:100%; */
}

.wrapper {
  width: 100%;
  height: 95vh;
  margin: 30rpx 0;
  overflow: hidden;
  display: flex;
  align-content: center;
  flex-direction: row;
  justify-content: center;
  font-size: 28rpx;
}

.handRight {
  display: inline-flex;
  align-items: center;
}

.handCenter {
  position: relative;
  border: 4rpx dashed #e9e9e9;
  flex: 5;
  overflow: hidden;
  box-sizing: border-box;
}

.overImg {
  position: absolute;
  top: 0;
  left: 0;
  background-color: #fff;
}

.handTitle {
  transform: rotate(90deg);
  flex: 1;
  color: #666;
}

.handBtn button {
  font-size: 28rpx;
}

.handBtn {
  height: 95vh;
  display: inline-flex;
  flex-direction: column;
  justify-content: space-between;
  align-content: space-between;
  flex: 1;
}

.backBtn {
  position: absolute;
  top: 50rpx;
  left: 0rpx;
  transform: rotate(90deg);
  color: #666;
}

.delBtn {
  position: absolute;
  top: 250rpx;
  left: 0rpx;
  transform: rotate(90deg);
  color: #666;
}


.subBtn {
  position: absolute;
  bottom: 52rpx;
  left: -3rpx;
  display: inline-flex;
  transform: rotate(90deg);
  background: #008ef6;
  color: #fff;
  margin-bottom: 30rpx;
  text-align: center;
  justify-content: center;
}
</style>