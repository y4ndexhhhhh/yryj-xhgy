<template>
	<view>
		<!--pages/number/number.wxml-->
		<view class="conter">
			 <view class="jifen">{{stroge.popularity_num}}</view>
			 <view class="hread">积分兑换</view>
			<!--	 <view class="rightBg" @click="goGrdeList">-->
			<!--	 	<text class="text">积分明细</text>-->
			<!--	 </view>-->
		</view>
		<!-- <view class='btn' catchtap="ationgs">兑换等待期</view> -->
		<view class="btn" @tap.stop="xiangmuzhuanyuan">兑换天使合伙人</view>
		<view class="btn" @tap.stop="putong">兑换注册合伙人</view>
		<view class="btn" @tap.stop="duihuan">兑换期权</view>
		<view class="btn" @click.stop="numType = true">提现</view>
		<view class="num_con" @click.stop="numType = false" v-if="numType">
			<view class="con_mode" @click.stop>
				<input type="text" class="mode_input" v-model="valueNumber" placeholder-class="input_plac" placeholder="请输入提现积分" />
				<view class="btn_num" @click.stop="tip">确定</view>
			</view>
		</view>
		<view class="zhifubao" @click.stop="zfbType = false" v-if="zfbType">
			<view class="zfb_mode" @click.stop>
				<input type="text" class="mode_input" v-model="name" placeholder-class="input_plac" placeholder="请输入姓名" />
				<input type="text" class="mode_input" v-model="account" placeholder-class="input_plac" placeholder="请输入支付宝账号" />
				<view class="zfb_mode_txt">请输入实名认证的姓名以及相对应的支付宝账号</view>
				<view class="btn_num" @click.stop="zfbClick">确定</view>
			</view>
		</view>
	</view>
</template>

<script>
// pages/number/number.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      stroge: '',
      pues: '',
      puess: "",
	  numType: false,
	  valueNumber: "",
	  zfbType: false,
	  name: "",
	  account: "",
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getstroge();
    this.exchange();
    this.exchanges();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},
  methods: {
	  // 提现
		tip() {
			let that = this;
			if(that.valueNumber == "") {
				uni.showToast({
					title: '积分不能为空',
					icon: "error"
				});
				return;
			}
			if(that.valueNumber == 0) {
				uni.showToast({
					title: '积分不能为0',
					icon: "error"
				});
				return;
			}
			if(that.valueNumber > that.stroge.popularity_num) {
				uni.showToast({
					title: '不能超出余额',
					icon: "error"
				});
				return;
			}
			that.numType = false;
			let data = {};
			data["uid"] = that.stroge.uid;
			data["type"] = 1;
			data["amount"] = Number(that.valueNumber);
			var arr = {
				data: data
			};
			var jsonStr = JSON.stringify(arr);
			var aesData = sha_1.Encrypt(jsonStr);
			uni.request({
				url: app.globalData.url + 'users/increment_withdraw',
				method: 'POST',
				data: {
					data: aesData
				},
				success: function(res) {
					console.log(res,"res")
					if(res.data.code == 201) {
						that.zfbType = true;
					} else if(res.data.code == 0) {
						uni.showToast({
							title: '申请发送成功',
							icon: "success"
						});
						that.valueNumber = "";
						that.getstroge();
					} else {
						uni.showToast({
							title: res.data.msg,
							icon: "none"
						});
					}
				},
			})
		},
		zfbClick() {
			let that =this;
			if(that.name == "") {
				uni.showToast({
					title: '姓名不能为空',
					icon: "error"
				});
				return;
			}
			if(that.account == "") {
				uni.showToast({
					title: '账号不能为空',
					icon: "error"
				});
				return;
			}
			let data = {};
			data["uid"] = that.stroge.uid;
			data["zfb_name"] = that.name;
			data["zfb_num"] = that.account;
			var arr = {
				data: data
			};
			var jsonStr = JSON.stringify(arr);
			var aesData = sha_1.Encrypt(jsonStr);
			uni.request({
				url: app.globalData.url + 'users/addzfb',
				method: 'POST',
				data: {
					data: aesData
				},
				success: function(res) {
					console.log(res,"JJJJ")
					if(res.data.code == 0) {
						that.zfbType = false;
						that.name = "";
						that.account = "";
						uni.showToast({
							title: '账号添加成功',
							icon: "success"
						});
					} else {
						that.zfbType = false;
						uni.showToast({
							title: res.data.msg,
							icon: "none"
						});
					}
				},
			})
		},
	  goGrdeList(){
		  uni.navigateTo({
		  	url:'../AanewPages/pointsList'
		  })
	  },
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    /*---等待值兑换---*/
    ationgs() {
      uni.navigateTo({
        url: '/pages/aiting/aiting'
      });
    },

    /*---合伙人亿积分兑换---*/
    exchange() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'partner/exchange_partner_yjf',
        method: "POST",
        data: {
          type: 10,
          uid: that.stroge.uid
        },

        success(res) {
          that.setData({
            pues: res.data.data
          });
        }

      });
    },

    /*---亿积分兑换---*/
    exchanges() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'partner/exchange_partner_yjf',
        method: "POST",
        data: {
          type: 15,
          uid: that.stroge.uid
        },

        success(res) {
          that.setData({
            puess: res.data.data
          });
        }

      });
    },

    /*---天使合伙人---*/
    xiangmuzhuanyuan() {
      var that = this;
      uni.navigateTo({
        url: '/pages/exchan/exchan?type=15&order=2&unit=' + that.puess.unit_price + '&need_yjf=' + that.puess.need_yjf + '&usable_yjf=' + that.puess.usable_yjf
      });
    },

    /*---普通合伙人---*/
    putong() {
      var that = this;
      uni.navigateTo({
        url: '/pages/exchang/exchang?type=10&order=2&unit=' + that.pues.unit_price + '&need_yjf=' + that.pues.need_yjf + '&usable_yjf=' + that.pues.usable_yjf + '&min_stock=' + that.pues.min_stock
      });
    },

    /*---兑换贡献值---*/
    duihuan() {
      var that = this;
      uni.navigateTo({
        url: '/pages/contribution/contribution'
      });
    }

  }
};
</script>
<style>
/* pages/number/number.wxss */
.conter {
  width: 100%;
  margin-bottom: 30rpx;
  position: relative;
  /* background-color: blue; */
}

.hread {
  text-align: center;
  margin: auto;
  color:#333333;
}

.jifen {
  padding: 20px 0;
  text-align: center;
  font-size: 16px;
  color: #4B65F1;
  font-size: 70rpx;
  
}
.rightBg{
	width: 192rpx;
	height: 72rpx;
	background: #FFAC38;
	opacity: 1;
	border-radius: 40rpx 0px 0px 40rpx;
	position: absolute;
	right: 0;
	top: 30rpx;
	text-align: center;
}
	.text{
		font-size: 32rpx;
		font-family: SourceHanSansCN-Regular;
		line-height: 72rpx;
		color: #FFFFFF;
		opacity: 1;
	}

.btn {
	width: 598rpx;
	height: 142rpx;
	background: #6178F3;
	opacity: 1;
	border-radius: 72rpx;
  line-height: 142rpx;
  margin: 0 auto;
  margin-top: 20px;
  text-align: center;
  font-size: 44rpx;
  font-family: SourceHanSansCN-Regular;
  color: #FFFFFF;
  opacity: 1;
}

/* .list{
  color:#fff;
  background:linear-gradient(138deg,rgba(86,206,248,1) 0%,rgb(67, 110, 238) 100%);
}
.frist{
  color:#67a5c3;
} */
.zhifubao, .num_con {
	top: 0;
	left: 0;
	width: 100%;
	height: 100vh;
	position: fixed;
	background: rgba(0,0,0,0.7);
}
.con_mode {
	top: 40%;
	left: 50%;
	width: 600rpx;
	height: 340rpx;
	position: absolute;
	margin-top: -150rpx;
	background: #FFFFFF;
	border-radius: 20rpx;
	margin-left: -300rpx;
	border: 1px solid #bababa;		
}
.mode_input {
	width: 90%;
	height: 100rpx;
	margin: 40rpx auto;
	padding-left: 20rpx;
	border-radius: 10rpx;
	border: 1rpx solid #eeeeee;
}
.input_plac {
	font-size: 26rpx;
}
.btn_num {
	width: 96%;
	margin: auto;
	height: 100rpx;
	color: #FFFFFF;
	margin-top: 50rpx;
	text-align: center;
	line-height: 100rpx;
	background: #007BFF;
	border-radius: 20rpx;
}
.zfb_mode {
	top: 40%;
	left: 50%;
	width: 600rpx;
	height: 550rpx;
	position: absolute;
	margin-top: -250rpx;
	background: #FFFFFF;
	border-radius: 20rpx;
	margin-left: -300rpx;
	border: 1px solid #bababa;	
}
.zfb_mode_txt {
	width: 100%;
	color: #d1d1d1;
	font-size: 24rpx;
	text-align: center;
}
</style>