<template>
	<view>
		<!--pages/contribution/contribution.wxml-->
		<view class="ait" v-if="status==1">
			<view class="nubmer">兑换数量</view>
			<input class="nubmer" name="nubmers" @input="nubmersFun" type="number" :value="nubmers" placeholder="请输入兑换的增值积分数量"></input>
			<!-- <view class="nubmers">1个增值积分兑换10期权</view> -->

		</view>
        <radio-group class="radig" @change="checkboxChange">
        	<radio class="radios" value="3"></radio>
        	我已阅读并同意
        	<text class="text" @tap.stop="privacy">《亿人一家服务平台隐私条例》</text>
        </radio-group>
		<view class="btn list" @tap.stop="btns">
			立即兑换期权
		</view>
		<view class="modalDlg" v-if="showModal">
			<view class="close_mask" @tap="close_mask">x</view>
			<view class="title">支付密码</view>
			<input class="showmode" type="password" name="shouw" @input="shouwFun" :value="shouw" placeholder="请输入支付密码"></input>
			<view class="showv" @tap.stop="btnshow">确定</view>
		</view>
		<view class="mask" catchtouchmove="preventTouchMove" v-if="showModal"></view>
	</view>
</template>

<script>
	// pages/contribution/contribution.js
	const app = getApp();
	var sha_1 = require("../../utils/sha_1.js");

	export default {
		data() {
			return {
				stroge: '',
				nubmers: '',
				ordie: '',
				shouw: "",
				hidde: true,
				isshow: false,
				gxz_num: '',
				showModal: false,
				status: 1
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			this.reqstatu();
			this.getstroge();
		},
		methods: {
			//获取本地数据
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				that.setData({
					stroge: stroge
				});
			},

			/*---同意协议---*/
			checkboxChange(e) {
				this.setData({
					ordie: e.detail.value
				});
			},

			nubmersFun(e) {
				// if(e.detail.value.length == 1){
					// e.detail.value = e.detail.value.replace(/\D/g,'')
					// console.log(e.detail.value.replace(/^(0+)|[^\d]+/g,''))
					this.nubmers = e.detail.value.replace(/^(0+)|[^\d]+/g,'');
				// }else{
				// }
				console.log(this.nubmers,"KKKKKKKK")
				// this.setData({
				// 	nubmers: e.detail.value,
				// 	gxz_num: e.detail.value * 10
				// });
			},

			shouwFun(e) {
				this.setData({
					shouw: e.detail.value
				});
			},

			/*---隐私条例---*/
			privacy() {
				uni.navigateTo({
					url: '/pages/privacy/privacy'
				});
			},

			/*输入密码确定*/
			btnshow() {
				var that = this;

				if (that.shouw == '') {
					uni.showToast({
						title: '密码不能为空'
					});
					return false;
				} else {
					that.setData({
						hidde: true
					});
					var data = {};
					var nubmers = that.nubmers;
					var stroge = that.stroge;
					data["uid"] = stroge.uid;
					data['integral'] = nubmers;
					data['pay_pass'] = that.shouw;
					var arr = {
						data: data
					};
					var jsonStr = JSON.stringify(arr);
					var aesData = sha_1.Encrypt(jsonStr);
					uni.request({
						url: app.globalData.url + 'initiated/integral_devote',
						method: "POST",
						data: {
							data: aesData
						},

						success(res) {
							if (res.data.code == 'ok') {
								that.setData({
									showModal: false
								});
								uni.showModal({
									title: '兑换',
									content: '兑换成功',
									success: res => {
										uni.redirectTo({
											url: '/pages/money/money?uid=' + that.stroge.uid
										});
									}
								});
							} else {
								uni.showToast({
									title: res.data.msg
								});
								that.setData({
									hidde: false
								});
							}
						}

					});
				}
			},

			/*立即兑换*/
			btns() {
				var that = this;
				if (that.nubmers == '') {
					uni.showToast({
						title: '请输入增值积分'
					});
					return false;
				} else if (that.ordie == '') {
					uni.showToast({
						title: '请勾选隐私条例'
					});
					return false;
				} else if (that.nubmers > that.stroge.popularity_num) {
					uni.showToast({
						title: '增值积分不足'
					});
					return false;
				} else {
					if (that.issetpay == 2) {
						uni.showModal({
							title: '支付密码',
							content: '未设置，去设置',
							success: res => {
								if (res.confirm) {
									uni.navigateTo({
										url: '/pages/setups/setups'
									});
								}
							}
						});
					} else {
						this.setData({
							showModal: true
						});
					}
				}
			},

			/*重新存储uid*/
			requid() {
				uni.request({
					url: app.globalData.url + 'users/userinfo',
					method: "POST",
					data: {
						uid: this.stroge.uid
					},

					success(res) {
						uni.setStorageSync('key', res.data.data);
					}

				});
			},

			hideMask: function() {
				this.setData({
					showModal: false
				});
			},
			preventTouchMove: function() {},
			close_mask: function() {
				this.setData({
					showModal: false
				});
			},

			reqstatu() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'shield/getShield',
					method: "POSt",
					data: {
						version_code: app.globalData.version_code
					},

					success(res) {
						that.setData({
							status: res.data.data.status
						});
					}

				});
			}

		}
	};
</script>
<style>
	page {
		color: #333;
		background-color: #F4F4F4;
	}

	input {
		border: 1px solid #eee;
		padding: 8px 0 10px;
		margin-top: 2vh;
		background-color: #FFFAFA;
		border-radius: 8px;
		text-align: center;

	}

	.ait {
		padding: 10px 15px;
		background-color: #fff;
	}

	.nubmer {
		margin-top: 14px;
	}

	.nubmers {
		margin-top: 20px;
		font-size: 12px;
		color: #999;
		line-height: 20px;

	}

	.radig {
		margin-top: 20px;
		margin-left: 20rpx;
		font-size: 12px;
		color: #333;
	}

	.text {
		color: #0B3FFF;
	}

	.radios {
		transform: scale(0.8)
	}

	.btns {
		width: 60%;
		line-height: 35px;
		background-color: #fff;
		margin: 200px auto 20px;
		border-radius: 20px;
		text-align: center;
		box-shadow: 0 0 8px #eee;
	}

	.shouw {
		position: absolute;
		top: 250px;
		left: 50%;
		margin-left: -120px;
		width: 200px;
		padding: 20px;
		border-radius: 8px;
		border: 1px solid #eee;
		text-align: center;
		background-color: #ffff;
	}

	.title {
		font-size: 22px;

	}

	.showv {
		margin: 10px auto 0;
		width: 18vw;
		padding: 6px 10px;
		border-radius: 6px;
		border: 1px solid #eee;
		text-align: center;
		background-color: blue;
		color: #eee;
	}

	.btn {
		width: 686rpx;
		height: 120rpx;
		background: #FFAC38;
		opacity: 1;
		border-radius: 60rpx;
		line-height: 120rpx;
		margin: 100px auto 20px;
		text-align: center;
	}

	.list {
		color: #fff;
		background:  #FFAC38;
		font-size: 44rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		opacity: 1;
	}

	.modalDlg {
		width: 580rpx;
		height: 450rpx;
		position: fixed;
		top: 50%;
		left: 0;
		z-index: 9999;
		margin: -370rpx 85rpx;
		background-color: #fff;
		border-radius: 36rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.mask {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		background: #000;
		z-index: 9000;
		opacity: 0.7;
	}

	.close_mask {
		color: #000;
		position: relative;
		left: 42%;
		font-size: 32rpx;
		padding: 8px 10px;

	}
</style>
