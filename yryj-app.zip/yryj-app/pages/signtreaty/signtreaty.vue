<template>
<view>
<!--pages/signtreaty/signtreaty.wxml-->
<view class="content">
  <view class="title">电子签名（章）授权委托书</view>
  <view class="topyou">授权方：<image :src="autograph_signtreaty"></image>
  </view>
  <view class="text">授权委托授权方
    <p>宁夏拓元互联网科技有限公司</p>在亿人一家（宁夏）互联网科技合伙企业的（合伙经营协议书）中的合伙人签名处使用授权方的电子签名（章），本协议与纸质协议具有同等法律效力。</view>
  <view class="botmyou">授权方：<image :src="autograph_signtreaty"></image>
  </view>
  <view class="me">被授权方：宁夏拓元互联网科技有限公司
    <image class="productList-title" src="/static/images/banner/icon_zhang.png"></image>
  </view>
  <view class="time">{{now_date}}</view>
</view>
<view class="boeder">
  <view class="btns" @tap="autograph" v-if="autograph_signtreaty == ''">立即签名</view>
  <view class="btns" @tap="empower" v-else>立即授权</view>
</view>
</view>
</template>

<script>
// pages/signtreaty/signtreaty.js
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      now_date: '2020-09-01',
      autograph_signtreaty: '',
      autograph_img: '',
      token: '',
      uid: 0
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    if (e.uid != undefined) {
      this.setData({
        uid: e.uid
      });
    }

    var now_date = util.formatDate(new Date());
    this.setData({
      now_date: now_date
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (app.globalData.autograph_signtreaty != '') {
      this.setData({
        autograph_signtreaty: app.globalData.autograph_signtreaty
      }); //上传图片

      this.getToken();
    }
  },
  methods: {
    // 跳转到签名页面
    autograph() {
      uni.navigateTo({
        url: '/pages/autograph/autograph?flag=2'
      });
    },

    //获取上传凭证
    getToken() {
      var that = this;
      var src = that.autograph_signtreaty;

      if (src) {
        uni.request({
          url: app.globalData.url + 'users/getqntoken',
          method: "POST",

          success(res) {
            if (res.data.code == 'ok') {
              that.setData({
                token: res.data.data
              }); //上传凭证获取成功，进行七牛云上传

              that.uploadQiniu(src, res.data.data);
            } else {
              uni.showModal({
                title: '启奏陛下',
                content: '获取上传凭证失败，请重试'
              });
            }
          }

        });
      }
    },

    /**
     * 图片上传七牛云
     */
    uploadQiniu(tempFilePaths, token) {
      var that = this; //let token = that.data.token;

      if (token != '') {
        uni.uploadFile({
          url: 'https://upload-z2.qiniup.com',
          name: 'file',
          filePath: tempFilePaths,
          header: {
            "Content-Type": "multipart/form-data"
          },
          formData: {
            token: token
          },
          success: function (res) {
            if (res.statusCode == 200) {
              let respones_data = JSON.parse(res.data);
              var qiniu_key = respones_data.key;
              that.setData({
                autograph_img: qiniu_key
              });
            } else {
              uni.showModal({
                title: '启奏陛下',
                content: '签名上传失败，请重试'
              });
            }
          },
          fail: function (res) {
            uni.showModal({
              title: '启奏陛下',
              content: '签名生成失败，请重试'
            });
          }
        });
      } else {
        uni.showModal({
          title: '启奏陛下',
          content: '上传凭证获取失败，请重试'
        });
      }
    },

    // 提交授权签名
    empower() {
      var that = this;
      var autograph_img = that.autograph_img;

      if (autograph_img == '') {
        uni.showModal({
          title: '启奏陛下',
          content: '请先签名',

          success(res) {
            uni.navigateTo({
              url: '../autograph/autograph'
            });
          }

        });
        return false;
      }

      var data = {};
      data["uid"] = that.uid;
      data["img_name"] = autograph_img;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'hhr/autograph_img',
        method: "POST",
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            uni.showModal({
              title: '启奏陛下',
              content: res.data.msg,
              success: res => {
                uni.switchTab({
                  url: '/pages/index/index'
                });
              }
            });
          } else {
            uni.showModal({
              title: '启奏陛下',
              content: res.data.msg
            });
          }
        }

      });
    }

  }
};
</script>
<style>
/* pages/signtreaty/signtreaty.wxss */
.content {
  padding: 0 8px;
}

.title {
  display: flex;
  justify-content: space-around;
  padding: 20px;
}

.topyou {
  text-indent: 2em;
}

.text {
  text-indent: 2em;
  letter-spacing: 1px;
  line-height: 40px;
  margin-top: 3px;

}

.text p {
  border-bottom: 1px solid #333;
}

.botmyou {
  margin-top: 70px;
}

.me {

  padding: 6vh 6vh 0 0;

  /* background: url("../../static/banner/icon_zhang.png"); */
}

.me image {
  width: 25vw;
  height: 15vh;

}

.topyou image {
  width: 20vw;
  height: 5vh;
}

.botmyou image {
  width: 20vw;
  height: 5vh;
}

.btns {
  width: 60%;
  line-height: 40px;
  background: #007bff;
  border-radius: 5px;
  text-align: center;
  color: #eee;
  margin-left: 20%;

}

.boeder {
  position: absolute;
  padding: 3px 0;
  bottom: 0px;
  border: 0.5px solid #999;
  width: 100%;
  background: #eee;
}

.productList-title {
  position: relative;
  top: 50%;
  left: 30%;
  transform: translateY(-50%);
}
</style>