<template>
	<!--pages/money/money.wxml-->
	<view class="content" >
		<view class="moneyNums">
			<view class="moneystop">
				<text>{{stroge.current_balance}}</text>
				<text class="text">健康积分 （分）</text>
			</view>
			<!-- <view class="moneysbuttom"> -->
				<!-- <view class="getMoney"  @click="navbak">
					<text>充值</text>
				</view> -->
			<!-- 	<view class="buttomLeft" @click="navbak">
					<text>充值</text>
				</view>
				<text class="line"></text>
				<view class="buttomRight" @click="moneys">
					<text>提现</text>
				</view> -->
			<!-- </view> -->
		</view>
		<view class="numTitle">
			<view class="itemsims" @click="jifen">
				<image src="/static/images/my/money_bg1.png" mode="" class="itemsbg"></image>
				<view class="itemsbox">
					<view class="itemstext">
						<image src="/static/images/my/money_bg4.png" mode="" class="imgs"></image>
						<text>增值积分</text>
					</view>
					<view class="itemsnum">
						<text>{{stroge.popularity_num}}</text>
					</view>
					<view class="getSee">
						<text>查看</text>
					</view>
				</view>
			</view>
			<!-- <view class="itemsims" @click="wraphead">
				<image src="/static/images/my/money_bg2.png" mode="" class="itemsbg"></image>
				<view class="itemsbox">
					<view class="itemstext">
						<image src="/static/images/my/money_bg5.png" mode="" style="width: 25rpx; height: 26rpx;" class="imgs"></image>
						<text>贡献值</text>
					</view>
					<view class="itemsnum">
						<text>{{stroge.devote_value}}</text>
					</view>
					<view class="getSee" style="background-color: #6EB0FC;">
						<text>查看</text>
					</view>
				</view>
			</view> -->
			<view class="itemsims">
				<image src="/static/images/my/money_bg3.png" mode="" class="itemsbg"></image>
				<view class="itemsbox">
					<view class="itemstext">
						<image src="/static/images/my/money_bg6.png" mode="" style="width: 26rpx; height: 26rpx;"  class="imgs"></image>
						<text>期权</text>
					</view>
					<view class="itemsnum">
						<text>{{stroge.shares}}</text>
					</view>
				</view>
			</view>
		</view>
	    <view class="itemsBox" @click="aiting">
	    	<view class="itemsLeft">
	    		<text>账户设置</text>
	    	</view>
	    	<view class="itemsRight" >
	    		<!-- <input type="text" v-model="username" placeholder="请输入用户名" class="input" placeholder-class="deful" /> -->
				<image src="/static/images/my/arrow_right.png" mode="" class="arrowRignth"></image>
	    	</view>
	    </view>
		<!-- <view class="itemsBox" @click="account_details">
			<view class="itemsLeft">
				<text>账户明细</text>
			</view>
			<view class="itemsRight">
				<image src="" mode="" class="arrowRignth"></image>
			</view>
		</view>
		<view class="itemsBox" @click="aiting_bank">
			<view class="itemsLeft">
				<text>银行卡</text>
			</view>
			<view class="itemsRight">
				<image src="" mode="" class="arrowRignth"></image>
			</view>
		</view>
		<view class="itemsBox" @click="aiting_fund">
			<view class="itemsLeft">
				<text>储备金</text>
			</view>
			<view class="itemsRight">
				<image src="" mode="" class="arrowRignth"></image>
			</view>
		</view> -->
	</view>
</template>

<script>
	// pages/money/money.js
	const app = getApp();

	export default {
		data() {
			return {
				stroge: "",
				poors: '',
				uid: '',
				recharge_status: 1,
				status: 1
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			this.reqstatu();

			if (options.uid != undefined) {
				this.setData({
					uid: options.uid
				});
			} else {
				this.requid();
			}
		},

		onShow() {
			this.requid();
		},

		/**
		 * 用户点击右上角分享
		 */
		onShareAppMessage: function() {},
		methods: {
			/*---充值---*/
			navbak() {
				uni.navigateTo({
					url: '/pages/stotails/stotails?oid=1'
				});
			},

			/*---信息服务---*/
			moneys() {
				uni.navigateTo({
					url: '/pages/equity/equity?uid=' + this.stroge.uid
				});
			},

			/*---积分---*/
			jifen() {
				uni.navigateTo({
					url: '/pages/number/number'
				});
			},

			/*---贡献值---*/
			wraphead() {
				uni.navigateTo({
					url: '/pages/gong/gong'
				});
			},

			/*---账户明细---*/
			account_details() {
				// wx.showModal({
				//   title: '启奏陛下',
				//   content: '臣有话说：该功能暂未开放，敬请期待',
				// })
				uni.navigateTo({
					url: '/pages/bill/bill'
				});
			},

			/*---账户设置---*/
			aiting() {
				uni.navigateTo({
					url: '/pages/setup/setup'
				});
			},

			// 银行卡
			aiting_bank() {
				uni.navigateTo({
					url: '/pages/bank/bank'
				});
			},
            aiting_fund(){
				uni.navigateTo({
					url:'/pages/AanewPages/reserveFund?money='+this.stroge.current_balance
				})
			},
			/*---合伙人协议---*/
			agreement() {
				uni.navigateTo({
					url: '/pages/agreements/agreements'
				});
			},

			/*重新存储uid*/
			requid() {
				var that = this;

				if (that.uid != '') {
					uni.request({
						url: app.globalData.url + 'users/userinfo',
						method: "POST",
						data: {
							uid: that.uid
						},

						success(res) {
							if (res.data.code == 'ok') {
								uni.setStorageSync('key', res.data.data);
								that.setData({
									stroge: res.data.data
								});
							} else {
								return false;
							}
						}

					});
				}
			},

			reqstatu() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'shield/getShield',
					method: "POSt",
					data: {
						version_code: app.globalData.version_code
					},

					success(res) {
						that.setData({
							recharge_status: res.data.data.recharge_status,
							status: res.data.data.status
						});
					}

				});
			}

		}
	};
</script>
<style lang="scss" scoped>
	page {
		width: 100%;
		height: 100vh;
		background: #F8F9FF;
	}

	.content {
		width: 100%;
		height: 100vh;
		background: #F8F9FF;

		.moneyNums {
			width: 100%;
			height: 300rpx;
			background-color: #FFFFFF;

			.moneystop {
				width: 100%;
				height: 200rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				flex-flow: column;

				text {
					font-size: 60rpx;
					font-family: PingFang SC;
					font-weight: 800;
					color: #4F74E8;
					opacity: 1;
				}

				.text {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 30rpx;
					color: #4F74E8;
					opacity: 1;
				}
			}

			.moneysbuttom {
				width: 100%;
				height: 100rpx;
				display: flex;
				justify-content: center;
				align-items: center;
                .getMoney{
					width: 344rpx;
					height: 72rpx;
					background: #4F74E8;
					opacity: 1;
					border-radius: 36rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					text{
						font-size: 40rpx;
						font-family: PingFang SC;
						font-weight: 500;
						// line-height: 24px;
						color: #FFFFFF;
						opacity: 1;
					}
				}
				// .line {
				// 	width: 2rpx;
				// 	height: 50rpx;
				// 	background: #F8F9FF;
				// 	border: 2rpx solid #F8F9FF;
				// 	opacity: 1;
				// }

				// .buttomLeft {
				// 	flex: 1;
				// 	height: 100%;
				// 	display: flex;
				// 	justify-content: center;
				// 	align-items: center;

				// 	text {
				// 		font-size: 40rpx;
				// 		font-family: PingFang SC;
				// 		font-weight: 500;
				// 		color: #4F74E8;
				// 		opacity: 1;
				// 	}
				// }

				// .buttomRight {
				// 	flex: 1;
				// 	height: 100%;
				// 	display: flex;
				// 	justify-content: center;
				// 	align-items: center;

				// 	text {
				// 		font-size: 40rpx;
				// 		font-family: PingFang SC;
				// 		font-weight: 500;
				// 		color: #FFAC38;
				// 		opacity: 1;
				// 	}
				// }
			}
		}

		.numTitle {
			width: 100%;
			height: 215rpx;
			display: flex;
			justify-content: space-around;
			align-items: center;
			padding: 0 30rpx;
			box-sizing: border-box;
            margin: 20rpx 0;
			.itemsims {
				width: 190rpx;
				height: 190rpx;
                  position: relative;
				  .itemsbg{
					 width: 190rpx;
					 height: 190rpx;
				  }
				  .itemsbox{
					  width: 190rpx;
					  height: 156rpx;
					  position: absolute;
					  left: 0;
					  top: 0;
					  z-index: 2;
					  .getSee{
						  width: 106rpx;
						  height: 36rpx;
						  background: #FC6EFC;
						  opacity: 1;
						  border-radius: 18rpx;
						
						  margin: 0 auto;
						   display: flex;
						   justify-content: center;
						   align-items: center;
						  text{
							  font-size: 24rpx;
							  font-family: PingFang SC;
							  font-weight: 500;
							  // line-height: 36rpx;
							  color: #FFFFFF;
							  opacity: 1;
						  }
					  }
					  .itemstext {
					  	width: 100%;
					  	height: 55rpx;
					  	display: flex;
					  	justify-content:flex-start;
					  	align-items: center;
					  	padding-top: 10rpx;
						padding-left: 20rpx;
					  	box-sizing: border-box;
					  	.imgs {
					  		width: 18rpx;
					  		height: 24rpx;
					  		// background-color: #FEFB01;
					  		margin-right: 10rpx;
					  	}
					  
					  	text {
					  		font-size: 32rpx;
					  		font-family: PingFang SC;
					  		font-weight: 600;
					  		line-height: 32rpx;
					  		color: #FFFFFF;
					  		opacity: 1;
					  	}
					  }
					  
					  .itemsnum {
					  	width: 100%;
					  	height: 75rpx;
					  	display: flex;
					  	justify-content: center;
					  	align-items: center;
					  
					  	text {
					  		font-size: 52rpx;
					  		font-family: PingFang SC;
					  		font-weight: 800;
					  		// line-height: 24px;
					  		color: #FFFFFF;
					  		opacity: 1;
					  	}
					  }
				  }

			}
		}
	    .itemsBox {
	    	width: 100%;
	    	height: 120rpx;
	    	display: flex;
	    	justify-content: center;
	    	align-items: center;
	    	background-color: #FFFFFF;
	    	padding: 0 30rpx;
	    	box-sizing: border-box;
	    	border-bottom: 1rpx solid #F8F9FF;
	    
	    	.itemsLeft {
	    		flex: 1;
	    		height: 100%;
	    		display: flex;
	    		justify-content: flex-start;
	    		align-items: center;
	    
	    		.icons {
	    			width: 52rpx;
	    			height: 52rpx;
	    			background-color: #f40;
	    		}
	    
	    		text {
	    			font-size: 30rpx;
	    			font-family: PingFang SC;
	    			font-weight: 500;
	    			line-height: 30rpx;
	    			color: #333333;
	    			opacity: 1;
	    			margin-left: 20rpx;
	    		}
	    	}
	    
	    	.itemsRight {
	    		flex: 1;
	    		height: 100%;
	    		display: flex;
	    		justify-content: flex-end;
	    		align-items: center;
	    
	    		.input {
	    			font-size: 30rpx;
	    			font-family: PingFang SC;
	    			font-weight: 500;
	    			line-height: 24rpx;
	    			color: #333333;
	    			opacity: 1;
	    			text-align: right;
	    		}
	    
	    		.deful {
	    			font-size: 30rpx;
	    			font-family: PingFang SC;
	    			font-weight: 500;
	    			line-height: 30rpx;
	    			color: #DBDBDB;
	    			opacity: 1;
	    		}
	    
	    		.avatar {
	    			width: 60rpx;
	    			height: 60rpx;
	    			background: #DBDBDB;
	    			border-radius: 50%;
	    			opacity: 1;
	    			margin-right: 10rpx;
	    		}
	    
	    		.arrowRignth {
	    			width: 20rpx;
	    			height: 28rpx;
	    			// background-color: #f40;
	    		}
	    	}
	    }
	}
</style>
