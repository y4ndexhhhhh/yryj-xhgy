<template>
	<!--pages/help_publicity_list/help_publicity_list.wxml-->
	<Tabs :tabs="tabs" @tabschenge="handletabschenge" v-if="status==1">
		<block v-if="tabs[0].isActive">
			<view class="list_wrap">
				<view v-for="(item, index) in publicity_list" :key="index" class="continer" @tap="publicity_details" :data-id="item.case_id"
				 :data-uid="item.uid" :data-index="index">
					<view class="continer_head_img">
						<image v-if="item.user_img" :src="url + '' + item.user_img"></image>
						<image v-else src="/static/images/banner/nv.jpg"></image>
					</view>
					<view class="continer_head_name">{{item.real_name}}</view>

					<view class="tui-countdown-content">
						剩余
						<text class="tui-conutdown-box">{{countDownList[item.case_id]['day']}}</text>天
						<text class="tui-conutdown-box">{{countDownList[item.case_id]['hou']}}</text>时
						<text class="tui-conutdown-box">{{countDownList[item.case_id]['min']}}</text>分
						<text class="tui-conutdown-box tui-countdown-bg">{{countDownList[item.case_id]['sec']}}</text>秒
					</view>
				</view>
			</view>
		</block>
		<block v-if="tabs[1].isActive">
			<view class="list_wrap">
				<view v-for="(oldItem, index) in old_publicity_list" :key="index" class="continer" @tap="old_publicity_details"
				 :data-id="oldItem.case_id" :data-uid="oldItem.uid" :data-index="index">
					<view class="continer_head_img">
						<image v-if="oldItem.user_img" :src="old_url + '' + oldItem.user_img"></image>
						<image v-else src="/static/images/banner/nv.jpg"></image>
					</view>
					<view class="continer_head_name">{{oldItem.real_name}}</view>
					<view class="continer_jion_time">加入时间{{oldItem.join_time}}</view>
				</view>
			</view>
		</block>
		 <doudi v-if="old_publicity_list.length == 0 || publicity_list.length == 0"></doudi>
	</Tabs>
</template>

<script>
	// pages/help_publicity_list/help_publicity_list.js
	const app = getApp();
	var sha_1 = require("../../utils/sha_1.js");
	import Tabs from "../conponent/Tabs/Tabs";

	export default {
		data() {
			return {
				page: 0,
				publicity_list: [],
				url: '',
				list: [],
				day: "",
				hour: "",
				minute: "",
				second: "",
				timeLeft: [],
				actEndTime: [],
				uid: 0,
				case_id: 0,
				list: [],
				flag: 0,
				old_publicity_list: [],
				old_url: '',
				tabs: [{
					id: 1,
					value: "公示中",
					isActive: true
				}, {
					id: 2,
					value: "往期公示",
					isActive: false
				}],
				index: 0,
				status: 1,
				actEndTimeList: "",
				countDownList: "",
				share_url: ""
			};
		},

		components: {
			Tabs
		},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(e) {
			this.reqstatu();

			if (e.flag != undefined) {
				let tabs = this.tabs;
				tabs[0]['isActive'] = false;
				tabs[1]['isActive'] = true;
				this.setData({
					tabs: tabs
				});
				uni.setStorageSync('keys', e.tuid);
				this.get_old_publicity();
			}

			if (e.uid == 0) {
				this.getstroge();
			} else {
				this.setData({
					uid: e.uid
				});
			}

			this.get_help_list(); // this.get_old_publicity()
		},

		// 监听用户上拉触底事件。
		onReachBottom() {
			var page = this.page + 1; //获取当前页数并+1

			this.setData({
				page: page //更新当前页数

			});

			if (this.index == 1) {
				this.get_old_publicity();
			} else {
				this.get_help_list();
			}
		},

		// 监听用户下拉刷新时间
		onPullDownRefresh() {
			// 重置数组
			if (this.index == 1) {
				this.setData({
					old_publicity_list: []
				});
				var page = 0;
				this.setData({
					page: page //更新当前页数

				});
				this.get_old_publicity();
			} else {
				this.setData({
					publicity_list: []
				});
				var page = 0;
				this.setData({
					page: page //更新当前页数

				});
				this.get_help_list();
			}
		},

		methods: {
			// 缓存获取
			getstroge() {
				let stroge = uni.getStorageSync('key');
				this.setData({
					uid: stroge.uid
				});
			},

			// 获取援助列表
			get_help_list() {
				var that = this;
				var data = {};
				// data["uid"] = that.uid;
				data["page"] = that.page;
				var arr = {
					data: data
				};
				console.log(arr)
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.api_url + 'h5/proposers/getPublicityList',
					method: 'POST',
					data: {
						data: aesData
					},

					success(res) {
						console.log(res)
						if (res.data.code == 200) {
							that.setData({
								publicity_list: res.data.data,
								url: res.data.url
							});
							let arr = res.data.data;
							let endTimeList = []; // 将结束时间参数提成一个单独的数组，方便操作

							arr.forEach(v => {
								endTimeList[v.case_id] = v.publicity_time;
							});
							that.setData({
								actEndTimeList: endTimeList
							}); // 执行倒计时函数

							that.countDown();

							if (that.page == 0) {
								let list = arr;
								that.setData({
									list: list
								});
							} else {
								//获取下拉刷新之前的list数据
								let old_data = that.list; //arr  代表page+1  新数据

								that.setData({
									publicity_list: old_data.concat(arr)
								});
							}
						} else {
							uni.showToast({
								title: res.data.msg,
								icon: 'none'
							});
						}

						uni.stopPullDownRefresh();
					},
					fail(err) {
						console.log(err)
					}

				});
			},

			// 公示详情事件
			publicity_details(e) {
				let index = e.currentTarget.dataset.index;
				let publicity_list = this.publicity_list;
				let url = this.url;
				let result = JSON.stringify(publicity_list[index]);
				uni.navigateTo({
					url: '/pages/help_publicity/help_publicity?url=' + url + '&result=' + result
				});
			},

			timeFormat(param) {
				//小于10的格式化函数
				return param < 10 ? '0' + param : param;
			},

			countDown() {
				//倒计时函数
				// 获取当前时间，同时得到活动结束时间数组
				let newTime = new Date().getTime();
				let endTimeList = this.actEndTimeList;
				let countDownArr = []; // 对结束时间进行处理渲染到页面

				endTimeList.forEach((v, k) => {
					let endTime = new Date(v).getTime();
					let obj = {}; // 如果活动未结束，对时间进行处理

					if (endTime - newTime > 0) {
						let time = (endTime - newTime) / 1000; // 获取天、时、分、秒

						let day = parseInt(time / (60 * 60 * 24));
						let hou = parseInt(time % (60 * 60 * 24) / 3600);
						let min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
						let sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
						obj = {
							day: this.timeFormat(day),
							hou: this.timeFormat(hou),
							min: this.timeFormat(min),
							sec: this.timeFormat(sec)
						};
					} else {
						//活动已结束，全部设置为'00'
						obj = {
							day: '00',
							hou: '00',
							min: '00',
							sec: '00'
						};
						this.get_stop_countDown(k);
					}

					countDownArr[k] = obj;
				}); // 渲染，然后每隔一秒执行一次倒计时函数

				this.setData({
					countDownList: countDownArr
				});
				setTimeout(this.countDown, 1000);
			},

			// 公示停止后请求事件
			get_stop_countDown(case_id) {
				var that = this;
				var data = {};
				data["uid"] = that.uid;
				data["case_id"] = case_id;
				var arr = {
					data: data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.api_url + '/h5/proposers/stopPublicity',
					method: 'POST',
					data: {
						data: aesData
					},

					success(res) {
						that.onLoad();
					}

				});
			},

			// 获取获取往期公示数据
			get_old_publicity() {
				var that = this;
				var data = {};
				data["uid"] = that.uid;
				data["page"] = that.page;
				var arr = {
					data: data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.api_url + 'h5/proposers/getHistoryPublicityList',
					method: 'POST',
					data: {
						data: aesData
					},

					success(res) {
						if (res.data.code == 200) {
							that.setData({
								old_publicity_list: res.data.data,
								old_url: res.data.url,
								share_url: res.data.share_url
							});

							if (that.page == 0) {
								let list = arr;
								that.setData({
									list: list
								});
							} else {
								//获取下拉刷新之前的list数据
								let old_data = that.list; //arr  代表page+1  新数据

								that.setData({
									old_publicity_list: old_data.concat(arr)
								});
							}
						} else {
							uni.showToast({
								title: res.data.msg,
								icon: 'none'
							});
						}

						uni.stopPullDownRefresh();
					}

				});
			},

			// tab点击事件
			handletabschenge(e) {
				const that = this; // 获取被点击标题的索引

				const {
					index
				} = e.detail;
				that.setData({
					index: index
				}); // 修改原数组

				let {
					tabs
				} = that;

				for (var k = 0, length = tabs.length; k < length; k++) {
					if (index == k) {
						tabs[k]['isActive'] = true;
					} else {
						tabs[k]['isActive'] = false;
					}
				} // 赋值到data中


				that.setData({
					tabs
				}); // 重新赋值

				that.setData({
					page: 0
				}); // 加载数据

				if (index == 1) {
					that.get_old_publicity();
				}
			},

			// 往期公示详情
			old_publicity_details(e) {
				let index = e.currentTarget.dataset.index;
				let old_publicity_list = this.old_publicity_list;
				let result = JSON.stringify(old_publicity_list[index]);
				uni.navigateTo({
					url: '/pages/old_help_publicity/old_help_publicity?result=' + result + '&share_url=' + this.share_url
				});
			},

			// 屏蔽
			reqstatu() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'shield/getShield',
					method: "POSt",
					data: {
						version_code: app.globalData.version_code
					},

					success(res) {
						that.setData({
							status: res.data.data.status
						});
					}

				});
			}

		}
	};
</script>
<style>
	/* pages/help_publicity_list/help_publicity_list.wxss */
	.continer {
		border: 1rpx solid #eee;
		border-radius: 8px;
		box-shadow: 2px 2px 2px #eee;
		margin: 10rpx;
		display: flex;
	}

	.continer_head_img {
		padding: 20rpx;
		width: 70px;
		height: 70px;
	}

	.continer_head_img image {
		width: 70px;
		height: 70px;
		border-radius: 8px;
	}

	.continer_head_name {
		display: flex;
		align-items: center;
	}

	.continer_jion_time {
		display: flex;
		align-items: center;
		margin-left: auto;
	}

	.tui-countdown-content {
		display: flex;
		align-items: center;
		margin-left: auto;
		padding: 0 10rpx;
	}
</style>
