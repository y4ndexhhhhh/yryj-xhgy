<template>
<view class="conter" v-if="status==1">
  <view class="wrap">
    <image src="/static/images/banner/fenhonggu.png"></image>
    <view class="title">
      认购合伙企业股
      <text>（最低{{pues.min_stock}}股）</text>
    </view>
    <view class="btn" @tap="pupay">认购</view>
  </view>
  <view class="wrap">
    <image src="/static/images/banner/jife.png"></image>
    <view class="title">
      增值积分兑换
      <text>（需要积分{{pues.need_yjf}}）</text>
    </view>
    <view class="btn" @tap="exchang">兑换</view>
  </view>
</view>
</template>

<script>
// pages/staff/staff.js
const app = getApp();

export default {
  data() {
    return {
      id: '',
      //代表类型
      stroge: '',
      str: '',
      status: 1,
      pues: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();
    this.setData({
      id: e.id
    });
    this.getstroge();
    this.exchange();
  },
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge,
        str: stroge
      });
    },

    /*---亿积分兑换---*/
    exchange() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'partner/exchange_partner_yjf',
        method: "POST",
        data: {
          type: that.id,
          uid: that.stroge.uid
        },

        success(res) {
          that.setData({
            pues: res.data.data
          });
        }

      });
    },

    /*---普通认购---*/
    pupay() {
      uni.navigateTo({
        url: '/pages/pupay/pupay?type=10&order=1&unit=' + this.pues.unit_price + '&min_stock=' + this.pues.min_stock
      });
    },

    /*---兑换---*/
    exchang() {
      var that = this; //console.log(that.data.pues.min_stock)

      uni.navigateTo({
        url: '/pages/exchang/exchang?type=10&order=2&unit=' + that.pues.unit_price + '&need_yjf=' + that.pues.need_yjf + '&usable_yjf=' + that.pues.usable_yjf + '&min_stock=' + that.pues.min_stock
      });
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
.wrap {
  width: 90%;
  padding: 10px 3px;
  margin: 30px auto;
  display: flex;
  justify-content: space-around;
  box-shadow: 0 0 8px #ccc;
  border-radius: 8px;
}

.wrap image {
  width: 45px;
  height: 45px;
}

.wrap .title {
  margin-top: 10px;
  font-size: 18px;
  font-weight: bold;
}

.wrap text {
  font-size: 12px;
}

.wrap .btn {
  width: 80px;
  height: 30px;
  margin-top: 6px;
  line-height: 30px;
  text-align: center;
  color: #fff;
  background: linear-gradient(270deg, rgba(255, 205, 104, 1) 0%, rgba(252, 119, 30, 1) 100%);
  box-shadow: 0px 0px 8px 0px rgba(0, 0, 0, 0.12);
  border-radius: 30px;
}
</style>