<template>
<!--pages/share/share.wxml-->
<view class="conter">
  <view class="back">
    <image src="/static/images/banner/back1.png"></image>
  </view>
  <view class="down">
    <h1>奖励规则</h1>
    <view class="conin">
      <view>
		  1、会员每成功邀请一位新人加入，奖励1万金币。
		  2、合伙人每成功邀请一位新人加入，奖励1万金币 + 10元增值积分。
		  3、每成功邀请一位新合伙人加入，奖励100元增值积分。
      </view>
      <!-- <view>注：一个亿积分可以冲抵一天等待期</view> -->
    </view>
    <!-- <button class="share" open-type="share">立即推荐</button> -->
    <button class="share" @click="onShare">立即推荐</button>
  </view>

</view>
</template>

<script>
// pages/share/share.js
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");
import appShare, {
		closeShare
	} from "@/js_sdk/zhouWei-APPshare/plugins/share/index.js"
export default {
  data() {
    return {
      uid: '',
      stroge: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getstroge();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    var data = {};
    data["uid"] = that.stroge.uid;
    data['type'] = 3;
    var arr = {
      data: data
    };
    var jsonStr = JSON.stringify(arr);
    var aesData = sha_1.Encrypt(jsonStr);
    uni.request({
      url: app.globalData.url + 'partner/share_award',
      method: "POST",
      data: {
        data: aesData
      },

      success(res) {}

    });
    return {
      title: '分享有礼',
      //desc: '分享页面的内容',
      path: '/pages/index/index?tuid=' + that.stroge.uid // 路径，传递参数到指定页面。

    };
  },
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },
	onShare() {
		let shareData = {
			shareUrl: "https://app01.wysyt.com/index/activity/yaoqinghan.html?uid=" + `${this.stroge.uid}`, // 分享地址
			shareTitle: "亿人一家", // 分享标题
			shareContent: "亿人计划——利用互联网强大的网络协同效应，有效解决社会大量人群因病致贫/返贫这一痛点问题而搭建的服务版块，极大降低社会成本及每个参与者的成本。旨在用互联网的方式解决参与会员因意外或疾病而发生的需要个人承担部分的医疗费用问题。", //分享描述
			shareImg: "https://swsdl.vivo.com.cn/appstore/developer/icon/20180810/201808101152462406707.jpg", // 分享 图片网络连接
		};
		// 调用
		let shareObj = appShare(shareData, res => {
			// 分享成功后关闭弹窗
			// 第一种关闭弹窗的方式
			closeShare();
		});
		setTimeout(() => {
			// 第二种关闭弹窗的方式
			shareObj.close();
		}, 5000);
	}

  }
};
</script>
<style>
/* pages/share/share.wxss */
.back {
  width: 100%;
  height: 50vh;
}

.back image {
  width: 100%;
  height: 100%;
}

.down {
  padding-top: 30px;
  width: 100%;
  height: 50vh;
  text-align: center;
  background-color: #1677F5;
}

.down h1 {
  color: #fff;
  font-size: 18px;
}

.conin {
  margin: auto;
  width: 70%;
  padding: 20px;
  background-color: #55CFF7;
  opacity: .8;
  border-radius: 10px;
}

.conin view {
  color: #fff;
  font-size: 14px;
  text-align: left;
}

.conin view+view {
  margin-top: 20px;
}

.share {
  margin-top: 30px;
  width: 80%;
  color: #fff;
  background-color: #0B3FFF;
}
</style>