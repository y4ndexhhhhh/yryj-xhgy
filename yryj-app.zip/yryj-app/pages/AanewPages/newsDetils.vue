<template>
	<view class="content" :style="{height:QHeight+'px'}">
		<view class="articeCotent">
			<view class="titleName">
				<text class="title">{{textinfo.title}}</text>
			</view>
			<view class="times">
				<text class="timer">{{textinfo.create_time}}</text>
			</view>
			<view class="contenttext">
				<view v-html="content" class="mycontent"></view>
				
			</view>
		</view>
		<view class="newsVideo" @click="loadAd" :loading="isLoaded">
			<image src="/static/images/home/news.png" mode="aspectFit" class="VideogoImgs"></image>
		</view>
		<!-- <view style="width: 100wh;height: 100vh;background: red;">
			<ad class="ad" adpid="1105658736"></ad>
		</view> -->
	</view>
</template>

<script>
	import popUp from '@/components/PopUp.vue'
	var splashModule = uni.requireNativePlugin("ZjSDKSplashModule")
	var ZjSplashView = uni.requireNativePlugin("ZjSplashView")
	const modal = uni.requireNativePlugin('modal');
	var rewardModule = uni.requireNativePlugin("ZjSDKRewardModule");
	var sha_1 = require("../../utils/sha_1.js");
	const app = getApp();
	import htmlParser from '@/utils/html-parser.js';
	import util from '@/utils/util.js'
	import { excitation } from "@/components/advertisement.js"
	// function parseImgs(nodes) {
	// 	nodes.forEach(node => {
	// 		if (
	// 			node.name === 'img' &&
	// 			node.attrs &&
	// 			node.attrs['data-img-size-val']
	// 		) {
	// 			const sizes = node.attrs['data-img-size-val'].split(',')
	// 			const width = uni.upx2px(720 * 0.8)
	// 			const height = parseInt(width * (sizes[1] / sizes[0]))
	// 			node.attrs.style = `width:${width};height:${height};`
	// 		}
	// 		if (Array.isArray(node.children)) {
	// 			parseImgs(node.children)
	// 		}
	// 	})

	// 	return nodes
	// }


	export default {
		components: {
			popUp
		},
		data() {
			return {
				QHeight: '',
				id: '',
				textinfo: '',
				content: '',
				stroge: '',
				code: true,
				other: '',
				timer:'',
				rewardedVideoAd: null,  // 定义激励视屏广告
				isLoaded: false,   // 广告按钮状态
			}
		},
		onLoad(options) {
			this.stroge = uni.getStorageSync('key');
			this.other = uni.getStorageSync('other');
			this.id = options.id;
			uni.getSystemInfo({
				success: (res) => {
					let height = res.windowHeight;
					this.QHeight = height;
				}
			})
			this.getNewsList();
			let that = this;
			this.timer = setTimeout(() => {
				//this.getGolod();
				clearTimeout(that.timer)
			}, 10000)
		},
		onBackPress(e){
			clearTimeout(this.timer)
		},
		onReady() {
			// 获取激励视频广告数据
			excitation(this,"1105658736",this.getMyGolod);
		},
		methods: {
			// 判断文章是否滚动到底部
			scrollBind(event) {
				// 	let moveY = Math.abs(event.contentOffset.y);
				// 	let movey = Math.ceil(moveY);
				// 	let contentH = (Math.ceil(event.contentSize.height)/1.8)
				// 	console.log(movey,contentH);
				// 	if(movey > contentH && this.code){
				// 		this.getGolod();
				// 		this.code = false;
				// 	}
			},
			getNewsList() {
				let that = this;
				var data = {};
				data["id"] = that.id;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'news/newsDetail',
					data: {
						data: aesData
					},
					method: 'get'
				}).then(res => {
					console.log(res)
					var content = ''
					if (res.data.code == 0) {

						let textInfo = res.data.data;
						textInfo.create_time = util.newsformatTime(textInfo.create_time)
						that.textinfo = res.data.data;
						content = res.data.data.content
					}
					this.content = content;
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			// getGolod() {
			// 	let that = this;
			// 	console.log(that.stroge)
			// 	var data = {};
			// 	data["id"] = that.id;
			// 	data["uid"] = that.stroge.uid;
			// 	var arr = {
			// 		"data": data
			// 	};
			// 	var jsonStr = JSON.stringify(arr);
			// 	var aesData = sha_1.Encrypt(jsonStr);
			// 	app.$request({
			// 		url: 'news/newsScore',
			// 		data: {
			// 			data: aesData
			// 		},
			// 		method: 'post'
			// 	}).then(res => {
			// 		var content = ''
			// 		if (res.data.code == 0) {
			// 			uni.showToast({
			// 				title: '获得' + res.data.data.score + '金币',
			// 				icon: 'none'
			// 			})
			// 		}
			// 	}).catch(err => {
			// 		console.error('登录异常', err);
			// 	})
			// },
			loadAd() {
				// 调用异步方法
				console.log('onZjAdReward create', 'create')
				uni.showLoading({
					title: '加载中'
				});
				// 打开激励视频广告
				this.rewardedVideoAd.show().then(() => {
					uni.hideLoading();
				}).catch((err) => {
					uni.hideLoading();
					console.log(err,"err");
				});
				// let that = this;
				// rewardModule.create("zjad_241286", "zj_11120200724056", "激励名称", 10, "扩展参数", true);
				// rewardModule.onZjAdLoaded((info) => {
				// 	console.log('onZjAdLoaded event', info)
				// 	rewardModule.showAd()
				// })
				// rewardModule.onZjAdVideoCached((info) => {
				// 	console.log('onZjAdVideoCached event', info)
				// 	uni.hideLoading();
				// 	// rewardModule.showAd()
				// })
				// rewardModule.onZjAdShow((info) => {
				// 	console.log('onZjAdShow event', info)
				// })
				// rewardModule.onZjAdClick((info) => {
				// 	console.log('onZjAdClick event', info)
				// })
				// rewardModule.onZjAdReward((info) => {
				// 	console.log('onZjAdReward event', info)
				// 	// that.getMyGolod();
				// })
				// rewardModule.onZjAdClose((info) => {
				// 	console.log('onZjAdClose event', info)
				// 	that.getMyGolod();
				// })
				// rewardModule.onZjAdError((info) => {
				// 	console.log('onZjAdError event', info)
				// })
			},
			getMyGolod() {
				console.log("video close & get coin")
				let that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				data["type"] = '4';
				data["score"] = that.other.video;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'user_ad/openEncourageAd',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					console.log(res)
					var content = ''
					if (res.data.code == 0) {
						uni.showToast({
							title: '获得' + that.other.video + '金币',
							icon: 'none'
						})
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
		},
		onUnload() {
			// 页面关闭销毁插屏广告
			this.rewardedVideoAd.destroy();
		}
		// onReady() {
		// 	this.$refs.bannerView.load("zjad_241298");

		// 	this.$refs.bannerView.onZjAdLoaded((info) => {
		// 		console.log('onZjAdLoaded event', info)
		// 	})
		// 	this.$refs.bannerView.onZjAdShow((info) => {
		// 		console.log('onZjAdShow event', info)
		// 	})
		// 	this.$refs.bannerView.onZjAdClick((info) => {
		// 		console.log('onZjAdClick event', info)
		// 	})

		// 	this.$refs.bannerView.onZjAdClose((info) => {
		// 		console.log('onZjAdClose event', info)
		// 	})
		// 	this.$refs.bannerView.onZjAdError((info) => {
		// 		console.log('onZjAdError event', info)
		// 	});
		// }
	}
</script>

<style lang="scss" scoped>
	.content {
		width: 750rpx;
		background-color: #F8F9FF;
		.articeCotent {
			width: 750rpx;
			background-color: #FFFFFF;
			padding: 0 30rpx;
			box-sizing: border-box;
			margin-bottom: 160rpx;
			.titleName {
				width: 100%;
				min-height: 80rpx;
				padding-top: 10rpx;
				padding-bottom: 10rpx;
				.title {
					font-size: 45rpx;
					font-family: Source Han Sans CN;
					font-weight: 500;
					line-height: 45upx;
					color: #4D4D4D;
					opacity: 1;
				}
			}
			

			
			.times {
				width:100%;
				height: 45rpx;
				align-items: flex-start;
				justify-content: flex-end;
				.timer {
					font-size: 30upx;
					font-family: Source Han Sans CN;
					font-weight: 500;
					line-height: 35upx;
					color: #4D4D4D;
					opacity: 1;
				}
			}

			
			.contenttext {
				width:100%;
				height: auto;
				word-wrap: break-word;
				word-break: break-all;
				 white-space: pre-wrap; 
				overflow: hidden;
				.mycontent {
					width: 100%;
					display: flex;
					justify-content:flex-start;
					align-items: center;
					flex-direction: column;
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 52rpx;
					color: #676767;
					opacity: 1;
				}
			}
	
		
		}
		.newsVideo {
			width: 750rpx;
			height: 160rpx;
			position: fixed;
			bottom: 0;
			display: flex;
			justify-content: center;
			align-items:flex-start;
		}
		.VideogoImgs {
			width: 686rpx;
			height: 140rpx;
		}
	}

	


</style>
