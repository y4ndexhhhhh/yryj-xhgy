<template>
	<view class="content">
		<view class="addres" v-if="orderList.length > 0">
			<view class="left" >
				<view class="name">
					<text>{{orderList[0].name}}</text>
					<text>{{orderList[0].tel}}</text>
				</view>
				<view class="addtext">
					<text>{{orderList[0].address}}</text>
				</view>
			</view>
		</view>
		<view class="adrestext" v-if="orderList.length > 0" v-for="(item,index) in shopDetail" :key="index">
			<view class="imgBox">
				<image :src="item.images" mode="aspectFit" class="imgs"></image>
			</view>
			<view class="textContent">
				<view class="name">
					<text>{{item.title}}</text>
				</view>
				<view class="desc">
					<text>{{item.title}}</text>
					<!-- <text>消脂滋润</text> -->
				</view>
				<view class="price">
					<text>￥{{item.original_price}}</text>
				</view>
			</view>
		</view>
		<view class="OrderInfo" v-if="orderList.length > 0">
			<view class="itemsBox">
				<view class="itemLeft">订单时间</view>
				<text class="text">{{orderList[0].add_time}}</text>
			</view>
			<view class="itemsBox">
				<view class="itemLeft">配送方式</view>
				<text class="text">邮政快递</text>
			</view>
			<view class="itemsBox">
				<view class="itemLeft">快递单号</view>
				<text class="text">1200000203000543523</text>
			</view>
			<view class="itemsBox">
				<view class="itemLeft">商品金额</view>
				<text class="text">￥{{orderList[0].increase_price}}</text>
			</view>
			<view class="itemsBox">
				<view class="itemLeft">运费</view>
				<text class="text">￥{{orderList[0].price}}</text>
			</view>
		</view>
		<view class="payMoney" v-if="orderList.length > 0">
			<text>实付:</text>
			<text>￥{{orderList[0].price}}</text>
		</view>
		<view class="Popup" @touchmove.stop.prevent="moveHandle" v-if="false">
			<view class="noTip">
				<view class="topTip">
					<text class="red">支付成功</text>
				</view>
				<view class="topBtn">
					<text>恭喜您获得</text>
					<text>10000</text>
					<text>金币</text>
				</view>
			</view>
			<image src="/static/images/home/clear.png" mode="" class="Clear" @click="goPay"></image>
		</view>
		 <doudi v-if="orderList.length == 0"></doudi>
	</view>
</template>

<script>
	var sha_1 = require("../../utils/sha_1.js");
		const app = getApp();
	export default {
		data() {
			return {
				rank: '-2',
				popupCode: true,
				stroge:'',
				orderList:[],
				shopDetail:''
			}
		},
		onLoad() {
			this.stroge = uni.getStorageSync('key');
			this.myorder();
		},
		methods: {
			myorder() {
				let that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				data["status"] = '2';
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'users/checkUserOrder',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					console.log(res)
					if (res.data.code == 0) {
						if(res.data.data.length >0){
							that.orderList = res.data.data;
							that.shopDetail = res.data.data[0].order_detail;
						}
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			goAddres() {
				uni.navigateTo({
					url: './addres'
				})
			},
			goPay() {
				this.popupCode = !this.popupCode
			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
	}

	.content {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
          .OrderInfo{
			  width: 100%;
			  height: auto;
			  padding: 0 20rpx;
			  box-sizing: border-box;
			  background-color: #FFFFFF;
			  .itemsBox{
				  width: 100%;
				  height: 70rpx;
				  display: flex;
				  justify-content: flex-start;
				  align-items: center;
				  .itemLeft{
					  width: 200rpx;
					  height: 70rpx;
					  display: flex;
					  justify-content: flex-start;
					  align-items: center;
					  
					  
					  font-size: 28rpx;
					  font-family: PingFang SC;
					  font-weight: 400;
					  // line-height: 56rpx;
					  color: #666666;
					  opacity: 1;
				  }
				  .text{
					 font-size: 26rpx;
					 font-family: PingFang SC;
					 font-weight: 400;
					 // line-height: 56rpx;
					 color: #666666;
					 opacity: 1; 
				  }
			  }
		  }
		  .payMoney{
			  width: 100%;
			  height: 80rpx;
			  display: flex;
			  justify-content: space-between;
			  align-items: center;
			  padding: 0 30rpx;
			  box-sizing: border-box;
			  background-color: #FFFFFF;
		  }
		.addres {
			width: 100%;
			height: 135rpx;
			padding: 0 32rpx;
			box-sizing: border-box;
			background-color: #FFFFFF;
			border-bottom: 1rpx solid #F8F9FF;
			display: flex;

			.left {
				flex: 5;
				height: 100%;
				display: flex;
				justify-content: center;
				align-items: flex-start;
				flex-flow: column;
				.name {
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #4D4D4D;
					opacity: 1;
					text {
						margin-right: 20rpx;
					}
				}
				.addtext {
					width: 560rpx;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
					text {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #4D4D4D;
						opacity: 1;
					}
				}
			}
			.right {
				flex: 1;
				height: 100%;
				display: flex;
				justify-content: flex-end;
				align-items: center;
				.arrow {
					width: 13rpx;
					height: 24rpx;
				}
			}
		}

		.adrestext {
			width: 100%;
			height: 280rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			background-color: #FFFFFF;
			border-bottom: 1rpx solid #F8F9FF;
			padding: 0 30rpx;
			box-sizing: border-box;
			.imgBox {
				width: 212rpx;
				height: 212rpx;
				.imgs {
					width: 212rpx;
					height: 212rpx;
					background: rgba(0, 0, 0, 0);
					opacity: 1;
				}
			}
			.textContent {
				margin-left: 20rpx;
				.name {
					font-size: 40rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					line-height: 40rpx;
					color: #4D4D4D;
					opacity: 1;
				}
				.desc {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 56rpx;
					color: #AAAAAA;
					opacity: 1;
				}
				.price {
					font-size: 40rpx;
					margin-top: 10rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 40rpx;
					color: #FF5151;
					opacity: 1;
				}
			}
		}
		.btnBox {
			width: 100%;
			height: 135rpx;
			position: fixed;
			left: 0;
			bottom: 0;
			background-color: #FFFFFF;
			display: flex;

			.left {
				width: 450rpx;
				height: 135rpx;
				display: flex;
				justify-content: center;
				align-items: center;

				text {

					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 56rpx;
					color: #575757;
					opacity: 1;
				}

				.red {

					font-size: 40rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 40rpx;
					color: #FF5151;
					opacity: 1;
				}
			}

			.rgiht {
				width: 300rpx;
				height: 135rpx;
				background: #FFAC38;
				opacity: 1;
				display: flex;
				justify-content: center;
				align-items: center;

				text {
					font-size: 44rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 24rpx;
					color: #FFFFFF;
					opacity: 1;
				}
			}
		}

		.Popup {
			width: 100%;
			height: 100vh;
			top: 0;
			left: 0;
			position: absolute;
			z-index: 99999;
			background-color: rgba(0, 0, 0, .4);
			display: flex;
			justify-content: center;
			align-items: center;
			flex-flow: column;

			.boxContet {
				width: 600rpx;
				height: 210rpx;
				background: #FFFFFF;
				opacity: 1;
				border-radius: 8rpx;
				.boxTop {
					width: 100%;
					height: 110rpx;
					border-bottom: 1rpx solid #ECECEC;
					display: flex;
					justify-content: center;
					align-items: center;
					text {
						font-size: 36rpx;
						font-family: SourceHanSansCN-Regular;
						line-height: 40rpx;
						color: #FF5451;
						opacity: 1;
					}

				}
				.boxClose {
					width: 100%;
					height: 98rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					text {
						font-size: 30rpx;
						font-family: SourceHanSansCN-Regular;
						line-height: 40rpx;
						color: #BBBBBB;
						opacity: 1;
					}
				}
			}

			.noTip {
				width: 600rpx;
				height: 320rpx;
				background-color: #FFFFFF;
				border-radius: 8rpx;

				.topTip {
					width: 100%;
					height: 170rpx;
					border-bottom: 1rpx solid #ECECEC;
					display: flex;
					justify-content: center;
					align-items: center;
					flex-flow: column;

					.red {
						font-size: 36rpx;
						font-family: SourceHanSansCN-Regular;
						line-height: 40rpx;
						color: #FF5451;
						opacity: 1;
					}

					text {
						font-size: 30rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						line-height: 40rpx;
						color: #707070;
						opacity: 1;
						margin-top: 20rpx;
					}
				}

				.topBtn {
					width: 100%;
					height: 145rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					text {
						font-size: 36rpx;
						font-family: SourceHanSansCN-Regular;
						line-height: 40rpx;
						color: #FF5451;
						opacity: 1;
					}
				}
			}
		    .Clear{
				width: 72rpx;
				height: 72rpx;
				// background-color: #f40;
				margin-top: 65rpx;
			}
		}
	}
</style>
