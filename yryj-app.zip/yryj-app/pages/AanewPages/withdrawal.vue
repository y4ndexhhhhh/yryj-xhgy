<template>
	<view class="content">
		<view class="boxs">
			<view class="boxstitles">
				<text>提现金额</text>
			</view>
			<view class="boxcontent">
				<text class="signs">￥</text>
				<input type="text"   v-model="inputNum" @blur="getInput" placeholder="请输入兑换的金币数量" placeholder-class="defult"/>
			</view>
			<view class="btntext">
				<text>可提现{{money}}元</text>
				<text style="color: #1C3EF5; margin-left: 20rpx;" @click="goBtn">全部提现</text>
			</view>
		</view>
		<!-- <payPass ref="verify" @finish="getCode"></payPass> -->
		<mybottom name="提现" @sublimt="getGoldWithdraw"></mybottom>
	    <PopupBottom :show="codeWeiChat" @close="goclear1">
			<view class="coverPop">
				<image src="/static/cart/order/wenchat.png" mode="" class="weichatIcon"></image>
				<view class="coverBtn" @click="getweChar">
					<text>授权微信提现</text>
				</view>
			</view>
		</PopupBottom>
	</view>
</template>

<script>
	import payPass from '../../components/pay-pass/pay-pass.vue';
	import PopupBottom from '@/components/popup-bottom/popup-bottom';
	var sha_1 = require("../../utils/sha_1.js");
		const app = getApp();
	export default{
		components:{
			payPass,
			PopupBottom
		},
		data(){
			return{
				keNum:100,
				inputNum:'',
				stroge:'',
				money:'',
				newCode:'',
				codeWeiChat:false
			}
		},
		onLoad(options) {
			this.stroge = uni.getStorageSync('key');
			let moneys = Number(options.money);
			this.money = Math.floor(moneys*100)/100;
			this.newCode = options.type;
			// this.getNewsUser();
		},
		
		methods:{
			goclear1(){
				this.codeWeiChat = false;
			},
			getweChar() {
					var that = this;
					uni.getProvider({
						service: 'oauth',
						success: function(res) {
							if (res.provider[0] == 'weixin') {
								uni.login({
									provider: 'weixin',
									success: function(loginRes) {
										that.getApploginData(loginRes)
									},
									fail:function(err){
										console.log(err)
									}
								})
							}
						}
					})
				},
				getApploginData(loginRes) {
					let that = this;
					var data = {};
					data["uid"] = that.stroge.uid;
					data["openid"] = loginRes.authResult.openid;
					var arr = {
						"data": data
					};
					var jsonStr = JSON.stringify(arr);
					var aesData = sha_1.Encrypt(jsonStr);
					app.$request({
						url: 'users/bindopenid',
						data: {
							data: aesData
						},
						method: 'post'
					}).then(res => {
						if (res.data.code == 0) {
							that.codeWeiChat = false;
							uni.showToast({
								title:'绑定成功',
								icon:'none'
							})
						}
					}).catch(err => {
						console.error('登录异常', err);
					})
			},
			getInput(e){
				this.money = e.target.value;
			},
			myclick(){
				 this.$refs.verify.show();
				// uni.showModal({
				//     title: '兑换失败',
				//     content: '金币不足',
				//     success: function (res) {
				//         if (res.confirm) {
				//             console.log('用户点击确定');
				//         } else if (res.cancel) {
				//             console.log('用户点击取消');
				//         }
				//     }
				// });
			},
			//  提现金币
			getGoldWithdraw() {
				let that = this;
				var data = {};
				if(that.money < 0.3){
					uni.showToast({
						title:'提现金额应大于0.3元',
						icon:'none'
					})
					return 
				}
				data["uid"] = that.stroge.uid;
				data["amount"] = that.money;
				data["type"] = that.newCode;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'users/withdraw',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					if (res.data.code == 0) {
						let objs = res.data.data.data;
						let arrays = [];
						for(let key in objs){
							 arrays.push(objs[key]);
						}
						that.goldList = arrays;
						uni.navigateBack()
					}else if(res.data.code == 500){
						that.codeWeiChat = true
					}
					uni.showToast({
						title: res.data.msg,
						icon: 'none'
					})
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			
			goBtn(){
				this.inputNum = this.money
			},
		    getCode:function(e){
				// this.getGoldWithdraw();
			 },
			yzbtn:function(){
			    this.$refs.verify.show();
			 },
		}
	}
</script>

<style lang="scss" scoped>
	.content{
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
		.coverPop{
			width: 750rpx;
			height: 420rpx;
			background-color: #FFFFFF;
			border-radius: 10rpx  10rpx 0 0;
			position: absolute;
			left: 0rpx;
			top: -400rpx;
			
			.weichatIcon{
				width: 120rpx;
				height: 120rpx;
				// background-color: #f40;
				display: block;
				margin: 60rpx auto 40rpx;
			}
			.coverBtn{
				width: 685rpx;
				height: 80rpx;
				background-color: #FFAC38;
				border-radius: 50rpx;
				margin: 0 auto;
				display: flex;
				justify-content: center;
				align-items: center;
				text{
					font-size: 34rpx;
					color: #FFFFFF;
					font-weight: 600;
				}
			}
		} 
		.boxs{
			width: 100%;
			height: 275rpx;
			padding: 0 30rpx;
			box-sizing: border-box;
			background-color: #FFFFFF;
			.boxstitles{
				width: 100%;
				height: 80rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				font-size: 36rpx;
				font-family: SourceHanSansCN-Regular;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
			}
			.boxcontent{
				width: 686rpx;
				height: 120rpx;
				// background: #EBEBEB;
				opacity: 1;
				border-radius: 8rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				border-bottom: 1rpx solid #E1E1E1;
				input{
					font-size: 28rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 62rpx;
					color: #333;
					opacity: 1;
					margin-top: 10rpx;
					// text-align: fl;
				}
				.defult{
					font-size: 28rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 30rpx;
					color: #B4B4B4;
					opacity: 1;
				}
				.signs{
					
					font-size: 60rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 62rpx;
					color: #2B2B2B;
					opacity: 1;
				}
			}
			.btntext{
				width: 100%;
				height: 70rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				text{
					font-size: 24rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 30rpx;
					color: #A1A1A1;
					opacity: 1;
				}
			}
		}
		   .yzbtn{
		        width: 200rpx;
		        height: 60rpx;
		        margin: 10rpx auto;
		        background: #56ACF9;
		        border-radius: 10rpx;
		        line-height: 60rpx;
		        color: #FFFFFF;
		        text-align: center;
		    }
	}
</style>
