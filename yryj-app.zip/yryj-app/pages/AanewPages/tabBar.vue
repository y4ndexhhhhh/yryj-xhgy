<template>
	<view class="content">
		<view class="tab-active" >
			<view class="tab-content" @click="handletabschenge(0)" :class="orderType==0?'active-box':''">
				推荐
			</view>
			<view class="tab-content" @click="handletabschenge(1)" :class="orderType==1?'active-box':''">
				阅读
			</view>
			<view class="tab-content" @click="handletabschenge(2)" :class="orderType==2?'active-box':''">
				视频
			</view>
		</view>
	</view>
</template>

<script>
</script>

<style lang="scss" scoped>
	.content {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
		position: relative;
	    
		.tab-active {
			display: flex;
			color: #919191;
			align-items: center;
			width: 100%;
			justify-content: space-around;
			height: 80rpx;
			background-color: #FFFFFF;
			font-size: 28rpx;
			padding: 0 30rpx;
			box-sizing: border-box;
			position: fixed;
			left: 0;
			top: 0;
			z-index: 9999;
			.tab-content {
				width: 20%;
				text-align: center;
				height: 100%;
				line-height: 80rpx;
				padding: 0 10rpx;
				box-sizing: border-box;
	
				image {
					width: 30rpx;
					height: 28rpx;
					vertical-align: middle;
					margin-left: 6rpx;
				}
			}
		}
	
		.active-box {
			width: 80%;
			border-bottom: 2px solid #FFAC38;
			color: #4E73E8;
		}
	}
</style>
