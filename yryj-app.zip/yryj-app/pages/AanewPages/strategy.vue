<template>
	<!-- 玩法攻略 -->
	<view class="content">
		<view class="title">一、如何获取金币</view>
		<view class="title2">1.加入会员</view>
		<view class="text">1) 加入系统超级会员，需支付10元系统建设费，加入成功后系统奖励1千健康积分和1千元提现手续费。</view>
		<view class="title2">2.签到</view>
		<view class="text">1）累计签到次数大于90次小于180次的会员患病可申请医保自付差额援助；累计签到次数大于180次以上的会员患病可申请医疗自费差额援助；每次签到均可获得数量不等的金币，连续签到可得更多金币；签到页面继续看视频可获得翻倍奖励。</view>
		<view class="text">2）连续签到第一周可得金币1088，第二、三周 1888，第四周 2888。</view>
		<view class="title2" style="">3.绑定个人信息</view>
		<view class="text">
			1) 绑定个人信息可得5000金币。
		</view>
		<view class="title2" style="">4.邀请好友</view>
		<view class="text">
			1）每成功邀请一位好友加入本APP会员，您可获得1万金币奖励。
		</view>
		<view class="text">
			2）好友在填写邀请码后您可以一直获取好友10%的金币奖励。
		</view>
		<view class="text">
			3）您可将活动页面通过微信、QO或者面对面、链接等方式分享给好友且好友首次下载后在10日内填写邀请码的，则视为您邀请成功。（注∶ 应用商店内直接下载无效）。
		</view>
		<view class="text">
			4）合伙人成功邀请好友加入会员的除奖励1万金币外，另外获得额外10元增值积分奖励。
		</view>
		<view class="text">
			5）会员个人账户低于3千健康积分的，金币每天凌晨自动兑换成健康积分，放入您的账户中，个人账户高于3千积分的，可手动兑换成增值积分或每天凌晨自动完成兑换。
		</view>
		<view class="text">
			6）增值积分可自主兑换为期权或现金。
		</view><view class="text">
			7）累计现金达到提现额度后，可申请提现，提现— 般3-5天到账，如遇双休日、节假日或提现高峰期， 提现到账时间可能会出现延迟，请耐心等待。
		</view>
		<view class="title2" style="">5.参加活动</view>
		<view class="text">
			1）走路得金币，根据每天走路步数可获得相应得金币，在本页面看视频可翻倍奖励，连走7天可领取高额金币奖励。
		</view>
		<view class="text">
			2）吃饭得金币，您每天可以在不同的时间段领取早餐、 午餐、晚餐、夜宵的金币补贴。
		</view>
		<view class="title2" style="">6.看视频、读文章</view>
		<view class="text">
			阅读文章和观看视频均可获得数额不等的金币奖励。
		</view>
		<view class="title">一、添加【亿人Y家】微信公众号获取10000金币奖励。</view>
		<view class="text">
			1、依次打开我的-金币管理-点击客服-人工客服，微信扫描，添加公众号。
		</view>
		<view class="text" style="margin-top: 10rpx;">
			2、提供相应手机号或者实名认证名，申请获取金币注∶金币发放存在延后的情况，一般48小时内发放到用户账户.
		</view>
		<view class="text" style="margin-top: 10rpx;">
			注∶金币发放存在延后的情况，一般48小时内发放到用户账户。
		</view>
		<view class="title">二、如何增加活跃度</view>
		<view class="text">
			1、新用户注册得50活跃度。
		</view>
		<view class="text">
			2、打开一次APP得5活跃度，每天50活跃度。
		</view>
		<view class="text">
			3、浏览一篇资讯内容，得10活跃度，每天150活跃度。
		</view>
		<view class="text">
			4、观看一次完整视频，得20活跃度，每天150活跃度。
		</view>
		<view class="text">
			5、不同的活跃等级会在您原有获得金币奖励的基础上 额外得到一定的活动金币奖励。
		</view>
		<view class="text">
			6、活跃等级统计时间为最近30天。
		</view>

		<view class="boxContent" style="margin-top: 20rpx;">
			<view class="titleBox">
				<view class="items">
					<text>活跃度</text>
				</view>
				<view class="items">
					<text>活跃等级</text>
				</view>
				<view class="items">
					<text>额外奖励</text>
				</view>
			</view>
			<view class="titleBox" style="border-top:none;margin-bottom: 20rpx;">
				<view class="items">
					<view class="itemnav">0-100</view>
					<view class="itemnav">101-800</view>
					<view class="itemnav">801-1500</view>
					<view class="itemnav">1501-2200</view>
					<view class="itemnav">2201-2900</view>
					<view class="itemnav">2901-3600</view>
					<view class="itemnav">3601-4300</view>
					<view class="itemnav">4301-5000</view>
					<view class="itemnav">5000+</view>
				</view>
				<view class="items">
					<view class="itemnav">LV0</view>
					<view class="itemnav">LV1</view>
					<view class="itemnav">LV2</view>
					<view class="itemnav">LV3</view>
					<view class="itemnav">LV4</view>
					<view class="itemnav">LV5</view>
					<view class="itemnav">LV6</view>
					<view class="itemnav">LV7</view>
					<view class="itemnav">LV8</view>
				</view>
				<view class="items">
					<view class="itemnav">无</view>
					<view class="itemnav">+6.0%</view>
					<view class="itemnav">+9.0%</view>
					<view class="itemnav">+12.0%</view>
					<view class="itemnav">+15.0%</view>
					<view class="itemnav">+18.0%</view>
					<view class="itemnav">+21.0%</view>
					<view class="itemnav">+24.0%</view>
					<view class="itemnav">+27.0%</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {

	}
</script>

<style lang="scss" scoped>
	page {
		width: 100%;
		height: 100vh;
		background-color: #FFFFFF;
	}

	.content {
		width: 100%;
		height: 100vh;
		background-color: #FFFFFF;
		padding: 0 30rpx;
		box-sizing: border-box;

		.title {
			opacity: 1;
			width: 100%;
			color: #000;
			display: flex;
			padding: 10rpx 0;
			font-weight: 600;
			font-size: 36rpx;
			align-items: center;
			font-family: PingFang SC;
			justify-content: flex-start;
		}

		.title2 {
			width: 100%;
			height: 60rpx;

			font-size: 32rpx;
			font-family: PingFang SC;
			font-weight: 600;
			line-height: 60rpx;
			color: #000;
			opacity: 1;
		}

		.text {
			width: 100%;
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			line-height: 40rpx;
			color: #333333;
			opacity: 1;
		}

		.boxContent {
			width: 100%;
			height: auto;
			padding: 0 20rpx;
			box-sizing: border-box;

			.titleBox {
				width: 100%;
				min-height: 70rpx;
				border: 1rpx solid #C2C2C2;
				// border-bottom: none;
				display: flex;
				justify-content: center;
				align-items: center;
				.items {
					flex: 1;
					display: flex;
					min-height: 70rpx;
					justify-content: center;
					align-items: center;
					flex-direction: column;
					.itemnav{
						width: 100%;
						height: 60rpx;
						display: flex;
						justify-content: center;
						align-items: center;
						
						
						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						line-height: 60rpx;
						color: #333333;
						opacity: 1;
					}
					// flex-direction: column;
				}
			}
		}
	}
</style>
