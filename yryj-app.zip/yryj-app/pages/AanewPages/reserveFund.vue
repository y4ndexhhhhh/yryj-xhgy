<template>
	<view class="content">
		<view class="itemsNum">
			<text>账户余额</text>
			<text class="blue">{{money}}</text>
		</view>
		<mybottom name="充值" @sublimt="goMoney"></mybottom>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				money:'00.00'
			}
		},
		onLoad(options) {
			console.log(options)
			this.money = options.money
		},
		methods:{
			goMoney(){
				console.log('1111')
				uni.navigateTo({
					url:'/pages/stotails/stotails'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.content{
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
		.itemsNum{
			width: 100%;
			height: 240rpx;
			background-color: #FFFFFF;
			display: flex;
			justify-content: center;
			align-items: center;
			flex-flow: column;
			text{
				
				font-size: 40rpx;
				font-family: PingFang SC;
				font-weight: 500;
				// line-height: 24px;
				color: #333333;
				opacity: 1;
			}
			.blue{
				font-size: 92rpx;
				font-family: PingFang SC;
				font-weight: 800;
				// line-height: 24px;
				color: #4B65F1;
				opacity: 1;
			}
		}
	}
</style>
