<template>
<view>
<!--pages/number/number.wxml-->
<view class="conter">
	 <view class="jifen">{{stroge.popularity_num}}</view>
     <view class="hread">积分兑换</view>
<!--	 <view class="rightBg" @click="goGrdeList">-->
<!--	 	<text class="text">积分明细</text>-->
<!--	 </view>-->
</view>
<!-- <view class='btn' catchtap="ationgs">兑换等待期</view> -->
<view class="btn" @tap.stop="xiangmuzhuanyuan">兑换项目专员</view>
<view class="btn" @tap.stop="putong">兑换普通合伙人</view>
<view class="btn" @tap.stop="duihuan">兑换贡献值</view>
</view>
</template>

<script>
// pages/number/number.js
const app = getApp();

export default {
  data() {
    return {
      stroge: '',
      pues: '',
      puess: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getstroge();
    this.exchange();
    this.exchanges();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},
  methods: {
	  goGrdeList(){
		  uni.navigateTo({
		  	url:'../AanewPages/pointsList'
		  })
	  },
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    /*---等待值兑换---*/
    ationgs() {
      uni.navigateTo({
        url: '/pages/aiting/aiting'
      });
    },

    /*---合伙人亿积分兑换---*/
    exchange() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'partner/exchange_partner_yjf',
        method: "POST",
        data: {
          type: 10,
          uid: that.stroge.uid
        },

        success(res) {
          that.setData({
            pues: res.data.data
          });
        }

      });
    },

    /*---亿积分兑换---*/
    exchanges() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'partner/exchange_partner_yjf',
        method: "POST",
        data: {
          type: 15,
          uid: that.stroge.uid
        },

        success(res) {
          that.setData({
            puess: res.data.data
          });
        }

      });
    },

    /*---项目专员---*/
    xiangmuzhuanyuan() {
      var that = this;
      uni.navigateTo({
        url: '/pages/exchan/exchan?type=15&order=2&unit=' + that.puess.unit_price + '&need_yjf=' + that.puess.need_yjf + '&usable_yjf=' + that.puess.usable_yjf
      });
    },

    /*---普通合伙人---*/
    putong() {
      var that = this;
      uni.navigateTo({
        url: '/pages/exchang/exchang?type=10&order=2&unit=' + that.pues.unit_price + '&need_yjf=' + that.pues.need_yjf + '&usable_yjf=' + that.pues.usable_yjf + '&min_stock=' + that.pues.min_stock
      });
    },

    /*---兑换贡献值---*/
    duihuan() {
      var that = this;
      uni.navigateTo({
        url: '/pages/contribution/contribution'
      });
    }

  }
};
</script>
<style>
/* pages/number/number.wxss */
.conter {
  width: 100%;
  margin-bottom: 30rpx;
  position: relative;
  /* background-color: blue; */
}

.hread {
  text-align: center;
  margin: auto;
  color:#333333;
}

.jifen {
  padding: 20px 0;
  text-align: center;
  font-size: 16px;
  color: #4B65F1;
  font-size: 70rpx;
  
}
.rightBg{
	width: 192rpx;
	height: 72rpx;
	background: #FFAC38;
	opacity: 1;
	border-radius: 40rpx 0px 0px 40rpx;
	position: absolute;
	right: 0;
	top: 30rpx;
	text-align: center;
}
	.text{
		font-size: 32rpx;
		font-family: SourceHanSansCN-Regular;
		line-height: 72rpx;
		color: #FFFFFF;
		opacity: 1;
	}

.btn {
	width: 598rpx;
	height: 142rpx;
	background: #6178F3;
	opacity: 1;
	border-radius: 72rpx;
  line-height: 142rpx;
  margin: 0 auto;
  margin-top: 20px;
  text-align: center;
  font-size: 44rpx;
  font-family: SourceHanSansCN-Regular;
  color: #FFFFFF;
  opacity: 1;
}

/* .list{
  color:#fff;
  background:linear-gradient(138deg,rgba(86,206,248,1) 0%,rgb(67, 110, 238) 100%);
}
.frist{
  color:#67a5c3;
} */
</style>