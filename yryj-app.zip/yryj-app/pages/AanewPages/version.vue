<template>
	<view class="content">
		<view class="itemsBox">
			<view class="itemsLeft">
				<text>版本说明</text>
			</view>
			<view class="itemsRight">
				<text>当前版本{{version}}</text>
					<!-- <image src="/static/images/my/arrow_right.png" mode="" class="arrowRignth"></image> -->
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				version:''
			}
		},
		onLoad() {
			let that = this;
			 plus.runtime.getProperty(plus.runtime.appid, function(widgetInfo) { 
				 that.version = widgetInfo.version
			 })
		},
		methods:{
			goMonnom(url){
				uni.navigateTo({
					url:url
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	page{
		width:100%;
		height: 100vh;
		background-color: #F8F9FF;
	}
	.content{
		width:100%;
		height: 100vh;
		background-color: #F8F9FF;

	.itemsBox {
		width: 100%;
		height: 120rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #FFFFFF;
		padding: 0 30rpx;
		box-sizing: border-box;
		border-bottom: 1rpx solid #F8F9FF;
	
		.itemsLeft {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;
	
			.icons {
				width: 52rpx;
				height: 52rpx;
				// background-color: #f40;
			}
	
			text {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
				margin-left: 20rpx;
			}
		}
	
		.itemsRight {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-end;
			align-items: center;
	        .redO{
				width: 20rpx;
				height: 20rpx;
				background: #FE0707;
				border-radius: 50%;
				opacity: 1;
				
			}
			.arrowRignth {
				margin-left: 20rpx;
				width: 13rpx;
				height: 24rpx;
				// background-color: #f40;
			}
		}
	}
  }
</style>
