<template>
	<view class="content">
		<view class="shopBoxs" v-for="(item,index) in freeShop" @click="getFreeshop(item.id)">
			<image v-if="item.images == ''" src="/static/images/my/zanwei.png" mode="aspectFit" class="imgs"></image>
			<image v-else :src="item.images" mode="aspectFit" class="imgs"></image>
			<view class="texts">
				<view class="shopname">{{item.title}}+{{item.give_integral}}金币</view>
				<view class="desc">
					（商品只需支付相应运营）
				</view>
			</view>
			<view class="btnget">
				<view class="mygetBtn">
					免费领
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import progressBar from '@/components/chocolate-progress-bar/chocolate-progress-bar.nvue';
	var sha_1 = require("../../utils/sha_1.js");
		const app = getApp();
	import popUp from '@/components/PopUp.vue'
	var rewardModule = uni.requireNativePlugin("ZjSDKRewardModule");
	var splashModule = uni.requireNativePlugin("ZjSDKSplashModule")
	var ZjSplashView = uni.requireNativePlugin("ZjSplashView")
	const modal = uni.requireNativePlugin('modal');
	
	export default {
		components: {
			progressBar,
			popUp
		},
		data() {
			return {
				stroge:'',
				freeShop:[],
				stroge:''
			}
		},
		onLoad() {
			this.stroge = uni.getStorageSync('key');
		},
		onShow() {
			this.getNewShop();
		},
		methods: {
			getFreeshop(id) {
				uni.navigateTo({
					url: '/pages/AanewPages/freeCharge?id='+id
				})
			},
			getNewShop() {
				let that = this;
				app.$request({
					url: 'login/goods',
					data: {},
					method: 'post'
				}).then(res => {
					console.log(res.data.data)
					if (res.data.code == 0) {
						that.freeShop = res.data.data;
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	page{
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
	}
	.content{
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
		display: flex;
		justify-content: flex-start;
		align-items: center;
		flex-direction: column;
		.shopBoxs {
			width: 100%;
			height: 220rpx;
			margin-top: 10rpx;
			background: #FFFFFF;
			border-radius: 8rpx;
			display: flex;
			align-items: center;
			padding: 0 30rpx;
			box-sizing: border-box;
			.imgs {
				width: 200rpx;
				height: 200rpx;
			}
			.texts {
				width: 540rpx;
				height: 100%;
				display: flex;
				flex-flow: column;
				justify-content: center;
				padding-left: 20rpx;
				box-sizing: border-box;
				.shopname {
					width: 400rpx;
					height: 100rpx;
					overflow: hidden;
					white-space: nowrap;
					text-overflow: ellipsis;
					font-size: 40rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					line-height: 60rpx;
					color: #4D4D4D;
					opacity: 1;
					
				}
				.desc {
					font-size: 24rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 56rpx;
					color: #AAAAAA;
					opacity: 1;
				}
		
			}
		
			.btnget {
				width: 115rpx;
				height: 100%;
				display: flex;
				justify-content: center;
				align-items: center;
				.mygetBtn {
					width: 110rpx;
					height: 60rpx;
					background: #FF5151;
					opacity: 1;
					border-radius: 30rpx;
					text-align: center;
					font-size: 30rpx;
					font-family: SourceHanSansCN-Medium;
					line-height: 60rpx;
					color: #FFFFFE;
					opacity: 1;
				}
			}
		}
	}
</style>
