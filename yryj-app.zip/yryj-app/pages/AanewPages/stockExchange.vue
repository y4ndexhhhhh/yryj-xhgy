<template>
	<view class="content">
		<view class="boxs">
			<view class="boxstitles">
				<text>金币数量</text>
			</view>
			<view class="boxcontent">
				<input type="text" :value="goldCoin" placeholder="兑换的金币数量" placeholder-class="defult"/>
			</view>
		</view>
		<view class="boxs">
			<view class="boxstitles">
				<text>分红股数</text>
			</view>
			<view class="boxcontent">
				<input type="text" v-model="nums" @input="getStrongmy" placeholder="请输入分红股数量" @blur="getmyGold" placeholder-class="defult"/>
			</view>
			<view class="btntext">
				<text>约{{allMoney}}个金币兑换1分红股 每股{{eveyMoney}}约元</text>
			</view>
		</view>
		<mybottom name="确认兑换" @sublimt="getGoldWithdraw"></mybottom>
	</view>
</template>

<script>
	var sha_1 = require("../../utils/sha_1.js");
		const app = getApp();
	export default{
		data(){
			return{
				goldCoin:0,
				stroge:'',
				nums:'',  // 可兑换股票数
				eveyMoney:'', // 每股多少钱
				allMoney:'',
				stroNums:''
			}
		},
		onLoad(options) {
			
			this.stroge = uni.getStorageSync('key');
        	let vipNumber = uni.getStorageSync('VipNumber');
			this.goldCoin = options.goldCoin;
			
			this.allMoney =Math.floor(1000 * (vipNumber.count / 100000));
			this.eveyMoney =((vipNumber.count / 100000)).toFixed(2);
	
			this.stroNums = (this.goldCoin / this.allMoney).toFixed(2);
		},
		methods:{
			getmyGold(){
				this.goldCoin = this.allMoney * this.nums
			},
			getStrongmy(e){
				let nums = e.detail.value;
				this.goldCoin = this.allMoney * nums
			},
			myclick(){
				uni.showModal({
				    title: '兑换失败',
				    content: '金币不足',
				    success: function (res) {
				        if (res.confirm) {
				            console.log('用户点击确定');
				        } else if (res.cancel) {
				            console.log('用户点击取消');
				        }
				    }
				});
			},
			//  提现金币
			getGoldWithdraw() {
				let that = this;
				if(this.nums > this.stroNums){
					uni.showToast({
						title:'金币不足',
						icon:'none'
					})
				}
				var data = {};
				data["uid"] = that.stroge.uid;
				data["bonus"] = that.nums;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'users/bonus',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					if (res.data.code == 0) {
						
					}
					uni.showToast({
						title: res.data.msg,
						icon: 'none'
					})
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.content{
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
		.boxs{
			width: 100%;
			min-height: 200rpx;
			padding: 0 30rpx;
			box-sizing: border-box;
			background-color: #FFFFFF;
			.boxstitles{
				width: 100%;
				height: 80rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				font-size: 36rpx;
				font-family: SourceHanSansCN-Regular;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
			}
			.boxcontent{
				width: 686rpx;
				height: 120rpx;
				background: #EBEBEB;
				opacity: 1;
				border-radius: 8rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				input{
					font-size: 35rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 40rpx;
					color: #333;
					opacity: 1;
					text-align: center;
				}
				.defult{
					font-size: 35rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 40rpx;
					color: #B4B4B4;
					opacity: 1;
					text-align: center;
				}
			}
			.btntext{
				width: 100%;
				height: 70rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				text{
					font-size: 24rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 30rpx;
					color: #A1A1A1;
					opacity: 1;
				}
			}
			// display: flex;
			// justify-content: ;
		}
	}
</style>
