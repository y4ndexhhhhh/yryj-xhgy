<template>
	<!-- 绑定推荐人 -->
	<view class="content">
		<view class="itemsBox">
			<view class="itemsLeft">
				<!-- <image src="" mode="" class="icons"></image> -->
				<text>推荐人ID</text>
			</view>
			<view class="itemsRight">
				<input type="text" v-model="phone" placeholder="请输入推荐人ID" class="input" placeholder-class="deful" />
			</view>
		</view>
		<mybottom @sublimt="BindContacts"></mybottom>
	</view>
</template>

<script>
	const sha_1 = require("../../utils/sha_1.js");
	const app = getApp();
	export default {
		data() {
			return {
				phone: '',
				stroge:''
			}
		},
		onLoad() {
			this.stroge = uni.getStorageSync('key');
		},
		methods:{
			BindContacts() {
				let that = this;
				if(that.phone == ''){
					uni.showToast({
						title:'请输入推荐人id',
						icon:'none'
					})
					return;
				}
				var data = {};
				data["uid"] = that.stroge.uid;
				data["t_uid"] = that.phone;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'users/recommand',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					console.log(res)
					if (res.data.code == 0) {
						that.code = (res.data.data.signCount - 1)
					}
					uni.showToast({
						title: res.data.msg,
						icon: 'none'
					})
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	page{
		width: 100%;
		height: 100vh;
		background-color:#F8F9FF;
	}
	.content {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;

		.itemsBox {
			width: 100%;
			height: 120rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			background-color: #FFFFFF;
			padding: 0 30rpx;
			box-sizing: border-box;
			border-bottom: 1rpx solid #F8F9FF;

			.itemsLeft {
				flex: 1;
				height: 100%;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.icons {
					width: 52rpx;
					height: 52rpx;
					background-color: #f40;
				}

				text {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 30rpx;
					color: #333333;
					opacity: 1;
					margin-left: 20rpx;
				}
			}

			.itemsRight {
				flex: 2.5;
				height: 100%;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.input {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 24rpx;
					color: #333333;
					opacity: 1;
					// text-align: rig;
				}

				.deful {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 30rpx;
					color: #DBDBDB;
					opacity: 1;
				}

				.avatar {
					width: 60rpx;
					height: 60rpx;
					background: #DBDBDB;
					border-radius: 50%;
					opacity: 1;
					margin-right: 10rpx;
				}

				.arrowRignth {
					width: 20rpx;
					height: 28rpx;
					background-color: #f40;
				}
			}
		}
	
	}
</style>
