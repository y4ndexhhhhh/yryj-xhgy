<template>
	<view class="content">
		
	</view>
</template>

<script>
	export default{
		
	}
</script>

<style lang="scss" scoped>
	
</style>
