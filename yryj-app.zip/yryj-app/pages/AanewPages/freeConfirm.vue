<template>
	<view class="content">
		<view class="adrestext">
			<view class="imgBox">
				<image :src="freeShop.images" mode="aspectFit" class="imgs"></image>
				<!-- <image :src="freeShop.images" mode="" class="imgs"></image> -->
			</view>
			<view class="textContent">
				<view class="name">
					<text>{{freeShop.title}}</text>
				</view>
				<view class="desc">
					<text v-if="freeShop.simple_desc == ''">暂无</text>
					<text v-else>{{freeShop.simple_desc}}</text>
					<!-- <text>消脂滋润</text> -->
				</view>
				<view class="price">
					<text v-if="freeShop.price == ''">￥0.00</text>
					<text v-else>￥{{freeShop.price}}</text>
				</view>
			</view>
		</view>
		<view class="btnBox">
			<view class="left">
				<text v-if="freeShop.price == ''" style="text-decoration:line-through;">已优惠0.00</text>
				<text v-else>已优惠{{freeShop.price}}</text>
				<text style="margin-right: 10rpx;margin-left: 10rpx;">含运费￥{{kuaidi}}</text>
				<text>总计</text>
				<text class="red">￥{{kuaidi}}</text>
			</view>
			<view class="rgiht" @click="submitOrder">
				<text>立即支付</text>
			</view>
		</view>

		<view class="Popup" @touchmove.stop.prevent="moveHandle" v-if="popupCode">
			<view class="noTip">
				<view class="topTip">
					<text class="red">支付成功</text>
				</view>
				<view class="topBtn">
					<text>恭喜您获得</text>
					<text>10000</text>
					<text>金币</text>
				</view>
			</view>
		</view>
		<popup-bottom :show="popupShow" @close="handleClose">
			<view class="popup-content">
				<view class="popup-title">
					<image class="image" @click="handleClose" src="../../static/cart/order/arrow_left.png" mode=""></image>
					<view class="viewtext">
						支付方式
					</view>
				</view>
				<view class="popup-item" v-for="(item,index) in paymentList">
					<view class="popup-item-r">
						<image class="image" :src="item.src" mode=""></image>
						<view class="" style="margin-left: 17rpx;">
							{{item.title}}
						</view>
					</view>
					<image class="image" v-if="checkerId == item.id" @click="clickCheckerBox(item)" src="/static/cart/order/gouxuan.png"
					 mode="aspectFit"></image>
					<image class="image" v-else @click="clickCheckerBox(item)" src="/static/cart/order/nogouxuan.png" mode="aspectFit"></image>
				</view>
				<view class="popup-item" style="height: 100rpx;justify-content: center;align-items: center;">
					<view class="popup-btn" @click="getPay">
						确认支付
					</view>
				</view>
			</view>
		</popup-bottom>
	</view>
</template>

<script>
	import PopupBottom from '@/components/popup-bottom/popup-bottom';
	var sha_1 = require("../../utils/sha_1.js");
	const app = getApp();
	export default {
		components: {
			PopupBottom
		},
		data() {
			return {
				rank: '-2',
				popupCode: false,
				popupShow: false,
				checkerId: 0,
				freeShop: '',
				kuaidi:0,
				id: '',
				orderNum: '',
				stroge: '',
				paymentList: [{
						id: 1,
						src: "/static/images/my/gold.png",
						title: "金币支付"
					},
					{
						id: 2,
						src: "/static/cart/order/wenchat.png",
						title: "微信支付"
					}

				]
			}
		},
		onLoad(options) {
			this.stroge = uni.getStorageSync('key');
			this.orderNum = options.orderNo;
			this.id = options.id;
			this.total = options.total_amount;
			this.goods = options.goods_amount;
			this.kuaidi = options.kuaidi;
			console.log(options)
			this.getGoodsDetil();
		},
		methods: {
			moveHandle() {},
			goAddres() {
				uni.navigateTo({
					url: './addres'
				})
			},
			getGoodsDetil() {
				let that = this;
				var data = {};
				data["id"] = that.id;
				var arr = {
					"data": data
				};
				console.log(arr);
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'login/goodsdetail',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					console.log(res)
					if (res.data.code == 0) {
						that.freeShop = res.data.data;
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			goPay() {
				if (!this.popupCode) {
					this.popupCode = !this.popupCode
				}
			},
			/**
			 * 隐藏遮罩层事件
			 */
			handleClose() {
				this.popupShow = false
			},
			submitOrder() {
				this.popupShow = true;
			},
			getPay() {
				let that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				data["orderNo"] = that.orderNum;
				data["payment_id"] = that.checkerId;
				var arr = {
					"data": data
				};
				console.log(arr);
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'login/pay',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					console.log(res)
					if (res.data.code == 0) {
						if (that.checkerId == 2) {
							const parameter = res.data.data;
							that.goPay(parameter);
						} else {
							that.popupCode = true;
							that.popupShow = false;
						}


					} else {
						that.popupCode = false;
						that.popupShow = false;
						uni.showToast({
							title: "支付失败",
							icon: 'none'
						})
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			clickCheckerBox(item) {

				this.checkerId = item.id
			},
			goPay(parameter) {
				console.log(parameter)
				var time = Date.parse( new Date() ).toString();//获取到毫秒的时间戳，精确到毫秒
				time = time.substr(0,10);//精确到秒
				// let objData = {
				// 	"appid":parameter.appid,
				// 	 "noncestr":parameter.nonce_str,
				// 	 "package":'Sign=WXPay',
				// 	 "partnerid":parameter.mch_id,
				// 	 "prepayid":parameter.prepay_id,
				// 	 "timestamp":time,
				// 	 "sign":parameter.sign
				// }
				// console.log(objData)
				let that = this;
				uni.requestPayment({
					provider: 'wxpay',
					orderInfo: parameter, //微信、支付宝订单数据
					success: function(res) {
						that.popupCode = true;
						that.popupShow = false;
						console.log('success:' + JSON.stringify(res));
					},
					fail: function(err) {
						console.log('fail:' + JSON.stringify(err));
					}
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
	}

	.content {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;

		.addres {
			width: 100%;
			height: 135rpx;
			padding: 0 32rpx;
			background-color: #FFFFFF;
			border-bottom: 1rpx solid #F8F9FF;
			display: flex;

			.left {
				flex: 5;
				height: 100%;
				// background-color: #f40;
				display: flex;
				justify-content: center;
				align-items: flex-start;
				flex-flow: column;

				.name {

					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 500;
					// line-height: 56px;
					color: #4D4D4D;
					opacity: 1;

					text {
						margin-right: 20rpx;
					}
				}

				.addtext {
					width: 560rpx;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;

					text {

						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 400;
						// line-height: 56px;
						color: #4D4D4D;
						opacity: 1;
					}
				}
			}

			.right {
				flex: 1;
				height: 100%;
				display: flex;
				justify-content: flex-end;
				align-items: center;

				.arrow {
					width: 13rpx;
					height: 24rpx;
					// background-color: #F56723;
				}
			}
		}

		.adrestext {
			width: 100%;
			height: 280rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			background-color: #FFFFFF;
			padding: 0 30rpx;
			box-sizing: border-box;

			.imgBox {
				width: 212rpx;
				height: 212rpx;
				// background-color: #f40;

				.imgs {
					width: 212rpx;
					height: 212rpx;
					background: rgba(0, 0, 0, 0);
					opacity: 1;
				}
			}

			.textContent {
				margin-left: 20rpx;
				width: 470rpx;

				.name {
					font-size: 40rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					line-height: 40rpx;
					color: #4D4D4D;
					opacity: 1;
				}

				.desc {
					width: 470rpx;
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 56rpx;
					color: #AAAAAA;
					opacity: 1;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
				}

				.price {

					font-size: 40rpx;
					margin-top: 10rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 40rpx;
					color: #FF5151;
					opacity: 1;
				}
			}
		}

		.btnBox {
			width: 100%;
			height: 135rpx;
			position: fixed;
			left: 0;
			bottom: 0;
			background-color: #FFFFFF;
			display: flex;

			.left {
				width: 450rpx;
				height: 135rpx;
				display: flex;
				justify-content: center;
				align-items: center;

				text {

					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 56rpx;
					color: #575757;
					opacity: 1;
				}

				.red {

					font-size: 40rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 40rpx;
					color: #FF5151;
					opacity: 1;
				}
			}

			.rgiht {
				width: 300rpx;
				height: 135rpx;
				background: #FFAC38;
				opacity: 1;
				display: flex;
				justify-content: center;
				align-items: center;

				text {
					font-size: 44rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 24rpx;
					color: #FFFFFF;
					opacity: 1;
				}
			}
		}

		.Popup {
			width: 100%;
			height: 100vh;
			top: 0;
			left: 0;
			position: absolute;
			z-index: 99999;
			background-color: rgba(0, 0, 0, .4);
			display: flex;
			justify-content: center;
			align-items: center;
			flex-flow: column;

			.boxContet {
				width: 600rpx;
				height: 210rpx;
				background: #FFFFFF;
				opacity: 1;
				border-radius: 8rpx;

				.boxTop {
					width: 100%;
					height: 110rpx;
					border-bottom: 1rpx solid #ECECEC;
					display: flex;
					justify-content: center;
					align-items: center;

					text {
						font-size: 36rpx;
						font-family: SourceHanSansCN-Regular;
						line-height: 40rpx;
						color: #FF5451;
						opacity: 1;
					}

				}

				.boxClose {
					width: 100%;
					height: 98rpx;
					display: flex;
					justify-content: center;
					align-items: center;

					text {
						font-size: 30rpx;
						font-family: SourceHanSansCN-Regular;
						line-height: 40rpx;
						color: #BBBBBB;
						opacity: 1;
					}
				}
			}

			.noTip {
				width: 600rpx;
				height: 320rpx;
				background-color: #FFFFFF;
				border-radius: 8rpx;

				.topTip {
					width: 100%;
					height: 170rpx;
					border-bottom: 1rpx solid #ECECEC;
					display: flex;
					justify-content: center;
					align-items: center;
					flex-flow: column;

					.red {
						font-size: 36rpx;
						font-family: SourceHanSansCN-Regular;
						line-height: 40rpx;
						color: #FF5451;
						opacity: 1;
					}

					text {
						font-size: 30rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						line-height: 40rpx;
						color: #707070;
						opacity: 1;
						margin-top: 20rpx;
					}
				}

				.topBtn {
					width: 100%;
					height: 145rpx;
					display: flex;
					justify-content: center;
					align-items: center;

					text {
						font-size: 36rpx;
						font-family: SourceHanSansCN-Regular;
						line-height: 40rpx;
						color: #FF5451;
						opacity: 1;
					}
				}
			}

			.Clear {
				width: 72rpx;
				height: 72rpx;
				// background-color: #f40;
				margin-top: 65rpx;
			}
		}

		.popup-content {
			width: 100%;
			background-color: #EEEEEE;
			border-top-left-radius: 24rpx;
			border-top-right-radius: 24rpx;

			.popup-title {
				display: flex;
				align-items: center;
				border-top-left-radius: 24rpx;
				border-top-right-radius: 24rpx;
				width: 100%;
				height: 60rpx;
				padding-left: 86rpx;
				box-sizing: border-box;
				background-color: #FFFFFF;

				.image {
					width: 17rpx;
					height: 30rpx;
				}

				.viewtext {
					font-size: 28rpx;
					color: #3b3b3b;
					margin-left: 215rpx;
				}
			}

			.popup-item {
				margin-top: 8rpx;
				width: 100%;
				height: 88rpx;
				padding-left: 86rpx;
				padding-right: 50rpx;
				box-sizing: border-box;
				display: flex;
				align-items: center;
				justify-content: space-between;
				background-color: #FFFFFF;

				.popup-item-r {
					flex: 1;
					height: 88rpx;
					display: flex;
					align-items: center;

					.image {
						width: 60rpx;
						height: 60rpx;
					}
				}

				.image {
					width: 31rpx;
					height: 31rpx;
				}
			}

			.popup-btn {
				width: 600rpx;
				height: 80rpx;
				text-align: center;
				background-color: #FFAC38;

				line-height: 80rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
				border-radius: 50rpx;
			}
		}
	}
</style>
