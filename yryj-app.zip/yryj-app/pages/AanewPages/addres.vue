<template>
	<view class="content">
		<view class="items">
			<view class="itemText">
				<text>姓名</text>
			</view>
			<view class="itemstext">
				<input type="text" v-model="username" placeholder-class="defual" placeholder="请输入你的姓名" />
			</view>
		</view>
		<view class="items">
			<view class="itemText">
				<text>手机号</text>
			</view>
			<view class="itemstext">
				<input type="text" v-model="phone" placeholder-class="defual" placeholder="请输入你的手机号" />
			</view>
		</view>
		<view class="itemsmap" style="flex-flow: column;">
			<view class="boxitem">
				<view class="itemText">
					<text>地址</text>
				</view>
				<view class="itemstext" @click="getLocation">
					<input type="text"  v-model="areas_address" disabled="disabled" placeholder-class="defual" placeholder="选择地区" />
				</view>
			</view>
			<view class="boxitem" style="height:150rpx;align-items: flex-start;padding-top: 22rpx;box-sizing: border-box;">
				<view class="itemText" style="margin-top: 9rpx;">
					<text>详细地址</text>
				</view>
				<view class="itemstext" style="justify-content:flex-start;align-items:flex-start;">
					<textarea type="text" v-model="detailed_address" placeholder-class="defual" placeholder="如：县、乡、村、街道、单元" />
				</view>
			</view>
		</view>
       <mybottom name="确认"  @sublimt="btns"></mybottom>
	</view>
</template>

<script>
	export default {
		components: {
		},
		data() {
			return {
				username:'',
				phone:'',
				areas_address:'',
				detailed_address:'',
				province:'',
				city:'',
				county:''
			}
		},
		methods: {
			DateChange(e) {
				this.date = e.detail.value
			},
			btns(){
				let obj = {
					username:this.username,
					phone:this.phone,
					areas_address:this.areas_address,
					detailed_address:this.detailed_address,
					province:this.province,
					city:this.city,
					county:this.county
				}
				uni.setStorageSync("freeAddres",obj)
                uni.navigateBack({
                	
                })
			},
			/***
			 * 判断是否开启定位服务
			 */
			getLocation() {
				let that = this;
				uni.getLocation({
					type: 'wgs84',
					geocode: true,
					success: function(res) {
						that.province=res.address.province;
						that.city=res.address.city;
						that.county=res.address.district;
						that.areas_address = res.address.province + res.address.city + res.address.district;
						let lat = res.latitude;
						let lon = res.longitude;
						
						uni.chooseLocation({
							latitude: lat,
							longitude: lon,
							success: function(res) {
								that.detailed_address = res.address;
							},
							fail(err) {
								console.log(err)
							}
						});
					}
				});

			}

		}
	}
</script>

<style lang="scss" scoped>
	.content {
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;

		.items {
			width: 686rpx;
			min-height: 120rpx;
			border-radius: 8rpx;
			margin-top: 20rpx;
			background-color: #FFFFFF;
			// box-shadow: 0px 6rpx 12rpx rgba(130, 130, 130, .16);
			padding: 0 20rpx;
			box-sizing: border-box;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.itemText {
				width: 130rpx;
				height: 30rpx;
				font-size: 30rpx;
				font-family: SourceHanSansCN-Regular;
				line-height: 30rpx;
				color: #707070;
				opacity: 1;
			}

			// .itemcontent{
			// 	width: 80rpx;
			// 	height: 80rpx;
			// 	background-color: #007AFF;
			// 	border-radius: 50%;
			// 	margin-left: 36rpx;
			// }
			.itemstext {
				width: 500rpx;
				height: 80rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				margin-left: 36rpx;

				input,
				textarea {
					font-size: 30rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					line-height: 30rpx;
					color: #333;
					opacity: 1;
					// background-color: #f40;
				}

				.defual {

					font-size: 30rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					line-height: 30rpx;
					color: #BBBBBB;
					opacity: 1;
				}
			}

		}

		.itemsmap {
			width: 686rpx;
			min-height: 180rpx;
			border-radius: 8rpx;
			margin-top: 20rpx;
			background-color: #FFFFFF;
			// box-shadow: 0px 6rpx 12rpx rgba(130, 130, 130, .16);

			display: flex;
			justify-content: flex-start;
			align-items: center;

			.boxitem {
				width: 100%;
				min-height: 120rpx;
				padding: 0 20rpx;
				box-sizing: border-box;
				display: flex;
				justify-content: center;
				align-items: center;
				// border-bottom: 1rpx solid #ececec;

				.itemText {
					width: 140rpx;
					height: 30rpx;
					font-size: 30rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 30rpx;
					color: #707070;
					opacity: 1;
				}

				.itemstext {
					width: 485rpx;
					min-height: 30rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					margin-left: 36rpx;

					input {
						width: 100%;
						font-size: 30rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						color: #333;
						opacity: 1;
						line-height: 30rpx;
					}

					textarea {
						width: 480rpx;
						height: 150rpx;
						font-size: 30rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						color: #333;
						opacity: 1;
						line-height: 30rpx;
						padding-top: 10rpx;
					}

					.defual {

						font-size: 30rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						// line-height: 0rpx;
						color: #BBBBBB;
						opacity: 1;
					}
				}
			}
		}
	}
</style>
