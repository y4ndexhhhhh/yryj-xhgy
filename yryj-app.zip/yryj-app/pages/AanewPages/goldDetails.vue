<template>

	<view class="content">
		<view class="itemsBox" v-for="(item,index) in bill_list" :key="index">
			<view class="itemsLeft">
				<view class="title">
					<text>{{item.msg}}</text>
					<!-- <text class="sign">充值</text> -->
				</view>
				<view class="times">
					<text>{{item.create_time}}</text>
				</view>
			</view>
			<view class="itemsRight">
				<text v-if="item.type == 1">+{{item.operation_integral}}</text>
				<text v-else>-{{item.operation_integral}}</text>
			</view>
		</view>
		<view class="more" @click="getMore">
			<text>{{MoreText}}</text>
		</view>
         <doudi v-if="bill_list.length == 0"></doudi>
	</view>
</template>

<script>
	// pages/bill/bill.js
	var util = require("../../utils/util.js"),
		sha_1 = require("../../utils/sha_1.js");
	const app = getApp();
	import Tabs from "../conponent/Tabs/Tabs";
let pagesnum = 1;
let nums = 0;
	export default {
		data() {
			return {
				orderType: 0,
				tabs: [{
					id: 1,
					type: 100,
					value: "全部",
					isActive: true
				}, {
					id: 2,
					type: 101,
					value: "收入",
					isActive: false
				}, {
					id: 3,
					type: 102,
					value: "支出",
					isActive: false
				}],
				stroge: '',
				describe: '',
				time: '',
				change: 0,
				bill_list: [],
				page: 0,
				type: 100,
				list: '',
				now_date: "",
				one_flag: "",
				startime:'',
				endtime:'',
				MoreText:'点击加载更多~'
			};
		},

		components: {
			Tabs
		},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			this.getTimeCalculation();
			this.getstroge();
			this.reqstatu();
			var now_date = util.formatDate(new Date());
			this.setData({
				now_date: now_date
			});
			
		},

		/**
		 * 生命周期函数--监听页面显示
		 */
		onShow: function() {},
      
		// 监听用户上拉触底事件。
		onReachBottom() {
			pagesnum++;
            this.timeForMat(pagesnum)
            
			this.reqstatu();
		},

		// 监听用户下拉刷新时间
		onPullDownRefresh() {
            this.bill_list = [];
            this.getTimeCalculation();
			this.reqstatu();
		},

		methods: {
			getMore(){
				pagesnum++;
				this.timeForMat(pagesnum)
				
				this.reqstatu();
			},
			// 一级大类 --- 标题得点击事件，从子组件传
			handletabschenge(id, prop) {
				const that = this; // 获取被点击标题的索引
				this.orderType = prop;
				that.setData({
					page: 0
				}); // 加载数据

				that.list = [];
				that.bill_list = [];
				that.reqstatu();
			},
			  /**
			   * 时间初始化计算  计算当天时间
			   */
			  getTimeCalculation() {
			    var now_time = new Date();
			    var now_Year = now_time.getFullYear();
			    var now_mon = (now_time.getMonth() + 1) > 10 ? (now_time.getMonth() + 1) : ('0' + (now_time.getMonth() + 1));
			    var now_day = (now_time.getDate() ) > 9 ? now_time.getDate() : ('0' + now_time.getDate());
			    var nowTime = now_Year + '-' + now_mon + '-' + now_day;
               
			      this.startime=nowTime+' '+'00:00:00';
			      this.endtime=nowTime+' '+'23:59:59';
			  },
              //最近七天和最近三十天时间
              timeForMat(count) {
                // 拼接时间
                let time1 = new Date()
                time1.setTime(time1.getTime() - (24 * 60 * 60 * 1000))
                let Y1 = time1.getFullYear()
                let M1 = ((time1.getMonth() + 1) > 10 ? (time1.getMonth() + 1) : '0' + (time1.getMonth() + 1))
                let D1 = (time1.getDate() + 1 > 9 ? time1.getDate() + 1 : '0' + (time1.getDate() + 1))
                let timer1 = Y1 + '-' + M1 + '-' + D1 // 当前时间
                let time2 = new Date()
                time2.setTime(time2.getTime() - (24 * 60 * 60 * 1000 * count))
                let Y2 = time2.getFullYear()
                let M2 = ((time2.getMonth() + 1) > 10 ? (time2.getMonth() + 1) : '0' + (time2.getMonth() + 1))
                let D2 = (time2.getDate() > 9 ? time2.getDate() : '0' + time2.getDate())
                let timer2 = Y2 + '-' + M2 + '-' + D2 // 之前的7天或者30天
                this.startime=timer2+' '+'00:00:00';
                this.endtime=timer1+' '+'23:59:59';
				return {
                  t1: timer1,
                  t2: timer2
                }
		
                // 　　return Y2 + '-' + M2 + '-' + D2 + ' 00:00:00';
              },
			//获取本地数据
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				that.setData({
					stroge: stroge
				});
			},

			// 获取数据
			reqstatu() {
				var that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
			    data["time_start"] =this.startime;
			    data["time_end"] = this.endtime;
				var arr = {
					"data":data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.url + 'users/scorelog',
					method: "POST",
					data: {
						data: aesData
					},
					success(res) {
						console.log(res)
						if (res.data.data.length == 0) {
							that.setData({
								bill_list: []
							});
						}

						if (res.data.code == '0') {
							let arr = res.data.data;
							if(nums == res.data.data.length){
								that.MoreText = '没有更多了~'
							}else{
							   nums = res.data.data.length;
							}
                          
							
							for (let i = 0; i < arr.length; i++) {
								arr[i]["create_time"] = util.formatTimeTwo(arr[i]["create_time"], 'Y-M-D h:m:s');
							}

							that.setData({
								bill_list: arr
							});

							if (that.page == 0) {
								let list = arr;
								that.setData({
									list: list
								});
							} else {
								//获取下拉刷新之前的list数据
								let old_data = that.list; //arr  代表page+1  新数据

								that.setData({
									bill_list: old_data.concat(arr)
								});
							}
						} else {
							uni.showToast({
								title: res.data.msg,
								icon: 'none'
							});
						}

						uni.stopPullDownRefresh();
					}

				});
			},

			billtails(id) {
				let bill_id = id;

				if (bill_id == '') {
					uni.showToast({
						title: '账单ID获取失败，请重试！！',
						icon: 'none'
					});
				} else {
					uni.navigateTo({
						url: '../billdetails/billdetails?id=' + bill_id
					});
				}
			}

		}
	};
</script>
<style lang="scss" scoped>
	page {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
	}

	.content {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;

		.tab-active {
			display: flex;
			color: #919191;
			align-items: center;
			width: 100%;
			justify-content: space-around;
			height: 80rpx;
			background-color: #FFFFFF;
			font-size: 28rpx;
			padding: 0 30rpx;
			box-sizing: border-box;
            position: fixed;
			top: 0;
			left: 0;
			.tab-content {
				width: 20%;
				text-align: center;
				height: 100%;
				line-height: 80rpx;
				padding: 0 10rpx;
				box-sizing: border-box;

				image {
					width: 30rpx;
					height: 28rpx;
					vertical-align: middle;
					margin-left: 6rpx;
				}
			}
		}

		.active-box {
			width: 80%;
			border-bottom: 2px solid #FFAC38;
			color: #4E73E8;
		}

		.itemsBox {
			width: 100%;
			min-height: 120rpx;
			padding: 10rpx 30rpx;
			box-sizing: border-box;
			background-color: #FFFFFF;
			border-bottom: 2rpx solid #F8F9FF;
			display: flex;

			// justify-content: f;
			.itemsLeft {
				flex: 2;
				height: 120rpx;
				display: flex;
				justify-content: center;
				align-items: flex-start;
				flex-flow: column;

				.title {
					font-size: 34rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 35rpx;
					color: #333333;
					opacity: 1;

					.sign {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 500;
						line-height: 30rpx;
						margin-top: 5rpx;
						color: #919191;
						opacity: 1;

					}
				}

				.times {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 30rpx;
					color: #919191;
					opacity: 1;
					margin-top: 20rpx;
				}
			}

			.itemsRight {
				flex: 1;
				height: 120rpx;
				display: flex;
				justify-content: flex-end;
				align-items: center;

				text {
					font-size: 34rpx;
					font-family: PingFang SC;
					font-weight: 600;
					line-height: 35rpx;
					color: #333333;
					opacity: 1;
				}
			}
		}
	    .more{
			width: 100%;
			height: 100rpx;
		    display: flex;
			justify-content: center;
			align-items: center;
			text{
				font-size: 28rpx;
				line-height: 30rpx;
				color: #888888;
			}
		}
	}



	/*弹性盒*/
	.box-flex {
		display: -webkit-box;
	}

	.box-flex-1 {
		-webkit-box-flex: 1;
	}

	.padding-lf-15 {
		padding-left: 16px;
		padding-right: 16px;
		margin-top: 2vh;
	}

	/* 明细*/
	.bill_detail_info_money {
		margin-top: 1vh;
		width: 110px;
		text-align: right;
		color: #EB4D30;
		font-weight: bold;
		font-size: 18px;
	}

	/*金额*/
	.bill_detail_info_1px {
		border-bottom: 1px solid #ccc;
	}

	.bill_detail_info_date {
		color: #A4A4A4;
		margin-top: 1vh;
		font-size: 12px;
		margin-bottom: 1vh;
	}
</style>

