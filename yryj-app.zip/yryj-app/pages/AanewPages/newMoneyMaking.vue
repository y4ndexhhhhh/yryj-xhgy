<template>
	<view class="content">
		<view class="activesitems">
			<image src="" mode="" class="imgsContent"></image>
		</view>
		<view class="listactives">
			<view class="listLeft">
				<view class="mytitle">
					<text>走路得金币</text> 
					<image src="" mode="" class="money"></image>
				</view>
				<view class="mydesc">
					<text>走一步就有奖励哦，快去走路吧~</text>
				</view>
			</view>
			<view class="listRight">
				
			</view>
		</view>
	</view>
</template>

<script>
</script>

<style lang="scss" scoped>
	page{
		width: 100%;
		height: 100vh;
		background-color:#F8F9FF;
	}
	.content{
		width: 100%;
		height: 100vh;
		background-color:#F8F9FF;
		.activesitems{
			width: 100%;
			height: 230rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			.imgsContent{
				width: 686rpx;
				height: 164rpx;
				background-color: #f40;
			}
		}
		.listactives{
			width: 750rpx;
			height: 120rpx;
			background-color: #FFFFFF;
			border-bottom: 1rpx solid #F8F9FF;
			display: flex;
			justify-content: center;
			align-items: center;
			.listLeft{
				flex: 2;
				height: 100%;
				.mytitle{
					width: 100%;
					height: 50rpx;
					
					font-size: 30px;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 24rpx;
					color: #333333;
					opacity: 1;
				}
			}
			.listRight{
				flex: 1;
				height: 100%;
			}
		}
	}
</style>
