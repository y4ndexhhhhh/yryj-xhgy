<template>
	<view class="content">
		<!-- <view class="itemsBox" @click="goMonnom('/pages/AanewPages/changePassword','0')">
			<view class="itemsLeft">
				<text>修改登录密码</text>
			</view>
			<view class="itemsRight">
					<image src="/static/images/my/arrow_right.png" mode="" class="arrowRignth"></image>
			</view>
		</view> -->
		<view class="itemsBox"  @click="goMonnom('/pages/AanewPages/systemMessage','1')">
			<view class="itemsLeft">
				<text>系统消息</text>
			</view>
			<view class="itemsRight">
				<text v-if="code" class="redO"></text>
			    <image src="/static/images/my/arrow_right.png" mode="" class="arrowRignth"></image>
			</view>
		</view>
		<view class="itemsBox" @click="goMonnom('/pages/AanewPages/version','0')">
			<view class="itemsLeft">
				<text>版本信息</text>
			</view>
			<view class="itemsRight">
					<image src="/static/images/my/arrow_right.png" mode="" class="arrowRignth"></image>
			</view>
		</view>
		<view class="itemsBox">
			<view class="itemsLeft">
				<text>人工客服</text>
			</view>
			<view class="itemsRight">
				400-086-0951
					<!-- <image src="/static/images/my/arrow_right.png" mode="" class="arrowRignth"></image> -->
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				code:true
			}
		},
		methods:{
			goMonnom(url,type){
				if(type == '1'){
					this.code = false
				}
				uni.navigateTo({
					url:url
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	page{
		width:100%;
		height: 100vh;
		background-color: #F8F9FF;
	}
	.content{
		width:100%;
		height: 100vh;
		background-color: #F8F9FF;

	.itemsBox {
		width: 100%;
		height: 120rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #FFFFFF;
		padding: 0 30rpx;
		box-sizing: border-box;
		border-bottom: 1rpx solid #F8F9FF;
	
		.itemsLeft {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;
	
			.icons {
				width: 52rpx;
				height: 52rpx;
				// background-color: #f40;
			}
	
			text {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
				margin-left: 20rpx;
			}
		}
	
		.itemsRight {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-end;
			align-items: center;
	        .redO{
				width: 20rpx;
				height: 20rpx;
				background: #FE0707;
				border-radius: 50%;
				opacity: 1;
				
			}
			.arrowRignth {
				margin-left: 20rpx;
				width: 13rpx;
				height: 24rpx;
				// background-color: #f40;
			}
		}
	}
  }
</style>
