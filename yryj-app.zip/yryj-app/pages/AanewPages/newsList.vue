<template>
	<view class="content">
		<view class="tab-active" id="test">
			<view class="tab-content" @click="handletabschenge(0)" :class="orderType==0?'active-box':''">
				复合广告
			</view>
			<view class="tab-content" @click="handletabschenge(1)" :class="orderType==1?'active-box':''">
				有奖游戏
			</view>
			<view class="tab-content" @click="handletabschenge(2)" :class="orderType==2?'active-box':''">
				公司资讯
			</view>
		</view>
		<view class="" style="width: 100%;height: 80rpx;"></view>
		<!-- <scroll-view scroll-y="true" :style="{height:QHeight+'px'}"> -->
		<view class="itemsBox" v-for="(item, index) in newsList" :key="index" @click="goDetils(item.id,item.type)">
			<!-- <view class="itemContent" v-if="item.type == 1 && item.cover_img == ''">
					<text>{{item.title}}</text>
				</view> -->
			<view class="item2Content" v-if="item.type == 1 && item.cover_img != ''">
				<view class="contentleft">
					<text>{{item.title}}</text>
				</view>
				<view class="contentright">
					<image :src="item.cover_img" mode="" class="imgs"></image>
				</view>
			</view>
			<view class="item3Content" v-if="item.type == 2">
				<view class="title">
					<text>【{{item.title}}】</text>
				</view>
				<view class="video">
					<!-- <view class="videos">
					    	
					    </view> -->
					<image :src="item.cover_img" mode="aspectFit" class="videos"></image>
					<view class="cover">
						<image src="/static/images/home/player.png" mode="aspectFit" class="coverImgs"></image>
					</view>
					<!-- <video class="videos" id="video" :show-mute-btn="show_mute_btn" :enable-play-gesture="enable_play_gesture"
						 :show-center-play-btn="show_center_play_btn" :page-gesture="page_gesture" :src="item.content" controls :poster="coverUrl"></video> -->
				</view>
			</view>
			<view class="itemTime">
				<text>{{item.create_time}}</text>
			</view>
		</view>
		<doudi v-if="newsList.length == 0"></doudi>
		<!-- </scroll-view> -->
	</view>
</template>

<script>
	import popUp from '@/components/PopUp.vue'
	var h5Module = uni.requireNativePlugin("ZjSDKH5Module")
	const modal = uni.requireNativePlugin('modal');
	var sha_1 = require("../../utils/sha_1.js");
	var util = require('../../utils/util.js')
	// var AD = require('../../utils/ad.js')
	const app = getApp();
	export default {
		components: {
			popUp
		},
		data() {
			return {
				title: '资讯',
				orderType: 2,
				reqType: 0,
				page_gesture: true,
				show_center_play_btn: false,
				enable_play_gesture: true,
				show_mute_btn: true,
				coverUrl: '',
				QHeight: '',
				showCode: true,
				tabs: [{
					id: 1,
					type: 100,
					value: "推荐",
					isActive: true
				}, {
					id: 2,
					type: 101,
					value: "阅读",
					isActive: false
				}, {
					id: 3,
					type: 102,
					value: "视频",
					isActive: false
				}],
				newsList: [],
				popupCode: false,
				pages: 1,
				getCode: true,
				loading: false,
				imgUrl: ""
			}
		},

		onShow() {
			//展示播放
		},
		onLoad() {
			uni.getSystemInfo({
				success: (res) => {
					let height = res.windowHeight;
					this.QHeight = (height - 40);
				}
			})
			this.getNewsList();
			// this.getGolod();
		},
		onReady() {
			this._isLoaded = false
			rewardedVideoAd = this._rewardedVideoAd = uni.createRewardedVideoAd({
				
				adpid: '1105658736'
			}) // 仅用于HBuilder基座调试 adpid: '1507000689'
			rewardedVideoAd.onLoad(() => {
				this._isLoaded = true
				console.log('onLoad event')
				// 当激励视频被关闭时，默认预载下一条数据，加载完成时仍然触发 `onLoad` 事件
			})
			rewardedVideoAd.onError((err) => {
				console.log('onError event', err)
			})
			rewardedVideoAd.onClose((res) => {
				console.log('onClose event', res)
			})
		},
		onHide() {

		},
		onUnload() {
			this.interactiveAd.destroy();
		},
		onReachBottom() {
			let that = this;
			if (that.getCode) {
				that.pages += 1;
				that.getNewsList();
				that.getCode = false
			}
		},
		onPullDownRefresh() {
			//监听下拉刷新动作的执行方法，每次手动下拉刷新都会执行一次
			this.newsList = [];
			this.pages = 1;
			this.getNewsList();
			setTimeout(function() {
				uni.stopPullDownRefresh(); //停止下拉刷新动画
			}, 1000);
		},
		methods: {
			handletabschenge(prop) {
				this.orderType = prop;
				if (prop == 0) { //广告
					this.reqType = 0;
					this.page = 1;
					this.newsList = [];
					this.showAD();
				}
				if (prop == 1) { //游戏
					this.reqType = 1;
					this.page = 1;
					this.newsList = [];
					this.goGame();
					//this.getNewsList();
				}
				if (prop == 2) { //资讯
					this.reqType = 0;
					this.page = 1;
					this.newsList = [];
					this.getNewsList();
				}
			},
			showAD() {
				if (this._isLoaded) {
					this._rewardedVideoAd.show()
				}
			},
			goDetils(prop, type) {
				if (type == '2') {
					uni.navigateTo({
						url: './newsDetils?id=' + prop
						//url: './videodetils?id='+prop
					})
				} else {
					uni.navigateTo({
						url: './newsDetils?id=' + prop
					})
				}

			},
			goViode() {
				// uni.navigateTo({
				// 	url: './videodetils?id='+prop
				// })
				this.loadAd();
			},
			createGame() {
				var interactiveAd = this.interactiveAd = uni.createInteractiveAd(this.adOption);
				interactiveAd.onLoad((e) => {
					this.loading = false;
					this.imgUrl = e.imgUrl;
					console.log("广告加载成功");
					// 如果有广告图片素材, 通过 e.imgUrl 获取
				});
				interactiveAd.onClose(() => {
					// 用户点击了关闭或返回键(仅Android有返回键)
					console.log("广告关闭");
				});
				interactiveAd.onError((err) => {
					this.loading = false;
					console.log("广告加载失败");
				});

				// 广告实例创建成功后默认会执行一次 load，加载广告数据
				// 如果界面有 "显示广告" 按钮，需要先禁用掉，防止用户点击，等待广告数据加载成功后在放开
				this.loading = true;
			},
			goGame() {
				// 调用 interactiveAd.show()，如果数据正在加载中不会显示广告，加载成功后才显示
				// 在数据没有加载成功时，需要防止用户频繁点击显示广告
				if (this.loading == true) {
					return
				}
				this.loading = true;
				this.interactiveAd.show().then(() => {
					this.loading = false;
				});
			},

			getNewsList() {
				let that = this;
				var data = {};
				data["page"] = that.pages;
				data["size"] = 20;
				// data["key"] = '1';
				data["type"] = that.reqType;
				var arr = {
					"data": data
				};
				//console.log(arr)
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'news/newsList',
					data: {
						data: aesData
					},
					method: 'get'
				}).then(res => {
					//console.log(res)
					if (res.data.code == 0) {
						let List = res.data.data;
						List.forEach(item => {
							item.create_time = util.formatTimeTwo(item.create_time, 'Y-M-D h:m')
						})
						//console.log(List)
						that.newsList = that.newsList.concat(List);
						that.showCode = true;
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},

			loadAd() {
				// 调用异步方法
				console.log('onZjAdReward create', 'create')
				uni.showLoading({
					title: '加载中'
				});
				rewardModule.create("zjad_241286", "zj_11120200724056", "激励名称", 10, "扩展参数", true);
				rewardModule.onZjAdLoaded((info) => {
					console.log('onZjAdLoaded event', info)
					rewardModule.showAd()
				})
				rewardModule.onZjAdVideoCached((info) => {
					console.log('onZjAdVideoCached event', info)
					uni.hideLoading();
					// rewardModule.showAd()
				})
				rewardModule.onZjAdShow((info) => {
					console.log('onZjAdShow event', info)
				})
				rewardModule.onZjAdClick((info) => {
					console.log('onZjAdClick event', info)
				})
				rewardModule.onZjAdReward((info) => {
					console.log('onZjAdReward event', info)
					uni.showToast({
						title: '激励',
						duration: 2000
					});
				})
				rewardModule.onZjAdClose((info) => {
					console.log('onZjAdClose event', info)
				})
				rewardModule.onZjAdError((info) => {
					console.log('onZjAdError event', info)
					uni.showToast({
						title: info,
						duration: 2000
					});
				})

			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
	}

	.content {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
		position: relative;

		.tab-active {
			display: flex;
			color: #919191;
			align-items: center;
			justify-content: space-around;
			width: 100%;
			box-shadow: 0rpx 4rpx 6rpx rgba(255, 255, 255, .36);
			height: 80rpx;
			background-color: #FFFFFF;
			font-size: 32rpx;
			padding: 0 30rpx;
			box-sizing: border-box;
			position: fixed;
			left: 0;
			top: 0;
			z-index: 9999;

			.tab-content {
				width: 40%;
				text-align: center;
				height: 100%;
				line-height: 80rpx;
				padding: 0 10rpx;
				box-sizing: border-box;

				image {
					width: 30rpx;
					height: 28rpx;
					font-weight: 600;
					vertical-align: middle;
					margin-left: 6rpx;
				}
			}
		}

		.active-box {
			width: 80%;
			border-bottom: 2px solid #FFAC38;
			color: #4E73E8;
		}

		.itemsBox {
			width: 100%;
			height: auto;
			border-top: 2rpx solid #EFEFEF;
			background-color: #FFFFFF;
			padding: 20rpx 30rpx;
			box-sizing: border-box;

			.itemContent {
				width: 100%;
				height: auto;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 40rpx;
				color: #333;
				opacity: 1;
			}

			.item2Content {
				width: 100%;
				height: auto;
				display: flex;
				justify-content: space-between;
				align-items: flex-start;

				.contentleft {
					width: 450rpx;
					height: auto;
					padding-right: 20rpx;
					box-sizing: border-box;
				}

				.contentright {
					width: 230rpx;
					min-height: 50rpx;
					display: flex;
					justify-content: flex-end;
					align-items: center;

					.imgs {
						width: 230rpx;
						height: 110rpx;
					}
				}
			}

			.item3Content {
				width: 100%;
				height: auto;

				.title {
					width: 100%;
					min-height: 60rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;

					text {
						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						line-height: 40rpx;
						color: #333333;
						opacity: 1;
					}
				}

				.video {
					width: 686rpx;
					height: 390rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					position: relative;

					.videos {
						width: 685rpx !important;
						height: 390rpx !important;
						background-color: #000000;
					}

					.cover {
						width: 686rpx;
						height: 390rpx;
						position: absolute;
						background-color: rgba(0, 0, 0, 0.3);
						display: flex;
						justify-content: center;
						align-items: center;

						.coverImgs {
							width: 80rpx;
							height: 80rpx;
							border-radius: 50%;
						}
					}
				}
			}

			.itemTime {
				width: 100%;
				height: 55rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				text {
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 28rpx;
					color: #8F8F8F;
					opacity: 1;
					margin-right: 20rpx;
				}
			}
		}

		.Popup {
			width: 100%;
			height: 100%;
			position: absolute;
			top: 0;
			left: 0;
			z-index: 99999;
			background-color: rgba(0, 0, 0, .4);
			display: flex;
			justify-content: center;
			align-items: center;
			flex-flow: column;

			.contoen {
				width: 650rpx;
				height: 665rpx;
				background-color: #FFFFFF;
			}
		}
	}
</style>
