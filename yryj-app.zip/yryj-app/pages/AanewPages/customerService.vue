<template>
	<view class="content">
		<view class="itemsBox"  @click="goMonnom('/pages/AanewPages/strategy','2')">
			<view class="itemsLeft">
				<text>金币规则</text>
			</view>
			<view class="itemsRight">
				<!-- <text v-if="code" class="redO"></text> -->
			    <image src="/static/images/my/arrow_right.png" mode="" class="arrowRignth"></image>
			</view>
		</view>
		 <!-- @click="goMonnom('','1')" -->
		<view class="itemsBox">
			<view class="itemsLeft">
				<text>人工客服</text>
			</view>
			<view class="itemsRight">
				400-086-0951
					<!-- <image src="/static/images/my/arrow_right.png" mode="" class="arrowRignth"></image> -->
			</view>
		</view>
		
		<popuver :show="code" @close="close">
			<view class="cover">
			    <image src="/static/images/my/weichat.jpg" mode="" class="imgs"></image>
				<view class="titles">
					客服微信  19965957158
				</view>
			</view>
		</popuver>
		
	</view>
</template>

<script>
	import popuver from '@/components/popup-bottom/popup-bottom.vue'
	export default{
		components:{
			popuver
		},
		data(){
			return{
				code:false
			}
		},
		methods:{
			goMonnom(url,type){
				console.log(url)
				if(type == '1'){
					this.code = true;
					return;
				}
				uni.navigateTo({
					url:url
				})
			},
			close(){
				this.code = false;
			}
		}
	}
</script>

<style lang="scss" scoped>
	page{
		width:100%;
		height: 100vh;
		background-color: #F8F9FF;
	}
	.content{
		width:100%;
		height: 100vh;
		background-color: #F8F9FF;
        display: flex;
		flex-direction: column;
		justify-content: flex-start;
	.itemsBox {
		width: 100%;
		height: 120rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #FFFFFF;
		padding: 0 30rpx;
		box-sizing: border-box;
		border-bottom: 1rpx solid #F8F9FF;
	
		.itemsLeft {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;
	
			.icons {
				width: 52rpx;
				height: 52rpx;
				// background-color: #f40;
			}
	
			text {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
				margin-left: 20rpx;
			}
		}
	
		.itemsRight {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-end;
			align-items: center;
	        .redO{
				width: 20rpx;
				height: 20rpx;
				background: #FE0707;
				border-radius: 50%;
				opacity: 1;
				
			}
			.arrowRignth {
				margin-left: 20rpx;
				width: 13rpx;
				height: 24rpx;
				// background-color: #f40;
			}
		}
	}
     .cover{
		width: 486rpx;
		height: 570rpx;
		background: #FFFFFF;
		opacity: 1;
		border-radius: 8rpx;
		margin: 0 auto;
		margin-bottom: 60%;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		.imgs{
			width: 382rpx;
			height: 382rpx;
			background: #E2E2E2;
			opacity: 1;
		}
		.titles{
			width: 100%;
			height: 60rpx;
			margin-top: 30rpx;
	        text-align: center;
			font-size: 34rpx;
			font-family: PingFang SC;
			font-weight: 500;
			line-height: 24rpx;
			color: #9A9A9A;
			opacity: 1;
		}
	 }
  }
</style>
