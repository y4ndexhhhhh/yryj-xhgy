<template>
	<view class="content">
		<view class="topBoxs">
			<view class="nums">
				 <text>{{goldCoin}}</text>
			</view>
			<view class="texts">
				<view class="Money" style="flex-direction: row; width: 686rpx;margin-top: 20rpx;">
					<!-- <text>10000金币=1元 满可提现</text> -->
					<text>金币优先转化为健康积分，直至账户健康积分大于3000分，会员才可以兑换或提现</text>
					<!-- <text v-for="(item,index) in goldList">{{item}}元、</text> -->
				</view>
				<!-- <text class="text" style="text-align: center; color: #f40;margin-top: 20rpx;">首次提现不限金额</text> -->
				
			</view>
			<view class="leftBox" @click="goldDetails">
				<text>金币明细</text>
			</view>
		</view>
		<!-- <view class="Boxbackg">
			<view class="itemsBox " :class="[newtype == 0 ? 'item_activ':'']" v-if="newCode" @click="getNewPersonCode(0)">
				<text class="text " :class="[newtype == 0 ? 'item_text':'']">新用户</text>
			</view>
			<view class="itemsBox" :class="[typeMoney == index ? 'item_activ':'']" v-for="(item,index) in goldList" @click="getMoneyCode(index,item)">
				<text class="text" :class="[typeMoney == index ? 'item_text':'']">提现</text>
				<text class="red" :class="[typeMoney == index ? 'item_red':'']">{{item}}元</text>
			</view>
		</view> -->
	    <!-- <view class="buttomtcomm" style="margin-top: 80rpx;" @click="goldStock">
			<text>兑换增值积分</text>
	    </view> -->
		<!-- <view class="buttomtcomm" style="margin-top: 50rpx;" @click="goldWidth">
			<text>提现</text>
		</view> -->
		<!-- <view class="txt_tit">
			<text>金币优先转化为健康积分，直至账户健康积分大于3000分，会员才可以兑换或提现</text>
		</view> -->
		<view class="con_tit">
			<view class="title">一、如何获取金币</view>
			<view class="title2">1.加入会员</view>
			<view class="text">1) 加入系统超级会员，需支付10元系统建设费，加入成功后系统奖励1千健康积分和1千元提现手续费。</view>
			<view class="title2">2.签到</view>
			<view class="text">1）累计签到次数大于90次小于180次的会员患病可申请医保自付差额援助；累计签到次数大于180次以上的会员患病可申请医疗自费差额援助；每次签到均可获得数量不等的金币，连续签到可得更多金币；签到页面继续看视频可获得翻倍奖励。</view>
			<view class="text">2）连续签到第一周可得金币1088，第二、三周 1888，第四周 2888。</view>
			<view class="title2" style="">3.绑定个人信息</view>
			<view class="text">
				1) 绑定个人信息可得5000金币。
			</view>
			<view class="title2" style="">4.邀请好友</view>
			<view class="text">
				1）每成功邀请一位好友加入本APP会员，您可获得1万金币奖励。
			</view>
			<view class="text">
				2）好友在填写邀请码后您可以一直获取好友10%的金币奖励。
			</view>
			<view class="text">
				3）您可将活动页面通过微信、QO或者面对面、链接等方式分享给好友且好友首次下载后在10日内填写邀请码的，则视为您邀请成功。（注∶ 应用商店内直接下载无效）。
			</view>
			<view class="text">
				4）合伙人成功邀请好友加入会员的除奖励1万金币外，另外获得额外10元增值积分奖励。
			</view>
			<view class="text">
				5）会员个人账户低于3千健康积分的，金币每天凌晨自动兑换成健康积分，放入您的账户中，个人账户高于3千积分的，可手动兑换成增值积分或每天凌晨自动完成兑换。
			</view>
			<view class="text">
				6）增值积分可自主兑换为期权或现金。
			</view><view class="text">
				7）累计现金达到提现额度后，可申请提现，提现— 般3-5天到账，如遇双休日、节假日或提现高峰期， 提现到账时间可能会出现延迟，请耐心等待。
			</view>
			<view class="title2" style="">5.参加活动</view>
			<view class="text">
				1）走路得金币，根据每天走路步数可获得相应得金币，在本页面看视频可翻倍奖励，连走7天可领取高额金币奖励。
			</view>
			<view class="text">
				2）吃饭得金币，您每天可以在不同的时间段领取早餐、 午餐、晚餐、夜宵的金币补贴。
			</view>
			<view class="title2" style="">6.看视频、读文章</view>
			<view class="text">
				阅读文章和观看视频均可获得数额不等的金币奖励。
			</view>
			<view class="title">一、添加【亿人Y家】微信公众号获取10000金币奖励。</view>
			<view class="text">
				1、依次打开我的-金币管理-点击客服-人工客服，微信扫描，添加公众号。
			</view>
			<view class="text" style="margin-top: 10rpx;">
				2、提供相应手机号或者实名认证名，申请获取金币注∶金币发放存在延后的情况，一般48小时内发放到用户账户.
			</view>
			<view class="text" style="margin-top: 10rpx;">
				注∶金币发放存在延后的情况，一般48小时内发放到用户账户。
			</view>
			<view class="title">二、如何增加活跃度</view>
			<view class="text">
				1、新用户注册得50活跃度。
			</view>
			<view class="text">
				2、打开一次APP得5活跃度，每天50活跃度。
			</view>
			<view class="text">
				3、浏览一篇资讯内容，得10活跃度，每天150活跃度。
			</view>
			<view class="text">
				4、观看一次完整视频，得20活跃度，每天150活跃度。
			</view>
			<view class="text">
				5、不同的活跃等级会在您原有获得金币奖励的基础上 额外得到一定的活动金币奖励。
			</view>
			<view class="text">
				6、活跃等级统计时间为最近30天。
			</view>
			
			<view class="boxContent" style="margin-top: 20rpx;">
				<view class="titleBox">
					<view class="items">
						<text>活跃度</text>
					</view>
					<view class="items">
						<text>活跃等级</text>
					</view>
					<view class="items">
						<text>额外奖励</text>
					</view>
				</view>
				<view class="titleBox" style="border-top:none;margin-bottom: 20rpx;">
					<view class="items">
						<view class="itemnav">0-100</view>
						<view class="itemnav">101-800</view>
						<view class="itemnav">801-1500</view>
						<view class="itemnav">1501-2200</view>
						<view class="itemnav">2201-2900</view>
						<view class="itemnav">2901-3600</view>
						<view class="itemnav">3601-4300</view>
						<view class="itemnav">4301-5000</view>
						<view class="itemnav">5000+</view>
					</view>
					<view class="items">
						<view class="itemnav">LV0</view>
						<view class="itemnav">LV1</view>
						<view class="itemnav">LV2</view>
						<view class="itemnav">LV3</view>
						<view class="itemnav">LV4</view>
						<view class="itemnav">LV5</view>
						<view class="itemnav">LV6</view>
						<view class="itemnav">LV7</view>
						<view class="itemnav">LV8</view>
					</view>
					<view class="items">
						<view class="itemnav">无</view>
						<view class="itemnav">+6.0%</view>
						<view class="itemnav">+9.0%</view>
						<view class="itemnav">+12.0%</view>
						<view class="itemnav">+15.0%</view>
						<view class="itemnav">+18.0%</view>
						<view class="itemnav">+21.0%</view>
						<view class="itemnav">+24.0%</view>
						<view class="itemnav">+27.0%</view>
					</view>
				</view>
			</view>
		</view>
		<!-- <view class="radioBox" @click="goCustomer">
			<image src="/static/images/my/couser.png" mode="aspectFit" class="img"></image>
			<text>客服</text>
		</view> -->
	</view>
</template>

<script>
	var sha_1 = require("../../utils/sha_1.js");
    const app = getApp();
	export default{
		data(){
			return{
				stroge:'',
				goldCoin:'',
				goldList:[],
				typeList:'',
				newCode:false,
				typeMoney:-1,
				typeMones:0,
				moneyType:0,
				newtype:-1,
			}
		},
		onLoad() {
			this.stroge = uni.getStorageSync('key');
			this.getGoldCoin();
			this.getGoldConfig();
			this.getNewsUser();
		},
		methods:{
			goCustomer(){
				uni.navigateTo({
					url:'./customerService'
				})
			},
			//  获取我的金币
			getGoldCoin() {
				let that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'users/myScore',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					if (res.data.code == 0) {
						that.goldCoin = res.data.data
						// that.code = (res.data.data.signCount - 1)
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			//  获取我的金币
			getGoldConfig() {
				let that = this;
				// var data = {};
				// data["uid"] = that.stroge.uid;
				// var arr = {
				// 	"data": data
				// };
				// var jsonStr = JSON.stringify(arr);
				// var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'users/withdrawConfig',
					data: {
						// data: aesData
					},
					method: 'get'
				}).then(res => {
					console.log(res)
					if (res.data.code == 0) {
						
						let objs = res.data.data.data;
						console.log(objs)
						that.typeList=objs;
						let arrays = [];
						for(let key in objs){
							 arrays.push(objs[key]);
						}
						that.goldList = arrays;
						console.log(that.goldList)
					}
					// uni.showToast({
					// 	title: res.data.msg,
					// 	icon: 'none'
					// })
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			//  新用户判定
			getNewsUser(){
				let that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'users/isNewUserWithdraw',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					console.log(res)
					if (res.data.code == 0) {
					    that.newCode = res.data.data.data;
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			goldDetails(){
				uni.navigateTo({
					url:'./goldDetails'
				})
			},
			goldStock(){
				console.log(this.goldCoin>0)
				if(this.goldCoin == 0){
					uni.showToast({
						title:'金币不足',
						icon:'none'
					})
					return;
				}
				uni.navigateTo({
					url:'./stockExchange?goldCoin='+this.goldCoin
				})
			},
			getNewPersonCode(prop){
				let nowmoney = (this.goldCoin/10000);
				this.newtype = prop;
				this.typeMoney = -1;
				uni.showToast({
					title:'新用户首次提现不限额',
					icon:'none'
				})
			},
			getMoneyCode(prop,money){

			let nowmoney = (this.goldCoin/10000);
			 if(nowmoney < money){
					uni.showToast({
						title:'金额不足',
						icon:'none'
					})
				}
				this.typeMoney = prop;
				this.typeMones = money;
				this.newtype = 1;
			},
			goldWidth(){
				if(this.typeMoney == -1 && this.newtype ==-1){
					uni.showToast({
						title:'请选择提现金额',
						icon:'none'
					})
					return;
				}
				let money= "";
				let type = 0;
				let nowMoney = (this.goldCoin/10000)
				if(this.newCode){
					money= nowMoney;
				}else{
					money= this.typeMones;
					type =this.typeMoney+1;
					if(money > nowMoney){
						uni.showToast({
							title:'金额不足',
							icon:'none'
						})
						return;
					}
				}
				if(money == 0){
					uni.showToast({
						title:'金额不足',
						icon:'none'
					})
					return;
				}
				uni.navigateTo({
					url:'./withdrawal?money='+money+'&type='+type
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.content{
		width: 100%;
		height: 100vh;
		display: flex;
		flex-flow: column;
		align-items: center;
		justify-content: flex-start;
		background-color: #F8F9FF;
		.topBoxs{
			width: 750rpx;
			height: 350rpx;
			background: #FFFFFF;
			border-bottom: 1rpx solid #F4F4F4;
			opacity: 1;
			position: relative;
			display: flex;
			justify-content: center;
			flex-direction: column;
			align-items: center;
			.nums{
				width: 100%;
				height: 130rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				margin-top: 30rpx;
				font-size: 92rpx;
				font-family: PingFang SC;
				font-weight: 800;
				color: #4B65F1;
				opacity: 1;
			}
			.Money{
				width: 100%;
				height: 65rpx;
				margin-top: 20rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				margin-bottom: 30px;
				// flex-flow: column;
				text{
					font-size: 28rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 30rpx;
					color: #C2C2C2;
					opacity: 1;
					margin-top: 10rpx;
				}
			}
			.text{
				font-size: 28rpx;
				font-family: SourceHanSansCN-Regular;
				line-height: 30rpx;
				color: #C2C2C2;
				opacity: 1;
				margin-top: 10rpx;
				display: block;
				margin: 0 auto;
				// text-align: center;
			}
		   .leftBox{
			   width: 190rpx;
			   height: 72rpx;
			   background-color: #FFAC38;
			   border-radius: 40rpx 0 0 40rpx;
			   position: absolute;
			   right: 0;
			   top: 15rpx;
			   display: flex;
			   justify-content: center;
			   align-items: center;
			   text{
				   font-size: 32rpx;
				   font-family: SourceHanSansCN-Regular;
				   line-height: 30rpx;
				   color: #FFFFFF;
				   opacity: 1;
			   }
		   }
		}
	    .Boxbackg{
			width: 100%;
			min-height: 120rpx;
			background-color: #FFFFFF;
			padding: 0 30rpx;
			box-sizing: border-box;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			.itemsBox{
				width: 120rpx;
				height: 80rpx;
				border: 1rpx solid #F4F4F4;
				border-radius: 10rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				margin-right: 20rpx;
				.text{
					font-size: 26rpx;
					line-height: 25rpx;
					font-weight: 500rpx;
					color: #333;
				}
				.red{
					font-size: 26rpx;
					line-height: 25rpx;
					font-weight: 500rpx;
					color: #f40;
				}
			}
			.item_activ{
				background-color: #6178F3;
				.item_text{
					color: #FFFFFF;
				}
				.item_red{
					color: #FFAC38;
				}
			}
		}
		
		.buttomtcomm{
			width: 686rpx;
			height: 120rpx;
			background: #6178F3;
			opacity: 1;
			border-radius: 60rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			
			text{
				font-size: 44rpx;
				font-family: SourceHanSansCN-Regular;
				line-height: 30rpx;
				color: #FFFFFF;
				opacity: 1;
			}
		}
		.radioBox{
			width: 120rpx;
			min-height: 120rpx;
			// background: #6386FA;
			border-radius: 50%;
			opacity: 1;
			position: fixed;
			left: 50rpx;
			bottom: 100rpx;
		    display: flex;
			justify-content: center;
			align-items: center;
			flex-direction: column;
			.img{
				width: 78rpx;
				height: 78rpx;
				margin: 0 auto;
				// background-color: #f40;
			}
			text{
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 24rpx;
				color: #333333;
				opacity: 1;
				margin-top: 10rpx;
			}
		}
	}
	.txt_tit {
		width: 90%;
		padding: 0;
		margin: auto;
		height: 800rpx;
		color: #bebebe;
		font-size: 30rpx;
		box-sizing: border-box;
	}
	.con_tit {
		width: 90%;
		margin: 50rpx auto;
	}
	.title {
		opacity: 1;
		width: 100%;
		color: #000;
		display: flex;
		padding: 10rpx 0;
		font-weight: 600;
		font-size: 36rpx;
		align-items: center;
		font-family: PingFang SC;
		justify-content: flex-start;
	}
	
	.title2 {
		width: 100%;
		height: 60rpx;
	
		font-size: 32rpx;
		font-family: PingFang SC;
		font-weight: 600;
		line-height: 60rpx;
		color: #000;
		opacity: 1;
	}
	
	.text {
		width: 100%;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		line-height: 40rpx;
		color: #333333;
		opacity: 1;
	}
	
	.boxContent {
		width: 100%;
		height: auto;
		padding: 0 20rpx;
		box-sizing: border-box;
	
		.titleBox {
			width: 100%;
			min-height: 70rpx;
			border: 1rpx solid #C2C2C2;
			// border-bottom: none;
			display: flex;
			justify-content: center;
			align-items: center;
			.items {
				flex: 1;
				display: flex;
				min-height: 70rpx;
				justify-content: center;
				align-items: center;
				flex-direction: column;
				.itemnav{
					width: 100%;
					height: 60rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					
					
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 60rpx;
					color: #333333;
					opacity: 1;
				}
				// flex-direction: column;
			}
		}
	}
</style>
