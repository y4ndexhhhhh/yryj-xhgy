<template>
	<!-- 绑定推荐人 -->
	<view class="content">
		<view class="itemsBox">
			<view class="itemsLeft">
				<!-- <image src="" mode="" class="icons"></image> -->
				<text>兑换码</text>
			</view>
			<view class="itemsRight">
				<input type="text" v-model="phone" placeholder="请输入兑换码" class="input" placeholder-class="deful" />
			</view>
		</view>
		<view class="title">
			<text>温馨提示:</text>
			<text>兑换成功后,请前往医补计划进行实名认证领取</text>
		</view>
		<mybottom name="确定"></mybottom>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				phone: ''
			}
		}
	}
</script>

<style lang="scss" scoped>
	page{
		width: 100%;
		height: 100vh;
		background-color:#F8F9FF;
	}
	.content {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;

		.itemsBox {
			width: 100%;
			height: 120rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			background-color: #FFFFFF;
			padding: 0 30rpx;
			box-sizing: border-box;
			border-bottom: 1rpx solid #F8F9FF;

			.itemsLeft {
				flex: 1;
				height: 100%;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.icons {
					width: 52rpx;
					height: 52rpx;
					background-color: #f40;
				}

				text {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 30rpx;
					color: #333333;
					opacity: 1;
					margin-left: 20rpx;
				}
			}

			.itemsRight {
				flex: 2.5;
				height: 100%;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.input {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 24rpx;
					color: #333333;
					opacity: 1;
					// text-align: rig;
				}

				.deful {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 30rpx;
					color: #DBDBDB;
					opacity: 1;
				}

				.avatar {
					width: 60rpx;
					height: 60rpx;
					background: #DBDBDB;
					border-radius: 50%;
					opacity: 1;
					margin-right: 10rpx;
				}

				.arrowRignth {
					width: 20rpx;
					height: 28rpx;
					background-color: #f40;
				}
			}
		}
	    .title{
			width: 100%;
			height: auto;
			padding: 0 30rpx;
			margin-top: 20rpx;
			box-sizing: border-box;
			display: flex;
			justify-content: flex-start;
			align-items: flex-start;
			flex-flow: column;
			text{
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 400;
				line-height: 40rpx;
				color: #AEAEAE;
				opacity: 1;
			}
		}
	}
</style>
