<template>
	<view class="wrap" catchtouchmove="preventTouchMove" v-if="wait_time_box">
		<view class="wrap_icon" :style="{height:QHeight +'px'}">
			<image src="/static/images/banner/quanyi01.jpg" mode="aspectFill" :style="{height:QHeight +'px'}"> </image>
		</view>
		<mybottom @sublimt="click_btn" name="确认升级"></mybottom>
	</view>
</template>

<script>
	// pages/Service upgrade/Service upgrade.js
	var util = require("../../utils/util.js");
	const app = getApp();

	export default {
		data() {
			return {
				wait_time_box: true,
				//首页实名认证弹窗
				equity_days: -1 + '天',
				bank_status: 0,
				oid: 0,
				help_num: 0,
				join_days: '',
				uid: 0,
				interests_flag: 2,
				status: 1,
				QHeight:''
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(e) {
			this.reqstatu();
			let strog = uni.getStorageSync('key');
			this.setData({
				bank_status: e.bank_status,
				oid: e.oid,
				uid: strog.uid,
				interests_flag: strog.interests_flag,
				equity_days: e.equity_days,
				help_num: e.help_num,
				join_days: strog.join_days
			});
			uni.getSystemInfo({
				success: (res) => {
					let height = res.windowHeight;
					this.QHeight = (height-80);
				}
			})
		},

		onShow() {},

		methods: {
			preventTouchMove: function(e) {},

			// 首页实名认证弹窗
			close_waiti_time(e) {
				this.setData({
					wait_time_box: false
				});
				uni.switchTab({
					url: '/pages/index/index'
				});
			},

			//按钮事件
			click_btn() {
				var that = this;

				if (that.interests_flag == 1) {
					uni.showToast({
						title: '您已经升级，请勿重复升级',
						icon: 'none'
					});
					return;
				}

				if (that.bank_status != 200) {
					uni.showModal({
						title: '提示',
						content: '您还未绑定银行卡，请绑定银行卡',

						success(res) {
							if (res.confirm) {
								uni.navigateTo({
									url: '/pages/bind_bank/bind_bank?oid=' + that.oid
								});
							}

							return;
						}

					});
					return;
				}

				if (that.equity_days <= 0) {
					uni.request({
						url: app.globalData.url + 'users/saveUserInterests',
						method: "POSt",
						data: {
							uid: that.uid
						},

						success(res) {
							if (res.data.code == 'ok') {
								uni.switchTab({
									url: '/pages/index/index'
								});
							}
						}

					});
				} else {
					uni.showToast({
						title: '您还未过等待期',
						icon: 'none',
						duration: 1500
					});
				}
			},

			reqstatu() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'shield/getShield',
					method: "POSt",
					data: {
						version_code: app.globalData.version_code
					},

					success(res) {
						that.setData({
							status: res.data.data.status
						});
					}

				});
			}

		}
	};
</script>
<style>
	page {
		width: 100%;
		height: 100vh;
	}

	.wrap {
		height: 100vh;
		width: 750rpx;
		border-radius: 7px;
		padding: 30rpx;
		box-sizing: border-box;
	}

	.wrap_icon image {
		height: 541px;
		width: 690rpx;
	}
</style>
