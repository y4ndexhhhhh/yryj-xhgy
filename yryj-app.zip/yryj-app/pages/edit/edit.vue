<template>
	<!--pages/myadd/myadd.wxml-->
	<view class="conter">
		<view class="itemsBox">
			<view class="itemsLeft">
				<!-- <image src="" mode="" class="icons"></image> -->
				<text>头像</text>
			</view>
			<view class="itemsRight" @click="getAvatar">
				<image :src="stroge.imgurl" mode="" class="avatar"></image>
				<image src="/static/images/my/arrow_right.png" mode="" class="arrowRignth"></image>
			</view>
		</view>
		<view class="itemsBox">
			<view class="itemsLeft">
				<!-- <image src="" mode="" class="icons"></image> -->
				<text>用户名</text>
			</view>
			<view class="itemsRight">
				<input type="text" v-model="username" placeholder="请输入用户名" class="input" placeholder-class="deful" />
			</view>
		</view>
		<view class="itemsBox">
			<view class="itemsLeft">
				<!-- <image src="" mode="" class="icons"></image> -->
				<text>手机号</text>
			</view>
			<view class="itemsRight">
				<input type="text" v-model="phone" placeholder="请输入手机号" class="input" placeholder-class="deful" />
			</view>
		</view>
		<view class="itemsBox">
			<view class="itemsLeft">
				<text>实名认证</text>
			</view>
			<view class="itemsRight">
				<input type="text" v-model="codee" placeholder="请输入身份证号" class="input" disabled="true" placeholder-class="deful" />
			</view>
		</view>
<!-- 		<view class="itemsBox">
			<view class="itemsLeft">
				<text>所在地区</text>
			</view>
			<view class="itemsRight">
				<input type="text" disabled="disabled" v-model="areas_address" placeholder="请选择地区" class="input" @click="getCheck"
				 placeholder-class="deful" />
			</view>
		</view> -->
		<view class="itemsmap" style="flex-flow: column;">
			<view class="boxitem" style="border: none; height:150rpx;align-items: flex-start;padding-top: 22rpx;box-sizing: border-box;">
				<view class="itemText" style="width: 140rpx;margin-top: 6rpx;">
					<text>详细地址</text>
				</view>
				<view class="itemstext" style="justify-content:flex-start;align-items:flex-start;">
					<textarea type="text" v-model="detailed_address" placeholder-class="defual" placeholder="如：县、乡、村、街道、单元" />
					</view>
		</view>
	</view>
	<!-- <bottomLine></bottomLine> -->
	<!-- <mybottom @sublimt="sublimt"></mybottom> -->
 <!-- <view class="formtable">
	 
    <form @submit="formSubmit">
      <view>
        <text>用户名</text>
        <input name="username" @input="user" :value="stroge.real_name" type="text" placeholder="请输入您的姓名(必填)"></input>
      </view>
      <view>
        <text>手机号码</text>
        <input name="phone" type="number" placeholder="请输入手机号(必填)" maxlength="11" @input="phoneFun" :value="stroge.phone"></input>
      </view>
      <view>
        <text>身份证号</text>
        <input name="codee" disabled="disabled" @input="codes" :value="stroge.id_card" type="text" placeholder="请输入身份证(必填)"></input>
      </view>
      <view class="section">
        <view class="section__title">所在地区:</view>
        <picker mode="region" @change="bindRegionChange" :value="region" :custom-item="customItem">
          <view class="picker" v-if="adders_flag">
            {{region[0]}}{{region[1]}}{{region[2]}}
          </view>
          <view class="picker" v-else>
            {{areas_address}}
          </view>
        </picker>
      </view>
      <view>
        <text>详细地址:</text>
        <input name="adders" @input="adder" :value="detailed_address" type="text" placeholder="如：县、乡、村、街道、单元" style="text-align:left;"></input>
      </view>
      <button form-type="submit" class="btn">确定修改</button>
    </form>

  </view> -->

</view>
</template>

<script>
// pages/myadd/myadd.js
var sha_1 = require("../../utils/sha_1.js");
const app = getApp();

export default {
  data() {
    return {
      stroge: {},
      //本地缓存数据
      username: "",
      phone: "",
      codee: "",
      adders: "",
      odders: "",
      region: ['选择省', '选择市', '选择区'],
      storage_address: "",
      areas_address: "",
      detailed_address: "",
      adders_flag: false,
	  map:'',
	  address:''
    };
  },

  components: {},
  props: {},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
	 // console.log() 
    this.getstroge();
  },
  onShow() {
    this.getstroge();
  },
  methods: {
	  // 获取头像
	  getAvatar(){
		  // 上传图片
		  	var that = this;
		  	if (that.stroge.uid == '') {
		  		uni.showModal({
		  			title: '启奏陛下',
		  			content: '请先进行登录',
		  			success: res => {
		  				uni.navigateTo({
		  					url: '/pages/login/login'
		  				});
		  			}
		  		});
		  	} else {
		  		uni.chooseImage({
		  			count: 1,
		  			success: res => {
		  				var src = res.tempFilePaths;
		  				if (src) {
		  					var that = this;
		  					uni.request({
		  						url: app.globalData.url + 'users/getqntoken',
		  						method: "POST",
		  						success(res) {
		  							that.setData({
		  								token: res.data.data
		  							});
		  							that.uploadQiniu(src);
		  						}
		  					});
		  				}
		  			}
		  		});
		  	}
	  },
	  /**
	   * 图片上传七牛云
	   */
	  uploadQiniu(tempFilePaths) {
	  	var that = this;
	  	let token = that.token;
		uni.showLoading({
		    title: '加载中'
		});
	  	if (token != '') {
	  		uni.uploadFile({
	  			url: 'https://upload-z2.qiniup.com',
	  			name: 'file',
	  			filePath: tempFilePaths[0],
	  			header: {
	  				"Content-Type": "multipart/form-data"
	  			},
	  			formData: {
	  				token: token
	  			},
	  			success: function(res) {
	  				if (res.statusCode == 200) {
	  					let respones_data = JSON.parse(res.data);
	  					var qiniu_key = respones_data.key;
	  					uni.request({
	  						url: app.globalData.url + 'users/seve_img',
	  						method: "POST",
	  						data: {
	  							uid: that.stroge.uid,
	  							user_img: qiniu_key
	  						},
	  						success(res) {
								uni.hideLoading()
	  							if (res.data.code == 'ok') {
	  								const stoges = res.data.data;
									that.stroge = res.data.data;
	  								uni.setStorageSync('key', stoges);
									uni.showToast({
										title:'头像上传成功',
										icon:'none'
									})
	  								// uni.showModal({
	  								// 	title: '启奏陛下',
	  								// 	content: '头像上传成功'
	  								// }); 
	  							} else {
	  								// uni.showModal({
	  								// 	title: '启奏陛下',
	  								// 	content: '头像上传失败，请稍后重试'
	  								// });
	  							}
	  						}
	  					});
	  				}
	  			},
	  			fail: function(res) {
	  				uni.showModal({
	  					title: '启奏陛下',
	  					content: '头像上传失败，请稍后重试'
	  				});
	  			}
	  		});
	  	} else {
	  		uni.showModal({
	  			title: '启奏陛下',
	  			content: '头像上传失败，请稍后重试'
	  		});
	  	}
	  },
	  // 获取地址
	  getCheck(){
	  			 let that = this;
	  				 uni.getLocation({
	  				     type: 'wgs84',
	  					 geocode: true,
	  				     success: function (res) {
	  						 //that.areas_address = res.address.province + res.address.city + res.address.district;
	  						 uni.chooseLocation({
	  							 latitude:res.latitude,
	  							 longitude:res.longitude,
	  						     success: function (res) {
	  								 that.detailed_address = res.address;
	  						     }
	  						 });
	  				     },
						 fail:function(err){
						 	console.log(err)
						 }
	  				 });
	  },
    /*获取本地数据*/
    getstroge() {
      const stroge = uni.getStorageSync('key');
      this.setData({
        stroge: stroge,
		username:stroge.real_name,
		phone: stroge.phone,
		codee:stroge.id_card,
		adders: "",
		odders:'',
        storage_address: stroge.address
      });
      const siptes = this.storage_address.split('-');
      this.setData({
        areas_address: siptes[0],
        detailed_address: siptes[1]
      });
    },

   
    /*--form表单提交数据--*/
    sublimt(e) {
      var that = this;
      var user = that.username;
      var phone = that.phone;
      var ader = that.areas_address;
      var code = that.codee;
      var addes = that.detailed_address;
      if (user == '' && phone == '' && ader == '选择省,选择市,选择区' && addes == '') {
        //说明用户没有点击输入
        uni.showToast({
          title: '资料无变动！'
        });
        return false;
      } else {
        if (ader == '选择省,选择市,选择区') {
          //用户没有点击所在地区---获取以前的原始数据
          ader = that.areas_address;
        }

        if (addes == '') {
          //用户没有点击详细地址---获取以前的原始数据
          addes = that.detailed_address;
        }

        var adder = `${ader}-${addes}`;
        uni.request({
          url: app.globalData.url + 'users/seve_img',
          method: "POST",
          data: {
            uid: this.stroge.uid,
            phone: phone,
            real_name: user,
            id_card: code,
            address: adder
          },
          success(res) {
            if (res.data.code == 'ok') {
			  const stoges = res.data.data;
			  if(!uni.getStorageSync("oneFrist")){

			  }
              uni.setStorageSync('key', stoges);
			  uni.showToast({
			    title: res.data.msg,
			  	icon:'none'
			  });
			  uni.switchTab({
			  	url:'/pages/my/my'
			  })
            } else {
              uni.showToast({
                title: res.data.msg,
				icon:'none'
              });
            }
          }

        });
      }
    },
    // 获取得到的金币
    getMyGolod(){
    		let that = this;
			let userinfoGold = uni.getStorageSync('other').userinfo;
    		var data = {};
    		data["uid"] = that.stroge.uid;
    		data["type"] = '6';
    		data["score"] = userinfoGold;
    		var arr = {
    			"data": data
    		};
    		var jsonStr = JSON.stringify(arr);
    		var aesData = sha_1.Encrypt(jsonStr);
    		app.$request({
    			url: 'user_ad/openEncourageAd',
    			data: {
    				data: aesData
    			},
    			method: 'post'
    		}).then(res => {
    			console.log(res)
    			var content =''
    			if (res.data.code == 0){
					uni.setStorageSync('oneFrist',true)
                    uni.showToast({
                       title:'获得'+userinfoGold+'金币',
    				   icon:'none'
                   })
    			}
    		}).catch(err => {
    			console.error('登录异常', err);
    		})
    	},
    /*重新存储uid*/
    requid() {
      uni.request({
        url: app.globalData.url + 'users/userinfo',
        method: "POST",
        data: {
          uid: this.stroge.uid
        },

        success(res) {
          uni.setStorageSync('key', res.data.data);
        }

      });
    }

  }
};
</script>
<style lang="scss" scoped>
/* pages/myadd/myadd.wxss */
@import url("./edit.css");
page{
	width: 100%;
	height: 100vh;
	/* background-color:; */
}
.conter{
	width: 100%;
	height: 100vh;
	background-color: #F8F9FF;
	.itemsBox {
		width: 100%;
		height: 120rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #FFFFFF;
		padding: 0 30rpx;
		box-sizing: border-box;
		border-bottom: 1rpx solid #F8F9FF;
	
		.itemsLeft {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;
	
			.icons {
				width: 52rpx;
				height: 52rpx;
				background-color: #f40;
			}
	
			text {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
				margin-left: 20rpx;
			}
		}
	
		.itemsRight {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-end;
			align-items: center;
	
			.input {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 24rpx;
				color: #333333;
				opacity: 1;
				text-align: right;
			}
	
			.deful {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				color: #DBDBDB;
				opacity: 1;
			}
	
			.avatar {
				width: 60rpx;
				height: 60rpx;
				background: #DBDBDB;
				border-radius: 50%;
				opacity: 1;
				margin-right: 10rpx;
			}
	
			.arrowRignth {
				width: 13rpx;
				height: 24rpx;
				// background-color: #f40;
			}
		}
	}
}
   .itemsmap {
    	width: 100%;
    	min-height: 180rpx;
    	border-radius: 8rpx;
    	background-color: #FFFFFF;
    	display: flex;
    	justify-content: flex-start;
    	align-items: center;
    
    	.boxitem {
    		width: 100%;
    		min-height: 120rpx;
    		padding: 0 20rpx;
    		box-sizing: border-box;
    		display: flex;
    		justify-content: center;
    		align-items: center;
    		border-bottom: 1rpx solid #ececec;
    
    		.itemText {
    			width: 140rpx;
    			height: 30rpx;
    			font-size: 30rpx;
    			font-family: SourceHanSansCN-Regular;
    			line-height: 30rpx;
    			color: #333333;
    			opacity: 1;
    		}
    
    		.itemstext {
    			width: 485rpx;
    			min-height: 30rpx;
    			display: flex;
    			justify-content: flex-start;
    			align-items: center;
    			margin-left: 36rpx;
                textarea{
    				width: 480rpx;
    				height: 150rpx;
    				font-size: 30rpx;
    				font-family: Source Han Sans CN;
    				font-weight: 400;
    				color: #333;
    				opacity: 1;
    				line-height: 30rpx;
					margin-top: 5rpx;
					text-align: right;
    			}
    			.defual {
    				font-size: 30rpx;
    				font-family: Source Han Sans CN;
    				font-weight: 400;
    				color: #BBBBBB;
    				opacity: 1;
    			}
    		}
    	}
    }
</style>
