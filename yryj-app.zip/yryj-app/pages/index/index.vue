<template>
	<!--index.wxml-->
	<!-- __UNI__9057DC1 -->
	<!-- zj_11120200724056 -->
	<view class="conten">
		<!-- <view class="popcover" @touchmove.stop.prevent="moveHandle" v-if="codeType1"> -->
		<!-- <popCover   :show="codeType1">
			<view class="content3">
				<image src="/static/images/home/homeTips.png" mode="scaleToFill" class="imgs"></image>
				<view class="tiptext">
					<text>越活跃</text>
					<text>钱越多</text>
				</view>
				<view class="contenttips">
					<text>每日打开APP可得活跃度</text>
				</view>
				<view class="grdesbtn" @click="goclear2">
					<text>恭喜获得5活跃度</text>
				</view>
				<image src="/static/images/home/clear.png" mode="" class="clear" @click="goclear2"></image>
			</view>
		
		</popCover> -->
		  <!-- :show="codeType2" -->
		<popup-bottom  :show="false" @close="goclear1">
			<view class="content4">
				<image src="/static/images/home/homeTips1.png" mode="scaleToFill" class="imgs"></image>
				<view class="toptitles">
					<text>新人大礼包</text>
				</view>
				<view class="title">
					恭喜获得
				</view>
				<view class="tiptext">
					50活跃度+200金币
				</view>
				<view class="tipsBox">
					绑定信息后再赠送5000金币
				</view>
				<scroll-view  scroll-y='true' class="freeBox">
					<view class="shopBoxs" v-for="(item,index) in freeShop" @click="getFreeshop(item.id)" :key="index">
						<image :src="item.images" mode="aspectFit" class="imgs"></image>
						<view class="texts">
							<view class="shopname">{{item.title}}+{{item.give_integral}}金币</view>
							<view class="desc">
								（商品只需支付相应运营）
							</view>
						</view>
						<view class="btnget">
							<view class="mygetBtn">
								免费领
							</view>
						</view>
					</view>
					<view class="tips">
						<text>没有更多了~</text>
					</view>
				</scroll-view>
				<image src="/static/images/home/clear.png" mode="" class="clear" @click="goclear1"></image>
			</view>
		</popup-bottom>
		<view class="nav">
			<!-- 	<view :class="'zan-dialog ' + ( showDialog ? 'zan-dialogshow' : '' )">
				<view class="zan-dialog__mask" @tap="toggleDialog"></view>
				<view class="zan-dialog__container">
					<view class="content">{{content}}</view>
					<view class="button">
						<view class="buttons" style="border-right:1px solid #eee" @tap="esc">取消</view>
						<view class="buttons" @tap="sign">立即签订</view>
					</view>
				</view>
			</view> -->
			<!-- 首页公告弹窗开始 -->
			<!-- 	<view class="drawer_screen" data-statu="close" v-if="showModalStatus" catchtouchmove="preventTouchMove"></view>
			<view class="drawer_box" v-if="showModalStatus" catchtouchmove="preventTouchMove">
				<image src="/static/images/banner/gg.jpg"> </image>
				<view class="close" @tap="close">X</view>
				<view class="circle">
					<view class="circle_content">{{Notice_msg}}</view>
				</view>
				<view class="buttons" @tap="know">知道了</view>
				<view class="drawer_content">
				</view>
			</view> -->
			<!-- 弹窗结束 -->
			<!-- 首页实名认证弹窗 开始 -->
			<!-- <view class="zhezhao" v-if="real_name_box"></view>
			<view class="wrap" v-if="real_name_box" :data-type="real_name_type" :data-time="real_name_time">
				<view class="close_real_name" @tap="close_real_name">X</view>
				<view class="div">
					<view class="title">温馨提示</view>
					<view class="content">亲,您还没有完成实名认证奥！</view>
					<view class="id_btn" @tap="go_real_name">立即认证</view>
				</view>
			</view> -->
			<!-- 弹窗结束 -->
			<!-- 首页绑定银行卡弹窗 开始 -->
			<!-- 	<view class="zhezhao" v-if="bind_bank_box" catchtouchmove="preventTouchMove"></view>
			<view class="wrap" catchtouchmove="preventTouchMove" v-if="bind_bank_box" :data-type="bind_bank_type" :data-time="bind_bank_time">
				<view class="close_real_name" @tap="close_bind_bank">X</view>
				<view class="div">
					<view class="title">温馨提示</view>
					<view class="content">亲,您还没有绑定银行卡</view>
					<view class="id_btn" @tap="go_bind_bank">立即绑定</view>
				</view>
			</view> -->
			<!-- 弹窗结束 -->
			<!-- 家人加入弹框 开始 -->
			<!-- 	<view class="zhezhao" v-if="family_box" catchtouchmove="preventTouchMove"></view>
			<view class="family_wrap" catchtouchmove="preventTouchMove" v-if="family_box" :data-type="add_family_type"
			 :data-time="add_family_time">
				<view class="close" @tap="close_family_box">X</view>
				<view class="family">
					<view class="head_box">
						<view class="circle1"></view>
						<view class="circle2"></view>
						<view class="circle3"></view>
					</view>
					<view class="family_content">关爱家人,共抵风险</view>
					<view class="btn_box" @tap="go_add_family">
						<view class="family_btn">
							<view class="family_btns">添加家人</view>
						</view>
					</view>
				</view>
			</view> -->


			<!-- 家人加入弹框 结束 -->
			<image src="/static/images/banner/nav.jpg"></image>
			<!-- 活动页-->
			<view class="banner">
				<image class="image" src="/static/images/banner/bg.png"></image>
			</view>
		</view>
		<!-- 公告 -->
		<view class="masseg" v-if="status==1">
			<image src="/static/images/home/speak.png" mode="aspectFit" class="mssegIcon"></image>
			<swiper class="mas" autoplay="true" vertical="true" circular="true" interval="2000">
				<block v-for="(item, index) in diversions" :key="index">
					<swiper-item>
						<view class="swiper-item">{{item.title}}</view>
					</swiper-item>
				</block>
			</swiper>
		</view>
		<!-- 活动 -->
		<view class="activity" v-if="status==1">
			<view v-for="(item, index) in activiy" :key="index" class="activ" :style="'background:' + item.color" @click="limet(index)">
				<image :src="item.img" mode="aspectFit"></image>
				<text>{{item.title}}</text>
			</view>
		</view>
		<!-- 注册人数和申请时间 -->
		<view class="dating" v-if="status==1">
			<view class="datop">
				<view class="datfont">{{registered.count}}</view>
				<text>注册人数</text>
			</view>
			<view class="datop">
				<view class="datfont">{{registered.sign_num}}</view>
				<text>累计签到</text>
			</view>
			<!-- <view class="datop" v-else>
				<view class="datfont">{{registered.help_num}}</view>
				<text>援助次数</text>
			</view> -->
		</view>

		<!-- banner轮播图 -->
		<swiper class="fun" indicator-dots="true" indicator-color="#000" indicator-active-color="#fff" autoplay="true">
			<block>
				<swiper-item v-for="(item, index) in banner" :key="index" @tap="swiperclick">
					<image :src="item.img" :data-id="item.id" :data-url="item.url" :data-target="item.target"></image>
					<text>{{item.url}}</text>
					<text>{{item.target}}</text>
				</swiper-item>
			</block>
		</swiper>
		<view class="newBox" v-if="newList.length > 0">
			<view class="" style="width:100%;height:auto; background-color: #FFFFFF; border-radius: 8rpx;">
				<view class="notice">
					<view class="notice_left">
						<view class="notice_icon" style="background: #FFAC38;"></view>
						<image src="/static/images/home/navBar.png" mode="" class="newsText"></image>
					</view>
					<view class="notice_right" @click="goNewsList">
						<text>更多</text>
						<image src="/static/images/home/arrow_right.png" mode="" class="icon_right"></image>
					</view>
				</view>
				<view class="contentArea" >
					<view class="leftBox" @click="goNewsDetail(newList[0].id,newList[0].type)">
						<view class="title" style="width:230rpx;">
							<text>{{newList[0].title}}</text> 
						</view>
						<view class="desc" style="width: 190rpx;">
							<text style="margin-right: 10rpx;">{{newList[0].sub_title}}</text>
						</view>
						<image v-if="newList[0].cover_img == ''" src="/static/images/my/zanwei.png" mode="aspectFit" class="imgs"></image>
						<image v-else :src="newList[0].cover_img" mode="" class="imgs"></image>
					</view>
					<view class="rightBox">
						<view class="rightop" @click="goNewsDetail(newList[1].id,newList[1].type)">
							<view class="title" style="width: 300rpx; justify-content: flex-start;  overflow: hidden;white-space: nowrap;text-overflow: ellipsis;">
								<text> {{newList[1].title}}</text>
							</view>
							<view class="desc_imgs">
								<view class="desc" style="width: 120rpx;">
									<text>{{newList[1].sub_title}}</text>
								</view>
								<view class="imgs">
									<image v-if="newList[1].cover_img == ''" src="/static/images/my/zanwei.png" mode="aspectFit" class="imgsicon"></image>
									<image v-else :src="newList[1].cover_img" mode="" class="imgsicon"></image>
								</view>
							</view>
						</view>
						<view class="rightbtn">
							<view class="rightbtn_left" @click="goNewsDetail(newList[2].id,newList[2].type)">
								<view class="title" style="width: 130rpx;">
								   <text>{{newList[2].title}}</text> 
								</view>
								<view class="desc">
									<text>{{newList[2].sub_title}}</text>
								</view>
								<image v-if="newList[2].cover_img == ''" src="/static/images/my/zanwei.png" mode="aspectFit" class="imgs"></image>
								<image v-else :src="newList[2].cover_img" mode="" class="imgs"></image>
							</view>
							<view class="rightbtn_right" @click="goNewsDetail(newList[3].id,newList[3].type)">
								<view class="title" style="width:130rpx;">
									<text>{{newList[3].title}}</text> 
								</view>
								<view class="desc">
									<text>{{newList[3].sub_title}}</text>
								</view>
								<image v-if="newList[3].cover_img == ''" src="/static/images/my/zanwei.png" mode="aspectFit" class="imgs"></image>
								<image v-else :src="newList[3].cover_img" mode="" class="imgs"></image>
							</view>
						</view>
					</view>
				</view>
				<view class="itembox"  v-if="newList.length >= 5" @click="goNewsDetail(newList[4].id,newList[4].type)">
					<view class="itemsign">
						<text v-if="newList[4].sub_type == 1">养生</text>
						<text v-if="newList[4].sub_type == 2">运动</text>
					</view>
					<view class="itemcontent">
						<text>{{newList[4].title}}</text>
					</view>
				</view>
				<view class="itembox" v-if="newList.length >= 6" @click="goNewsDetail(newList[5].id,newList[5].type)">
					<view class="itemsign">
						<text v-if="newList[5].sub_type == 1">养生</text>
						<text v-if="newList[5].sub_type == 2">运动</text>
					</view>
					<view class="itemcontent">
						<text>{{newList[5].title}}</text>
					</view>
				</view>
				<view class="itembox" v-if="newList.length >= 7" @click="goNewsDetail(newList[6].id,newList[6].type)">
					<view class="itemsign">
						<text v-if="newList[6].sub_type == 1">养生</text>
						<text v-if="newList[6].sub_type == 2">运动</text>
					</view>
					<view class="itemcontent">
						<text>{{newList[6].title}}</text>
					</view>
				</view>
			</view>
		</view>
		<view class="newtipBox">
			<image src="/static/images/home/tabBar.png" mode="aspectFit" class="newismgs"></image>
		</view>
		<!-- 人民代表 -->
		<view @tap.stop="behalf">
			<view v-for="(item, index) in fullname" :key="index" class="comman" style=" padding-bottom: 10rpx;">
				<view class="comtop">
					<view class="left">全员大会</view>
					<view class="right">
						<text>查看更多</text>
						<image src="/static/images/home/arrow_rig.png" mode="" style="margin-left: 15rpx; width: 10rpx;height: 18rpx;"></image>
					</view>
				</view>
				<text>{{item.title}}</text>
				<view class="comon">
					<image src="/static/images/banner/ren.jpg"></image>
					<text>{{item.partake_num}}人已参与</text>
				</view>
				<view class="comdow">
					<view class="imglet">
						{{item.title_one}}
					</view>
					<view>
						<image class="imgon" src="/static/images/home/pake.png"></image>
					</view>
					<view class="imgright">
						{{item.title_two}}
					</view>
				</view>
			</view>
		</view>

		<!-- 项目视频介绍 -->
		<view class="comman" v-if="is_open_video">
			<view class="comtop">
				<view class="left">{{title}}</view>
			</view>
			<view class="conse">
				<video class="myVideo" :src="url_video" show-center-play-btn="true" show-play-btn="true" controls></video>
			</view>
		</view>
		<!-- 公司简介 -->
		<view class="comman" @tap.stop="company" v-else>
			<view class="comtop">
				<view class="left">项目简介</view>
				<view class="right">
					<text>查看更多</text>
					<image src="/static/images/home/arrow_rig.png" mode="" style="margin-left: 15rpx; width: 10rpx;height: 18rpx;"></image>
				</view>
			</view>
			<view class="conse">
				<image src="/static/images/banner/gongsi.png" mode="widthFix"></image>
			</view>
		</view>

		<!-- 	    <view class="popcover" v-if="codeType"  @touchmove.stop.prevent="moveHandle">
	    	<view class="mycontent1">
	    		<image src="/static/images/my/goldMoney.png" mode="" class="imgs"></image>
	    		<view class="redText">
	    			<text>恭喜获得100金币</text>
	    		</view>
	    		<view class="myKonew" @click="loadAd">
	    			<text>去翻倍</text>
	    		</view>
	    		<view class="mygetMoney" @click="getgoldCoin">
	    			<text>直接领取</text>
	    		</view>
	    	</view>
	    </view> -->
        <view class="FloatingBox" v-show="codeType1">
			<view class="flotingCover">
				<image src="/static/images/home/tips.png" mode="aspectFit" class="imgsBox"></image>
				<view class="floatingtext">
					<view class="floaingDay">
						每日登录
					</view>
					<view class="floaingGrade">
						+50
					</view>
					<view class="floaingsign">
						活跃度
					</view>
				</view>
				<image src="/static/images/home/clear_1.png" mode="" class="floaingClaer" @click="goclear2"></image>
			</view>
        </view>
	</view>
</template>

<script>
	// 1105658736	线上激励视频id
	// 1507000689  测试激励视频id
	//index.js
	//获取应用实例
	const app = getApp();
	const common = require("../../utils/reqstatus.js");
	var sha_1 = require("../../utils/sha_1.js"),
		util = require("../../utils/util.js");
	var rewardModule = uni.requireNativePlugin("ZjSDKRewardModule");
	var splashModule = uni.requireNativePlugin("ZjSDKSplashModule")
	var ZjSplashView = uni.requireNativePlugin("ZjSplashView")
	const modal = uni.requireNativePlugin('modal');
	import PopupBottom from '@/components/popup-bottom/popup-bottom';
	export default {
		data() {
			return {
				diversions: [],
				//跑马灯
				fullname: [],
				//全国代码大会
				registered: '',
				//注册人数和申请时间
				banner: '',
				// 功能区
				van: [ // { 
					//   img:'../../images/banner/1.jpg',
					//   title:'医保计划'
					// },
					// {
					//   img: '../../images/banner/2.jpg',
					//   title: '电子自传'
					// },
					// {
					//   img: '../../images/banner/3.jpg',
					//   title: '大爱行动'
					// },
					// {
					//   img: '../../images/banner/4.jpg',
					//   title: '电子银行'
					// }
				],
				activiy: [{
					color: 'linear-gradient(142deg,rgba(250,128,114,1) 0%,rgba(255,69,0,1) 100%);',
					img: "/static/images/home/tool1.png",
					title: '医补计划'
				}, {
					color: 'linear-gradient(138deg,rgba(137,216,252,1) 0%,rgba(84,180,249,1) 100%,rgba(110,136,215,1) 100%)',
					img: "/static/images/home/tool2.png",
					title: '合伙计划'
				}, {
					color: 'linear-gradient(142deg,rgba(211,151,255,1) 0%,rgba(171,97,255,1) 100%);',
					img: "/static/images/home/tool3.png",
					title: '分享有礼'
				}, {
					color: 'linear-gradient(142deg,rgb(255, 140, 105) 0%,rgb(238, 149, 114) 100%);',
					img: "/static/images/home/tool4.png",
					title: '申请援助'
				}, {
					color: 'linear-gradient(142deg,rgb(255, 181, 197) 0%,rgb(255, 174, 185) 100%);',
					img: "/static/images/home/tool5.png",
					title: '援助公示'
				}, {
					color: 'linear-gradient(142deg,rgb(171, 130, 255) 0%,rgb(171, 130, 255) 100%);',
					img: "/static/images/home/tool6.png",
					title: '权益升级'
				}],
				uid: 0,
				stroge: '',
				status: "",
				id: 1,
				showDialog: false,
				//是否签约弹窗
				showModalStatus: false,
				//首页公告弹窗
				real_name_box: false,
				//首页实名认证弹窗
				family_box: true,
				bind_bank_box: false,
				content: "",
				src: '',
				is_open_video: false,
				url_video: '',
				title: '',
				oid: 1,
				Notice_msg: '',
				type: 1,
				time: '',
				bank_status: 0,
				equity_days: -1,
				help_num: 0,
				showModal: false,
				box_flag: false,

				codeType: false,
				codeType1: false,
				codeType2: false,
				golacoin: ["eat", "run", "runseries", "activie", "sign", "other"],
				newList:[],
				freeShop: '', // 免费商品
			};
		},

		components: {
			PopupBottom
		},
		props: {},
		onLoad: function(e) {
			let golad = this.golacoin;
			for (var i = 0; i < golad.length; i++) {
				this.getGolod(golad[i]);
			}
			this.getNewShop();
			// console.log();

			// if (e.tuid != undefined) {
			// 	uni.setStorageSync('keys', e.tuid);
			// } 
			this.getstroge();
			// this.getIndexHome();
			//  /*---跑马灯---*/
			//   this.diversions()
			//   /*---全国代表大会---*/
			//   this.fullname()
			//   /*---注册人数和申请时间---*/
			//   this.registered()
			//   /*---轮播图---*/
			//   this.reqbanner()

			this.reqstatu();
			this.getNewsUser();
			// this.getSignMoney();
		},

		onShow() {
			this.getstroge();
			this.isPop();
			/*---跑马灯---*/

			this.diversionsFun();
			/*---全国代表大会---*/

			this.fullnameFun();
			/*---注册人数和申请时间---*/

			this.registeredFun();
			/*---轮播图---*/

			this.reqbanner();
			this.requid(); // 视频事件

			this.video(); // tabar右上角的红点

			this.tabrredhot(); // 通过场景值判断是否调用方法

			this.get_Notice();
			this.getbind_bank();
		},
		methods: {
			//  新用户判定
			getNewsUser(){
				let that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'users/isNewUserOrder',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					console.log(res.data.data.data)
					if (res.data.code == 0) {
					    that.codeType2 = res.data.data.data;
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			goNewsList() {
				uni.switchTab({
					url: '../AanewPages/newsList'
				})
			},
			goNewsDetail(prop,type) {
				console.log(prop);
				if(type == 1){
					uni.navigateTo({
						url: '../AanewPages/newsDetils?id=' + prop
					})
				}else{
					uni.navigateTo({
						url: '../AanewPages/videodetils?id=' + prop
					})
				}
			},
			goclear2() {
				this.codeType1 = false;
			},
			goclear1() {
				// console.log('111')
				this.codeType2 = false;
				this.codeType1 = true;
			},
			moveHandle() {},
			getgoldCoin() {
				this.codeType = !this.codeType;

			},
			getFreeshop(id) {
				uni.navigateTo({
					url: '/pages/AanewPages/freeCharge?id='+id
				})
			},
			goSeckill() {

			},
			goMakeGroup() {

			},
			goChecke() {

			},
			goNews() {
				uni.navigateTo({
					url: '/pages/home/newsList'
				})
			},

			//每日第一次打开app
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				if (stroge != '') {
					    that.uid = stroge.uid,
						that.stroge = stroge
						that.requid()
				}
				if (that.$openApp) {
					that.codeType2 = false;
					that.codeType1 = true;
					that.getSignMoney();
				}
			},
			getSignMoney() {
				let that = this;
				var data = {};
				data["uid"] = that.uid;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'user_ad/openApp',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					console.log(res)
					if (res.data.code == 0) {
						that.$openApp = false;
						// that.dayNum=res.data.data.runSeries,
						// that.daysone=res.data.data.todayCount
					}
					// uni.showToast({
					// 	title:res.data.msg,
					// 	icon:'none'
					// })
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			getNewShop() {
				let that = this;
				app.$request({
					url: 'login/goods',
					data: {},
					method: 'post'
				}).then(res => {
					if (res.data.code == 0) {
						that.freeShop = res.data.data;
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			/*---跑马灯---*/
			diversionsFun() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'login/notice',
					method: 'POST',

					success(res) {
						that.setData({
							diversions: res.data.data
						});
					}

				});
			},

			/*---全国代表大会---*/
			fullnameFun() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'users/congress',
					method: 'POST',
					data: {
						uid: ''
					},
					success(res) {
						that.setData({
							fullname: res.data.data
						});
					}

				});
			},

			/*注册人数和申请时间*/
			registeredFun() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'login/indexinfo',
					method: 'POST',
					data: {
						uid: that.uid
					},

					success(res) {
						// console.log(res.data.data.news, '---------------')
						uni.setStorageSync('VipNumber', res.data.data)
						that.newList = res.data.data.news
						that.setData({
							registered: res.data.data,
							equity_days: res.data.data.equity_days,
							help_num: res.data.data.help_num
						});
					}

				});
			},

			/*---医保 电子跳转详情页---*/
			headnav(e) {
				const key = e.currentTarget.dataset.key; //console.log(key);

				switch (key) {
					case 0:
						if (this.stroge == '') {
							uni.showModal({
								title: '启奏陛下',
								content: '请先进行登录',
								success: res => {
									uni.switchTab({
										url: '/pages/my/my'
									});
								}
							});
						} else {
							uni.navigateTo({
								url: '/pages/mentary/mentary'
							});
						}

						break;

					case 1:
						uni.navigateTo({
							url: '/pages/autobiog/autobiog'
						});
						break;

					case 2:
						uni.navigateTo({
							url: '/pages/share/share'
						});
						break;

					case 3:
						uni.navigateTo({
							url: '/pages/bank/bank'
						});
						break;
				}
			},
            showtoast(){
				uni.showToast({
					title:'请先进行登录~',
					icon:'none'
				})
			},
			/*---限时活动 合伙人---*/
			limet(prop) {
				let that = this;
				const id = prop;
				console.log(id)
				switch (id) {
					case 0:
						if (that.stroge == '') {
							that.showtoast();
							uni.switchTab({
								url: '/pages/login/login'
							});
						} // else if(this.data.stroge.rank == 0){
						//   wx.showModal({
						//     title: '启奏陛下',
						//     content: '请先成为我们的会员即可享受该服务',
						//     success: (res) => {
						//       wx.navigateTo({
						//         url: '/pages/equity/equity?uid=' + that.data.uid
						//       })
						//     }
						//   })
						// } 
						else {
							uni.navigateTo({
								url: '/pages/mentary/mentary'
							});
						}

						break;

					case 1:
						that.requid();
						that.getstroge();

						if (that.stroge == '') {
							that.showtoast();
							uni.switchTab({
								url: '/pages/login/login'
							});
							
						} // else if(this.data.stroge.rank == 0){
						//   wx.showModal({
						//     title: '启奏陛下',
						//     content: '请先成为我们的会员即可享受该服务',
						//     success: (res) => {
						//       wx.navigateTo({
						//         url: '/pages/equity/equity?uid=' + that.data.uid
						//       })
						//     }
						//   })
						// }
						else {
							if (that.stroge.join_status == 1) {
								if (that.stroge.rank == 2) {
									uni.navigateTo({
										url: '/pages/partnership/partnership?rank=' + that.stroge.rank
									});
								} else if (that.stroge.rank == 3) {
									//rqcode无用 
									uni.navigateTo({
										url: '/pages/partnership/partnership?rank=' + that.stroge.rank
									});
								} else {
									uni.navigateTo({
										url: '/pages/partnership/partnership?rank=' + that.stroge.rank
									});
								}
							} else {
							
											const stroge = that.stroge;

											if (stroge.real_status == 1) {
												if (stroge.join_status == 2) {
													uni.navigateTo({
														url: '/pages/aplay/aplay?uid=' + that.stroge.uid + '&oid=3'
													});
												} else {
													uni.navigateTo({
														url: '/pages/mdsucerr/mdsucerr'
													});
												}
											} else {
												uni.navigateTo({
													url: '/pages/myadd/myadd'
												});
											}
										
									// }
								// });
							}
						} //  wx.navigateTo({
						//    url: '/pages/partnership/partnership',
						//  })


						break;

					case 2:
						if (that.stroge == '') {
							that.showtoast();
							uni.switchTab({
								url: '/pages/login/login'
							});
						} // else if(this.data.stroge.rank == 0){
						//   wx.showModal({
						//     title: '启奏陛下',
						//     content: '请先成为我们的会员即可享受该服务',
						//     success: (res) => {
						//       wx.navigateTo({
						//         url: '/pages/equity/equity?uid=' + that.data.uid
						//       })
						//     }
						//   })
						// }
						else {
							uni.navigateTo({
								url: '/pages/share/share'
							});
						}

						break;

					case 3:
						if (that.stroge == '') {
							that.showtoast();
							uni.switchTab({
								url: '/pages/login/login'
							});
						} else {
							let registered = that.registered;

							if (registered.days > 0) {
								uni.showToast({
									title: '您尚未过等待期，不符合申请援助条件',
									icon: 'none'
								});
								return;
							} else {
								that.getProgress();
							}
						}

						break;

					case 4:
						uni.navigateTo({
							url: '/pages/help_publicity_list/help_publicity_list?uid=' + that.uid
						});
						break;

					case 5:
						if (that.stroge == '') {
							that.showtoast();
							uni.switchTab({
								url: '/pages/login/login'
							});
						} else {
							uni.navigateTo({
								url: '/pages/Service_upgrade/Service_upgrade?bank_status=' + that.bank_status + '&oid=' + that.oid +
									'&equity_days=' + that.equity_days + '&help_num=' + that.help_num
							});
						}

						break;
						// case 3:
						//   wx.navigateToMiniProgram({
						//     appId: 'wx0866672a413d083c',//要打开的小程序 appId
						//     path: 'pages/index/index',//打开的页面路径，如果为空则打开首页
						//     envVersion: 'release',// release 要打开的小程序版本。
						//     success(res) {
						//       // 打开成功
						//       //console.log('打开成功');
						//     }
						//   })
						//   break;
				}
			},

			/**---全民大会---*/
			behalf() {
				var that = this;

				if (that.stroge == '') {
					that.showtoast();
					uni.switchTab({
						url: '/pages/login/login'
					});
				} else {
					uni.request({
						url: 'https://app01.wysyt.com/h5/fun_config/getH5Config',

						success(res) {
							res.data.data.map((item, index) => {
								switch (item.id) {
									case 1:
										if (item.status == 2) {
											uni.showToast({
												title: '该功能暂未开放，敬请期待',
												icon:'none'
											})
										} else {
											uni.navigateTo({
												url: '/pages/usernum/usernum'
											});
										}

										break;
								}
							});
						}

					});
				}
			},

			/*---公司简介---*/
			company() {
				uni.navigateTo({
					url: '/pages/compan/compan'
				});
			},

			/*---轮播图---*/
			reqbanner() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'login/banner',
					method: 'POST',

					// data: {
					//   uid: that.data.stroge.uid
					// },
					success(res) {
						console.log(res)
						that.setData({
							banner: res.data.data
						});
					}

				});
			},

			reqstatu() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'shield/getShield',
					method: "POSt",
					data: {
						version_code: app.globalData.version_code
					},

					success(res) {
						// console.log('status:-------------------'+JSON.stringify(res) )
						that.setData({
							status: res.data.data.status
						});
					},
					fail(err) {
						// console.log(err,'----------------')
					}

				});
			},

			/*重新存储uid*/
			requid() {
				if (this.stroge != '') {
					uni.request({
						url: app.globalData.url + 'users/userinfo',
						method: "POST",
						data: {
							uid: this.stroge.uid
						},

						success(res) {
							uni.setStorageSync('key', res.data.data);
							this.stroge = res.data.data
						}

					});
				}
			},

			swiperclick(e) {
				console.log(e)
				var that = this;
				var url = e.target.dataset.url;
				var target = e.target.dataset.target;

				if (target == '_openxcx') {
					// uni
					// uni.navigateToMiniProgram({
					// 	appId: 'wx0866672a413d083c',
					// 	//要打开的小程序 appId
					// 	path: 'pages/index/index',
					// 	//打开的页面路径，如果为空则打开首页
					// 	envVersion: 'release',

					// 	// release 要打开的小程序版本。
					// 	success(res) {
					// 		// 打开成功
					// 		that.recordUserNum('fzsb');
					// 	}

					// });
				} else if (target == '_openzcjd') {
					uni.navigateTo({
						url: '/pages/policy/policy'
					});
				} else {
					uni.navigateTo({
						url: '/pages/bannerurl/bannerurl?url=' + url
					});
				}
			},

			/**
			 * 控制 pop 的打开关闭
			 * 该方法作用有2:
			 * 1：点击弹窗以外的位置可消失弹窗
			 * 2：用到弹出或者关闭弹窗的业务逻辑时都可调用
			 */
			// 提示框时间
			toggleDialog() {
				this.setData({
					showDialog: !this.showDialog
				});
			},

			//// 
			submit: function() {
				this.setData({
					showModal: true
				});
			},

			sign() {
				var that = this;

				if (that.uid == 0) {
					that.setData({
						showDialog: false
					});
					uni.showToast({
						title: '请先进行登录!',
						icon: 'none'
					});
					return false;
				}
				uni.navigateTo({
					url: '/pages/signtreaty/signtreaty?uid=' + that.uid
				});
			},

			esc() {
				this.setData({
					showDialog: false
				});
			},

			//是否弹框
			isPop() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'hhr/qianming_status',
					method: "POST",
					data: {
						uid: this.stroge.uid
					},

					success(res) {
						let Message_flag = uni.getStorageSync('message_flag');

						if (Message_flag != 1) {
							uni.request({
								url: app.globalData.api_url + '/h5/proposers/sendMessage',
								method: "POST",
								data: {
									uid: that.stroge.uid
								},

								success(res) {
									if (res.data.code == 200 || res.data.code == 201) {
										let message_flag = res.data.message_flag;
										uni.setStorageSync('message_flag', message_flag);
									}
								}

							});
						}

						if (res.data.code == 1016) {
							that.setData({
								showDialog: true,
								content: '由于您的合伙人协议还未签订，相关权益无法生效。请立即签订协议！'
							});
						} else if (res.data.code == 1017) {
							that.setData({
								showDialog: true,
								content: '由于您的签名不符合协议签署规定，合伙人权益不能生效，需要重新签订合伙人协议！'
							});
						} else {
							that.setData({
								showDialog: false
							});
						}
					}

				});
			},

			// 视频组件
			video() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'project_intro/getVideo',
					method: "POST",

					success(res) {
						if (res.data.code == 'ok') {
							if (res.data.data.status == 2) {
								that.setData({
									is_open_video: false
								});
							} else {
								that.setData({
									is_open_video: true,
									url_video: res.data.data.url,
									title: res.data.data.title
								});
							}
						} else {
							that.setData({
								is_open_video: false
							});
						}
					}

				});
			},

			/*统计打开合作渠道小程序人数*/
			recordUserNum(channel_flag) {
				var that = this;
				uni.request({
					url: app.globalData.url + 'statistics_user/recordUserNum',
					method: 'POST',
					data: {
						uid: that.uid,
						channel_flag: channel_flag
					}
				});
			},

			// tabar右上角红点
			tabrredhot() {
				var that = this;
				var uid = that.uid;

				if (uid == 0) {
					return;
				}

				uni.request({
					url: app.globalData.url + 'message_info/isReadMessage',
					method: 'POST',
					data: {
						uid: uid
					},

					success(res) {
						if (res.data.code == 'ok') {
							let message_num = res.data.data;

							if (message_num != 0) {
								let num = message_num + '';
								uni.setTabBarBadge({
									index: 2,
									text: num
								});
							} else {
								uni.removeTabBarBadge({
									index: 2
								});
							}
						} else {
							uni.removeTabBarBadge({
								index: 2
							});
						}
					}

				});
			},

			// 首页公告事件
			get_Notice() {
				var that = this;

				if (that.uid == 0) {
					that.setData({
						showDialog: false
					});
					uni.switchTab({
						url: '/pages/login/login'
					});
					return;
				}

				var data = {};
				data["uid"] = that.uid;
				var arr = {
					data: data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.api_url + 'index/popup/getPopUpData',
					method: 'POST',
					data: {
						data: aesData
					},

					success(res) {
						if (res.data.code == 200) {
							if (res.data.user_popup_data.status == 1) {
								that.setData({
									Notice_msg: res.data.data.content,
									showModalStatus: true
								});
							} else {
								that.know();
							}
						} else {
							that.know();
						}
					}

				});
			},

			// 公告事件
			know() {
				var that = this;
				var data = {};
				var data_pop = {};
				let pops_list = uni.getStorageSync('pops') || [];
				let time = util.newformatDate(new Date());

				if (that.stroge.real_status != 1) {
					if (pops_list.length == 0) {
						data['type'] = 1;
						data['time'] = time;
						pops_list.unshift(data);
						uni.setStorageSync('pops', pops_list);
						that.setData({
							showModalStatus: false,
							real_name_box: true
						});
					} else {
						var is_exist = that.get_list(1, 'real_name_box');

						if (!is_exist) {
							data_pop['type'] = 1;
							data_pop['time'] = time;
							pops_list.unshift(data_pop);
							uni.setStorageSync('pops', pops_list);
							that.setData({
								showModalStatus: false,
								real_name_box: true
							});
						}
					}

					return;
				} else if (that.stroge.my_family_num == 0) {
					if (pops_list.length == 0) {
						data['type'] = 2;
						data['time'] = time;
						pops_list.unshift(data);
						uni.setStorageSync('pops', pops_list);
						that.setData({
							showModalStatus: false,
							family_box: true
						});
					} else {
						var is_exist = that.get_list(2, 'family_box');

						if (!is_exist) {
							data_pop['type'] = 2;
							data_pop['time'] = time;
							pops_list.unshift(data_pop);
							uni.setStorageSync('pops', pops_list);
							that.setData({
								showModalStatus: false,
								family_box: true
							});
						}
					}

					return;
				} else {
					that.getbind_bank();
				}
			},

			// 查询是否已经签约，未签约进行绑定银行卡
			getbind_bank() {
				var that = this;
				var data = {};
				data["uid"] = that.uid;
				var arr = {
					data: data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.url + 'union_pay/getUserBanknoInfo',
					method: 'POST',
					data: {
						data: aesData
					},

					success(res) {
						that.setData({
							bank_status: res.data.code
						});

						if (res.data.code != 200) {
							var data_pop = {};
							let pops_list = uni.getStorageSync('pops') || [];
							let time = util.newformatDate(new Date());

							if (pops_list.length == 0) {
								data_pop['type'] = 3;
								data_pop['time'] = time;
								pops_list.unshift(data_pop);
								uni.setStorageSync('pops', pops_list);
								that.setData({
									showModalStatus: false,
									bind_bank_box: true
								});
							} else {
								var is_exist = that.get_list(3, 'bind_bank_box');

								if (!is_exist) {
									data_pop['type'] = 3;
									data_pop['time'] = time;
									pops_list.unshift(data_pop);
									uni.setStorageSync('pops', pops_list);
									that.setData({
										showModalStatus: false,
										bind_bank_box: true
									});
								}
							}
						}
					}

				});
			},

			// 首页弹窗事件
			close() {
				this.setData({
					showModalStatus: false
				});
			},

			// 首页实名认证弹窗
			close_real_name() {
				this.setData({
					real_name_box: false
				});
			},

			// 前往实名认证
			go_real_name() {
				uni.navigateTo({
					url: '/pages/myadd/myadd'
				});
				this.setData({
					real_name_box: false
				});
			},

			// 前往添加家人
			go_add_family() {
				this.setData({
					family_box: false
				});
				uni.navigateTo({
					url: '/pages/mentary/mentary'
				});
			},

			// 关闭添加家人弹窗
			close_family_box() {
				this.setData({
					family_box: false
				});
			},

			// 前往绑定银行卡
			go_bind_bank() {
				this.setData({
					bind_bank_box: false
				});
				uni.navigateTo({
					url: '/pages/bind_bank/bind_bank?oid=' + this.oid
				});
			},

			// 关闭绑定银行卡
			close_bind_bank() {
				this.setData({
					bind_bank_box: false
				});
			},

			// 数组遍历事件
			get_list(param_type, box_flag) {
				var that = this;
				let pops_list = uni.getStorageSync('pops') || [];
				let time = util.newformatDate(new Date());
				let is_exist = false;

				for (let i = 0; i < pops_list.length; i++) {
					var type = pops_list[i]['type'];
					var storage_time = pops_list[i]['time'];

					if (type == param_type) {
						if (storage_time == time) {
							that.setData({
								showModalStatus: false,
								box_flag: false
							});
						} else {
							pops_list[i]['time'] = time;
							uni.setStorageSync('pops', pops_list);
							that.setData({
								showModalStatus: false,
								box_flag: true
							});
						}

						is_exist = true;
						return is_exist;
					}
				}
			},

			// 获取用户步骤数据
			getProgress() {
				var that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				var arr = {
					data: data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.api_url + 'h5/proposers/getProgress',
					method: 'POST',
					data: {
						data: aesData
					},

					success(res) {
						if (res.data.code == 200 || res.data.code == 201 || res.data.code == 203 || res.data.code == 204) {
							let next_step = res.data.data.next_step;
							let case_status = res.data.data.status;

							if (case_status == 6) {
								// case_status==6 已打款
								uni.navigateTo({
									url: '/pages/apply_help/apply_help?uid=' + that.uid + '&case_id=' + res.data.data.case_id + '&code=' + res
										.data.gongyue_code + '&ele_card_pass_flag=' + 1
								});
							} else {
								if (res.data.code == 204) {
									var ele_card_pass_flag = 2;
								} else {
									var ele_card_pass_flag = 1;
								}

								if (next_step == 1) {
									uni.navigateTo({
										url: '/pages/apply_help/apply_help?uid=' + that.uid + '&case_id=' + res.data.data.case_id + '&code=' +
											res.data.gongyue_code + '&ele_card_pass_flag=' + ele_card_pass_flag
									});
								} else if (next_step == 2) {
									uni.navigateTo({
										url: '/pages/upload_apply/upload_apply?uid=' + that.uid + '&case_id=' + res.data.data.case_id
									});
								} else if (next_step == 3) {
									uni.navigateTo({
										url: '/pages/apply_bill/apply_bill?uid=' + that.uid + '&case_id=' + res.data.data.case_id
									});
								} else if (next_step == 4) {
									uni.navigateTo({
										url: '/pages/witness/witness?uid=' + that.uid + '&case_id=' + res.data.data.case_id
									});
								} else if (next_step == 5) {
									uni.navigateTo({
										url: '/pages/apply_help_msg/apply_help_msg?uid=' + that.uid + '&cose_status=' + res.data.data.status +
											'&desc=' + res.data.data.desc + '&is_thanks_letter=' + res.data.data.is_thanks_letter + '&video_url=' +
											res.data.data.video_url + '&case_id=' + res.data.data.case_id
									});
								} else {
									uni.navigateTo({
										url: '/pages/apply_help/apply_help?uid=' + that.uid + '&case_id=' + res.data.data.case_id + '&code=' +
											res.data.gongyue_code + '&ele_card_pass_flag=' + ele_card_pass_flag
									});
								}
							}
						} else {
							uni.showToast({
								title: res.data.msg,
								icon: 'none',
								duration: 1500
							});
						}
					}

				});
			},

			// 获取金币配置
			getGolod(typekid) {
				let that = this;
				var data = {};
				data["type"] = typekid;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'theme_config/scoreConfig',
					data: {
						data: aesData
					},
					method: 'get'
				}).then(res => {
					if (res.data.code == 0) {
						let other = res.data.data;
						uni.setStorageSync(typekid, other)
					}
				}).catch(err => {
					// console.error('登录异常', err);
				})
			},
		}
	};
</script>
<style lang="scss" scoped>
	@import url("./index.css");

	.newBox {
		width: 100%;
		min-height: 100px;
		padding: 0 30rpx;
		box-sizing: border-box;
		opacity: 1;
		border-radius: 8px;
		background-color: #EFF4FD;

		.itembox {
			width: 686rpx;
			height: 80rpx;
			border-top: 2rpx solid #EFF4FD;
			padding: 0 30rpx;
			box-sizing: border-box;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.itemsign {
				width: 58rpx;
				height: 34rpx;
				border: 1rpx solid #FFAC38;
				opacity: 1;
				border-radius: 8rpx;
				display: flex;
				justify-content: center;
				align-items: center;

				text {
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 22rpx;
					color: #FFAC38;
					opacity: 1;
				}
			}

			.itemcontent {
				width: 624rpx;
				height: 100%;
				padding-left: 20rpx;
				box-sizing: border-box;
				display: block;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;

				text {
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 80rpx;
					color: #333333;
					opacity: 1;
				}
			}
		}
	}

	.newtipBox {
		width: 100%;
		height: 155rpx;
		display: flex;
		justify-content: center;
		align-items: flex-end;

		.newismgs {
			width: 686rpx;
			height: 124rpx;
			// background-color: #f40;
		}
	}

	.notice {
		width: 100%;
		height: 92rpx;
		// background:  #FD62F8;
		margin-top: 20rpx;
		padding: 0 30rpx;
		box-sizing: border-box;
		display: flex;
		justify-content: flex-start;
		align-items: center;
		border-bottom: 2rpx solid #EFF4FD;

		.notice_left {
			width: 80%;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			.notice_icon {
				width: 8rpx;
				height: 36rpx;
				background: #4D72E7;
				opacity: 1;
				border-radius: 4rpx;
			}

			.newsText {
				width: 86rpx;
				height: 56rpx;
				margin-left: 15rpx;
			}

			.swiper {
				width: 500rpx;
				height: 100%;

				.swiper-item {
					width: 500rpx;
					height: 100%;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
					display: flex;
					justify-content: flex-start;
					align-items: center;
				}
			}
		}

		.notice_right {
			width: 20%;
			height: 100%;
			display: flex;
			justify-content: flex-end;
			align-items: center;

			text {
				font-size: 24rpx;
				font-family: Source Han Sans SC;
				font-weight: 400;
				line-height: 6rpx;
				color: #FF6B24;
				opacity: 1;
			}

			.icon_right {
				width: 12rpx;
				height: 22rpx;
				// background-color: #F0AD4E;
				margin-left: 12rpx;
			}
		}
	}

	.bannerTip {
		width: 100%;
		height: 110rpx;
		// background: #FD62F8;
		border-bottom: 2rpx solid #EFF4FD;
		border-top: 2rpx solid #EFF4FD;
		display: flex;
		justify-content: center;
		align-items: center;

		.myimgs {
			width: 460rpx;
			height: 84rpx;
			background-color: #f40;
		}
	}

	.swbox {
		width: 686rpx;
		height: 220rpx;
	}
	.contentArea {
		width: 100%;
		height: 378rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		.leftBox {
			width: 330rpx;
			height: 100%;
			border-right: 2rpx solid #EFF4FD;
			display: flex;
			justify-content: flex-start;
			align-items: flex-start;
			flex-flow: column;
			padding-left: 30rpx;
			padding-top: 20rpx;
			box-sizing: border-box;

			.imgs {
				width: 240rpx;
				height: 240rpx;
				// background-color: #f40;
				margin-top: 15rpx;
			}
		}

		.rightBox {
			width: 418rpx;
			height: 100%;

			.rightop {
				width: 100%;
				height: 178rpx;
				border-bottom: 2rpx solid #EFF4FD;
				padding-top: 20rpx;
				padding-left: 10rpx;
				padding-right:10rpx;
				box-sizing: border-box;

				.desc_imgs {
					width: 100%;
					height: 90rpx;
					// background-color: #f40;
					display: flex;
					justify-content: space-between;
					align-items: center;

					.desc {
						width: 130rpx;
						height: 100%;
						display: flex;
						justify-content: flex-start;
						text{
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							line-height: 28rpx;
							color: #F99811;
							opacity: 1;
							white-space: nowrap;
							overflow: hidden;
							text-overflow: ellipsis;
						}
					}

					.imgs {
						width: 200rpx;
						height: 90rpx;
						.imgsicon {
							width: 200rpx;
							height: 90rpx;
						}
					}
				}

			}

			.rightbtn {
				width: 100%;
				height: 198rpx;
				display: flex;

				.rightbtn_left {
					width: 208rpx;
					height: 198rpx;
				
					border-right: 2rpx solid #EFF4FD;
					padding: 20rpx 0 0 15rpx;
					box-sizing: border-box;
                    white-space:nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
					.imgs {
						width: 130rpx;
						height: 56rpx;
						margin-left: 24rpx;
						margin-top: 20rpx;
					}
				}

				.rightbtn_right {
					width: 175rpx;
					height: 198rpx;
					padding: 20rpx 0 0 15rpx;
					box-sizing: border-box;
					
					.imgs {
						width: 130rpx;
						height:56rpx;
						margin-left: 24rpx;
						margin-top: 20rpx;
					}
				}
			}
		}

		.title {
			width:175rpx;
			height: 45rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			// white-space:nowrap;
			// overflow: hidden;
			// text-overflow: ellipsis;
			text{
				font-size: 36rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 40rpx;
				color: #333333;
				opacity: 1;
				white-space:nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
			}
		}
		.desc {
			margin-top: 10rpx;
			margin-left: 10rpx;
			font-size: 24rpx;
			font-family: PingFang SC;
			font-weight: 400;
			line-height: 28rpx;
			color: #F99811;
			opacity: 1;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
	}
    .FloatingBox{
		width: 140rpx;
		height: 175rpx;
		// background-color: #f40;
		position: fixed;
		right: 35rpx;
		bottom: calc(50% - 85rpx);
		.flotingCover{
			width: 140rpx;
			height: 175rpx;
			position: relative;
			.imgsBox{
				width: 140rpx;
				height: 175rpx;
			}
			.floaingClaer{
				width: 30rpx;
				height: 30rpx;
				position: absolute;
				left: 10rpx;
				top: 10rpx;
			}
			.floatingtext{
				width: 140rpx;
				height: 175rpx;
				position: absolute;
				left: 0;
				top: 0;
				display: flex;
				justify-content: center;
				align-items: center;
				flex-direction: column;
				.floaingDay{
					margin-top: 25rpx;
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 24rpx;
					color: #FFFFFF;
					opacity: 1;
				}
				.floaingGrade{
					font-size: 60rpx;
					font-family: PingFang SC;
					font-weight: 600;
					line-height: 60rpx;
					color: #FFFFFF;
					opacity: 1;
				}
				.floaingsign{
					margin-top: 10rpx;
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 24rpx;
					color: #FFFFFF;
					opacity: 1;
				}
			}
		}
	}
	// .popcover {
	// 	width: 100%;
	// 	height: 100vh;
	// 	background: rgba(0, 0, 0, .56);
	// 	position: absolute;
	// 	left: 0;
	// 	top: 0;
	// 	z-index: 999;
	// 	display: flex;
	// 	justify-content: center;
	// 	align-items: center;
	// 	flex-flow: column;

		.mycontent2 {
			width: 606rpx;
			height: 624rpx;
			background-color: #FFFFFF;
			border-radius: 8rpx;
			margin: 0 auto;
			margin-bottom: 60%;
			.title {
				width: 100%;
				height: 100rpx;
				background-color: #FFFFFF;
				border-bottom: 1rpx solid #EFEFEF;
				text-align: center;
				text {
					display: block;
					margin: 0 auto;
					font-size: 36rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 100rpx;
					color: #646464;
					opacity: 1;
				}
			}

			.itemsBoxs {
				width: 100%;
				padding: 20rpx 20rpx;
				box-sizing: border-box;
				display: flex;

				.yellow {
					width: 16rpx;
					height: 16rpx;
					margin-top: 15rpx;
					display: block;
					background: #FFAC38;
					border-radius: 50%;
					opacity: 1;
					margin-right: 10rpx;
				}

				text {
					font-size: 30rpx;
					font-family: SourceHanSansCN-Regular;
					line-height: 36rpx;
					color: #646464;
					opacity: 1;
				}
			}

			.myKonew {
				width: 360rpx;
				height: 80rpx;
				background: #FFAC38;
				opacity: 1;
				border-radius: 40rpx;
				margin: 15rpx auto 0;
				text-align: center;

				text {
					font-size: 40rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 80rpx;
					color: #FFFFFF;
					opacity: 1;
				}
			}

		}

		.mycontent1 {
			width: 606rpx;
			height: 700rpx;
			background-color: #FFFFFF;
			border-radius: 8rpx;
            margin: 0 auto;
            margin-bottom: 60%;
			.imgs {
				width: 352rpx;
				height: 234rpx;
				// margin-top: 20rpx;
				// background-color: #f40;
				margin: 20rpx auto;
				display: block;
			}

			.redText {
				width: 100%;
				height: 80rpx;
				text-align: center;

				text {
					font-size: 36rpx;
					font-family: Source Han Sans CN;
					font-weight: 500;
					line-height: 80rpx;
					color: #FF5451;
					opacity: 1;
				}
			}

			.myKonew {
				width: 510rpx;
				height: 100rpx;
				background: #FFAC38;
				opacity: 1;
				border-radius: 56rpx;
				margin: 30rpx auto 0;
				text-align: center;

				text {
					font-size: 44rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 100rpx;
					color: #FFFFFF;
					opacity: 1;
				}
			}

			.mygetMoney {
				width: 510rpx;
				height: 100rpx;
				border: 2rpx solid #FFAC38;
				opacity: 1;
				border-radius: 56rpx;
				margin: 30rpx auto 0;
				text-align: center;

				text {
					font-size: 44rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					line-height: 100rpx;
					color: #FFAC38;
					opacity: 1;
				}
			}
		}

		.imgsBox {
			width: 100%;
			height: 60rpx;
			margin-top: 30rpx;

			.imgs {
				width: 60rpx;
				height: 60rpx;
				display: block;
				margin: 0 auto;
				border-radius: 50%;
				// background-color: #f40;
			}
		}

		.content3 {
			width: 600rpx;
			height: 728rpx;
			position: relative;
             margin: 0 auto;
             margin-bottom: 40%;
			.imgs {
				width: 600rpx;
				height: 728rpx;
			}

			.tiptext {
				width: 100%;
				height: 60rpx;
				// background-color: #f40;
				position: absolute;
				top: 406rpx;
				left: calc(50% - 300rpx);
				text-align: center;

				text {
					font-size: 60rpx;
					font-family: Source Han Sans CN;
					font-weight: 500;
					line-height: 60rpx;
					color: #4D4D4D;
					opacity: 1;
					margin-left: 10rpx;
				}
			}

			.contenttips {
				width: 100%;
				height: 50rpx;
				// background-color: #f40;
				position: absolute;
				top: 486rpx;
				left: calc(50% - 300rpx);
				text-align: center;

				text {
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 50rpx;
					color: #666666;
					opacity: 1;
				}
			}

			.grdesbtn {
				width: 520rpx;
				height: 90rpx;
				background: #FF9600;
				position: absolute;
				bottom: 40rpx;
				left: calc(50% - 260rpx);
				text-align: center;
				opacity: 1;
				border-radius: 93rpx;

				text {
					font-size: 44rpx;
					font-family: SourceHanSansCN-Medium;
					line-height: 90rpx;
					color: #FFFFFF;
					opacity: 1;
				}
			}
          .clear {
          	width: 72rpx;
          	height: 72rpx;
          	display: block;
          	margin: 0 auto;
          	position: absolute;
          	bottom: -10%;
          	left: calc(50% - 36rpx);
          }
		}

		.content4 {
			width: 600rpx;
			min-height: 600rpx;
			position: relative;
            margin: 0 auto;
            margin-bottom: 30%;
			.imgs {
				width: 600rpx;
				height: 930rpx;
			}

			.toptitles {
				width: 100%;
				height: 60rpx;
				text-align: center;
				position: absolute;
				top: 178rpx;
				font-size: 40rpx;
				font-family: PingFang SC;
				font-weight: 800;
				line-height: 60rpx;
				color: #FFFFFF;
				opacity: 1;
			}

			.title {
				width: 100%;
				height: 60rpx;
				position: absolute;
				top: 360rpx;
				text-align: center;
				font-size: 48rpx;
				font-family: Source Han Sans CN;
				font-weight: bold;
				line-height: 60rpx;
				color: #FF5151;
				opacity: 1;
			}

			.tiptext {
				width: 100%;
				height: 60rpx;
				position: absolute;
				top: 450rpx;
				text-align: center;
				font-size: 48rpx;
				font-family: Source Han Sans CN;
				font-weight: 500;
				line-height: 40rpx;
				color: #4D4D4D;
				opacity: 1;
			}

			.tipsBox {
				width: 540rpx;
				height: 92rpx;
				background: #FFF7CC;
				border-radius: 46rpx;
				position: absolute;
				top: 515rpx;
				left: calc(50% - 270rpx);
				text-align: center;
				font-size: 34rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				line-height: 92rpx;
				color: #FFAC38;
			}

			.freeBox {
				width: 550rpx;
				height: 270rpx;
                display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				overflow-y: auto;
				position: absolute;
				bottom:30rpx;
				left: calc(50% - 270rpx);
				.tips{
					width: 540rpx;
					height: 80rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					text{
						font-size: 30rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						line-height: 40rpx;
						color:  #AAAAAA;
						margin-top:10rpx;
					}
				}
				.shopBoxs {
					width: 540rpx;
					height: 112rpx;
					margin-top: 10rpx;
					background: #FFE6E6;
					border-radius: 8rpx;
					display: flex;
					align-items: center;
					padding: 0 15rpx;
					box-sizing: border-box;
					.imgs {
						width: 94rpx;
						height: 94rpx;
					}
					.texts {
						width: 300rpx;
						height: 100%;
						display: flex;
						flex-flow: column;
						justify-content: center;
						padding-left: 20rpx;
						box-sizing: border-box;
						.shopname {
							width: 280rpx;
							height: 100rpx;
						    // background-color: #f40;
							overflow: hidden;
							white-space: nowrap;
							text-overflow: ellipsis;
							font-size: 34rpx;
							font-family: Source Han Sans CN;
							font-weight: 400;
							line-height: 60rpx;
							color: #4D4D4D;
							opacity: 1;
							
						}
						.desc {
							font-size: 16rpx;
							font-family: SourceHanSansCN-Regular;
							line-height: 56rpx;
							color: #AAAAAA;
							opacity: 1;
						}

					}

					.btnget {
						width: 115rpx;
						height: 100%;
						display: flex;
						justify-content: center;
						align-items: center;
						.mygetBtn {
							width: 110rpx;
							height: 44rpx;
							background: #FF5151;
							opacity: 1;
							border-radius: 30rpx;
							text-align: center;
							font-size: 24rpx;
							font-family: SourceHanSansCN-Medium;
							line-height: 44rpx;
							color: #FFFFFE;
							opacity: 1;
						}
					}
				}
			}
           .clear {
           	width: 72rpx;
           	height: 72rpx;
           	display: block;
           	margin: 0 auto;
           	position: absolute;
           	bottom: -10%;
           	left: calc(50% - 36rpx);
           	// margin-bottom: 30%;
           }
           
		}

	
</style>
