<template>
<!--pages/ontinue/ontinue.wxml-->
<view class="conter">
  <view class="bg">
    <image src="/static/images/banner/chahua.png"></image>
  </view>
  <view class="show_family_list" @tap="go_family_list">
    <view class="family_list_title">查看家人列表</view>
  </view>
  <view class="wrap">
    <text>家人姓名:</text>
    <input type="text" placeholder="请输入家人的姓名(必填)" @blur="family_nameFun"  v-model="family_name" name="family_name"></input>
  </view>
  <block v-for="(item, index) in list" :key="index">
    <view class="list">
      <view class="name">{{item.relev_name}}</view>
      <view class="dele" @tap.stop="deleate" :data-id="index">解除</view>
    </view>
  </block>
  <view class="btn" @tap.stop="addontinue" >继续添加</view>
  <button class="buttons" @tap.stop="sumebtn" :disabled="disabled">确定加入</button>
</view>
</template>

<script>
// pages/ontinue/ontinue.js
// const app = getApp();

export default {
  data() {
    return {
      list: '',
      family_name:'',
      disabled: true,
      uid: 0
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let userStorageData = uni.getStorageSync("key");
    this.setData({
      uid: userStorageData.uid
    });
  },

  onShow() {
 
    this.getClick();

  },

  methods: {
	 getClick(){
		 let list = uni.getStorageSync("test");
		 this.setData({
		   list: list
		 });
		 if (list.length == 0) {
		   this.setData({
		     disabled: true
		   });
		 } else {
		   this.setData({
		     disabled: false
		   });
		 }
	 },
    // 将家人名字保存在本地中
    Save_Family_Data() {
      var that = this;
      var data = {};
      data['relev_name'] = that.family_name;
      data['account_uid'] = that.uid;
      data['id_card'] = '';
      let arr = uni.getStorageSync("test") || [];
      arr.unshift(data);
      uni.setStorageSync("test", arr);
	  this.list = arr
      // this.onShow(); //家人信息保存本地成功后清空全局变量
       this.getClick();
      this.setData({
        family_name: ''
      });
    },

    /*删除数据*/
    deleate(e) {
      var that = this;
      const id = e.currentTarget.dataset.id;
      const lists = that.list;
      const arr = lists.splice(id, 1);
       this.getClick();
      if (lists.length !== 0) {
        uni.setStorageSync('test', lists);
      } else {
        uni.setStorageSync('test', []);
      }

      // this.onShow();
    },

    /*继续添加*/
    addontinue() {
      var data_list = uni.getStorageSync("test");
      var family_num = data_list.length;
      this.getClick();
      if (family_num >= 3) {
        uni.showToast({
          title: '每次只支持为3位家人加入',
          icon: 'none'
        });
        return false;
      }

      if (this.family_name == '') {
        uni.showToast({
          title: '请输入家人姓名'
        });
        return false;
      } else {
          this.Save_Family_Data();
      }
    },

    /*---提交订单----*/
    sumebtn() {
      var FamilyData = this.list;

      if (FamilyData.length == 0) {
        uni.showToast({
          title: '请先添加家人信息',
          icon: 'none'
        });
        return;
      }

      uni.navigateTo({
        url: '/pages/aplay/aplay?oid=9'
      });
    },

    // 查看家人列表事件
    go_family_list() {
      uni.navigateTo({
        url: '/pages/familylist/familylist'
      });
    },

    /*---获取家人姓名---*/
    family_nameFun() {
      var that = this;
      var data_list = uni.getStorageSync("test");
      var family_num = data_list.length;
      var name =that.family_name;
      const reg = /^[\u0391-\uFFE5]+$/;

      if (!reg.test(name)) {
        uni.showToast({
          title: '请输入正确的用户名,谢谢',
          icon: 'none'
        });
        return;
      }

      if (family_num > 0) {
        data_list.forEach(v => {
          if (name == v.relev_name) {
            uni.showToast({
              title: '请勿添加相同名字的家人',
              icon: 'none'
            });
          }
        });
        return;
      }

      if (family_num >= 3) {
        uni.showToast({
          title: '每次只支持为3位家人加入',
          icon: 'none'
        });
        return false;
      }
	  
      this.Save_Family_Data();
    }

  }
};
</script>
<style>
/* pages/ontinue/ontinue.wxss */
.bg {
  width: 100%;
  height: 40vh;
}

.bg image {
  width: 100%;
  height: 100%;
}

.list {
  display: flex;
  justify-content: space-around;
  width: 80%;
  margin: 20px auto;
  font-size: 12px;
  color: #333;
}

.btn {
  width: 80%;
  margin: 20px auto;
  text-align: center;
  line-height: 35px;
  background-color: #eeee;
  color: #107BFD;
  border-radius: 10px;
}

.buttons {
  position: absolute;
  left: calc(50% - 343rpx); 
  bottom: 20px;
  /* margin-left: -40%; */
  width: 686rpx;
  border-radius: 50rpx;
  line-height: 40px;
  background-color: #0B3FFF;
  color: #fff;
}
.show_staff_list {
  display: flex;

}

.family_list_title {
  border: 1rpx solid #eee;
  border-radius: 8px;
  padding: 20rpx;
  color: #107BFD;
  margin: 20rpx;
  width: 80px;
  font-size: 13px;
  margin-left: auto;
}
.wrap {
  display: flex;
  margin: auto;
  width: 80%;
  padding: 18px 10px;
  box-shadow: 0 0 10px 0 #ccc;
  border-radius: 10px;
}
.wrap input {
  width: 70%;
  margin-left: 12px;
}
</style>