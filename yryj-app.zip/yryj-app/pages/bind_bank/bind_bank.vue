<template>
<!--pages/bind_bank/bind_bank.wxml-->
<!-- <view @submit="formSubmit" v-if="status==1">
<view class="bind_bank_card">
  <view class="bank_card_msg">
    <view class="bank_card">
      <view class="bank_card_label">姓名</view>
     <view>{{user}}</view>
    </view>
    <view class="bank_card">
      <view class="bank_card_label">身份证</view>
      <view>{{Idcard}}</view>
    </view>
    <view class="bank_card">
      <view class="bank_card_label">银行名</view>
      <view class="aa">
      <picker @change="bindPickerChange" :data-value="objectArray[index].value" :value="index" range-key="name" :range="objectArray">
        <view class="picker">
         {{objectArray[index].name}}
        </view>
      </picker>
      </view>
    </view>
    <view class="bank_card">
      <view class="bank_card_label">银行卡号</view>
      <input type="number" :value="userInputCardNum" placeholder="储蓄卡/借记卡" placeholder-class="placeholder-tip" @blur="click"></input>
      <view class="clearimag" @tap="clearInputEvent" data-type="bankCard" v-if="userInputCardNum">
        <image src="/static/images/banner/clear.png"></image>
      </view>
    </view>
    <view class="bank_card">
      <view class="bank_card_label">预留电话</view>
      <input type="number" :value="phone" maxlength="11" placeholder="请输入银行卡预留电话" placeholder-class="placeholder-tip" @blur="phoneInput"></input>
      <view class="clearimag" @tap="clearInputEvent" data-type="phone" v-if="phone">
        <image src="/static/images/banner/clear.png"></image>
      </view>
      <view class="rightimag" @tap="toggleDialog">
        <image src="/static/images/banner/wenhao.png"></image>
      </view>
    </view>
    <view class="bank_card_show">
      <view class="bank_image_img" v-if="bankimg">
        <image :src="bankimg"></image>
      </view>
      <view class="bank_name" v-else>{{bankName}}</view>
    </view>
  </view>
  <button class="bind_btn" form-type="submit" :disabled="btn_disabled">{{btn_next_name}}</button>
  <view :class="'zan-dialog ' + ( showDialog ? 'zan-dialog--show' : '' )">
    <view class="zan-dialog__mask"></view>
    <view class="zan-dialog__container">
      <view class="title">手机号说明</view>
      <view class="content">银行预留手机号是你在办理该银行卡时所填写的手机号。没有预留、手机号忘记或者已停用，请联系银行客服处理。</view>
      <view class="button">
        <view class="buttons" plain @tap="toggleDialog">知道了</view>
      </view>
    </view>
  </view>
  <view :class="'zan-dialog ' + ( showlog ? 'zan-dialog--show' : '' )">
    <view class="zan-dialog__mask"></view>
    <view class="zan-dialog__container">
      <view class="title">请输入短信验证码</view>
      <view class="changeInfoName">
        <input placeholder="请输验证码" placeholder-class="placeholder-tip-msg" @blur="codeInput" :value="code" style="width:50%;"></input>
      </view>
      <view class="button">
        <button class="buttons" @tap="getmessage" :disabled="disabled">{{btn_name}}</button>
      </view>
    </view>
  </view>
</view>
</view> -->
   <view class="content">
   	<view class="items">
   		<view class="itemText">
   			<text>用户名</text>
   		</view>
   		<view class="itemstext">
   			<input type="text" v-model="user" placeholder-class="defual" placeholder="请输入持卡人姓名" />
   		</view>
   	</view>
	<view class="items">
		<view class="itemText">
			<text>身份证</text>
		</view>
		<view class="itemstext">
			<input type="text"  v-model="Idcard" placeholder-class="defual" placeholder="请输入持卡人身份证号" />
		</view>
	</view>

   	<view class="items">
   		<view class="itemText">
   			<text>银行</text>
   		</view>
   		<view class="itemstext">
		   <picker @change="bindPickerChange" :data-value="objectArray[index].value" :value="index" range-key="name" :range="objectArray">
   			<input type="text" disabled="disabled" :value="objectArray[index].name" placeholder-class="defual" placeholder="请选择开户行" />
		  </picker>
   		</view>
   	</view>
	<view class="items">
		<view class="itemText">
			<text>银行卡号</text>
		</view>
		<view class="itemstext">
			<input type="text"  v-model="userInputCardNum" placeholder-class="defual" @blur="click"  placeholder="请输入银行卡号" />
		</view>
	</view>
<!-- 	<view class="items">
		<view class="itemText">
			<text>预留电话</text>
		</view>
		<view class="itemstext">
			<input type="text" v-model="phone" placeholder-class="defual"   placeholder="请输入银行卡预留电话" />
		</view>
	</view> -->
	<view class="itemsBox">
		<view class="itemsLeft">
			<text>预留电话</text>
		</view>
		<view class="itemsRight">
			<input type="text" v-model="phone" placeholder="请输入银行卡预留电话" class="input" placeholder-class="deful" />
		    
			<view class="yancode" style="background-color: none;color: #666;" v-if="disabled">
		    	<text>{{codename}}s后重新获取</text>
		    </view>
			<view class="yancode" v-else @tap="formSubmit">
				<text>获取验证码</text>
			</view>
		</view>
	</view>
	<view class="itemsBox">
		<view class="itemsLeft">
			<text>验证码</text>
		</view>
		<view class="itemsRight">
			<input type="text" v-model="codeNum" placeholder="请输入验证码" class="input" placeholder-class="deful" />
		</view>
	</view>
   	<mybottom name="确认"  @sublimt="getmessage"></mybottom>
   </view>
</template>

<script>
var bankCard = require("../../utils/bankCard.js"),
    sha_1 = require("../../utils/sha_1.js"),
    reg = require("../../utils/reg.js");
const app = getApp();

export default {
  data() {
    return {
      userInputCardNum: '',
      // 银行卡账号
      cardlen: 0,
      bankName: '',
      // 银行名字
      cardType: '',
      // 银行卡类型
      user: '',
      // 持卡人姓名
      phone: '',
      // 持卡人手机号
      bankimg: '',
      //银行卡图标
      Idcard: '',
      //用户身份证
      showDialog: false,
      showlog: false,
      //短信验证码对话框
      uid: 0,
      rank: 0,
	  codename:'',
	  codeNum:'',
      // codename: '获取验证码',
      // text: '接收短信的电话号码为您办理银行卡时所填写的电话号码，请确认您是否填写正确',
      order_id: 0,
      code: '',
      bank: '',
      sendbtn: false,
      btn_name: '确定',
      disabled: false,
      lock: false,
      btn_next_name: '进行下一步',
      btn_disabled: true,
      getest: '',
      status: 1,
      oid: 0,
      title: '',
      objectArray: [{
        id: 0,
        name: '请选择银行',
        value: ''
      }, {
        id: 1,
        name: '中国建设银行',
        value: 'CCB'
      }, {
        id: 2,
        name: '中国农业银行',
        value: 'ABC'
      }, {
        id: 3,
        name: '中国交通银行',
        value: 'COMM'
      }, {
        id: 4,
        name: '中国邮政储蓄银行',
        value: 'PSBC'
      }, {
        id: 5,
        name: '中国工商银行',
        value: 'ICBC'
      }, {
        id: 6,
        name: '中国银行',
        value: 'BOC'
      }, {
        id: 7,
        name: '平安银行',
        value: 'SPABANK'
      }, {
        id: 8,
        name: '中信银行',
        value: 'CITIC'
      }, {
        id: 9,
        name: '中国民生银行',
        value: 'CMBC'
      }, {
        id: 10,
        name: '华夏银行',
        value: 'HXBANK'
      }, {
        id: 11,
        name: '广发银行',
        value: 'GDB'
      }, {
        id: 12,
        name: '兴业银行',
        value: 'CIB'
      }, {
        id: 13,
        name: '上海银行',
        value: 'SHBANK'
      }, {
        id: 14,
        name: '中国光大银行',
        value: 'CEB'
      }],
      index: 0,
      bank_type: ''
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.getstroge();
    this.reqstatu();

    if (e.oid == 9) {
      //只有是家人加入才进行本地数据的获取
      this.getstrogeFamilyData();
    }

    this.setData({
      oid: e.oid
    });
  },
  methods: {
    /*获取本地数据*/
    getstroge() {
      const stroge = uni.getStorageSync('key');
      this.setData({
        user: stroge.real_name,
        Idcard: stroge.id_card,
        uid: stroge.uid,
        rank: stroge.rank
      });
    },

    //获取家人本地数据
    getstrogeFamilyData() {
      var that = this;
      const getest = uni.getStorageSync('test');
      that.setData({
        getest: getest
      });
    },

    click(e) {
      var that = this;
      let value = e.detail.value;
      that.setData({
        userInputCardNum: value
      });
      let cardNum = that.userInputCardNum;

      if (that.bank_type == '') {
        that.setData({
          //如果没有选择银行名，置空卡号
          userInputCardNum: ''
        });
        uni.showToast({
          title: '请先选择银行名！',
          icon: 'none',
          duration: 1500
        });
        return;
      }

      if (cardNum == '' || cardNum == 0) {
        uni.showToast({
          title: '请输入正确的银行卡卡号',
          icon: 'none'
        });
        return;
      }

      let cardNo = cardNum.replace(/\s*/g, ""); // 格式化字符串的空格

      uni.request({
        url: 'https://ccdcapi.alipay.com/validateAndCacheCardInfo.json?cardBinCheck=true&cardNo=' + cardNo,
        method: 'GET',

        success(res) {
          if (res.data.stat == 'ok' && res.data.validated) {
            let bank = res.data.bank;

            if (bank != that.bank_type) {
              var title = '卡号和银行名不一致,请重新选择或填写！';
              that.msgTips(title);
            } else {
              that.setData({
                // 银行类型上传
                bank: bank
              });
              uni.downloadFile({
                url: 'https://apimg.alipay.com/combo.png?d=cashier&t=' + bank,

                success(res) {
                  if (res.statusCode == 200) {
                    that.setData({
                      bankimg: res.tempFilePath
                    }); // 将数组里的数据放入缓存中

                    var stroge_bank = [{
                      type: bank,
                      img: res.tempFilePath
                    }];
                    uni.setStorageSync("bankimg_list", stroge_bank);
                  }
                }

              });
            }
          } else {
            uni.showToast({
              title: '请输入正确的银行卡卡号',
              icon: 'none'
            });
            return;
            var temp = bankCard.bankCardAttribution(cardNo);

            if (temp == Error) {
              temp.bankName = '';
              temp.cardTypeName = '';
            } else {
              that.setData({
                bankName: temp.bankName
              });
            }
          }
        }

      });
    },

    // 银行卡提示信息
    msgTips(title) {
      uni.showToast({
        title: title,
        icon: 'none'
      });
      return;
    },

    // 账号输入框的监听事件
    bankcardInput: function (e) {
      console.log(e);
      var card = e.detail.value; // 格式

      var len = card.length; //判断用户是输入还是回删

      if (len > this.cardlen) {
        //用户输入
        if ((len + 1) % 5 == 0) {
          card = card + ' ';
        }
      } //将处理后的值赋予到输入框


      this.setData({
        userInputCardNum: card
      }); //将每次用户输入的卡号长度赋予到长度中转站

      this.setData({
        cardlen: len
      });
    },
    // 卡类型事件
    bankcardTypeInput: function (e) {
      let cardTypeInput = e.detail.value;
      console.log(cardTypeInput);
      this.setData({
        cardType: cardTypeInput
      });
    },
    // 持卡人姓名事件
    userInput: function (e) {
      let username = e.detail.value;
      reg.validChinesName(username);
      this.setData({
        user: username
      });
    },
    // 持卡人手机号事件
    e: function (e) {
		console.log()
      let phoneNum = e.detail.value;
      var verif_phone = reg.validphoneNum(phoneNum);

      if (verif_phone) {
        this.setData({
          phone: phoneNum,
          btn_disabled: false
        });
      }
    },
    // 持卡人身份证事件
    userIdcard: function (e) {
      let useridcard = e.detail.value;
      reg.validChineseIdCard(useridcard);
      this.setData({
        Idcard: useridcard
      });
    },
    // 短信验证码事件
    codeInput: function (e) {
      let codenum = e.detail.value;
      this.setData({
        code: codenum
      });
    },
    clearInputEvent: function (e) {
      let type = e.currentTarget.dataset['type'];

      if (type == '') {
        uni.showToast({
          title: '信息类型错误，请重试！！',
          icon: 'none'
        });
      } else {
        switch (type) {
          case 'userName':
            this.setData({
              'user': ''
            });
            break;

          case 'idCard':
            this.setData({
              'Idcard': ''
            });
            break;

          case 'bankCard':
            this.setData({
              'userInputCardNum': ''
            });
            break;

          case 'phone':
            this.setData({
              'phone': '',
              btn_disabled: true
            });
            break;
        }
      }
    },

    // 提交表单中的信息
    formSubmit() {
      var that = this;
      var AccName = that.user;
      var MobileNo = that.phone;
      var CertNo = that.Idcard;
      var CardNo = that.userInputCardNum.replace(/\s|\xA0/g, "");
      var bank_type = that.bank_type;

      if (AccName == '') {
        uni.showToast({
          title: '请填写您的姓名',
          icon: 'none'
        });
      } else if (CertNo == '') {
        uni.showToast({
          title: '请填写您的身份证信息',
          icon: 'none'
        });
      } else if (bank_type == '') {
        uni.showToast({
          title: '请先选择银行名',
          icon: 'none'
        });
      } else if (CardNo == '') {
        uni.showToast({
          title: '请填写您的银行卡号码',
          icon: 'none'
        });
      } else {
        //  按钮节流
        that.reduceAsk(); // wx.showModal({
        var data = {};
        data["uid"] = that.uid;
        data["AccName"] = AccName;
        data["MobileNo"] = MobileNo;
        data["CertNo"] = CertNo;
        data["CardNo"] = CardNo;
        data["bank_type"] = bank_type;
        var arr = {
          data: data
        };
		console.log(arr,app.globalData.url)
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.url + 'union_pay/unionSendSms',
          method: 'POST',
          data: {
            data: aesData
          },
            
          success(res) {
            uni.showLoading({
              title: '正在提交中...',
              mask: true
            });
             console.log(res)
            if (res.data.code == 200) {
              that.setData({
                order_id: res.data.data
              });
              uni.hideLoading();
			  uni.showToast({
			  	title: res.data.msg,
				icon:'none'
			  })
			  that.showlogFun();
            } else {
              uni.hideLoading();
              uni.showToast({
                title: '请稍后重试',
                icon: 'none'
              });
            }
          },fail(err) {
          	console.log(err)
          }

        }); //     }
        //   }
        // })
      }
    },

    // 提示框事件
    toggleDialog() {
      this.setData({
        showDialog: !this.showDialog
      });
    },

    showlogFun() {
      this.setData({
        code: '',
        showlog: !this.showlog
      });
    },

    // 短信验证对话框
    getmessage() {
      var that = this;
      var code = that.code;

      if (code == '') {
        uni.showToast({
          title: '请输入验证码',
          icon: 'none'
        });
        return;
      }

      that.setData({
        btn_name: ' 等待中...',
        disabled: true
      });
      var data = {};
      data["uid"] = that.uid;
      data["code"] = that.code;
      data["order_id"] = that.order_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'union_pay/unionSign',
        method: 'POST',
        data: {
          data: aesData
        },
        success(res) {
          if (res.data.code == 200) {
            that.postaply(res.data.data);
          } else {
            that.setData({
              showlog: false,
              disabled: false,
              btn_name: '确定'
            });
            uni.showModal({
              title: '提示',
              content: res.data.msg,

              success(res) {
                if (res.confirm) {
                  that.setData({
                    phone: '' //userInputCardNum: ''

                  });
                }
              }

            });
          }
        }

      });
    },

    // 唤起支付事件
    postaply(order_id) {
      if (order_id == '') {
        uni.showToast({
          title: '订单创建失败，请重试！',
          icon: 'none'
        });
        return;
      }

      var that = this;
      var data = {};
      data["uid"] = that.uid;

      if (that.oid == 9) {
        data["type"] = 9;
        data['cord'] = that.getest; //家人数据
      } else if (that.oid == 3) {
        data["type"] = 1;
      }

      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'union_pay/unionPay',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {
            that.setData({
              showlog: false
            }); // 此处绑定银行已经成功，即将进行扣款

            var oid = that.oid;

            if (oid == 3) {
              var content = '您已成功绑定银行卡，并加入了医补计划';
            } else if (oid == 9) {
              var content = '您已成功绑定银行卡，并为您的家人加入了医补计划';
            } else {
              var content = '您已成功绑定银行卡';
            }

            uni.showModal({
              title: '提示',
              content: content,

              success(res) {
                if (res.confirm) {
                  // wx.switchTab({
                  //   url: '/pages/index/index',
                  // })
                  uni.navigateTo({
                    url: '/pages/mail/mail?uid=' + that.uid + that.rank
                  });
                }
              }

            });
          } else {
            uni.showToast({
              title: '加入失败'
            });
            that.setData({
              showlog: false,
              disabled: false,
              btn_name: '确定'
            });
          }
        }

      });
    },

    /*按钮节流*/
    reduceAsk() {
      var _this = this;

      if (!_this.lock) {
        _this.setData({
          lock: true
        });

        var num = 6; //6秒后可以再次点击

        var timer = setInterval(function () {
          num--;

          if (num <= 0) {
            clearInterval(timer);

            _this.setData({
              btn_next_name: '进行下一步',
              btn_disabled: false
            });
          } else {
            _this.setData({
              btn_next_name: num + "s" + ' 等待中...',
              btn_disabled: true
            });
          }
        }, 1000);
        setTimeout(function () {
          _this.lock = false;
        }, 5000);
      }
    },
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },
        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }
      });
    },
    // 银行选择器
    bindPickerChange: function (e) {
      var index = e.detail.value;
      var bankData = this.objectArray;
      this.setData({
        index: index,
        bank_type: bankData[index]['value']
      });
    },

  }
};
</script>
<style lang="scss" scoped>
/* pages/bind_bank/bind_bank.wxss */

.content{
	width:750rpx;
	height: 100vh;
	background-color: #F8F9FF;
	display: flex;
	justify-content: flex-start;
	align-items: center;
	flex-flow: column;
	.itemsBox {
		width: 100%;
		height: 120rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #FFFFFF;
		padding: 0 30rpx;
		box-sizing: border-box;
		border-bottom: 1rpx solid #F8F9FF;
	
		.itemsLeft {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;
	
			.icons {
				width: 52rpx;
				height: 52rpx;
				background-color: #f40;
			}
	
			text {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
				// margin-left: 20rpx;
			}
		}
	
		.itemsRight {
			flex: 3.7;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;
	
			.input {
				width: 100%;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 24rpx;
				color: #333333;
				opacity: 1;
				padding-left: 10rpx;
				box-sizing: border-box;
				// text-align: right;
			}
	
			.deful {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				color: #DBDBDB;
				opacity: 1;
			}
	         .yancode{
				 width: 176rpx;
				 height: 60rpx;
				 background: #4E73E8;
				 opacity: 1;
				 border-radius: 30rpx;
				 padding: 0 15rpx;
				 text-align: center;
				 display: flex;
				 justify-content: center;
				 align-items: center;
				 text{
					 font-size: 24rpx;
					 font-family: PingFang SC;
					 font-weight: 500;
					 line-height: 60rpx;
					 color: #FFFCFC;
					 opacity: 1;
				 }
			 }
			.avatar {
				width: 60rpx;
				height: 60rpx;
				background: #DBDBDB;
				border-radius: 50%;
				opacity: 1;
				margin-right: 10rpx;
			}
	
			.arrowRignth {
				width: 20rpx;
				height: 28rpx;
				background-color: #f40;
			}
		}
	}
	.items {
		width: 750rpx;
		min-height: 120rpx;
		border-radius: 8rpx;
		padding: 0 30rpx;
		box-sizing: border-box;
		background-color: #FFFFFF;
		display: flex;
		justify-content: flex-start;
		align-items: center;
		.itemText {
			width: 130rpx;
			height: 30rpx;
			font-size: 30rpx;
			font-family: SourceHanSansCN-Regular;
			line-height: 30rpx;
			color: #707070;
			opacity: 1;
		}
		.itemstext {
			width: 500rpx;
			height: 80rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			margin-left: 36rpx;
			input ,textarea{
				font-size: 30rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				color: #333;
				opacity: 1;
			}
	
			.defual {
				font-size: 30rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				line-height: 30rpx;
				color: #BBBBBB;
				opacity: 1;
			}
		}
	
	}
}






</style>