<template>
<!--pages/stotails/stotails.wxml-->
<view class="contaner">
	<image src="/static/images/moneny/huiyuan.png" class="image_bank"></image>
	<view class="btn_title" @click="moneys">立即领取</view>
  <!-- <view class="type">
	  <text>选择充值金额:</text> 
  </view>
  <radio-group name="money" @change="radioChange">
    <view class="label">
      <label v-for="(item, index) in items" :key="index" :class="'ui-radio ' + (item.checked==true?'active':'')">
        <radio :value="item.value" :checked="item.checked"></radio>
        <text class="text">{{item.name}}</text>
      </label>
    </view>
  </radio-group>

  <view class="label" v-if="oid == 4">
    <text class="text">共：{{friend_num}} 人</text>
  </view>

  <radio-group class="radig" @change="checkboxChange">
    <radio class="radios" value="3"></radio>
    我已阅读并同意<text class="text" style=" color: #0B3FFF; font-size: 24rpx;" @tap.stop="privacy">《会员公约》</text>
  </radio-group>
  <mybottom name="充值" @sublimt="moneys"></mybottom> -->
</view>
</template>

<script>
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      items: [{
        value: '10',
        name: '10元',
		checked:false
      }, {
        value: '30',
        name: '30元',
		checked:false
      }, {
        value: '50',
        name: '50元',
		checked:false
      }, {
        value: '100',
        name: '100元',
		checked:false
      }, {
        value: '200',
        name: '200元',
		checked:false
      }, {
        value: '500',
        name: '500元',
		checked:false
      }],
      stroge: '',
      getest: '',
      gettests: '',
      friendDataLength: '',
      friend_num: 0,
      friendData: '',
      amount: "",
      order_id: '',
      code: "",
      oid: '',
      //页面跳转参数
      frind: '',
      order_idd: '',
      flag: 1,
      ordie: '',
      pay_name: '确认支付',
      disabled: false,
      val: "",
      status: "",
      lock: false
    };
  },

  components: {},
  props: {},

  //生命周期
  onLoad(e) {
    if (e.oid != undefined) {
      this.setData({
        oid: e.oid
      });
    }

    if (e.oid == 4) {
      this.setData({
        friend_num: e.friend_num
      });
    } //本地数据uid


    this.getstroge();
    this.getstrogeFamilyData();
    this.getstrogeFirendData();
    this.getstrogefrinder();
    // this.reqstatu();
  },

  onShow() {
    // uni.login({
    //   success: res => {
    //     this.setData({
    //       code: res.code
    //     }); // 发送 res.code 到后台换取 openId, sessionKey, unionId
    //   }
    // });
  },

  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    getstrogeFirendData() {
      var that = this;
      const friendData = uni.getStorageSync('mystaff');
      that.setData({
        friendData: friendData
      });
    },

    getstrogeFamilyData() {
      var that = this;
      const getest = uni.getStorageSync('test');
      that.setData({
        getest: getest
      });
    },

    getstrogecode() {
      var that = this;
      const code = uni.getStorageSync('code');
      that.setData({
        code: code
      });
    },

    getstrogefrinder() {
      var that = this;
      const frind = uni.getStorageSync('mystaff');
      that.setData({
        frind: frind
      });
    },
	

    /*金额选择*/
    radioChange: function (e) {
      // uni.login({
      //   success: res => {
      //     this.setData({
      //       code: res.code
      //     }); // 发送 res.code 到后台换取 openId, sessionKey, unionId
      //   }
      // });
      var items = this.items;

      for (var i = 0; i < items.length; ++i) {
        items[i].checked = items[i].value == e.detail.value;
      }

      this.setData({
        items: items
      });
      this.setData({
        val: e.detail.value
      });

      if (this.oid == 4) {
        //朋友加入
		this.amount = e.detail.value * this.friend_num;
        // this.setData({
        //   amount: e.detail.value * this.friend_num
        // });
      } else {
		  this.amount = e.detail.value
      }
    },

    checkboxChange(e) {
      this.setData({
        ordie: e.detail.value
      });
    },

    /*---隐私条例---*/
    privacy() {
      uni.navigateTo({
        url: '/pages/privacy/privacy'
      });
    },

    //支付类型
    moneys() {
		this.val = 10;
      // if (this.val == undefined) {
      //   uni.showToast({
      //     title: '请选择充值类型'
      //   });
      //   return false;
      // }

      // if (this.ordie === '') {
      //   uni.showToast({
      //     title: '请勾选会员公约'
      //   });
      //   return false;
      // }

      this.reduceAsk();
      // this.onShow();
      if (this.oid == 1) {
        this.printe();
      } else if (this.oid == 3) {
        this.addmy();
      } else if (this.oid == 4) {
	
        this.addFirend();
      } else {
	
        this.filarmy();
      }
    },

    //员工充值
    addFirend() {
      if (this.val != undefined) {
        var that = this;
        var data = {};
        var price = that.val;
        var stroge = that.stroge;
        var friendDataLength = that.friendData.length;
        var amount = price * friendDataLength;
        that.setData({
          friendDataLength: friendDataLength
        });
        that.setData({
          amount: amount
        });
        data["uid"] = stroge.uid;
        data["type"] = 4;
        data['amount'] = amount;
        data['cord'] = that.friendData; //员工数据

        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.url + 'partner/ygpy_joining',
          method: "POST",
          data: {
            data: aesData
          },
          success: res => {
		
            if (res.data.code == 'ok') {
            let orderID = res.data.data.order_id;
            let amount = res.data.data.amount;
            that.order_idd=res.data.data.order_id;
            var data = {};
            data['order_id'] = orderID;
            data["total_fee"] = amount;
              var arr = {
                data: data
              };
              var jsonStr = JSON.stringify(arr);
              var aesData = sha_1.Encrypt(jsonStr);
              uni.request({
                url: app.globalData.url + 'join_project/wx_pay',
                //正式
                //url: app.url + 'notify/local_notify',
                method: "POST",
                data: {
                  data: aesData
                },
                success: res => {
                  // if (res.data.code == 'ok') {
                    const parameter = res.data;
					uni.requestPayment({
						provider: 'wxpay',
						orderInfo: parameter, //微信、支付宝订单数据
						success: function(res) {
							         //清除缓存
						    uni.removeStorageSync('mystaff');
							this.requid();
							uni.switchTab({
							    url: '/pages/index/index'
							});
				
						},
						fail: function(err) {
				
						}
					});
                  // }
                }
              });
            }
          }
        });
      } else {
        uni.showToast({
          title: '请选择充值类型'
        });
      }
    },

    //家人充值
    filarmy() {
      if (this.val != undefined) {
        var that = this;
        var data = {};
        var price = that.val;
        var stroge = that.stroge;
        var gettests = that.getest.length;
        var amount = 10;
		// that.gettests = gettests;
		that.amount = (amount * gettests)
        data["uid"] = stroge.uid;
        data['amount'] = that.amount;
        data['cord'] = that.getest; //家人数据
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.url + 'partner/family_order',
          method: "POST",
          data: {
            data: aesData
          },
          success: res => {
            if (res.data.code == 'ok') {
              let orderID = res.data.data.order_id;
              let amount = res.data.data.amount;
              that.order_idd=res.data.data.order_id;
              var data = {};
              data['order_id'] = orderID;
              data["total_fee"] = amount;
              var arr = {
                data: data
              };
              var jsonStr = JSON.stringify(arr);
              var aesData = sha_1.Encrypt(jsonStr);
              uni.request({
                url: app.globalData.url + 'join_project/wx_pay',
                //正式
                //url: app.url + 'notify/local_notify',
                method: "POST",
                data: {
                  data: aesData
                },
                success: res => {
                  // if (res.s == 'ok') {
                    const parameter = res.data;
					uni.requestPayment({
						provider: 'wxpay',
						orderInfo: parameter, //微信、支付宝订单数据
						success: function(res) {
							           //清除缓存
							           uni.removeStorageSync('test');
							           this.requid();
							           uni.switchTab({
							             url: '/pages/index/index'
							           });
				
						},
						fail: function(err) {
				
						}
					});
                  // }
                }
              });
            }
          },
		  fail(err) {
		
		  }
        });
      } else {
        uni.showToast({
          title: '请选择充值类型'
        });
      }
    },

    //我的充值
    printe() {
      if (this.val != undefined) {
        var that = this;
        var data = {};
        var price = that.val;
        var stroge = that.stroge;
        var amount = price;
        that.setData({
          amount: amount
        });
        data["uid"] = stroge.uid;
        data['amount'] = amount;
        data['cord'] = that.code;
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.url + 'join_project/recharge',
          method: "POST",
          data: {
            data: aesData
          },
          success: res => {


            if (res.data.code == 'ok') {
				let orderID = res.data.data.order_id;
			    let amount = res.data.data.amount;
				that.order_idd=res.data.data.order_id;
				var data = {};
				data['order_id'] = orderID;
				data["total_fee"] = amount;
              var arr = {
                data: data
              };
              var jsonStr = JSON.stringify(arr);
              var aesData = sha_1.Encrypt(jsonStr);
              uni.request({
                url: app.globalData.url + 'join_project/wx_pay',
                method: "POST",
                data: {
                  data: aesData
                },
                success: res => {
		
                  if (res.statusCode == '200') {
                    const parameter = res.data;
					uni.requestPayment({
						provider: 'wxpay',
						orderInfo: parameter, //微信、支付宝订单数据
						success: function(res) {
							 uni.navigateBack({
							    //返回
							     delta: 1
							 });
				
						},
						fail: function(err) {
				
						}
					});
                  }
                }
              });
            }
          }
        });
      } else {
        uni.showToast({
          title: '请选择充值类型'
        });
      }
    },

    /*---自己加入---*/
    addmy() {
      if (this.val != undefined) {
        var that = this;
        var data = {};
        var stroge = that.stroge;
        var amount = that.val;
        that.setData({
          amount: amount
        });
        data["uid"] = stroge.uid;
        data['amount'] = amount;
        data['cord'] = that.code;
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.url + 'partner/self_order',
          method: "POST",
          data: {
            data: aesData
          },
          success: res => {
			  let orderID = res.data.data.order_id;
			  let amount = res.data.data.amount;
              that.order_idd=res.data.data.order_id;
            if (res.data.code == 'ok') {
				let orderID = res.data.data.order_id;
				let amount = res.data.data.amount;
				that.order_idd=res.data.data.order_id;
              var data = {};
              data['order_id'] = orderID;
              data["total_fee"] = amount;
              var arr={
              	"data": data
              };
		
              var jsonStr = JSON.stringify(arr);
              var aesData = sha_1.Encrypt(jsonStr);
		
              uni.request({
                url: app.globalData.url + 'join_project/wx_pay',
                method: "POST",
                data: {
                  data: aesData
                },
                success: res => {
		
                  if (res.statusCode == '200') {
                    const parameter = res.data;
                 
					uni.requestPayment({
						provider: 'wxpay',
						orderInfo: parameter, //微信、支付宝订单数据
						success: function(res) {
							that.requid();
				
							    uni.switchTab({
							      url: '/pages/index/index'
							  });
						},
						fail: function(err) {
				
						}
					});
                  }
                }
              });
            }
          }
        });
      } else {
        uni.showToast({
          title: '请选择充值类型'
        });
      }
    },

    /*重新存储uid*/
    requid() {
      uni.request({
        url: app.globalData.url + 'users/userinfo',
        method: "POST",
        data: {
          uid: this.stroge.uid
        },

        success(res) {
          uni.setStorageSync('key', res.data.data);
        }

      });
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    },

    /*按钮节流*/
    reduceAsk() {
      var _this = this;

      if (!_this.lock) {
        _this.setData({
          lock: true
        });

        var num = 6;
        var timer = setInterval(function () {
          num--;

          if (num <= 0) {
            clearInterval(timer);

            _this.setData({
              pay_name: '确认支付',
              disabled: false
            });
          } else {
            _this.setData({
              pay_name: num + "s" + ' 等待中...',
              disabled: true
            });
          }
        }, 1000);
        setTimeout(function () {
          _this.lock = false;
        }, 5000);
      }
    }

  }
};
</script>
<style>
/* pages/stotails/stotails.wxss */
.contaner {
  padding: 0;
  width: 100%;
  height: 100vh;
  margin: 0 auto;
  0overflow: hidden;
  position: relative;
  box-sizing: border-box;
  background-color: #F8F9FF;
}
.image_bank {
	width: 100%;
	height: 100%;
	overflow: hidden;
}
.image_bank img {
	width: 100%;
	height: 100%;
}
.btn_title {
	width: 100%;
	bottom: 60rpx;
	color: #ffff0f;
	font-size: 50rpx;
	font-weight: 900;
	position: absolute;
	text-align: center;
}

/* .switch-type {
  width: 70%;
  text-align: center;
  line-height: 40px;
  border-radius: 10px;
  margin: 20px auto;
} */

.pay_btn {
  background: #007bff;
  color: #fff;
}


.ui-radio radio,
.ui-radio checkbox {
  display: none;
}

.label {
  padding: 16rpx 0;
  width: 686rpx;
  margin: 0 auto;
  height: auto;
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  box-sizing: border-box;
}

.ui-radio {
  border: 1rpx solid #D9D9D9;
  width: 26vw;
  border-radius: 5rpx;
  height: 70rpx;
  text-align: center;
  margin: 10rpx 10rpx;
  white-space: nowrap;
  font-size: 14rpx;
}

.ui-radio.active {
  background-color: #007bff;
  color: #fff;
  border-radius: 5rpx;
  border: 1rpx solid #007bff;
  height: 70rpx;
  text-align: center;
  margin: 10rpx 10rpx;
  white-space: nowrap;
}

.text {
 
 font-size: 44rpx;
 font-family: PingFang SC;
 font-weight: 500;
 line-height: 70rpx;
 color: #B4B4B4;
 opacity: 1;
  padding: 0 10rpx;
}

.ui-radio.active .text {
  color: #fff;
  line-height: 70rpx;
  font-size: 14px;
}

.type {
  /* padding: 10rpx 0; */
  font-size: 24rpx;
  height: 80rpx;
  padding: 0 30rpx;
  box-sizing: border-box;
  width: 100%;
  color: #444;
  display: flex;
  justify-content: flex-start;
  align-items: center;
}

.nub {
  margin: 30rpx 0 40rpx 10rpx;
  padding: 0 10rpx;
  font-size: 16rpx;
  line-height: 40rpx;
  color: #333;
  text-align: right;
  box-shadow: 0 0 4rpx #ccc;
}

.radig {
  padding: 0 30rpx;
  box-sizing: border-box;
  font-size: 12px;
  color: #333;
}


</style>