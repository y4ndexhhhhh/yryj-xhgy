<template>
<!--pages/exchan/exchan.wxml-->
<!--pages/exchang/exchang.wxml-->
<view class="conter">
  <view class="putop">
    <view>
      充值金额
      <view class="money">{{express_money}}</view>
    </view>
    <view class="title">纸质合约中内置了申请援助时需要提供的“个人密钥”，
      同时也作为保护您自身权益的法律文书</view>
  </view>
  <view class="aoder">
    <view class="wxaplay">付款方式</view>
    <view>
      <image src="/static/images/banner/wxaplay.png"></image>微信支付
    </view>
  </view>
  <radio-group class="radig" @change="checkboxChange">
    <radio class="radios" value="3"></radio>
    我已阅读并同意<text class="text" @tap.stop="privacy">《亿人一家服务平台隐私条例》</text>
  </radio-group>
  <button class="buttons" @click.stop="aplay" :disabled="disabled">{{pay_name}}</button>
</view>
</template>

<script>
// pages/postage/postage.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      ordie: '',
      code: '',
      uid: '',
      openid: '',
      order_id: '',
      express_money: 0,
      pay_name: '确认支付',
      disabled: false,
      lock: false
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getstroge();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      const order_id = uni.getStorageSync('order_id');
      const express_money = uni.getStorageSync('express_money');

      if (order_id == '') {
        uni.navigateBack({
          //返回
          delta: 1
        });
      } else {
        that.setData({
          order_id: order_id,
          express_money: express_money
        });
      }

      if (stroge == '') {
        uni.showModal({
          title: '启奏陛下',
          content: '请先进行登录',
          success: res => {
            uni.switchTab({
              url: '/pages/my/my'
            });
          }
        });
      } else {
        if (stroge.xcx_openid != undefined) {
          that.setData({
            uid: stroge.uid,
            openid: stroge.xcx_openid
          });
        } else {
          that.setData({
            uid: stroge.uid,
            openid: ''
          });
        }
      }
    },

    /*---亿人一家服务平台隐私条例---*/
    privacy() {
      uni.navigateTo({
        url: '/pages/privacy/privacy'
      });
    },

    // 隐私条例勾选
    checkboxChange(e) {
      this.setData({
        ordie: e.detail.value
      });
    },

    // 微信支付
    aplay() {
      var that = this;
      if (that.ordie == '') {
        uni.showToast({
          title: '请勾选隐私条例'
        });
        return false;
      }

      if (that.express_money == 0) {
        that.setData({
          express_money: 11
        });
      } //按钮节流
      that.reduceAsk();
      that.wxPay();
    },

    //获取微信code
    wxPay() {
      var that = this;
      if (that.openid == undefined || that.openid == '') {
        uni.login({
          success: res => {
            that.wakeWxPay(res.code, 1);
          }
        });
      } else {
        uni.login({
          success: res => {
            that.wakeWxPay(res.code, 1);
          }
        }); //that.wakeWxPay('', 2)
      }
    },

    //唤醒微信支付
    wakeWxPay(code, flag) {
      var data = {};
      var that = this;
      if (flag == 1) {
        if (code == '') {
          uni.showToast({
            title: '微信code获取失败'
          });
          return false;
        }

        data["code"] = code;
      } else {
        //data["code"] = '';
        data["code"] = code;
      }

      data["total_fee"] = that.express_money;
      data['order_id'] = that.order_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        // url: app.url + 'join_project/xcx_wx_pay',
        url: app.globalData.url + 'join_project/wx_pay',
        method: "POST",
        data: {
          data: aesData
        },
        success: res => {
          // if (res.data.code == 'ok') {
            const parameter = res.data;
            uni.requestPayment({
              provider: 'wxpay',
              orderInfo: parameter, //微信、支付宝订单数据
              success: res => {
                // uni.showModal({
                //   title: '支付',
                //   content: '支付成功',
                //   success: res => {
                //     this.requid();
                //     uni.navigateBack({
                //       //返回
                //       delta: 1
                //     });
                //   }
                // });
              }
            });
          // }
        }
      });
    },

    /*按钮节流*/
    reduceAsk() {
      var _this = this;

      if (!_this.lock) {
        _this.setData({
          lock: true
        });

        var num = 6; //6秒后可以再次点击

        var timer = setInterval(function () {
          num--;

          if (num <= 0) {
            clearInterval(timer);

            _this.setData({
              pay_name: '确认支付',
              disabled: false
            });
          } else {
            _this.setData({
              pay_name: num + "s" + ' 等待中...',
              disabled: true
            });
          }
        }, 1000);
        setTimeout(function () {
          _this.lock = false;
        }, 5000);
      }
    }

  }
};
</script>
<style>
page {
  background-color: #F4F4F4;
}

.putop {

  padding: 30px 10px;
  background-color: #fff;
}

.putop .money {
  padding: 6px 0;
  color: #FF9797;
  border-bottom: 1px solid #ccc;
}

.title {
  margin-top: 20px;
  font-size: 12px;
  color: #999;
  line-height: 20px;
}

.radig {
  margin: 30px;
  font-size: 12px;
  color: #333;
}

.text {
  color: #0B3FFF;
}

.aoder {
  padding: 8px 20px;
  background-color: #fff;
  margin-top: 20px;
  box-shadow: 0 0 5px #ccc;
}

.aoder image {
  width: 20px;
  height: 20px;
  vertical-align: middle;
}

.aoder view {
  /* border-bottom: 1px solid #ccc; */
  padding: 8px 0;
}

.wxaplay {
  padding: 8px 0;
  border-bottom: 1px solid #ccc;
}

.buttons {
  margin: 100px auto 20px;
  width: 60%;
  line-height: 40px;
  background: #007bff;
  text-align: center;
  color: #ffff;
  border-radius: 10px;

}
</style>