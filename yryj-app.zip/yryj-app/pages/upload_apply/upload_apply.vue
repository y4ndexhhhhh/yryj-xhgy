<template>
<!--pages/upload_apply/upload_apply.wxml--> 
<form @submit="formSubmit" v-if="status==1">
<view class="content">
  <view class="head_content">
    <view class="head_title">*请上传身份证正反面</view>
    <view class="head_content_block">
      <view class="Id_card" @tap="chooseimg1" data-id="id_card_img1">
        <image v-if="id_card_img1 == ''" src="/static/images/banner/zheng.png"></image>
        <image v-else :src="id_card_img1"></image>
        <view class="title">上传身份证人像面</view>
      </view>
      <view class="Id_card" @tap="chooseimg2" data-id="id_card_img2">
        <image v-if="id_card_img2 == ''" src="/static/images/banner/fan.png"></image>
        <image v-else :src="id_card_img2"></image>
        <view class="title">上传身份证国徽面</view>
      </view>
    </view>
  </view>
</view>
<view class="between_content">
  <view class="content_block">
    <view class="content_input">
      <view class="input_title">姓名</view>
      <input placeholder="请输入姓名" placeholder-class="input_text" @blur="username" :value="real_name" name="real_name"></input>
    </view>
  </view>
  <view class="content_block">
    <view class="content_input">
     <view class="input_title">身份证号</view> 
      <input placeholder="请输入身份证号码" placeholder-class="input_text" @blur="idcard" :value="id_card" name="id_card"></input>
    </view>
  </view>
</view>
  <view class="head_content">
    <view class="head_title">*请上传社保卡正反面</view>
    <view class="head_content_block">
      <view class="Id_card" @tap="chooseimg3" data-id="card_img1">
        <image v-if="card_img1 == ''" src="/static/images/banner/zheng.png"></image>
        <image v-else :src="card_img1"></image>
        <view class="title">上传社保卡人像面</view>
      </view>
      <view class="Id_card" @tap="chooseimg4" data-id="card_img2">
        <image v-if="card_img2 == ''" src="/static/images/banner/fan.png"></image>
        <image v-else :src="card_img2"></image>
        <view class="title">上传社保卡国徽面</view>
      </view>
    </view>
  </view>
  <button class="btn-area" form-type="submit">下一步</button>
  </form>
</template>

<script>
// pages/upload_apply/upload_apply.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js"),
    reg = require("../../utils/reg.js");

export default {
  data() {
    return {
      uid: 0,
      imgs: [],
      id_card_img1: '',
      id_card_img2: '',
      card_img1: '',
      card_img2: '',
      id_card_img3: '',
      id_card_img4: '',
      card_img5: '',
      card_img6: '',
      token: '',
      real_name: '',
      id_card: '',
      user_msg_img: '',
      uid: 0,
      case_id: 0,
      status: 1
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();

    if (e != undefined) {
      this.setData({
        uid: e.uid,
        case_id: e.case_id
      });
    }

    this.getstroge();
  },
  methods: {
    // 获取本地数据
    getstroge() {
      let that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        uid: stroge.uid
      });
    },

    chooseimg1(e) {
      const index = e.currentTarget.dataset.id;
      var that = this;
      uni.chooseImage({
        count: 1,
        success: res => {
          var tempFilePaths = res.tempFilePaths;

          if (tempFilePaths) {
            var that = this;
            uni.request({
              url: app.globalData.url + 'users/getqntoken',
              method: "POST",

              success(res) {
                that.setData({
                  token: res.data.data,
                  id_card_img1: tempFilePaths
                });
                that.uploadQiniu(index, tempFilePaths);
              }

            });
          }
        }
      });
    },

    chooseimg2(e) {
      const index = e.currentTarget.dataset.id;
      var that = this;
      uni.chooseImage({
        count: 1,
        success: res => {
          var tempFilePaths = res.tempFilePaths;

          if (tempFilePaths) {
            var that = this;
            uni.request({
              url: app.globalData.url + 'users/getqntoken',
              method: "POST",

              success(res) {
                that.setData({
                  token: res.data.data,
                  id_card_img2: tempFilePaths
                });
                that.uploadQiniu(index, tempFilePaths);
              }

            });
          }
        }
      });
    },

    chooseimg3(e) {
      const index = e.currentTarget.dataset.id;
      uni.chooseImage({
        count: 1,
        success: res => {
          var tempFilePaths = res.tempFilePaths;

          if (tempFilePaths) {
            var that = this;
            uni.request({
              url: app.globalData.url + 'users/getqntoken',
              method: "POST",

              success(res) {
                that.setData({
                  token: res.data.data,
                  card_img1: tempFilePaths
                });
                that.uploadQiniu(index, tempFilePaths);
              }

            });
          }
        }
      });
    },

    chooseimg4(e) {
      const index = e.currentTarget.dataset.id;
      uni.chooseImage({
        count: 1,
        success: res => {
          var tempFilePaths = res.tempFilePaths;

          if (tempFilePaths) {
            var that = this;
            uni.request({
              url: app.globalData.url + 'users/getqntoken',
              method: "POST",

              success(res) {
                that.setData({
                  token: res.data.data,
                  card_img2: tempFilePaths
                });
                that.uploadQiniu(index, tempFilePaths);
              }

            });
          }
        }
      });
    },

    //用户姓名
    username(e) {
      let real_name = e.detail.value;
      reg.validChinesName(real_name);
      var that = this;
      that.setData({
        real_name: real_name
      });
    },

    // 用户身份证
    idcard(e) {
      let id_card = e.detail.value;
      reg.validChineseIdCard(id_card);
      var that = this;
      that.setData({
        id_card: id_card
      });
    },

    /**
      * 图片上传七牛云
      */
    uploadQiniu(index, tempFilePaths) {
      var that = this;
      let token = that.token;

      if (token != '') {
        uni.uploadFile({
          url: 'https://upload-z2.qiniup.com',
          name: 'file',
          filePath: tempFilePaths[0],
          header: {
            "Content-Type": "multipart/form-data"
          },
          formData: {
            token: token
          },
          success: function (res) {
            if (res.statusCode == 200) {
              let respones_data = JSON.parse(res.data);
              var qiniu_key = respones_data.key;

              if (index == 'id_card_img1') {
                that.setData({
                  id_card_img3: qiniu_key
                });
              } else if (index == 'id_card_img2') {
                that.setData({
                  id_card_img4: qiniu_key
                });
              } else if (index == 'card_img1') {
                that.setData({
                  card_img5: qiniu_key
                });
              } else if (index == 'card_img2') {
                that.setData({
                  card_img6: qiniu_key
                });
              } else {
                uni.showToast({
                  title: '请重新上传'
                });
              }
            } else {
              uni.showToast({
                title: res.data.msg
              });
            }
          }
        });
      } else {
        uni.showToast({
          title: res.data.msg
        });
      }
    },

    // 提交表单数据
    formSubmit() {
      var that = this;

      if (that.real_name == '') {
        uni.showToast({
          title: '请填写您的真实姓名',
          icon: 'none'
        });
      } else if (that.id_card == '') {
        uni.showToast({
          title: '请填写您的身份证号',
          icon: 'none'
        });
      } else if (that.id_card_img3 == '' || that.id_card_img4 == '' || that.card_img5 == '' || that.card_img6 == '') {
        uni.showToast({
          title: '请上传您的身份证照片或医保卡照片',
          icon: 'none'
        });
      } else {
        var jichu_data = {};
        var extra_data = {};
        var data = {};
        jichu_data["uid"] = that.uid;
        jichu_data["case_id"] = that.case_id;
        jichu_data["real_name"] = that.real_name;
        jichu_data["id_card_num"] = that.id_card;
        extra_data["id_card1"] = that.id_card_img3;
        extra_data["id_card2"] = that.id_card_img4;
        extra_data["social1"] = that.card_img5;
        extra_data["social2"] = that.card_img6;
        data['jichu_data'] = jichu_data;
        data['extra_data'] = extra_data;
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.api_url + 'h5/proposers/saveUserInfo',
          method: 'POST',
          data: {
            data: aesData
          },

          success(res) {
            if (res.data.code == 200) {
              uni.navigateTo({
                url: '/pages/apply_bill/apply_bill?uid=' + that.uid + '&case_id=' + that.case_id
              });
            } else {
              uni.showToast({
                title: res.data.msg
              });
            }
          }

        });
      }
    },

    // 屏蔽
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/upload_apply/upload_apply.wxss */
.content{
 padding: 20rpx 0; 
}
.head_content{
  margin-top: 10rpx;
}
.head_title{
  font-size: 15px;
}
.head_content_block{
  display: flex;
  justify-content: space-between;
  margin-top: 30rpx;
  padding: 20rpx;
}
.Id_card{
   width: 47%;
   height: 100px;
 
}
.Id_card image{
  display: block;
  width: 100%;
  height: 100%;
}
.title{
  display: flex;
  margin-top: 10rpx;
  padding: 20rpx;
  border: 1rpx solid #eee;
  background: #eee;
  justify-content: center;
}
.between_content{
    padding: 40px 20rpx 20rpx 20rpx;
}
.content_block{
padding: 10rpx;
margin-top: 20rpx;
}
.content_input{
  display: flex;
  padding: 20rpx;
  border: 1rpx solid #eee;
  border-radius: 8px;
}
.input_title{
  width: 70px;
}
.input_text{
  font-size: 13px;
}
.btn-area {
  margin-top: 60px;
  width: 60%;
  background-color: #007bff;
  color: white;
}
</style>