<template>
<view>
<!--pages/treaty/treaty.wxml-->
<!-- <loading show="{{show}}"duration="{{duration}}">
  加载中...
 </loading> -->
<!-- <view class="img" wx:for='{{treaty_list}}' wx:key='index'>
<image src="{{item.fengmian}}"></image> -->
<view class="pageBox pageOne">
  <view class="list">
    <swiper indicator-dots="true" indicator-color="#000" indicator-active-color="#fff" autoplay="true" :current="current" @change="changeswiper">
      <block v-for="(item, index) in treaty_list" :key="index">
        <swiper-item @tap="swiperclick(item.url,index)">
          <image :src="item.fengmian"></image>
        </swiper-item>
      </block>
    </swiper>
  </view>
</view>
<!-- </view> -->
<view class="btns">
  <view class="btnBlue" @tap.stop="goEmall">
	邮寄
  </view>
  <view class="btnYellow" @tap.stop="btn">
	  查看公约
  </view>
</view>
</view>
</template>

<script>
// pages/treaty/treaty.js
var sha_1 = require("../../utils/sha_1.js");
const app = getApp();

export default {
  data() {
    return {
      stroge: true,
	  type:0,
      status: '',
      uid: '',
      src: '',
      treaty_list: [],
      id: 1,
      url: '',
      current: 0,
      rank: 1,
      sw_index: 0
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
	  console.log(options)
	this.type = options.type;
	this.sw_index = (options.type);
	if(options.type == 0){
		uni.setNavigationBarTitle({
		    title: '会员公约'
		});
	}else{
		uni.setNavigationBarTitle({
		    title: '合伙人协议'
		});
	}

	 const stroge = uni.getStorageSync('key');
	this.uid=stroge.uid,
	this.rank=stroge.rank


	// console.log(options)
     this.reqstatu(),
	 this.treaty();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {},

  methods: {
	  goEmall(){
		  uni.navigateTo({
		     url: '/pages/mail/mail?uid=' + this.uid + '&rank='+this.rank
		  });
	  },
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');

      if (stroge == '') {
        that.setData({
          stroge: false
        });
      } else {
          that.uid=stroge.uid,
          that.rank=stroge.rank
      }
    },

    // 数据请求
    treaty() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'express/user_xieyi',
        method: "POSt",
        data: {
          data: aesData
        },

        success(res) {
			console.log(res)
          uni.showLoading({
            title: '加载中',
            icon: 'loading',
            duration: 500
          });

          if (res.data.code == 'ok') {
			  console.log(res)
            that.setData({
              treaty_list: res.data.data
            });
          } else {
            return false;
          }
        }

      });
    },

    // 数据请求
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    },

    btn() {
      var that = this;
	  console.log(that.sw_index)
      // if (that.rank == 1 || that.rank == 0) {
      //   if (that.sw_index == 0) {
      //     var url = 'https://app01.wysyt.com/xcxapi/open_banner/open_154';
      //     wx.navigateTo({
      //       url: '/pages/viptreaty/viptreaty?uid=' + that.uid + '&url=' + url
      //     })
      //   }
      // } else {
        // if (that.sw_index == 0) {
          var url = 'https://app01.wysyt.com/xcxapi/open_banner/open_154';
          uni.navigateTo({
            url: '/pages/viptreaty/viptreaty?type=' + `${that.sw_index}`
          })
        // }
      // }
    },

    // 轮播图事件
    swiperclick(url,index) {
      var that = this;
      uni.navigateTo({
        url: '/pages/viptreaty/viptreaty?type=' + `${that.sw_index}`
      })
    },

    changeswiper(e) {
      this.setData({
        sw_index: e.detail.current
      });
    }

  }
};
</script>
<style>
/* pages/treaty/treaty.wxss */
.btns {
  width: 100%;
  margin: 10vh auto 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30rpx;
  box-sizing: border-box;
}
.btnBlue{
	width: 330rpx;
	height: 120rpx;
	background: #6178F3;
	border-radius: 60rpx;
		font-size: 44rpx;
		font-family: PingFang SC;
		font-weight: 500;
		line-height:120rpx;
		color: #FFFFFF;
		opacity: 1;
		text-align: center;
}
.btnYellow{
	width: 330rpx;
	height: 120rpx;
	background: #FFAC38;
	opacity: 1;
	border-radius: 60rpx;
	text-align: center;
	font-size: 44rpx;
	font-family: PingFang SC;
	font-weight: 500;
	line-height: 120rpx;
	color: #FFFFFF;
	opacity: 1;
}

.pageOne swiper {
  width: 750rpx;
  height: 1000rpx;
}

.pageOne swiper-item {
  padding-top: 100rpx;
}

.pageOne image {
  width: 80%;
  height: 90%;

  /* left: 50%;  */
  display: flex;
  justify-content: space-around;
  margin-left: 40px;
  /* margin-left: -188rpx; */
}

.pageOne image.active {
  transform: scale(1.14);
  transition: all 1s ease-in 0s;
}
</style>