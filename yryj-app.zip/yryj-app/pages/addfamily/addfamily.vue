<template>
<!--pages/addfamily/addfamily.wxml-->
<!--pages/family/family.wxml-->
<!--pages/myadd/myadd.wxml-->
<view class="conter">
  <view class="formtable">
    <form @submit="formSubmit">
      <view class="conters">
        <text>真实姓名：{{relev_name}}</text>
      </view>
      <view class="section">
        <picker @change="bindPickerChange2" :value="index" range-key="name" :range="objectArray">
          <view class="picker">
            与我关系: <input type="text" :value="' ' + objectArray[index].name"></input>
          </view>
        </picker>
      </view>
      <view class="conters">
        <text>身份证号：</text>
        <input type="text" name="id_card" @blur="oncode" :value="id_card" placeholder="请输入家人身份证（必填）"></input>
      </view>
      <view class="conters">
        <text>手机号码：</text>
        <input type="text" name="phone" @input="onphone" :value="phone" placeholder="请输入家人手机号（选填）"></input>
      </view>
      <view class="family">
        <h2 class="title">温馨提示</h2>
        <view class="mosice">
          帮家人加入，可以不填手机号。
        </view>
      </view>
      <button form-type="submit" class="btn" :disabled="disabled">确认</button>
    </form>

  </view>

</view>
</template>

<script>
// pages/addfamily/addfamily.js
const app = getApp();

export default {
  data() {
    return {
      stroge: {},
      relev_name: '',
      phone: '',
      id_card: '',
      title: '',
      objectArray: [{
        name: '请选择关系',
        value: 0
      }, {
        name: '父母',
        value: 3
      }, {
        name: '子女',
        value: 4
      }, {
        name: '爷爷奶奶',
        value: 5
      }, {
        name: '外公外婆',
        value: 6
      }, {
        name: '配偶',
        value: 7
      }, {
        name: '兄弟姐妹',
        value: 8
      }],
      index: 0,
      relevance_id: 0,
      uid: 0,
      id: 0,
      checkpass: false,
      disabled: true
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var relev_name = e.name;
    var id = e.id; // 获取uid

    this.getstroge();
    this.setData({
      relev_name: relev_name,
      id: id
    });
  },
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge,
        uid: stroge.uid
      });
    },

    /* 关系事件*/
    bindPickerChange2: function (e) {
      var index = e.detail.value;
      var relevance_Data = this.objectArray;
      this.setData({
        index: index,
        relevance_id: relevance_Data[index]['value']
      });
    },

    onphone(e) {
      this.setData({
        phone: e.detail.value
      });
    },

    oncode(e) {
      var id_card = e.detail.value;
      var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;

      if (!reg.test(id_card)) {
        this.setData({
          disabled: true
        });
        uni.showToast({
          title: '请输入正确的身份证号',
          icon: 'none'
        });
        return;
      }

      this.setData({
        id_card: id_card,
        disabled: false
      });
    },

    formSubmit(e) {
      var that = this;
      const phone = that.phone;
      const id_card = that.id_card;
      const relevance_id = that.relevance_id;

      if (relevance_id == 0) {
        uni.showToast({
          title: '关系不能为空!',
          icon: 'none'
        });
        return false;
      }

      if (phone) {
        uni.request({
          url: app.globalData.url + 'partner/ver_phone',
          method: "POST",
          data: {
            phone: that.phone
          },

          success(res) {
            if (res.data.code == 'ok') {
              uni.showToast({
                title: '手机号验证通过!',
                icon: 'none'
              });
            } else {
              uni.showToast({
                title: `${res.data.msg}`
              });
            }
          }

        });
      }

      if (id_card == '') {
        uni.showToast({
          title: '请输入身份证号!',
          icon: 'none'
        });
        return false;
      } else {
        uni.request({
          url: app.globalData.url + 'partner/id_cord',
          method: "POST",
          data: {
            uid: that.stroge.uid,
            id_card: that.id_card
          },

          success(res) {
            if (res.data.code != 'ok') {
              uni.showToast({
                title: `${res.data.msg}`,
                icon: 'none'
              });
              that.setData({
                checkpass: false,
                disabled: true
              });
            } else {
              that.setData({
                checkpass: true
              });
            }
          }

        });
      }

      if (that.checkpass) {
        // 提交表单信息
        uni.request({
          url: app.globalData.url + 'partner/updateFamilyData',
          method: "POST",
          data: {
            uid: that.uid,
            id: that.id,
            phone: phone,
            relevance_id: relevance_id,
            id_card: id_card
          },

          success(res) {
            if (res.data.code != 'ok') {
              uni.showToast({
                title: `${res.data.msg}`,
                icon: 'none'
              });
              return;
            } else {
              uni.showToast({
                title: res.data.msg,
                icon: 'none',
                duration: 1500,
                mask: true,

                success(data) {
                  setTimeout(function () {
                    //要延时执行的代码
                    uni.redirectTo({
                      url: '/pages/familylist/familylist'
                    });
                  }, 1500); //延迟时间
                }

              });
            }
          }

        });
      }
    }

  }
};
</script>
<style>
/* pages/addfamily/addfamily.wxss */
/* pages/family/family.wxss */
/* pages/myadd/myadd.wxss */
.formtable {
  margin: auto;
  width: 80%;
  padding: 20px 10px 0 10px;
}

form .conters {
  padding: 12px 0;
  display: flex;
}

form input {
  width: 70%;
  border-bottom: 1px solid #eee;
}

.family {
  margin-top: 30px
}

.title {
  font-weight: bolder;
}

.mosice {
  color: #7E8A9D;
  text-indent: 30px;
  font-size: 15px;
  margin-top: 20px;
}

.btn {
  width: 100%;
  margin-top: 60px;
  background-color: #107BFD;
  line-height: 35px;
  border-radius: 35px;
  color: #fff;
}

.picker {
  display: flex;
}

.picker input {
  margin-left: 10px;
}

.conte {
  display: none;
}
</style>