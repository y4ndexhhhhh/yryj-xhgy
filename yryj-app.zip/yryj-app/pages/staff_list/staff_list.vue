<template>
<view>
<!--pages/familylist/familylist.wxml-->
<view class="conter">
  <view v-if="!new_list.length==0">
    <view v-for="(item, index) in new_list" :key="index" class="list">
      <view class="listtop">
        <view class="left">
          <view>已加入天数</view>
          <view>{{item.join_time}}</view>
        </view>
        <view class="right">
          <view>账户余额</view>
          <view>{{item.amount}}</view>
        </view>
      </view>
      <view class="listtop">
        <view>姓名：{{item.real_name}}</view>
      </view>
      <view class="listtop">
        <view>身份证号：{{item.id_card}}</view>
        <view class="btn" @tap.stop="deleta" :data-id="item.id">解绑</view>
      </view>
    </view>
  </view>
</view>
<form>
  <view class="modalDlg" v-if="showModal">
    <view class="close_mask" @tap="close_mask">x</view>
    <view class="title">确定解绑</view>
    <input name="phones" @input="onphones" :value="phones" maxlength="11" placeholder="请输入员工的手机号"></input>
    <view class="showmode">
      <view class="showv" @tap.stop="close">取消</view>
      <view class="showv1" @tap.stop="formSubmit">提交</view>
    </view>
  </view>
  <view class="mask" catchtouchmove="preventTouchMove" v-if="showModal"></view>
</form>
</view>
</template>

<script>
// pages/staff_list/staff_list.js
const app = getApp();

export default {
  data() {
    return {
      stroge: "",
      list: "",
      new_list: [],
      hidde: true,
      id: '',
      phones: '',
      showModal: false,
      page: 0
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    /**---获取uid---*/
    this.getstroge();
    /*---获取数据列表---*/

    this.staff_list();
  },

  // 监听用户上拉触底事件。
  onReachBottom() {
    var page = this.page + 1; //获取当前页数并+1

    this.setData({
      page: page //更新当前页数

    });
    this.staff_list();
  },

  // 监听用户下拉刷新时间
  onPullDownRefresh() {
    // 重置数组
    this.setData({
      new_list: []
    }); // 重置页码

    this.setData({
      page: 0 //更新当前页数

    }); // 重新发送请求

    this.staff_list();
  },

  methods: {
    /**---获取uid---*/
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    /*---获取员工数据列表---*/
    staff_list() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'users/getStaffList',
        method: "POST",
        data: {
          uid: that.stroge.uid,
          page: that.page
        },

        success(res) {
          let arr = res.data.data;

          if (res.data.code == 200) {
            that.setData({
              new_list: arr
            });

            if (that.page == 0) {
              let list = arr;
              that.setData({
                list: list
              });
            } else {
              //获取下拉刷新之前的list数据
              let old_data = that.list; //arr  代表page+1  新数据

              that.setData({
                new_list: old_data.concat(arr)
              });
            }
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none'
            });
          }

          uni.stopPullDownRefresh();
        }

      });
    },

    /*---解除---*/
    deleta(e) {
      const id = e.currentTarget.dataset.id;
      this.setData({
        hidde: false,
        id: id,
        showModal: true
      });
    },

    /*弹窗input值*/
    onphones(e) {
      this.setData({
        phones: e.detail.value
      });
    },

    /*---取消---*/
    close() {
      this.setData({
        showModal: false
      });
    },

    /*确定*/
    formSubmit(e) {
      var that = this;
      uni.request({
        url: app.globalData.url + 'users/doUnbindStaff',
        method: 'POST',
        data: {
          uid: that.stroge.uid,
          id: that.id,
          phone: that.phones
        },

        success(res) {
          if (res.data.code == 'ok') {
            const ph = res.data.data.phone;
            const paw = res.data.data.paw;
            const msg = res.data.data.msg;
            uni.showModal({
              title: '解除成功！',
              content: `手机号：${ph} 初始密码：${paw}`,

              success(res) {
                if (res.confirm) {
                  that.setData({
                    showModal: false,
                    page: 0,
                    phones: ''
                  });
                  that.staff_list();
                }
              }

            });
          } else {
            const msg = res.data.msg;
            uni.showModal({
              title: '解除失败',
              content: `${msg}`
            });
          }
        }

      });
    },

    close_mask: function () {
      this.setData({
        showModal: false
      });
    },
    hideMask: function () {
      this.setData({
        showModal: false
      });
    },
    preventTouchMove: function () {}
  }
};
</script>
<style>
/* pages/staff_list/staff_list.wxss */
/* pages/familylist/familylist.wxss */
.conter {
  position: relative;
}

.list {
  margin: 30px auto;
  width: 80%;
  padding: 15px;
  background-color: #eff;
  box-shadow: 0 0 8px #eff;
  border-radius: 10px;
  color: #333;
  font-size: 14px;
}

.listtop {
  display: flex;
  justify-content: space-between;
  text-align: center;
}

.listtop+.listtop {
  margin-top: 20px;
}

.left,
.right {
  width: 48%;
}



.btn {
  padding: 3px 5px;
  color: #fff;
  border-radius: 4px;
  background-color: #107BFD;
}


.heider {
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -65px;
  margin-left: -35%;
  padding-top: 15px;
  width: 70%;
  height: 130px;
  text-align: center;
  background: #fff;
  border: 1px solid #333;
  box-shadow: 0 0 6px #ccc;
}

.heider view {
  display: flex;
  margin-top: 20px;
}

.heider view {
  text-align: left;
}

.heider view input {
  line-height: 35px;
  border-bottom: 1px solid #ccc;
}

.buttons {
  justify-content: space-around;
}

.btne {
  outline: none;
  border: none;
  background: none;
  font-size: 14px;
}

.modalDlg {
  width: 580rpx;
  height: 450rpx;
  position: fixed;
  top: 50%;
  left: 0;
  z-index: 9999;
  margin: -370rpx 85rpx;
  background-color: #fff;
  border-radius: 36rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.mask {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background: #000;
  z-index: 9000;
  opacity: 0.7;
}

.close_mask {
  color: #000;
  position: relative;
  left: 42%;
  /* top: -82%; */
  font-size: 32rpx;
  padding: 8px 10px;

}

.title {
  font-size: 22px;

}

.showv {

  width: 18vw;
  padding: 6px 10px;
  border-radius: 6px;
  border: 1px solid #eee;
  text-align: center;
  background-color: blue;
  color: #eee;
  display: inline-block;
  margin-right: 6vw;

}

.showv1 {
  margin: 10px auto 0;
  width: 18vw;
  padding: 6px 10px;
  border-radius: 6px;
  border: 1px solid #eee;
  text-align: center;
  background-color: blue;
  color: #eee;
  display: inline-block;
}

.showmode {
  color: #eee;
  margin-top: 6vh;


}

input {
  border: 1px solid #eee;
  padding: 8px 0 10px;
  margin-top: 2vh;
  background-color: #FFFAFA;
  border-radius: 8px;
  text-align: center;

}
</style>