<template>
<!--pages/new_html/new_html.wxml-->
<web-view :src="request_url" v-if="status==1"></web-view>
</template>

<script>

export default {
  data() {
    return {
      request_url: '',
      status: 1
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.setData({
      request_url: e.request_url + '?code=' + e.code
    });
  },
  methods: {
    // 屏蔽
    reqstatu() {
      var that = this;
      uni.request({
        url: app.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/new_html/new_html.wxss */
</style>