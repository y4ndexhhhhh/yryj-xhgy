<template>
<!-- 监听自定义事件 -->

<Tabs :tabs="tabs" @tabschenge="handletabschenge">

  <block v-if="tabs[0].isActive">

    <!-- <view class="num">({{zt_user_count}})人</view> -->
    <view>
      <view class="conter" v-if="status==1">
        <view class="head">
          <view class="headname">姓名</view>
          <view class="headphone">手机号</view>
          <view class="headstatus">是否加入</view>
          <view class="headtime">加入时间</view>
        </view>
        <view v-for="(item, index) in list" :key="index" class="head">
          <view class="headname">
            <text v-if="item.real_name==null ||item.real_name==''">未实名</text>
            <text v-else>{{item.real_name}}</text>
          </view>
          <view class="headphone">{{item.phone}}</view>
          <view class="headstatus">
            <text v-if="item.join_status==1">已加入</text>
            <text v-else>未加入</text>
          </view>
          <view class="headtime">
            <text v-if="item.join_time==null ||item.join_time==''"></text>
            <text v-else>{{item.join_time}}</text>
          </view>
        </view>
      </view>
    </view>
  </block>
  <block v-else-if="tabs[1].isActive">
    <!-- <Tabbs :tabbs="tabbs" @tabbschenge="handletabbschenge2"> -->
      <!-- <block v-if="tabbs[0].isActive"> -->

        <view class="conter" v-if="status==1">
          <!-- <view class="num2">({{jt_one_user_count}})人</view>
      <view class="num2">({{jt_two_user_count}})人</view> -->
          <view class="head">

            <view class="headname">姓名</view>
            <view class="headphone">手机号</view>
            <view class="headstatus">是否加入</view>
            <view class="headtime">加入时间</view>
          </view>
          <view v-for="(item, index) in list_jt_01" :key="index" class="head">
            <view class="headname">
              <text v-if="item.real_name==null ||item.real_name==''">未实名</text>
              <text v-else>{{item.real_name}}</text>
            </view>
            <view class="headphone">{{item.phone}}</view>
            <view class="headstatus">
              <text v-if="item.join_status==1">已加入</text>
              <text v-else>未加入</text>
            </view>
            <view class="headtime">
              <text v-if="item.join_time==null ||item.join_time==''"></text>
              <text v-else>{{item.join_time}}</text>
            </view>
          </view>
        </view>
      <!-- </block> -->
      <!-- <block v-else-if="tabbs[1].isActive"> -->
        <!-- <view class="conter">
          <view class="head">
            <view class="headname">姓名</view>
            <view class="headphone">手机号</view>
            <view class="headstatus">是否加入</view>
            <view class="headtime">加入时间</view>
          </view>
          <view v-for="(item, index) in list_jt_02" :key="index" class="head">
            <view class="headname">
              <text v-if="item.real_name==null ||item.real_name==''">未实名</text>
              <text v-else>{{item.real_name}}</text>
            </view>
            <view class="headphone">{{item.phone}}</view>
            <view class="headstatus">
              <text v-if="item.join_status==1">已加入</text>
              <text v-else>未加入</text>
            </view>
            <view class="headtime">
              <text v-if="item.join_time==null ||item.join_time==''"></text>
              <text v-else>{{item.join_time}}</text>
            </view>
          </view>
		  view>
        </ -->
      <!-- </block> -->
    <!-- </Tabbs> -->
  </block>
    <doudi v-if="list_jt_02.length == 0 || list.length == 0 || list_jt_01.length == 0"></doudi>
</Tabs>
</template>

<script>
// // pages/ordie/ordie.js
var utils = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");
const app = getApp();
import Tabs from "../conponent/Tabs/Tabs";
import Tabbs from "../conponent/Tabbs/Tabbs";

export default {
  data() {
    return {
      tabs: [{
        id: 1,
        value: "直推列表",
        isActive: true,
        countnum: 0
      }, {
        id: 2,
        value: "间推列表",
        isActive: false
      }],
      tabbs: [{
        id: 1,
        value: "间一",
        isActive: true,
        countnum: 0
      }, {
        id: 2,
        value: "间二",
        isActive: false,
        countnum: 0
      }],
      stroge: "",
      list: '',
      page: 0,
      limit: 10,
      status: "",
      type: 1,
      child_type: 1,
      list_jt_01: '',
      list_jt_02: '',
      zt_user_count: '',
      jt_one_user_count: '',
      jt_two_user_count: '',
      one_flag: 1,
      two_flag: 1
    };
  },

  components: {
    Tabs,
    Tabbs
  },
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getstroge();
    this.reqocse();
    this.reqstatu();
  },

  // 监听用户上拉触底事件。
  onReachBottom() {
    var page = this.page + 1; //获取当前页数并+1

    this.setData({
      page: page //更新当前页数

    });
    this.reqocse();
  },

  // 监听用户下拉刷新时间
  onPullDownRefresh() {
    // 重置数组
    this.setData({
      list: [],
      list_jt_01: [],
      list_jt_02: []
    }); // 重置页码

    var page = 0;
    this.setData({
      page: page //更新当前页数

    }); // 重新发送请求

    this.reqocse();
  },

  methods: {
    // 一级大类 --- 标题得点击事件，从子组件传
    handletabschenge(e) {
      // 获取被点击标题的索引
      const {
        index
      } = e.detail; // 修改原数组

      let {
        tabs
      } = this; // tabs.forEach((v, i) => i == index ? v.isActive = true : v.isActive = false)

      for (var k = 0, length = tabs.length; k < length; k++) {
        if (index == k) {
          tabs[k]['isActive'] = true;
          this.setData({
            one_flag: tabs[k]['id'],
            type: tabs[k]['id']
          });
        } else {
          tabs[k]['isActive'] = false;
        }
      } // 赋值到data中


      this.setData({
        tabs
      });
      const that = this; // 重新赋值

      this.setData({
        page: 0
      }); //加载数据

      that.reqocse();
    },

    // 二级大类 ---  标题得点击事件，从子组件传
    handletabbschenge2(e) {
      // 获取被点击标题的索引
      const {
        index
      } = e.detail; // 修改原数组

      let {
        tabbs
      } = this; //tabbs.forEach((v, i) => i == index ? v.isActive = true : v.isActive = false)

      for (var k = 0, length = tabbs.length; k < length; k++) {
        if (index == k) {
          tabbs[k]['isActive'] = true;
          this.setData({
            two_flag: tabbs[k]['id'],
            child_type: tabbs[k]['id']
          });
        } else {
          tabbs[k]['isActive'] = false;
        }
      } // 赋值到data中


      this.setData({
        tabbs,
        page: 0
      });
      const that = this; //加载数据

      that.reqocse();
    },

    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    // 获取数据
    reqocse() {
      var that = this;
      var data = {};
      data["uid"] = that.stroge.uid;
      data['page'] = that.page;
      data['type'] = that.type;
      data['child_type'] = that.child_type;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: 'https://app01.wysyt.com/index/recommend/tuiJianList',
        method: "POST",
        data: {
          data: aesData
        },
        success: res => {
          if (res.data.code == 200) {
            let arr = res.data.data;
            that.setData({
              zt_user_count: res.data.total_num.zt_user_count,
              jt_one_user_count: res.data.total_num.jt_one_user_count,
              jt_two_user_count: res.data.total_num.jt_two_user_count
            });
            this.tabs[0].countnum = '(' + this.zt_user_count + ')' + '人';
            this.setData({
              tabs: this.tabs
            });
            this.tabbs[0].countnum = this.jt_one_user_count;
            this.setData({
              tabbs: this.tabbs
            });
            this.tabbs[1].countnum = this.jt_two_user_count;
            this.setData({
              tabbs: this.tabbs
            });

            if (that.page == 0) {
              let list = arr;

              if (that.type == 1) {
                that.setData({
                  list: list
                });
              } else {
                if (that.child_type == 1) {
                  that.setData({
                    list_jt_01: list
                  });
                } else {
                  that.setData({
                    list_jt_02: list
                  });
                }
              }
            } else {
              //获取下拉刷新之前的list数据
              let old_data = that.list; //arr  代表page+1  新数据

              if (that.type == 1) {
                that.setData({
                  list: old_data.concat(arr)
                }); //console.log(that.data.list)
              } else {
                if (that.child_type == 1) {
                  that.setData({
                    list_jt_01: old_data.concat(arr)
                  });
                } else {
                  that.setData({
                    list_jt_02: old_data.concat(arr)
                  });
                }
              }
            }
          } else {
            uni.showToast({
              title: res.data.msg,
			  icon:'none'
            });
          }

          uni.stopPullDownRefresh();
        }
      });
    },

    // 屏蔽开关接口
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        success(res) {
		 // console.log(status)
          that.setData({
            status: res.data.data.status
          });
        }
      });
    }

  }
};
</script>
<style>
.conter {
  width: 100%;
  margin: 0 auto;
  color: #333;
}

.head {
  display: flex;
  width: 90%;
  margin-left: 10px;
  text-align: center;
  padding: 5px 5px 10px 10px;
  border-bottom: 1px solid #ccc;
}

.headname {
  line-height: 25px;
  width: 16%;
  text-align: center;
  padding: 2px 2px;
}

.headphone {
  line-height: 25px;
  width: 25%;
  text-align: center;
  padding: 2px 2px;
}

.headstatus {
  line-height: 25px;
  width: 27%;
  text-align: center;
  padding: 2px 2px;
}

.headtime {
  line-height: 25px;
  width: 30%;
  text-align: center;
  padding: 2px 2px;
}

.num {
  color: black;
  padding: 1px 75px;
}

.num2 {
  float: right;
  text-align: center;
  padding: 50px 2px 10px 10px;
  height: 0;
}
</style>