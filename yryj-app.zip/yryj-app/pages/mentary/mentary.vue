<template>
<!--pages/mentary/mentary.wxml-->
<view class="conter" v-if="status==1">
  <view class="header">
    <image src="/static/images/banner/bg.png" mode="widthFix"></image>
  </view>
  <view class="head-body">
    <view class="heade-type">
      <image src="/static/images/banner/ziji.png"></image>
      <view>
        <view class="head-title">自己加入</view>
        <view class="head-titles">爱护自己，夯实健康保障</view>
      </view>
      <view class="btn" @tap.stop="myadd">加入计划</view>
    </view>
    <view class="heade-type">
      <image src="/static/images/banner/jiaren.png"></image>
      <view>
        <view class="head-title">家人加入</view>
        <view class="head-titles">为家人的健康保驾护航</view>
      </view>
      <view class="btn" @tap.stop="fiamladd">加入计划</view>
    </view>
    <view class="heade-type">
      <image src="/static/images/banner/pey.png"></image>
      <view>
        <view class="head-title">他人加入</view>
        <view class="head-titles">关爱他人，注重健康保障</view>
      </view>
      <view class="btn" @tap.stop="frindeadd">加入计划</view>
    </view>
  </view>
  <!-- 什么是互助 -->
  <view class="mentary">
    <text class="title">什么是医补计划?</text>
    <view>
      医补计划是亿人一家基于解决因病致贫、因病返 贫的社会痛点问题，专为中国老百姓量身定做的一款 普惠大众的健康服务产品。
    </view>
    <view>
      没有行业限制、没有健康限制、没有年龄限制、 没有援助次数限制、没有援助金额限制。
    </view>
  </view>
  <!-- 援助机制 -->
  <view class="mentary">
    <text class="title">援助机制</text>
    <view>
      1、会员累计签到90次，援助医保自付部分。
    </view>
    <view>
      2、会员累计签到180次，援助医疗自费部分。
    </view>
  </view>
</view>
</template>

<script>
// pages/mentary/mentary.js
const app = getApp();

export default {
  data() {
    return {
      oid: 0,
      stroge: {},
      status: 1
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.reqstatu();
    that.getstroge();
  },
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    /*---自己加入---*/
    myadd() {
      var that = this;
      const stroge = this.stroge;

      if (stroge.real_status == 1) {
        if (stroge.join_status == 2) {
          uni.navigateTo({
            url: '/pages/aplay/aplay?uid=' + that.stroge.uid + '&oid=3'
          });
        } else {
          uni.navigateTo({
            url: '/pages/mdsucerr/mdsucerr'
          });
        }
      } else {
        uni.navigateTo({
          url: '/pages/myadd/myadd'
        });
      }
    },

    /*---家人加入---*/
    fiamladd() {
      var that = this;
      const stroge = that.stroge;

      if (stroge.real_status === 2) {
        uni.showToast({
          title: '请先自己加入'
        });
        return false;
      } else {
        uni.navigateTo({
          url: '/pages/ontinue/ontinue'
        });
      }
    },

    /*---朋友加入---*/
    frindeadd() {
      var that = this;
      const stroge = that.stroge;

      if (stroge.real_status === 2) {
        uni.showToast({
          title: '请先自己加入'
        });
        return false;
      } else {
        uni.navigateTo({
          url: '/pages/frinde/frinde'
        });
      }
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/mentary/mentary.wxss */
pages {
  background-color: #F4F4F4;
}

.header image {
  width: 100%;
}

.head-body {
  margin: auto;
  width: 90%;
}

.heade-type {
  padding: 14px 6px;
  display: flex;
  justify-content: space-around;
  box-shadow: 0px 0px 12px 0px rgba(0, 0, 0, 0.2);
  border-radius: 15px;
}

.heade-type+.heade-type {
  margin-top: 10px;
}

.heade-type image {
  width: 32px;
  height: 32px;
}

.head-title {
  font-size: 16px;
  font-weight: bolder;
}

.head-titles {
  color: #666;
  font-size: 14px;
}

.btn {
  width: 80px;
  height: 30px;
  line-height: 30px;
  border-radius: 30px;
  font-size: 14px;
  color: #fff;
  text-align: center;
  background: linear-gradient(270deg, rgba(255, 205, 104, 1) 0%, rgba(252, 119, 30, 1) 100%);
  box-shadow: 0px 0px 8px 0px rgba(0, 0, 0, 0.12);
}

.mentary {
  padding: 0 8px 10px 8px;
  margin: 30px auto 0;
  width: 86%;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 0 10px 0 #ccc;
  margin-bottom: 30rpx;
  
}

.mentary .title {
  display: block;
  padding: 20px 0;
  font-size: 18px;
  font-weight: bolder;
}

.mentary view {
  line-height: 25px;
  color: #7E8A9D;
  font-size: 14px;
  text-indent: 24px;
}
</style>