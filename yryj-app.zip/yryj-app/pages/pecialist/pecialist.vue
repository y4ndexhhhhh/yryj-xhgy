<template>
<!--pages/pecialist/pecialist.wxml-->
<view class="conter" v-if="status==1">
  <view class="wrap">
    <image src="/static/images/banner/fenhonggu.png"></image>
    <view class="title">
      {{name}}
    </view>
    <view class="btn" @tap.stop="pupay">认购</view>
  </view>
  <view class="wrap">
    <image src="/static/images/banner/jife.png"></image>
    <view class="title">
      增值积分兑换
      <text>（增值积分{{pues.need_yjf}}）</text>
    </view>
    <view class="btn" @tap.stop="exchan">兑换</view>
  </view>
</view>
</template>

<script>
// pages/pecialist/pecialist.js
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      id: '',
      name: '',
      des: '',
      price: '',
      image_url: '',
      mgUrls: [],
      pues: {},
      stroge: '',
      status: 1
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();
    this.setData({
      id: e.id
    });
    this.getstroge();
    this.exchange();
    this.giftbag();
  },
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    /*---亿积分兑换---*/
    exchange() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'partner/exchange_partner_yjf',
        method: "POST",
        data: {
          type: that.id,
          uid: that.stroge.uid
        },

        success(res) {
          that.setData({
            pues: res.data.data
          });
        }

      });
    },

    // 获取礼包内容
    giftbag() {
      var that = this;
      var data = {};
      data["type"] = 1;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'gift_info/getGiftData',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          that.setData({
            name: res.data.data.name,
            des: res.data.data.des,
            price: res.data.data.price,
            image_url: res.data.data.image_url,
            mgUrls: res.data.data.image_url_json
          });
        }

      });
    },

    /*---普通认购---*/
    pupay() {
      uni.navigateTo({
        url: '/pages/giftbag/giftbag?type=15&order_flag=1&name=' + this.name + '&des=' + this.des + '&price=' + this.price + '&image_url=' + this.image_url
      });
    },

    /*---兑换---*/
    exchan() {
      var that = this;
      uni.navigateTo({
        url: '/pages/exchan/exchan?type=15&order_flag=2&unit=' + that.pues.unit_price + '&need_yjf=' + that.pues.need_yjf + '&usable_yjf=' + that.pues.usable_yjf
      });
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/pecialist/pecialist.wxss */
.wrap {
  width: 90%;
  padding: 10px 3px;
  margin: 30px auto;
  display: flex;
  justify-content: space-around;
  box-shadow: 0 0 8px #ccc;
  border-radius: 8px;
}

.wrap image {
  width: 42px;
  height: 42px;
  margin-left: 3px;
}

.wrap .title {
  margin-top: 10px;
  font-size: 18px;
  font-weight: bold;
  margin: auto;
  margin-left: 30px;

}

.wrap text {
  font-size: 12px;
}

.wrap .btn {
  width: 80px;
  height: 30px;
  margin-top: 6px;
  line-height: 30px;
  text-align: center;
  margin-right: 10px;
  color: #fff;
  background: linear-gradient(270deg, rgba(255, 205, 104, 1) 0%, rgba(252, 119, 30, 1) 100%);
  box-shadow: 0px 0px 8px 0px rgba(0, 0, 0, 0.12);
  border-radius: 30px;
}
</style>