<template>
	<!--pages/bank/bank.wxml-->
	<!-- <view class="card-box" v-if="status==1"> -->

	<!--  <view class="card-list">
  <view class="my_card">
    <view class="my_card_num">
    <view class="text">我的卡数 : {{bank_num}} 张</view>
  </view>
  </view>
    <navigator v-for="(bankItem, index) in bank_list" :key="index" class="card-wrap" :url="'/pages/bank_detail/bank_detail?sign_id=' + bankItem.sign_id + '&bank_type=' + bankItem.bank_type + '&&acc_no=' + bankItem.acc_no">
      <view v-for="(bankimgItem, index2) in bankimg_list" :key="index2" class="bank_msg_image" v-if="bankItem.bank_type == bankimgItem.type">
        <image :src="bankimgItem.img"></image>
      </view>
      <view class="card-num">{{bankItem.acc_no}}</view>
    </navigator>
    <view class="add_btn" @tap="add_bank">
      <view class="add">
        <image src="/static/images/banner/add.png"></image>
      </view>
      <view class="text">添加银行卡</view>
    </view>
  </view> -->
	<!-- </view> -->
	<view class="content">
		<!-- <navBar :title="title"></navBar> -->
		<view class="bankNum">
			<text>我的卡数: {{bank_num}}张</text>
		</view>
		<view class="bankCard" v-for="(item,index) in bank_list" v-if="bank_list.length > 0">
			<view class="bankTop">
				<view class="radio"></view>
				<text class="text">{{item.bankName}}</text>
				<text class="type">储蓄卡</text>
			</view>
			<view class="bankBottom">
				<text>{{item.acc_no}}</text>
				<!-- 	<text>****</text>
				<text>****</text>
				<text>****</text>
				<text>3698</text> -->
			</view>
		</view>
		<mybottom v-if="bank_num == 0" name="添加银行卡" @sublimt='add_bank'></mybottom>
		 <doudi v-if="bank_list.length == 0"></doudi>
	</view>

</template>

<script>
	// pages/bank/bank.js
	const app = getApp();
	var sha_1 = require("../../utils/sha_1.js");

	export default {
		data() {
			return {
				uid: '',
				bankimg_list: [],
				bank_list: [],
				bank_num: 0,
				status: 1,
				objectArray: [{
					id: 0,
					name: '请选择银行',
					value: ''
				}, {
					id: 1,
					name: '中国建设银行',
					value: 'CCB'
				}, {
					id: 2,
					name: '中国农业银行',
					value: 'ABC'
				}, {
					id: 3,
					name: '中国交通银行',
					value: 'COMM'
				}, {
					id: 4,
					name: '中国邮政储蓄银行',
					value: 'PSBC'
				}, {
					id: 5,
					name: '中国工商银行',
					value: 'ICBC'
				}, {
					id: 6,
					name: '中国银行',
					value: 'BOC'
				}, {
					id: 7,
					name: '平安银行',
					value: 'SPABANK'
				}, {
					id: 8,
					name: '中信银行',
					value: 'CITIC'
				}, {
					id: 9,
					name: '中国民生银行',
					value: 'CMBC'
				}, {
					id: 10,
					name: '华夏银行',
					value: 'HXBANK'
				}, {
					id: 11,
					name: '广发银行',
					value: 'GDB'
				}, {
					id: 12,
					name: '兴业银行',
					value: 'CIB'
				}, {
					id: 13,
					name: '上海银行',
					value: 'SHBANK'
				}, {
					id: 14,
					name: '中国光大银行',
					value: 'CEB'
				}],
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(e) {
			this.reqstatu();
			this.getstroge();
			this.getUserBanknoList();
		},
		methods: {
			/*获取本地数据*/
			getstroge() {
				const stroge = uni.getStorageSync('key');
				const stroge_bankimg_list = uni.getStorageSync('bankimg_list');
				this.setData({
					uid: stroge.uid,
					bankimg_list: stroge_bankimg_list
				});
			},

			// 添加银行卡
			add_bank() {
				if (this.bank_num == 0) {
					uni.navigateTo({
						url: '/pages/bind_bank/bind_bank'
					});
				}
			},

			// 获取银行卡信息列表
			getUserBanknoList() {
				var that = this;
				var uid = this.uid;
				if (uid == '') {
					uni.showToast({
						title: '用户信息不存在，请重新登录！',
						icon: 'none'
					});
					return;
				}

				var data = {};
				data["uid"] = that.uid;
				var arr = {
					data: data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.url + 'union_pay/getUserBanknoList',
					method: 'POST',
					data: {
						data: aesData
					},

					success(res) {
						if (res.data.code == 200) {
							var bank_list = res.data.data; //缓存中是否存在银卡图片

							//      if (that.bankimg_list.length == 0) {
							//        // 将数组里的数据放入缓存中
							//        var stroge_bank = [];
							//        bank_list.forEach(v => {
							//          uni.downloadFile({
							//            url: 'https://apimg.alipay.com/combo.png?d=cashier&t=' + v.bank_type,

							//            success(res) {
							// console.log(res)
							//              if (res.statusCode == 200) {
							//                stroge_bank.push({
							//                  'type': v.bank_type,
							//                  'img': res.tempFilePath
							//                });
							//                uni.setStorageSync("bankimg_list", stroge_bank);
							//              }
							//            }

							//          });
							//        }); //wx.setStorageSync("bankimg_list",stroge_bank)
							//      }
							for (var i in that.objectArray) {
								for (var j in bank_list) {
									if (that.objectArray[i].value == bank_list[j].bank_type) {
										bank_list[j].bankName = that.objectArray[i].name
									}
								}
							}
							that.setData({
								bank_list: bank_list,
								bank_num: res.data.bandCardNum
							});
						} else {
							uni.showToast({
								title: res.data.msg,
								icon: 'none'
							})
							uni.navigateTo({
								url: '/pages/bind_bank/bind_bank'
							});
						}
					}

				});
			},

			reqstatu() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'shield/getShield',
					method: "POSt",
					data: {
						version_code: app.globalData.version_code
					},

					success(res) {
						that.setData({
							status: res.data.data.status
						});
					}

				});
			},

			// 跳转到银行卡详情页
			go_bank_detail() {
				uni.navigateTo({
					url: '/pages/bank_detail/bank_detail'
				});
			}

		}
	};
</script>
<style lang="scss" scoped>
	.content {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: flex-start;

		.bankNum {
			width: 100%;
			height: 80rpx;
			padding: 0 30rpx;
			box-sizing: border-box;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			line-height: 24rpx;
			color: #333333;
			opacity: 1;
		}

		.bankCard {
			width: 686rpx;
			height: 170rpx;
			background: #FC6469;
			opacity: 1;
			border-radius: 8rpx;
			padding: 0 30rpx;
			box-sizing: border-box;
			margin-top: 20rpx;

			.bankTop {
				width: 100%;
				height: 85rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.radio {
					width: 30rpx;
					height: 30rpx;
					background-color: #FFFFFF;
					border-radius: 50%;
				}

				.text {
					font-size: 36rpx;
					font-family: Segoe UI;
					font-weight: 400;
					line-height: 48rpx;
					color: #FFFFFF;
					opacity: 1;
					margin-left: 30rpx;
				}

				.type {
					margin-left: 20rpx;
					font-size: 26rpx;
					font-family: Segoe UI;
					font-weight: 400;
					line-height: 34rpx;
					color: #FFFFFF;
					opacity: 1;
				}
			}

			.bankBottom {
				width: 100%;
				height: 85rpx;
				display: flex;
				// justify-content:;
				padding-left: 120rpx;
				box-sizing: border-box;
				align-items: center;

				text {
					margin-right: 20rpx;
					font-size: 36rpx;
					font-family: Segoe UI;
					font-weight: 600;
					line-height: 48rpx;
					color: #FFFFFF;
					// letter-spacing: 80px;
					opacity: 1;
				}
			}
		}
	}
</style>
