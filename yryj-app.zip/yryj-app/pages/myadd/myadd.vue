<template>
<!--pages/myadd/myadd.wxml-->
<view class="conter" v-if="status==1">
  <view class="wrap">
    <view>
     <view class="input_wrap">
        <text>手机号:</text>
        <view> {{stroge.phone}}</view>
      </view>
      <view class="input_wrap">
        <text>姓名：</text>
        <input name="username"  v-model="username" type="text" placeholder="请输入您的姓名(必填)"></input>
      </view>
      <view class="input_wrap">
        <text>身份证号：</text>
        <input name="codee"  v-model="id_card" type="text" placeholder="请输入身份证(必填)"></input>
      </view>
<!--      <view class="input_wrap">
        <text style="width: 200rpx;">所在地区：</text>
          <view class="picker" v-if="areas_address == ''" @click="getLocation">
              请选择地址
          </view>
         <view class="picker" v-else @click="getLocation">
            {{areas_address}}
          </view>
      </view> -->
      <view class="input_wrap" style="">
        <text>详细地址：</text>
        <input name="bindblur" @input="adder" v-model="detailed_address" type="text" placeholder="如：县、乡、村、街道、单元" style="text-align:left;"></input>
      </view>
        <!-- <button class="btns" form-type="submit" :disabled="disabled">确认</button> -->
		
		<!-- <button type="default"></button> -->
    </view>
	<mybottom @sublimt="formSubmit"></mybottom>
  </view>
</view>
</template>

<script>
// pages/myadd/myadd.js
const app = getApp();

export default {
  data() {
    return {
      stroge: {},
      //本地缓存数据
      username: "",
      phone: "",
      id_card: "",
      adders: "",
      join_status: '',
      adders_flag: false,
      flag: 1,
      region: ['选择省', '选择市', '选择区'],
      disabled: true,
      status: 1,
      storage_address: "",
      areas_address: "",
      detailed_address: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();
    this.getstroge();
  },

  onShow() {
    this.getstroge();
  },

  methods: {
    /*获取本地数据*/
    getstroge() {
      const stroge = uni.getStorageSync('key');
	  console.log(stroge)
      this.setData({
        stroge: stroge,
        storage_address: stroge.address,
		areas_address:stroge.address,
		username:stroge.real_name,
		id_card:stroge.id_card
      });
      if (this.storage_address) {
        const siptes = this.storage_address.split('-');
        this.setData({
          areas_address: siptes[0],
          detailed_address: siptes[1]
        });
      }
    },

    /*姓名 */
    user(e) {
      let username = e.detail.value;
      let usernamerule = /^[\u4E00-\u9FA5]{2,4}$/;

      if (!usernamerule.test(username)) {
        uni.showToast({
          title: '请输入正确的姓名',
          icon: 'none'
        });
      } else {
        this.setData({
          username: username
        });
      }
    },

    /*身份证*/
    id_cardFun(e) {
      var that = this;
      let id_card = e.detail.value;
      let check_card = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;

      if (!check_card.test(id_card)) {
        this.setData({
          disabled: true
        });
        uni.showToast({
          title: '请输入正确的身份证号',
          icon: 'none'
        });
      } else {
        that.checkIdCard(id_card).then(res => {
          if (res.code != 'ok') {
            this.setData({
              disabled: true
            });
            uni.showToast({
              title: res.msg,
              icon: 'none'
            });
          } else {
            this.setData({
              id_card: id_card
            });
          }
        }).catch(res => {});
      }
    },

    bindRegionChange: function (e) {
      var that = this;
      let region = e.detail.value;

      if (region) {
        this.setData({
          region: region,
          adders_flag: true
        });
      } else {
        that.setData({
          disabled: true
        });
        uni.showToast({
          title: '请输入详细地址',
          icon: 'none'
        });
      }
    },

    // /*详细地址*/
    adder(e) {
      var that = this;
      let adders = e.detail.value;

      if (adders) {
        that.setData({
          adders: adders,
          disabled: false
        });
      } else {
        that.setData({
          disabled: true
        });
        uni.showToast({
          title: '请输入详细地址',
          icon: 'none'
        });
      }
    },
     /***
      * 判断是否开启定位服务
      */
     getLocation() {
     	let that = this;
     	uni.getLocation({
     		type: 'wgs84',
     		geocode: true,
     		success: function(res) {
				console.log(res)
     			//that.areas_address = res.address.province + res.address.city + res.address.district;
     			let lat = res.latitude;
     			let lon = res.longitude;
     			
     			uni.chooseLocation({
     				latitude: lat,
     				longitude: lon,
     				success: function(res) {
     					that.detailed_address = res.address;
     				},
     				fail(err) {
     					console.log(err)
     				}
     			});
     		}
     	});
     
     },
    /*--form表单提交数据--*/
    formSubmit(e) {
      var that = this;
      var user = that.username;
      var ader = that.areas_address;
      var id_card = that.id_card;
      var addes = that.detailed_address;
      var flag = that.flag;

      if (user == '') {
        uni.showToast({
          title: '请输入姓名',
          icon: 'none'
        });
      } else if (ader == '选择省,选择市,选择区') {
        uni.showToast({
          title: '请选择地区',
          icon: 'none'
        });
      } else if (addes == '') {
        uni.showToast({
          title: '请输入详细地址',
          icon: 'none'
        });
      } else if (id_card == '') {
        uni.showToast({
          title: '请输入身份证号',
          icon: 'none'
        });
      } else {
        that.saveUserData(user, id_card, flag, ader, addes);
      }
    },

    checkIdCard(id_card) {
      var that = this;
      return new Promise(function (resolve, reject) {
        uni.request({
          url: app.globalData.url + 'partner/id_cord',
          method: "POST",
          data: {
            uid: that.stroge.uid,
            id_card: id_card
          },
          success: res => {
            let result = res.data;
            resolve(result);
          },
          fail: () => {
            reject("系统异常，请重试！");
          }
        });
      });
    },

    saveUserData(real_name, id_card, flag, ader, addes) {
      var that = this;
      var adder = `${ader}-${addes}`;
      uni.request({
        url: app.globalData.url + 'users/seve_img',
        method: "POST",
        data: {
          uid: that.stroge.uid,
          real_name: real_name,
          id_card: id_card,
          address: adder,
          flag: flag
        },

        success(res) {
			console.log(res,"KKKKKKKKKK")
          const stoges = res.data.data;

          if (res.data.code == 'ok') {
            uni.setStorageSync('key', stoges);
            uni.showToast({
              title: '实名认证成功',
              icon: 'none',
              duration: 500,
              mask: true,

              success(data) {
                setTimeout(function () {
                  //要延时执行的代码
                  that.resplay();
                }, 500); //延迟时间
              }

            });
          } else {
            uni.showToast({
              title: res.data.msg
            });
          }
        }

      });
    },

    resplay() {
      uni.navigateTo({
        url: '/pages/aplay/aplay?oid=1'
      });
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/myadd/myadd.wxss */
.formtable {
  margin: auto;
  width: 80%;
  padding: 20px 10px 0 10px;
}
form input {
  width: 70%;
  border-bottom: 1px solid #eee;
}

.picker {
  width: 100%;
  /* border-bottom: 1px solid #eee; */
}

.wrap {
  padding: 20rpx;
  font-size: 14px;
  color: #333;
}
.input_wrap{
display: flex;
width: 100%;
padding: 30rpx 0;
border-bottom: 1rpx solid #eee;
}
.input_wrap text{
width: 80px;
}
.btn{
display: flex;
justify-content: center;
text-align: center;
margin-top: 40rpx;
 line-height: 60rpx;
}

.btns {
width: 60%;
color: #fff;
background-color: #107BFD;
border-radius: 12px;
display: flex;
justify-content: center;
}

</style>