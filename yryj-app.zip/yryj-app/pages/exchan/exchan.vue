<template>
<!--pages/exchan/exchan.wxml-->
<!--pages/exchang/exchang.wxml-->
<view class="conter" v-if="status==1">
  <view class="putop">
    <view>
      当前兑换天使合伙人所需的增值积分为：
      <text class="money">{{need_yjf}}</text>
    </view>
    <!-- <view class='gufen'>
         认购股份: 
         <text class='money'>{{need_yjf}}</text>
       </view> -->
    <view class="title">积分规则为{{need_yjf}}个增值积分。</view>
  </view>
  <view class="aoder">
    <text>剩余积分：</text>
    <text>{{usable_yjf}}</text>
  </view>
  <radio-group class="radig" @change="checkboxChange">
    <radio class="radios" value="3"></radio>
    我已阅读并同意<text class="text" @tap.stop="agreement">《合伙人计划》</text>
  </radio-group>
  <view class="buttons" @tap.stop="buttons">
	  确认兑换
  </view>
</view>
</template>

<script>
// pages/pupay/pupay.js
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      stroge: '',
      ordie: '',
      type: '',
      order_flag: '',
      unit: "",
      share: '',
      money: 0,
      code: '',
      order_id: '',
      status: 1,
      need_yjf: "",
      usable_yjf: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();
    this.setData({
      type: e.type,
      order_flag: e.order,
      unit: e.unit,
      need_yjf: e.need_yjf,
      usable_yjf: e.usable_yjf
    });
    this.getstroge();
    this.getstrogecode();
  },
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    getstrogecode() {
      var that = this;
      const code = uni.getStorageSync('code');
      that.setData({
        code: code
      });
    },

    /*---增值积分兑换---*/
    exchange(money) {
      var that = this;
      var data = {};
      data["uid"] = that.stroge.uid;
      data["type"] = that.type;
      data["order_flag"] = that.order_flag;
      data['amount'] = money;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'partner/hhr_order',
        method: "POST",
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            uni.showModal({
              title: '兑换',
              content: res.data.msg,

              success(res) {
                if (res.confirm) {
                  that.requid();
                  uni.switchTab({
                    url: '/pages/index/index'
                  });
                }
              }

            });
          } else {
            uni.showModal({
              title: '兑换',
              content: res.data.msg,

              success(res) {
                if (res.confirm) {
                  uni.switchTab({
                    url: '/pages/index/index'
                  });
                }
              }

            });
          }
        }

      });
    },

    shares(e) {
      this.setData({
        share: e.detail.value
      });
    },

    /*---同意协议---*/
    checkboxChange(e) {
      this.setData({
        ordie: e.detail.value
      });
    },

    /*---支付---*/
    buttons() {
      var that = this;
      const money = that.need_yjf;

      if (that.ordie == '') {
        uni.showToast({
          title: '请勾选合伙人计划',
          icon: 'none'
        });
        return false;
      } else {
        that.exchange(money);
      }
    },

    /*---合伙人协议---*/
    agreement() {
      uni.navigateTo({
        url: '/pages/autobiog/autobiog'
      });
    },

    /*重新存储uid*/
    requid() {
      uni.request({
        url: app.globalData.url + 'users/userinfo',
        method: "POST",
        data: {
          uid: this.stroge.uid
        },

        success(res) {
          uni.setStorageSync('key', res.data.data);
        }

      });
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
page {
  background-color: #F4F4F4;
}

.putop {
  padding: 30px 10px;
  background-color: #fff;
}

.putop .money {
  color: #FF9797;
}

.gufen {
  margin-top: 20px;
}

.gufen .money {
  margin-left: 13px;
}

.title {
  margin-top: 20px;
  font-size: 12px;
  color: #999;
  line-height: 20px;
}

.radig {
  margin: 30px;
  margin-left: 20rpx;
  font-size: 12px;
  color: #333;
}

.text {
  color: #0B3FFF;
}

.aoder {
  padding: 8px 20px;
  background-color: #fff;
  /* margin-top: 20px; */
  /* box-shadow: 0 0 5px #ccc; */
}

.aoder image {
  width: 25px;
  height: 25px;
  vertical-align: middle;
}

.buttons {
  margin: 100px auto 20px;
  /* width: 60%; */
  width: 686rpx;
  height: 120rpx;
  background: #FFAC38;
  opacity: 1;
  border-radius: 60rpx;
  line-height: 120rpx;
  text-align: center;
  
  
  font-size: 44rpx;
  font-family: PingFang SC;
  font-weight: 500;
  color: #FFFFFF;
  opacity: 1;
}
</style>