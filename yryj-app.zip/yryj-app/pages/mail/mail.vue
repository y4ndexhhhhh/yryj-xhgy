<template>
<!--pages/mail/mail.wxml-->
<view class="conter">

  <form>
    <view class="ifno">
      <view>邮寄地址：</view>
      <view>
        <text>收货姓名：</text>
        <input name="username"  v-model="username" type="text" placeholder="请输入您的姓名(必填)" maxlength="5" ></input>
      </view>
      <view>
        <text>手机号码：</text>
        <input name="phone" type="number" placeholder="请输入手机号(必填)" maxlength="11" v-model="phone"></input>
      </view>
	  <view @click="getLocation">
			<text>所在地区：</text>
			<input name="adders"  type="text" placeholder="请输选择地址" disabled="disabled"  v-model="adders"></input>
	  </view>
      <view>
        <text>详细地址：</text>
        <input name="adders" type="text" placeholder="如：县、乡、村、街道、单元" disabled="disabled"  v-model="adderrs"></input>
      </view>
      <view>
        <view class="vip">会员公约签署</view>
        <view style="color:blue;" @tap="lookvip">查看公约</view>
      </view>

      <view class="canvas" @tap="autographFun" v-if="autograph!=''">
        <view class="canvasborder">
          <cover-image :src="autograph"></cover-image>
        </view>
      </view>

      <view class="canvas" @tap="autographFun" v-else>
        <view class="canvasborder">
          <text class="canvastext">轻触去签名</text>
        </view>
      </view>
    </view>
  </form>
  <view class="buttons" @tap.stop="formSubmit">点我提交</view>


</view>
</template>

<script>
// pages/mail/mail.js
var app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      src: "",
      cvsHeight: '100%',
      // hidden: true,
      // ishow: true,
      uid: "",
      username: "",
      phone: "",
      codee: "",
      adders: "",
      //所在地区
      adderrs: "",
      //详细地址
      region: ['选择省', '选择市', '选择区'],
      storage_address: "",
      areas_address: "",
      detailed_address: "",
      user_express_address: [],
      autograph: '',
      autograph_img: '',
      token: '',
      rank: 1,
      adders_flag: true,
      address: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    if (JSON.stringify(e) != '{}') {
      this.setData({
        uid: e.uid,
        rank: e.rank
      });
    } else {
      const stroge = uni.getStorageSync('key');
      this.setData({
        uid: stroge.uid,
        rank: stroge.rank
      });
    }

    this.getLastAddress();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (e) {
    if (app.globalData.autograph != '') {
      this.setData({
        autograph: app.globalData.autograph
      }); //上传图片

      this.getToken();
    }
  },
  methods: {
    // 跳转到签名页面
    autographFun() {
      uni.navigateTo({
        url: '/pages/autograph/autograph?flag=1'
      });
    },

    /*---input框中的value值---*/
    // 用户名
    usernameFun(e) {
      var username = e.detail.value;

      if (username != '') {
        var myreg = /^[\u4E00-\u9FA5]+$/;

        if (!myreg.test(username)) {
          uni.showToast({
            title: '姓名只能为汉字',
            icon: 'none',
            duration: 500
          });
        } else {
          this.setData({
            username: e.detail.value
          });
        }
      } else {
        uni.showToast({
          title: '请输入姓名',
          icon: 'none',
          duration: 500
        });
        this.setData({
          username: '系统'
        });
        return;
      }
    },

    // 手机号
    onphone(e) {
      var phone = e.detail.value;

      if (phone != '') {
        var myreg = /^1[3456789]\d{9}$/;

        if (!myreg.test(phone)) {
          uni.showToast({
            title: '请输入正确的手机号',
            icon: 'none',
            duration: 1000
          });
        } else {
          this.setData({
            phone: e.detail.value
          });
        }
      } else {
        uni.showToast({
          title: '请输入手机号',
          icon: 'none',
          duration: 500
        });
        this.setData({
          phone: '系统'
        });
        return;
      }
    },

    // 所在地区
    onadder(e) {
      this.setData({
        address: e.detail.value
      });
    },

    // 详细地址
    onadderrs(e) {
      var adders = e.detail.value;

      if (adders != '') {
        this.setData({
          adders: e.detail.value
        });
      } else {
        uni.showToast({
          title: '请输入详细地址',
          icon: 'none',
          duration: 500
        });
        this.setData({
          adders: '系统'
        });
        return;
      }
    },

    bindRegionChange: function (e) {
      this.setData({
        region: e.detail.value,
        adders_flag: true
      });
    },

    /*--form表单提交数据--*/
    formSubmit(e) {
      var that = this;
      var autograph_img = that.autograph_img;
      var username = that.username;
      var phone = that.phone; 
	  //所在地区
      var address = that.adderrs; //详细地址
      var addres = that.adders;
	  
      var data = {};

      if (username == '' && phone == '' && address == '选择省,选择市,选择区' && addres == '') {
        //说明用户没有点击输入--地址保持不变
        if (autograph_img == '') {
          uni.showToast({
            title: '请在签名处签名',
            icon: 'none',
            duration: 500
          });
          return false;
        } else {
          data["name"] = that.username;
          data["phone"] = that.phone;
          data["addr1"] = that.addres;
          data["addr2"] = that.address;
        }
      } else {
        if (username == '系统') {
          uni.showToast({
            title: '姓名不能为空',
            icon: 'none',
            duration: 500
          });
          return false;
        } else {
          data["name"] = username;
        }

        if (phone == '系统') {
          uni.showToast({
            title: '电话号码不能为空',
            icon: 'none',
            duration: 500
          });
          return false;
        } else {
          data["phone"] = phone;
        }

        if (addres == '系统') {
          uni.showToast({
            title: '详细地址不能为空',
            icon: 'none',
            duration: 500
          });
          return false;
        } else {
          data["addr2"] = addres;
        }

        if (autograph_img == '') {
          uni.showToast({
            title: '请在签名处签名',
            icon: 'none',
            duration: 500
          });
          return false;
        }
      }

      data["uid"] = that.uid;
      data["addr1"] = address;
      data["qianming"] = autograph_img;
      var arr = {
        data: data
      };
	  console.log(autograph_img)
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'express/express_order',
        method: "POST",
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            uni.setStorageSync('order_id', res.data.data);
            uni.setStorageSync('express_money', res.data.express_money);
            uni.showToast({
              title: '邮寄信息提交成功',
              icon: 'none',
              duration: 500,
              success: res => {
                uni.navigateTo({
                  url: '/pages/postage/postage'
                });
              }
            });
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 500
            });
          }
        }

      });
    },

    /*获取用户最近一次的收货地址*/
    getLastAddress() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'express/last_addr',
        method: "POST",
        data: {
          data: aesData
        },
        success(res) {
          if (res.data.code == 'ok') {
			  let userInfo = res.data.data;
			  this.username = userInfo.name;
			  this.phone = userInfo.phone;
			  this.adders = userInfo.addr1;
			  this.adderrs = userInfo.addr2;
            that.setData({
              user_express_address: res.data.data,
              adders_flag: false
            });
          }
        }

      });
    },
    
	/***
	 * 判断是否开启定位服务
	 */
	getLocation() {
		let that = this;
		uni.getLocation({
			type: 'wgs84',
			geocode: true,
			success: function(res) {
				
				that.adders = res.address.province + res.address.city + res.address.district;
				console.log(that.adders)
				let lat = res.latitude;
				let lon = res.longitude;
				uni.chooseLocation({
					latitude: lat,
					longitude: lon,
					success: function(res){
						that.adderrs = res.address;
					},
					fail(err) {
						console.log(err)
					}
				});
			}
		});
	
	},
    /*地址*/
    bindRegionChange: function (e) {
      this.setData({
        region: e.detail.value,
        adders_flag: true
      });
    },

    //获取上传凭证
    getToken() {
      var that = this;
      var src = that.autograph;

      if (src) {
        uni.request({
          url: app.globalData.url + 'users/getqntoken',
          method: "POST",

          success(res) {
            if (res.data.code == 'ok') {
              that.setData({
                token: res.data.data
              }); //上传凭证获取成功，进行七牛云上传

              that.uploadQiniu(src);
            } else {
              uni.showModal({
                title: '启奏陛下',
                content: '获取上传凭证失败，请重试'
              });
            }
          }

        });
      }
    },

    /**
     * 图片上传七牛云
     */
    uploadQiniu(tempFilePaths) {
      var that = this;
      let token = that.token;

      if (token != '') {
        uni.uploadFile({
          url: 'https://upload-z2.qiniup.com',
          name: 'file',
          filePath: tempFilePaths,
          header: {
            "Content-Type": "multipart/form-data"
          },
          formData: {
            token: token
          },
          success: function (res) {
            if (res.statusCode == 200) {
              let respones_data = JSON.parse(res.data);
              var qiniu_key = respones_data.key;
              that.setData({
                autograph_img: qiniu_key
              });
            }
          },
          fail: function (res) {
            uni.showModal({
              title: '启奏陛下',
              content: '签名生成失败，请重试'
            });
          }
        });
      } else {
        uni.showModal({
          title: '启奏陛下',
          content: '签名生成失败，请重试'
        });
      }
    },

    lookvip() {
      var that = this;

      if (that.rank == 1 || that.rank == 0) {
        var url = 'https://app01.wysyt.com/xcxapi/open_banner/open_154';
      } else {
        var url = 'https://app01.wysyt.com/xcxapi/open_banner/open_50';
      }

      uni.navigateTo({
        url: '/pages/bannerurl/bannerurl?url=' + url
      });
    }

  }
};
</script>
<style>
/* pages/mail/mail.wxss */
.conter {
  display: flex;
  justify-content: space-around;
  height: 100%;
  overflow: hidden;
}

.form view {}

.form view input {
  border-bottom: 1px solid #eee;
}

.ifno {
  padding: 20px;
  width: 300px;
  background: #fff;
  border-radius: 10px;
  border: 1px solid #eee;
}

.ifno view {
  display: flex;
  padding: 10px 0;
}

.ifno view input {
  width: 220px;
  border-bottom: 1px solid #eee;
}

.buttons {
  position: absolute;
  padding: 10px;
  bottom: 3px;
  width: 50%;
  margin-left: auto;
  background: #007bff;
  text-align: center;
  color: #ffff;
  border-radius: 10px;

  box-sizing: border-box;

}

image {
  /* height: 50%;
  width: 50%; */
}

.canvas {
  margin-top: 10px;
  height: 25vh;
  display: flex;
  justify-content: space-around;
}

.canvasborder {
  width: 90%;
  border: 4rpx dashed #e9e9e9;
  box-sizing: border-box;
  font-size: 30px;
  color: #666;
}

.image {
  width: 90%;
  height: 25vh;
}

.canvastext {
  position: relative;
  top: 40%;
  left: 25%;
}

.section {
  padding: 0;
}

.picker {
  width: 140%;
  border-bottom: 1px solid #eee;
}

.vip {
  margin-right: 140px;
}

.cover {
  height: 100%;
  width: 100%;
}

::-webkit-scrollbar {
  display: none;
}
</style>