<template>
	<view>
		<!--pages/vido/vido.wxml-->
		<!-- <view wx:if='{{!list.length==0}}'>
  <block wx:for='{{list}}' wx:key='index'>
    <video class='myvido' src='{{item.url}}'></video>
  </block>
</view> -->
		<view class="boxs">
			<view class="boxstitles">
				<text>兑换码</text>
			</view>
			<view class="boxcontent">
				<input maxlength="8" @input="excodeFun" style="text-align: center;" placeholder="兑换码最大长度为8位" placeholder-class="defult" />
			</view>
			<view class="btntext">
				<text>温馨提示：兑换成功后，请前往医补计划进行实名认证领取</text>
			</view>
		</view>
		<!-- <view class="viess">
  <view class="vies">
    <input maxlength="8" @input="excodeFun" style="text-align: center;" placeholder="兑换码最大长度为8位"></input>
  </view> -->
		<!-- <button form-type="submit">确认</button> -->
		<!-- <view class="buttons" @tap.stop="buttons">确认</view> -->
		<mybottom @sublimt="buttons"></mybottom>

		<!-- </view>
<text class="text"></text> -->
	</view>
</template>

<script>
	// pages/vido/vido.js
	const app = getApp();
	var util = require("../../utils/util.js"),
		sha_1 = require("../../utils/sha_1.js");
	// const bttom from require()
	export default {
		data() {
			return {
				excode: '',
				stroge: {} //本地缓存数据

			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			this.getstroge(); // this.reqlist();
		},

		/**
		 * 用户点击右上角分享
		 */
		onShareAppMessage: function() {},
		methods: {
			//获取本地数据
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				that.setData({
					stroge: stroge
				});
			},

			//兑换会员
			doExchange() {
				var that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				data["excode"] = that.excode;
				var arr = {
					data: data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.url + 'exchange/doExchangeMember',
					method: 'POST',
					data: {
						data: aesData
					},

					success(res) {
						const msg = res.data.msg;

						if (res.data.code == 'ok') {
							uni.showToast({
								title: msg,
								icon: "none"
							})
							uni.switchTab({
								url: '/pages/index/index'
							});

						} else {
							uni.showToast({
								title: msg,
								icon: 'none'
							})
							return false;
						}
					}

				});
			},

			excodeFun(e) {
				this.setData({
					excode: e.detail.value
				});
			},

			//确认提交
			buttons(e) {
				var that = this;

				if (that.excode == '') {
					uni.showToast({
						title: '请输入兑换码',
						icon: 'none'
					});
					return false;
				} else if (isNaN(that.excode)) {
					uni.showToast({
						title: '兑换码不正确',
						icon: 'none'
					});
				} else {
					that.doExchange();
				}
			}

		}
	};
</script>
<style lang="scss" scoped>
	/* pages/vido/vido.wxss */
	.boxs {
		width: 100%;
		height: 275rpx;
		padding: 0 30rpx;
		box-sizing: border-box;
		background-color: #FFFFFF;

		.boxstitles {
			width: 100%;
			height: 80rpx;
			margin-top: 15rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			font-size: 36rpx;
			font-family: SourceHanSansCN-Regular;
			line-height: 30rpx;
			color: #333333;
			opacity: 1;
		}

		.boxcontent {
			width: 686rpx;
			height: 120rpx;
			background: #EBEBEB;
			opacity: 1;
			border-radius: 8rpx;
			display: flex;
			justify-content: center;
			align-items: center;

			input {
				font-size: 32rpx;
				font-family: SourceHanSansCN-Regular;
				line-height: 30rpx;
				color: #333;
				opacity: 1;
				text-align: center;
			}

			.defult {
				font-size: 32rpx;
				font-family: SourceHanSansCN-Regular;
				line-height: 30rpx;
				color: #B4B4B4;
				opacity: 1;
				text-align: center;
			}
		}

		.btntext {
			width: 100%;
			height: 70rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			margin-top: 10rpx;

			text {
				font-size: 28rpx;
				font-family: SourceHanSansCN-Regular;
				line-height: 30rpx;
				color: #A1A1A1;
				opacity: 1;
			}
		}

		// display: flex;
		// justify-content: ;
	}
</style>
