<template>
	<!--pages/login/login.wxml-->
	<view class="content">
		<view class="logoBox">
			<image src="/static/images/my/logo.png" mode="" class="logos"></image>
		</view>

		<view class="myContent">
			<view class="itemsText">
				<image src="/static/images/my/phone.png" mode="" class="icon"></image>
				<view class="line"></view>
				<input type="number" v-model="phone" maxlength="11"  class="input" placeholder-class="deflut" placeholder="请输入手机号" />
				<!-- 	<view class="timer" @tap="getVerificationCode">
				<text v-if="disabled">{{codename}}</text>
				<view class="timerBox"  v-else>
					<text>获取验证码</text>
				</view>
			</view> -->
			</view>
			<!-- 		<view class="itemsText">
			<image src="/static/images/my/yaochi.png" style="width: 35rpx;height: 41rpx;" mode="aspectFit" class="icon"></image>
			<view class="line"></view>
			<input type="text" v-model="pascode" class="deflut" placeholder="请输入验证码" />
			<view class="timer" >
			</view>
		</view> -->
			<view class="itemsText">
				<image src="/static/images/my/password.png" style="width: 35rpx;height: 44rpx;" mode="" class="icon"></image>
				<view class="line"></view>
				<input type="password" maxlength="16" v-model="password" class="input" placeholder-class="deflut" style="width: 400rpx;" placeholder="请输入6-16位字母和数字密码" />
			</view>
		</view>
		<view class="agreetext">
			<text @tap.stop="registered">没有账号，去注册</text>
			<text @tap.stop="passwords">忘记密码</text>
		</view>
		<view class="btn" @click="formSubmit">
			<text>登录</text>
		</view>
		<view class="agreetext">
			<text style="color: #4E73E8;" @tap.stop="beuser">《用户协议》</text>
			<text style="color: #4E73E8;" @tap.stop="privacy">《隐私政策》</text>
		</view>



		<view class="authorization" @click="getweChar">
			<image src="/static/images/my/wechart.png" mode="" class="imgs"></image>
			<view class="authtext">
				微信快捷登录
			</view>
		</view>
		<!--  <form @submit="formSubmit">
    <view class="login">
      <input name="phone" type="number" placeholder="请输入手机号" maxlength="11" @input="getPhoneValue" :value="phone"></input>
      <input type="password" name="password" @input="getPasswordValue" :value="password" placeholder="请输入密码"></input>
      <view class="pws">
        <text @tap.stop="registered">没有账号，注册</text>
        <text @tap.stop="passwords">忘记密码</text>
      </view>
      <button form-type="submit">登录</button>
    </view>
  </form> -->
	</view>
</template>

<script>
	// pages/login/login.js
	const app = getApp();
	var sha_1 = require("../../utils/sha_1.js");
	export default {
		data() {
			return {
				phone: '',
				password: ''
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			const a = uni.getStorageSync('key');

			if (a.uid) {
				uni.switchTab({
					url: '/pages/index/index'
				});
			}
		},
		methods: {

			getweChar() {
				var that = this;
				uni.getProvider({
					service: 'oauth',
					success: function(res) {
						console.log(res.provider[0],res);
						if (res.provider[0] == 'weixin') {
							uni.login({
								provider: 'weixin',
								success: function(loginRes) {
									console.log(loginRes);
									that.getApploginData(loginRes)
								},
								fail:function(err){
									console.log(err)
								}
							})
						}
					}
				})
			},
	    	getApploginData(loginRes) {
				console.log(loginRes.authResult)
				let that = this;
				var data = {};
				data["openid"] = loginRes.authResult.openid;
				var arr = {
					"data": data
				};
				console.log(arr)
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'wxopen/wxlogin',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					console.log(res)
					if (res.data.code == 0) {
						// uni.setStorageSync('key', res.data.data.data);	
						const uid = res.data.data.data.uid;
						app.globalData.uid = uid;
						uni.showToast({
							title:res.data.msg,
							icon:'none'
						})
						uni.setStorage({
						    key: 'key',
						    data: res.data.data.data,
						    success: function (res) {
								console.log(res)
						      uni.switchTab({
						      	url: '/pages/index/index'
						      });
						    },
							fail(err) {
								console.log(err)
							}
						});
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
		},
			//获取input输入框的值
			getPhoneValue: function(e) {
				this.setData({
					phone: e.detail.value
				});
			},

			getPasswordValue(e) {
				this.setData({
					password: e.detail.value
				});
			},

			/*---登录---*/
			formSubmit() {
				var myreg = /^1[3456789]\d{9}$/;
				var passwrod = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$/;
                let that = this;
				if (this.phone == '') {
					uni.showToast({
						icon: 'none',
						title: '手机号不能为空！'
					});
					return false;
				} else if (!myreg.test(this.phone)) {
					uni.showToast({
						icon: 'none',
						title: '手机号不符合！'
					});
					return false;
				}

				if (this.password == '') {
					uni.showToast({
						icon: 'none',
						title: '密码不能为空！'
					});
					return false;
				}

				uni.request({
					url: this.$apiUrl + 'login/login',
					method: "POST",
					data: {
						phone: this.phone,
						pass_word: this.password
					},

					success(res) {
						console.log(res)
						if (res.data.code === 'ok') {
							const uid = res.data.data;
							app.globalData.uid = uid;
							uni.showToast({
								title:res.data.msg,
								icon:'none'
							})
							uni.setStorage({
							    key: 'key',
							    data: res.data.data,
							    success: function (res) {
							      uni.switchTab({
							      	url: '/pages/index/index'
							      });
							    },
								fail(err) {
									console.log(err)
								}
							});
						} else {
							uni.showModal({
								title: '登录',
								content: res.data.msg,
								icon:'none'
							});
						}
					}

				});
			},
			/*---点击跳转注册---*/
			registered(e) {
				uni.redirectTo({
					url: '/pages/log/log'
				});
			},
			/*--忘记密码---*/
			passwords() {
				uni.redirectTo({
					url: '/pages/forget/forget'
				});
			},
			/*---用户协议---*/
			beuser(){
				uni.navigateTo({
					url: '/pages/AanewPages/userClause'
				});
			},
			/*---隐私条例---*/
			privacy(){
				uni.navigateTo({
					url: '/pages/AanewPages/privacyClause'
				});
			},

		}
	};
</script>
<style lang="scss" scoped>
	.content {
		width: 100%;
		height: 100%;
		background-color: #FFFFFF;

		.logoBox {
			width: 100%;
			height: 140rpx;
			margin-top: 50rpx;
			margin-bottom: 110rpx;

			.logos {
				margin: 0 auto;
				display: block;
				width: 120rpx;
				height: 120rpx;
			}
		}

		.myContent {
			width: 100%;
			height: auto;

			.itemsText {
				// display: flex;
				margin: 0 auto;
				width: 687rpx;
				height: 120rpx;
				border-bottom: 1rpx solid #BEBEBE;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				padding: 0 25rpx;
				box-sizing: border-box;

				.icon {
					width: 33rpx;
					height: 50rpx;
					// background-color: #f40;
				}

				.line {
					width: 0px;
					height: 40rpx;
					border: 1rpx solid #BEBEBE;
					opacity: 1;
					margin: 0 30rpx;
				}

				.deflut {
					width: 330rpx;
					height: 50rpx;
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 50rpx;
					color: #B8B8B8;
					opacity: 1;
				}
                .input{
					width: 330rpx;
					height: 50rpx;
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 50rpx;
					opacity: 1;
					color: #333333;
				}
				.timer {
					width: 206rpx;
					height: 72rpx;
					display: flex;
					justify-content: flex-end;
					align-items: center;
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					// line-height: 24px;
					color: #B8B8B8;
					opacity: 1;

					.timerBox {
						width: 206rpx;
						height: 72rpx;
						background: #4F74E8;
						opacity: 1;
						border-radius: 36rpx;
						display: flex;
						justify-content: center;
						align-items: center;

						text {
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 400;
							// line-height: 24px;
							color: #FFFFFF;
							opacity: 1;
						}
					}

				}
			}
		}

		.btn {
			width: 686rpx;
			height: 120rpx;
			background: #4F74E8;
			opacity: 1;
			border-radius: 60rpx;
			margin: 80rpx auto 0;
			text-align: center;

			text {
				font-size: 44rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 120rpx;
				color: #FFFFFF;
				opacity: 1;
			}
		}

		.agreetext {
			width: 686rpx;
			height: 80rpx;
			margin: 0 auto;
			display: flex;
			justify-content: space-between;
			align-items: center;

			text {
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 600;
				line-height: 40rpx;
				color: #333;
				opacity: 1;
			}
		}

		.authorization {
			width: 100%;
			height: auto;
			margin-top: 55rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			flex-flow: column;

			.imgs {
				width: 108rpx;
				height: 108rpx;
				// background-color: #FFFF00;
			}

			.authtext {
				margin-top: 20rpx;
				width: 144rpx;
				height: 34rpx;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
			}
		}
	}
</style>
