<template>
	<!--pages/bill/bill.wxml-->

	<!-- <Tabs :tabs="tabs" @tabschenge="handletabschenge">

  <block v-if="tabs[0].isActive">
    <view v-for="(item, index) in bill_list" :key="index" class="box-flex padding-lf-15" @tap="billtails" :data-id="item.id">
      <view class="box-flex-1 box-flex bill_detail_info_1px">
        <view class="box-flex-1 ">
          <view>{{item.describe}}</view>
          <view class="bill_detail_info_date">{{item.time}}</view>
        </view>
        <view class="bill_detail_info_money">{{item.change}}元</view>
      </view>
    </view>
  </block>
  <block v-else-if="tabs[1].isActive">
    <view v-for="(item, index) in bill_list" :key="index" class="box-flex padding-lf-15" @tap="billtails" :data-id="item.id">
      <view class="box-flex-1 box-flex bill_detail_info_1px">
        <view class="box-flex-1 ">

          <view>{{item.describe}}</view>
          <view class="bill_detail_info_date">{{item.time}}</view>
        </view>
        <view class="bill_detail_info_money">{{item.change}}</view>
      </view>
    </view>
  </block>
  <block v-else="tabs[1].isActive">
    <view v-for="(item, index) in bill_list" :key="index" class="box-flex padding-lf-15" @tap="billtails" :data-id="item.id">
      <view class="box-flex-1 box-flex bill_detail_info_1px">
        <view class="box-flex-1 ">
          <view>{{item.describe}}</view>
          <view class="bill_detail_info_date">{{item.time}}</view>
        </view>
        <view class="bill_detail_info_money">{{item.change}}</view>
      </view>
    </view>
  </block>
</Tabs> -->
	<view class="content">
		<view class="tab-active">
			<view class="tab-content" v-for="(item,index) in tabs" @click="handletabschenge(item.type,index)" :class="orderType==index?'active-box':''"
			 :key="index">
				{{item.value}}
			</view>
		</view>
		<view class="" style="width: 100%;height: 80rpx;">
			
		</view>
		<view class="itemsBox" v-for="(item,index) in bill_list" :key="index" @tap="billtails(item.id)" >
			<view class="itemsLeft">
				<view class="title">
					<text>{{item.describe}}</text>
					<!-- <text class="sign">充值</text> -->
				</view>
				<view class="times">
					<text>{{item.time}}</text>
				</view>
			</view>
			<view class="itemsRight">
				<text v-if="orderType == 1">{{item.change}}元</text>
				<text v-else>{{item.change}}元</text>
			</view>
		</view>
       <doudi v-if="bill_list.length == 0"></doudi>
	</view>


</template>

<script>
	// pages/bill/bill.js
	var util = require("../../utils/util.js"),
		sha_1 = require("../../utils/sha_1.js");
	const app = getApp();
	import Tabs from "../conponent/Tabs/Tabs";
    
	export default {
		data() {
			return {
				orderType: 0,
				tabs: [{
					id: 1,
					type: 100,
					value: "全部",
					isActive: true
				}, {
					id: 2,
					type: 101,
					value: "收入",
					isActive: false
				}, {
					id: 3,
					type: 102,
					value: "支出",
					isActive: false
				}],
				stroge: '',
				describe: '',
				time: '',
				change: 0,
				bill_list: [],
				page: 0,
				type: 100,
				list: '',
				now_date: "",
				one_flag: ""
			};
		},

		components: {
			Tabs
		},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			this.getstroge();
			this.reqstatu();
			var now_date = util.formatDate(new Date());
			this.setData({
				now_date: now_date
			});
		},

		/**
		 * 生命周期函数--监听页面显示
		 */
		onShow: function() {},

		// 监听用户上拉触底事件。
		onReachBottom() {
			var page = this.page + 1; //获取当前页数并+1

			this.setData({
				page: page //更新当前页数

			});
			this.reqstatu();
		},

		// 监听用户下拉刷新时间
		onPullDownRefresh() {
			// 重置数组
			this.setData({
				bill_list: []
			}); // 重置页码

			var page = 0;
			this.setData({
				page: page //更新当前页数

			}); // 重新发送请求

			this.reqstatu();
		},

		methods: {
			// 一级大类 --- 标题得点击事件，从子组件传
			handletabschenge(type, prop) {
				const that = this; // 获取被点击标题的索引
				this.orderType = prop;
				// console.log(id)
				this.type =type;
				that.setData({
					page: 0
				}); // 加载数据

				that.list = [];
				that.bill_list = [];
				that.reqstatu();
			},

			//获取本地数据
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				that.setData({
					stroge: stroge
				});
			},

			// 获取数据
			reqstatu() {
				var that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				data["page"] = that.page;
				data["type"] = that.type;
				var arr = {
					data: data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.url + 'wallet/bill_list',
					method: "POST",
					data: {
						data: aesData
					},

					success(res) {
						if (res.data.data.length == 0) {
							that.setData({
								bill_list: []
							});
						}

						if (res.data.code == 'ok') {
							let arr = res.data.data;

							for (let i = 0; i < arr.length; i++) {
								arr[i]["time"] = util.formatTimeTwo(arr[i]["time"], 'Y-M-D h:m:s');
							}

							that.setData({
								bill_list: arr
							});

							if (that.page == 0) {
								let list = arr;
								that.setData({
									list: list
								});
							} else {
								//获取下拉刷新之前的list数据
								let old_data = that.list; //arr  代表page+1  新数据

								that.setData({
									bill_list: old_data.concat(arr)
								});
							}
						} else {

						}

						uni.stopPullDownRefresh();
					}

				});
			},

			billtails(id) {
				let bill_id = id;

				if (bill_id == '') {
					uni.showToast({
						title: '账单ID获取失败，请重试！！',
						icon: 'none'
					});
				} else {
					uni.navigateTo({
						url: '../billdetails/billdetails?id=' + bill_id
					});
				}
			}

		}
	};
</script>
<style lang="scss" scoped>
	page {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
	}

	.content {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;

		.tab-active {
			display: flex;
			color: #919191;
			align-items: center;
			width: 100%;
			justify-content: space-around;
			height: 80rpx;
			background-color: #FFFFFF;
			font-size: 32rpx;
			padding: 0 30rpx;
			box-sizing: border-box;
            position: fixed;
			top: 0;
			left: 0;
			.tab-content {
				width: 20%;
				text-align: center;
				height: 100%;
				line-height: 80rpx;
				padding: 0 10rpx;
				box-sizing: border-box;

				image {
					width: 30rpx;
					height: 28rpx;
					vertical-align: middle;
					margin-left: 6rpx;
				}
			}
		}

		.active-box {
			width: 80%;
			border-bottom: 2px solid #FFAC38;
			color: #4E73E8;
		}

		.itemsBox {
			width: 100%;
			min-height: 120rpx;
			padding: 10rpx 30rpx;
			box-sizing: border-box;
			background-color: #FFFFFF;
			border-bottom: 2rpx solid #F8F9FF;
			display: flex;

			// justify-content: f;
			.itemsLeft {
				flex: 2;
				height: 120rpx;
				display: flex;
				justify-content: center;
				align-items: flex-start;
				flex-flow: column;

				.title {
					font-size: 34rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 35rpx;
					color: #333333;
					opacity: 1;

					.sign {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 500;
						line-height: 30rpx;
						margin-top: 5rpx;
						color: #919191;
						opacity: 1;

					}
				}

				.times {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 30rpx;
					color: #919191;
					opacity: 1;
					margin-top: 20rpx;
				}
			}

			.itemsRight {
				flex: 1;
				height: 120rpx;
				display: flex;
				justify-content: flex-end;
				align-items: center;

				text {
					font-size: 34rpx;
					font-family: PingFang SC;
					font-weight: 600;
					line-height: 35rpx;
					color: #333333;
					opacity: 1;
				}
			}
		}
	}



	/*弹性盒*/
	.box-flex {
		display: -webkit-box;
	}

	.box-flex-1 {
		-webkit-box-flex: 1;
	}

	.padding-lf-15 {
		padding-left: 16px;
		padding-right: 16px;
		margin-top: 2vh;
	}

	/* 明细*/
	.bill_detail_info_money {
		margin-top: 1vh;
		width: 110px;
		text-align: right;
		color: #EB4D30;
		font-weight: bold;
		font-size: 18px;
	}

	/*金额*/
	.bill_detail_info_1px {
		border-bottom: 1px solid #ccc;
	}

	.bill_detail_info_date {
		color: #A4A4A4;
		margin-top: 1vh;
		font-size: 12px;
		margin-bottom: 1vh;
	}
</style>
