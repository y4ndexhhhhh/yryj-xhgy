<template>
<view>
<!--pages/help_publicity/help_publicity.wxml-->
<view class="publicity_wrap" v-if="status==1">
  <view class="publicity_head">
    <view class="head_title">
      申请人信息
    </view>
  </view>
  <view class="wrap">
    <view class="title">加入时间</view>
    <view class="wrap_num">{{join_time}}</view>
  </view>
    <view class="wrap">
      <view class="title">姓名</view>
      <view class="wrap_num">{{real_name}}</view>
    </view>
  <view class="wrap">
    <view class="title">身份证号</view>
    <view class="wrap_num">{{id_card}}</view>
  </view>
  <view class="wrap">
    <view class="title">出院结算单</view>
    <view class="img" @tap="big_image" data-index="1">
      <image :src="url + '' + hospital_img"></image>
    </view>
  </view>
  <view class="wrap">
    <view class="title">审核截图</view>
    <view class="img" v-if="medical_img" @tap="big_image" data-index="2">
      <image :src="url + '' + medical_img"></image>
    </view>
    <view class="img_text" v-else>
      审核中
    </view>
  </view>
  <view class="wrap">
    <view class="title">援助金额</view>
    <view class="wrap_num">{{help_amount}}元</view>
  </view>
  <view class="wrap">
    <view class="title">参与均摊人数</view>
    <view class="wrap_num">{{share_num}}人</view>
  </view>
  <view class="wrap">
    <view class="title">公示倒计时</view>
    <view class="wrap_num">还有
    <view class="day">{{day}}</view>
    <view class="hour">{{hour}}</view>
    <view class="minute">{{minute}}</view>
    <view class="second">{{second}}</view>
    </view>
  </view>
  <view class="wrap_wintess">
    <view class="title">真实性证明人</view>
    <view class="witness_name">
      <view v-for="(item, index) in people_list" :key="index" class="name_box">{{item.real_name}}</view>
    </view>
  </view>
</view>
<view class="footer_wrap" v-if="status==1">
  <view class="continer">
    <view class="continer_text">我对本次援助有异议，并对投诉内容真实性负责</view>
    <view class="continer_btn">
      <view class="btn" @tap="set_complaint">提交投诉</view>
    </view>
  </view>
</view>
</view>
</template>

<script>
// pages/help_publicity/help_publicity.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      publicity_list: '',
      id: 0,
      uid: 0,
      case_id: 0,
      join_time: '',
      real_name: '',
      id_card: 0,
      hospital_img: '',
      medical_img: '',
      publicity_time: '',
      share_num: 0,
      help_amount: 0,
      url: '',
      people_list: [],
      day: "",
      hour: "",
      minute: "",
      second: "",
      status: 1
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.reqstatu();
    this.setData({
      publicity_list: JSON.parse(options.result),
      url: options.url
    });
    this.aaa();
    this.get_PublicityDetails();
    var startTime = this.publicity_time; //倒计时的时间

    var msTime = +new Date(startTime);
    var timer = setInterval(this.countDown, 1000, msTime);
  },
  methods: {
    aaa() {
      let publicity_list = this.publicity_list;
      this.setData({
        uid: publicity_list.uid,
        case_id: publicity_list.case_id,
        join_time: publicity_list.join_time,
        real_name: publicity_list.real_name,
        id_card: publicity_list.id_card,
        hospital_img: publicity_list.hospital_img,
        medical_img: publicity_list.medical_img,
        publicity_time: publicity_list.publicity_time,
        share_num: publicity_list.share_num,
        help_amount: publicity_list.help_amount
      });
    },

    // 获取援助公示证明人
    get_PublicityDetails() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      data["case_id"] = that.case_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.api_url + 'h5/proposers/getPublicityDetails',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {
            that.setData({
              people_list: res.data.data
            });
          }
        }

      });
    },

    // 倒计时
    countDown(start) {
      let that = this;
      var now = +new Date();
      var diff = start - now;
      that.setData({
        day: Math.floor(diff / (1000 * 60 * 60 * 24)) + "天",
        hour: Math.floor(diff / (1000 * 60 * 60) % 24) + "时",
        minute: Math.floor(diff / (1000 * 60) % 60) + "分",
        second: Math.floor(diff / 1000 % 60) + "秒"
      });

      if (that.day <= 0 && that.hour <= 0 && that.minute <= 0 && that.second <= 0) {
        that.setData({
          day: 0,
          hour: 0,
          minute: 0,
          second: 0
        });
        clearInterval(timer);
        that.get_stop_countDown();
      }
    },

    // 公示停止后请求事件
    get_stop_countDown() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      data["case_id"] = that.case_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.api_url + '/h5/proposers/stopPublicity',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          that.onLoad();
        }

      });
    },

    // 提交投诉事件
    set_complaint() {
      uni.navigateTo({
        url: '/pages/set_complaint/set_complaint?uid=' + this.uid + '&case_id=' + this.case_id
      });
    },

    big_image(e) {
      var that = this;
      let urls = [];
      const current = e.currentTarget.dataset.index;

      if (current == 1) {
        const url = that.url.concat(that.hospital_img);
        urls.push(url);
      } else {
        const url = that.url.concat(that.medical_img);
        urls.push(url);
      }

      uni.previewImage({
        current,
        urls
      });
    },

    // 屏蔽
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/help_publicity/help_publicity.wxss */
.publicity_wrap {
  padding: 10rpx;
  border: 1rpx solid #eee;
  box-shadow: 2px 2px 2px 2px #eee;
  border-radius: 8px;
}

.publicity_head {
  text-align: center;
  padding: 20rpx 0;
}

.head_title {
  font-size: 18px;
  font-weight: bold;
}

.wrap {
  padding: 10rpx;
  display: flex;
}

.wrap_num {
  font-size: 16px;
  display: flex;
}

.title {
  width: 100px;
}

.img {
  width: 90px;
  height: 90px;
  border: 1rpx solid #eee;
  border-radius: 8px;
}

.img image {
  width: 90px;
  height: 90px;
  border-radius: 8px;
}

.img_text {
  display: flex;
  justify-content: center;
  align-items: center;
}

.wrap_wintess {
  padding: 10rpx;
}

.witness_name {
  color: #fff;
  display: flex;
  flex-wrap: wrap;
  padding: 10rpx 0;
  text-align: center;
}

.name_box {
  border: 1rpx solid #eee;
  background-color: #6495ED;
  border-radius: 8px;
  width: 73px;
  padding: 13rpx;
  margin: 1rpx;
}

.footer_wrap {
  margin-top: 10rpx;
}

.continer {
  padding: 20rpx 0;
  text-align: center;
}

.continer_text {
  padding: 10rpx 0;
}

.continer_btn {
  display: flex;
  justify-content: center;
  color: #fff;
  margin-top: 30px;
}

.btn {
  border: 1rpx solid #eee;
  width: 50%;
  padding: 20rpx;
  border-radius: 8px;
  background-color: cornflowerblue;
  box-shadow: 2px 2px 2px cornflowerblue;
}
</style>