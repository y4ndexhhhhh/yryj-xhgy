<template>
	<!--pages/my/my.wxml-->
	<view class="conter">
		<view class="newmyHeader" style="background-color: #0B3FFF;">
			<view class="newtopinfo">
				<view class="avatarBox">
					<!-- @click="chooseImageUpload" -->
					<image :src='stroge.imgurl' class="imgs" v-if='stroge.imgurl'></image>
					<image src='/static/images/my/avatar.png' class="imgs" v-else></image>
				</view>
				<view class="newsuserBox">
					<view class="newsname">
						<text>{{stroge.real_name}}</text>
						<text class="newtags" v-if="rank==0">非会员</text>
						<text class="newtags" v-if="rank==1">会员</text>
						<text class="newtags" v-if="rank==2">普通合伙人</text>
						<text class="newtags" v-if='rank==3'>天使合伙人</text>
						<text class="newtags" v-if="rank==-1" @click="goLogin">未登录</text>
					</view>
					<view class="newstar" @click="goCommone('../AanewPages/activeLevel')">
						<view class="newgrade">
							<view class="newlvone">
								<text>LV {{stroge.activeLevel}}</text>
							</view>
							<view class="newdengji">
								{{stroge.active}}/
								<text v-if="stroge.activeLevel == '0'">{{activelist[0].title}}</text>
								<text v-if="stroge.activeLevel == '1'">{{activelist[1].title}}</text>
								<text v-if="stroge.activeLevel == '2'">{{activelist[2].title}}</text>
								<text v-if="stroge.activeLevel == '3'">{{activelist[3].title}}</text>
								<text v-if="stroge.activeLevel == '4'">{{activelist[4].title}}</text>
								<text v-if="stroge.activeLevel == '5'">{{activelist[5].title}}</text>
								<text v-if="stroge.activeLevel == '6'">{{activelist[6].title}}</text>
								<text v-if="stroge.activeLevel == '7'">{{activelist[7].title}}</text>
							</view>
						</view>
						<view class="newsline">
							<view class="lines">

							</view>
						</view>
					</view>
				</view>
			</view>
		
		</view>
		
		<view class="commonBox">
			<view class="commonitems">
				<view class="item" @click="goCommone('/pages/bank/bank')">
					<image src="/static/images/my/nav1.png" mode="" class="item_icon"></image>
					<text>银行卡</text>
				</view>
				<!--				<view class="item" @click="goCommone('/pages/AanewPages/bindContacts')">-->
				<view class="item" @click="recommand()">
					<image src="/static/images/my/nav2.png" mode="" class="item_icon"></image>
					<text>推荐人</text>
				</view>
				<view class="item" @click="goCommone('/pages/edit/edit')">
					<image src="/static/images/my/nav3.png" mode="" class="item_icon"></image>
					<text>实名认证</text>
				</view>
				<view class="item" @click="goCommone('/pages/ordie/ordie')">
					<image src="/static/images/my/nav4.png" mode="" class="item_icon"></image>
					<text>推荐关系</text>
				</view>
			</view>
		</view>

		<!-- 常用工具 -->
		<view class="commonBox">
			<view class="commonTitle">
				<view class="title_left">
					<text>常用工具</text>
				</view>
			</view>
			<view class="changitems">
				<view class="item" @click="oview">
					<image src="/static/images/my/nav5.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>我的兑换码</text>
				</view>
				<!-- 
				<view class="item"  @click="goCommone('/pages/AanewPages/invitationCode')"> -->
				<view class="item" @click="goCommone('/pages/code/code')">
					<image src="/static/images/my/nav6.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>邀请码</text>
				</view>
				<view class="item" @click="money">
					<image src="/static/images/my/nav7.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>账单管理</text>
				</view>
				<view class="item" @click="goCommone('/pages/bill/bill')">
					<image src="/static/images/my/nav8.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>账单明细</text>
				</view>
			</view>
			<view class="changitems">
				<view class="item" @click="treaty">
					<image src="/static/images/my/nav9.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>我的协议</text>
				</view>
				<view class="item" @click="goCommone('/pages/agreements/agreements')">
					<image src="/static/images/my/nav10.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>用户须知</text>
				</view>
				<view class="item" @click="goCommone('/pages/customer/customer')">
					<image src="/static/images/my/nav11.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>常见疑问</text>
				</view>
				<view class="item" @click="goCommone('/pages/AanewPages/strategy')">
					<image src="/static/images/my/nav12.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>玩法攻略</text>
				</view>
			</view>
			<view class="changitems">
				<view class="item" @click="goCommone('/pages/AanewPages/myOrder')">
					<image src="/static/images/my/nav14.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>免费领取</text>
				</view>
				<view class="item" @click="goCommone('/pages/AanewPages/changePassword')">
					<image src="/static/images/my/nav15.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>修改密码</text>
				</view>
				<view class="item" @click="goCommone('/pages/AanewPages/aboutUs')">
					<image src="/static/images/my/nav13.png" mode="aspectFit" class="item_icon item_icons"></image>
					<text>关于我们</text>
				</view>
				<view class="item"></view>
			</view>
		</view>

		<view class="zhezhao" v-if="QR_box"></view>
		<view class="wrap" v-if="QR_box">
			<image src="../../static/images/banner/clear.png" mode="" class="QR_box" @click="close_QR_border"></image>
			<view class="div">
				<image mode="widthFix" :src="img"></image>
			</view>
		</view>

		<view class="buttom" v-if="rank == -1">
			<view class="boxbtn" @click="login" style="background-color:#FFAC38;">
				<text>去登录</text>
			</view>
		</view>
		
		<view class="buttom" v-if="rank != -1">
			<view class="boxbtn" @click="delogin" style="background-color:#FFAC38;">
				<text>退出登录</text>
			</view>
		</view>
		
		<view style="text-align: center;">
			<text style="color: #4E73E8;" @tap.stop="beuser">《用户协议》</text>
			<text style="color: #4E73E8;" @tap.stop="privacy">《隐私政策》</text>
		</view>

	</view>
</template>

<script>
	// pages/my/my.js
	const app = getApp();
	var sha_1 = require("../../utils/sha_1.js");
	// var rewardModule = uni.requireNativePlugin("ZjSDKRewardModule");
	// var splashModule = uni.requireNativePlugin("ZjSDKSplashModule")
	// var ZjSplashView = uni.requireNativePlugin("ZjSplashView")
	const modal = uni.requireNativePlugin('modal');
	import {
		InsertScreen,
		showInsertScreen,
		excitation
	} from "@/components/advertisement.js"
	export default {
		data() {
			return {
				uid: 0,
				stroge: true,
				msg: false,
				status: '',
				hiddenName: true,
				rank: -1,
				token: '',
				message_num: 0,
				show: true,
				url: '',
				QR_box: false,
				img: '',
				join_status: "",
				real_status: "",
				popularity_num: "",
				goldCoin: 0,
				codeType2: false,
				activelist: [{
					key: 0,
					title: '100',
					num: 'Lv0'
				}, {
					key: 1,
					title: '800',
					num: 'Lv1'
				}, {
					key: 2,
					title: '1500',
					num: 'Lv2'
				}, {
					key: 3,
					title: '2200',
					num: 'Lv3'
				}, {
					key: 4,
					title: '2900',
					num: 'Lv4'
				}, {
					key: 5,
					title: '3600',
					num: 'Lv5'
				}, {
					key: 6,
					title: '4300',
					num: 'Lv6'
				}, {
					key: 7,
					title: '5000+',
					num: 'Lv7'
				}],
				rewardedVideoAd: null, // 定义激励视屏广告
				isLoaded: false, // 广告按钮状态
				interstitialAd: null, // 定义插屏广告
				isLoading: false, // 广告按钮状态
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {

			this.getstroge();
			this.reqstatu();
			this.removeredhot();

		},

		onShow() {
			this.getstroge();
			this.getUserinfo();
			this.reqstatu();
			this.getGoldCoin();
			this.getNewsUser();
			this.removeredhot(); // if (this.data.stroge.rank == 2 || this.data.stroge.rank == 3) {
			//   this.setData({
			//     msg: false
			//   })
			// } else {
			//   this.setData({
			//     msg: true
			//   })
			// }
		},
		onReady() {
			// 获取激励视频广告数据
			excitation(this, "1105658736");
		},
		onUnload() {
			// 页面关闭销毁激励视频广告
			this.rewardedVideoAd.destroy();
			// 页面关闭销毁插屏广告
			this.interstitialAd.destroy();
		},
		mounted() {
			// 获取插屏广告
			InsertScreen(this, "1116373634");
		},
		methods: {
			//  新用户判定
			getNewsUser() {
				let that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'users/isNewUserOrder',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					if (res.data.code == 0) {
						that.codeType2 = res.data.data.data;
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			loadAd() {
				// 打开激励视频广告
				this.rewardedVideoAd.show().then(() => {
					uni.hideLoading();
				}).catch((err) => {
					uni.hideLoading();
					console.log(err, "err");
				});
				// 调用异步方法
				// console.log('onZjAdReward create', 'create')
				// uni.showLoading({
				// 	title: '加载中'
				// });
				// let that = this;
				// rewardModule.create("zjad_241286", "zj_11120200724056", "激励名称", 10, "扩展参数", true);
				// rewardModule.onZjAdLoaded((info) => {
				// 	console.log('onZjAdLoaded event', info)
				// 	rewardModule.showAd()
				// })
				// rewardModule.onZjAdVideoCached((info) => {
				// 	console.log('onZjAdVideoCached event', info)
				// 	uni.hideLoading();
				// 	// rewardModule.showAd()
				// })
				// rewardModule.onZjAdShow((info) => {
				// 	console.log('onZjAdShow event', info)
				// })
				// rewardModule.onZjAdClick((info) => {
				// 	console.log('onZjAdClick event', info)
				// })
				// rewardModule.onZjAdReward((info) => {
				// 	console.log('onZjAdReward event', info)
				// 	this.codeType = false;
				// 	// that.getMyGolod()
				// })
				// rewardModule.onZjAdClose((info) => {
				// 	console.log('onZjAdClose event', info)
				// 	this.codeType = false;
				// 	that.getMyGolod()
				// })
				// rewardModule.onZjAdError((info) => {
				// 	console.log('onZjAdError event', info)
				// 	this.codeType = false;

				// })

			},
			// 获取插屏广告
			openID() {
				// 打开广告
				showInsertScreen(this);
			},
			// 获取个人信息
			getUserinfo() {
				let that = this;
				app.$request({
					url: 'users/userinfo',
					data: {
						uid: that.stroge.uid
					},
					method: 'post'
				}).then(res => {
					if (res.data.code == 'ok') {
						that.stroge = res.data.data;
						uni.setStorage({
							key: 'key',
							data: res.data.data,
							success: function(res) {
								console.log(res)
							},
							fail(err) {
								console.log(err)
							}
						});
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			goNewPerson() {
				uni.navigateTo({
					url: '../AanewPages/NewPersonList'
				})
			},
			// 获取得到的金币
			getMyGolod() {
				let that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				data["type"] = '4';
				data["score"] = 50;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'user_ad/openEncourageAd',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					if (res.data.code == 0) {
						uni.showToast({
							title: '获得50金币',
							icon: 'none'
						})
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			//  获取我的金币
			getGoldCoin() {
				let that = this;
				var data = {};
				data["uid"] = that.stroge.uid;
				var arr = {
					"data": data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				app.$request({
					url: 'users/myScore',
					data: {
						data: aesData
					},
					method: 'post'
				}).then(res => {
					if (res.data.code == 0) {
						that.goldCoin = res.data.data
					}
				}).catch(err => {
					console.error('登录异常', err);
				})
			},
			goLogin() {
				uni.navigateTo({
					url: '/pages/login/login'
				})
			},
			goReade() {
				uni.switchTab({
					url: '/pages/AanewPages/newsList'
				})
			},
			goCommone(url) {
				var that = this;
				if (that.stroge == '') {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			recommand() {

				var that = this;
				if (that.stroge == '') {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				} else {
					if (this.rank < 1) {
						uni.showToast({
							title: '请先加入会员才能进行绑定邀请人！',
							icon: 'none',
							duration: 1000
						}); // return false;
						return false;
					}
					uni.navigateTo({
						url: '/pages/AanewPages/bindContacts'
					})
				}
			},
			//获取本地数据
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				if (stroge == '') {
					that.setData({
						stroge: false
					});
				} else {
					that.setData({
						stroge: stroge,
						uid: stroge.uid,
						join_status: stroge.join_status,
						real_status: stroge.real_status,
						popularity_num: stroge.popularity_num,
						rank: stroge.rank
					});
				}
			},

			/*---我的资料---*/
			datas() {
				var that = this;

				if (this.stroge == '') {
					uni.showModal({
						title: '启奏陛下',
						content: '请先进行登录',
						success: res => {
							uni.navigateTo({
								url: '/pages/login/login'
							});
						}
					});
				} else {
					uni.navigateTo({
						url: '/pages/edit/edit'
					});
				}
			},

			/*---我的钱包---*/
			money() {
				if (this.stroge == '') {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				} else {
					uni.navigateTo({
						url: '/pages/money/money?uid=' + this.stroge.uid
					});
				}
			},

			/*---合伙人图谱---*/
			map() {
				if (this.stroge == '') {
					uni.showModal({
						title: '启奏陛下',
						content: '请先进行登录',
						success: res => {
							uni.navigateTo({
								url: '/pages/login/login'
							});
						}
					});
				} else {
					uni.navigateTo({
						url: '/pages/ordie/ordie'
					});
				}
			},

			/*---我的兑换码---*/
			oview() {
				if (this.stroge == '') {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				} else {
					uni.navigateTo({
						url: '/pages/vido/vido'
					});
				}
			},
			baste() {
				var that = this;
				uni.request({
					url: app.globalData.url + '/xcx_qrcode/getXcxQrcode',
					method: "POST",
					data: {
						uid: this.uid
					},
					success(res) {
						that.setData({
							QR_box: true,
							img: res.data.data
						});
					}

				});
			},

			/*---推出登录---*/
			delogin() {
				this.rank = -1;
				// uni.clearStorage();
				uni.clearStorage({
					success: res => {
						uni.reLaunch({
							url: '/pages/login/login'
						});
					}
				});
			},

			/*---登录---*/
			login() {
				uni.navigateTo({
					url: '/pages/login/login'
				});
			},

			// 注册页面
			register() {
				uni.navigateTo({
					url: '/pages/log/log'
				});
			},
			/*---用户协议---*/
			beuser() {
				uni.navigateTo({
					url: '/pages/AanewPages/userClause'
				});
			},
			/*---隐私条例---*/
			privacy() {
				uni.navigateTo({
					url: '/pages/AanewPages/privacyClause'
				});
			},

			/*重新存储uid*/
			requid() {
				uni.request({
					url: app.globalData.url + 'users/userinfo',
					method: "POST",
					data: {
						uid: this.stroge.uid
					},

					success(res) {
						uni.setStorageSync('key', res.data.data);
					}

				});
			},

			reqstatu() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'shield/getShield',
					method: "POSt",
					data: {
						version_code: app.globalData.version_code
					},

					success(res) {
						that.setData({
							status: res.data.data.status
						});
					}

				});
			},

			// 上传图片
			chooseImageUpload() {
				var that = this;

				if (that.stroge.uid == '') {
					uni.showModal({
						title: '启奏陛下',
						content: '请先进行登录',
						success: res => {
							uni.navigateTo({
								url: '/pages/login/login'
							});
						}
					});
				} else {
					uni.chooseImage({
						count: 1,
						success: res => {
							var src = res.tempFilePaths;

							if (src) {
								var that = this;
								uni.request({
									url: app.globalData.url + 'users/getqntoken',
									method: "POST",

									success(res) {
										that.setData({
											token: res.data.data
										});
										that.uploadQiniu(src);
									}

								});
							}
						}
					});
				}
			},

			/**
			 * 图片上传七牛云
			 */
			uploadQiniu(tempFilePaths) {
				var that = this;
				let token = that.token;

				if (token != '') {
					uni.uploadFile({
						url: 'https://upload-z2.qiniup.com',
						name: 'file',
						filePath: tempFilePaths[0],
						header: {
							"Content-Type": "multipart/form-data"
						},
						formData: {
							token: token
						},
						success: function(res) {
							if (res.statusCode == 200) {
								let respones_data = JSON.parse(res.data);
								var qiniu_key = respones_data.key;
								uni.request({
									url: app.globalData.url + 'users/seve_img',
									method: "POST",
									data: {
										uid: that.stroge.uid,
										user_img: qiniu_key
									},

									success(res) {
										if (res.data.code == 'ok') {
											const stoges = res.data.data;
											uni.setStorageSync('key', stoges);
											uni.showModal({
												title: '启奏陛下',
												content: '头像上传成功'
											}); //刷新当前页面

											// that.onShow();
										} else {
											uni.showModal({
												title: '启奏陛下',
												content: '头像上传失败，请稍后重试'
											});
										}
									}

								});
							}
						},
						fail: function(res) {
							uni.showModal({
								title: '启奏陛下',
								content: '头像上传失败，请稍后重试'
							});
						}
					});
				} else {
					uni.showModal({
						title: '启奏陛下',
						content: '头像上传失败，请稍后重试'
					});
				}
			},

			/*---我的协议---*/
			treaty() {
				if (this.stroge == '') {
					uni.showModal({
						title: '启奏陛下',
						content: '请先进行登录',
						success: res => {
							uni.navigateTo({
								url: '/pages/login/login'
							});
						}
					});
				} else {
					uni.navigateTo({
						url: '/pages/AanewPages/myAgreement?uid=' + this.stroge.uid
					})

				}
			},

			// 进入我的页面移除右上角红点
			removeredhot() {
				var that = this;
				var uid = that.uid;

				if (uid == 0) {
					return;
				}

				uni.request({
					url: app.globalData.url + 'message_info/isReadMessage',
					method: 'POST',
					data: {
						uid: uid
					},

					success(res) {
						let message_num = res.data.data;

						if (message_num > 0) {
							that.setData({
								message_num: message_num,
								show: true
							});
							let num = message_num + '';
							uni.setTabBarBadge({
								index: 2,
								text: num
							});
						} else {
							show: false;
						}
					}

				});
			},

			// 进入系统消息点击事件
			gomessage() {
				uni.navigateTo({
					url: '/pages/msg/msg?uid=' + this.stroge.uid
				});
			},

			// 关闭二维码弹框
			close_QR_border() {
				this.setData({
					QR_box: false
				});
			}

		}
	};
</script>
<style lang="scss" scoped>
	@import url("./my.css");

	.conter {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
	}

	/* pages/my/my.wxss */
	.newmyHeader {
		width: 100%;
		min-height: 230rpx;
		background-color: #F8F9FF;
		position: relative;

		.newtopinfo {
			width: 100%;
			height: 175rpx;
			padding-left: 30rpx;
			box-sizing: border-box;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			position: relative;

			.avatarBox {
				width: 120rpx;
				height: 120rpx;
				background: #DBDBDB;
				border-radius: 50%;
				opacity: 1;

				.imgs {
					width: 120rpx;
					height: 120rpx;
					border-radius: 50%;
				}
			}

			.newsuserBox {
				width: 350rpx;
				height: 50rpx;
				padding-left: 20rpx;
				box-sizing: border-box;

				.newsname {
					font-size: 36rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 24rpx;
					color: #FFFFFF;
					opacity: 1;

					.newtags {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 500;
						line-height: 24rpx;
						color: #D1D1D1;
						opacity: 1;
						margin-left: 10rpx;
					}
				}

				.newstar {
					width: 100%;
					height: 60rpx;
					margin-top: 5rpx;

					.newgrade {
						width: 100%;
						height: 50rpx;
						display: flex;
						justify-content: flex-start;
						align-items: center;

						.newlvone {
							width: 82rpx;
							height: 36rpx;
							background: #FBE551;
							opacity: 1;
							border-radius: 4rpx;
							display: flex;
							justify-content: center;
							align-items: center;

							text {
								font-size: 36rpx;
								font-family: PingFang SC;
								font-weight: 800;
								line-height: 24rpx;
								color: #A76301;
								opacity: 1;
							}
						}

						.newdengji {
							width: 84rpx;
							height: 42rpx;
							font-size: 30rpx;
							font-family: PingFang SC;
							font-weight: 500;
							line-height: 42rpx;
							color: #6676E1;
							opacity: 1;
							margin-left: 6rpx;
						}
					}

					.newsline {
						width: 174rpx;
						height: 4rpx;
						background: #D1D1D1;
						opacity: 1;
						border-radius: 8rpx;

						.lines {
							width: 50rpx;
							height: 4rpx;
							background: #FF2E2E;
							opacity: 1;
							border-radius: 8rpx;
						}
					}
				}
			}

			.newgoMoney {
				width: 230rpx;
				height: 72rpx;
				position: absolute;
				right: 0;
				top: 60rpx;
				background: #FFF8F5;
				opacity: 1;
				padding-left: 20rpx;
				box-sizing: border-box;
				border-radius: 40rpx 0rpx 0rpx 40rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.newsmoney {
					width: 44rpx;
					height: 44rpx;
					// background-color: #f40;

				}

				text {
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 32rpx;
					color: #FFFFFF;
					opacity: 1;
					color: #A76301;
					margin: 0 15rpx;
				}

				.newarrow {
					width: 13rpx;
					height: 24rpx;
					background-color: #f40;
				}
			}
		}

		.newsbttoninfo {
			width: 100%;
			height: 120rpx;
			display: flex;
			justify-content: center;

			.newsimgs {
				width: 500rpx;
				height: 120rpx;
				position: relative;

				.imgs {
					width: 500rpx;
					height: 120rpx;
					// background-color: #f40;
				}

				.newsmoneytext {
					width: 500rpx;
					height: 120rpx;
					position: absolute;
					left: 0;
					top: 0;
					display: flex;
					justify-content: center;
					align-items: center;

					.line {
						width: 4rpx;
						height: 68rpx;
						background: #FFFFFF;
						opacity: 1;
						border-radius: 8rpx;
					}

					.garaders {
						flex: 1;
						height: 100%;
						display: flex;
						justify-content: center;
						flex-flow: column;
						align-items: center;

						.newsicons {
							width: 18rpx;
							height: 24rpx;
							background-color: #FEFB01;
						}

						text {
							font-size: 32rpx;
							font-family: PingFang SC;
							font-weight: 500;
							line-height: 28rpx;
							color: #FFFFFF;
							opacity: 1;
							margin: 5rpx 15rpx;
							margin-bottom: 10rpx;
						}
					}

				}
			}
		}

		.clearIocn {
			width: 110rpx;
			height: 110rpx;
			position: absolute;
			right: 22rpx;
			bottom: 0rpx;
			display: flex;
			justify-content: center;
			align-items: center;

			.clearBox {
				width: 100rpx;
				height: 110rpx;
				position: relative;

				.clearstips {
					width: 100rpx;
					height: 110rpx;
				}

				.newtext {
					width: 100%;
					height: 20rpx;
					position: absolute;
					left: 5rpx;
					bottom: 20rpx;
					text-align: center;
					font-size: 16rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 16rpx;
					color: #FFFFFF;
					opacity: 1;
				}
			}
		}
	}

	.itemscontent {
		width: 100%;
		height: auto;
		margin-top: 20rpx;
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-around;
		align-items: center;
		flex-wrap: wrap;
		padding: 20rpx 30rpx;
		box-sizing: border-box;

		.newsitems {
			width: 334rpx;
			height: 140rpx;
			position: relative;
			margin-top: 15rpx;

			.imgs {
				width: 334rpx;
				height: 140rpx;
				// background-color: #f40;
			}

			.sgan {
				position: absolute;
				width: 260rpx;
				height: 140rpx;
				position: absolute;
				display: flex;
				justify-content: center;
				align-items: center;
				flex-flow: column;
				left: 0;
				top: 0;

				.name {
					font-size: 40rpx;
					font-family: PingFang SC;
					font-weight: bold;
					// line-height: 24px;
					color: #FFFFFF;
					opacity: 1;
				}

				.sgintext {
					width: 94rpx;
					height: 30rpx;
					background: #F98500;
					margin-top: 15rpx;
					opacity: 1;
					border-radius: 16rpx;
					display: flex;
					justify-content: center;
					align-items: center;

					text {
						font-size: 20rpx;
						font-family: PingFang SC;
						font-weight: 400;
						// line-height: 24rpx;
						color: #FFFFFF;
						opacity: 1;
					}
				}
			}
		}
	}

	.buttom {
		width: 100%;
		height: 160rpx;
		display: flex;
		justify-content: center;
		align-items: center;

		.boxbtn {
			width: 686rpx;
			height: 80rpx;
			// background: linear-gradient(130deg,#FF8045 0%,#FF5252 100%);
			border-radius: 60rpx;
			display: flex;
			justify-content: center;
			align-items: center;

			text {
				font-size: 38rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				line-height: 32rpx;
				color: #FFFFFF;
				// letter-spacing: 120px;
				opacity: 1;
			}
		}
	}

	.adItemsBox {
		width: 100%;
		height: 112rpx;
		margin-top: 20rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		padding: 0 30rpx;
		box-sizing: border-box;
		position: relative;

		.adImgs {
			width: 100%;
			height: 112rpx;
		}

		.aditemtext {
			width: 600rpx;
			height: 100%;
			display: flex;
			justify-content: center;
			align-items: flex-start;
			flex-flow: column;
			padding-left: 50rpx;
			box-sizing: border-box;
			position: absolute;
			left: 0;
			bottom: 0;

			.names {
				font-size: 40rpx;
				font-family: Source Han Sans CN;
				font-weight: 500;
				color: #F76003;
				opacity: 1;
			}

			.adtexts {
				width: 116rpx;
				height: 32rpx;
				background: #F76003;
				opacity: 1;
				border-radius: 16rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				margin-left: 40rpx;

				text {
					font-size: 20rpx;
					font-family: PingFang SC;
					font-weight: 400;
					// line-height: 24px;
					color: #FFFFFF;
					opacity: 1;
				}
			}
		}
	}

	.itemsBox {
		width: 100%;
		height: 120rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #FFFFFF;
		padding: 0 30rpx;
		box-sizing: border-box;
		border-bottom: 1rpx solid #F8F9FF;

		.itemsLeft {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.icons {
				width: 52rpx;
				height: 52rpx;
				// background-color: #f40;
			}

			text {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
				margin-left: 20rpx;
			}
		}

		.itemsRight {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-end;
			align-items: center;

			.arrowRignth {
				width: 13rpx;
				height: 24rpx;
				// background-color: #f40;
			}
		}
	}

	.commonBox {
		width: 100%;
		min-height: 212rpx;
		background-color: #FFFFFF;
		border-radius: 12rpx;
		margin: 30rpx auto;

		.commonTitle {
			width: 100%;
			height: 80rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #ECECEC;
			padding: 0 30rpx;
			box-sizing: border-box;

			.title_left {
				flex: 1;
				height: 100%;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				font-size: 28rpx;
				font-family: Source Han Sans CN;
				font-weight: 600;
				line-height: 54rpx;
				color: #333333;
				opacity: 1;
			}

			.title_right {
				flex: 3;
				height: 100%;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				font-size: 24rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				line-height: 54rpx;
				color: #9D9D9D;
				opacity: 1;

				.shopImgs {
					width: 56rpx;
					height: 48rpx;
					// background-color: #f40;
				}

				.arrow_right {
					width: 165rpx;
					height: 36rpx;
					// background-color: #f40;
					margin-left: 10rpx;
					position: relative;

					.bgbox {
						width: 165rpx;
						height: 36rpx;
					}

					.text {
						position: absolute;
						left: 22rpx;
						top: 10rpx;
						font-size: 20rpx;
						font-family: PingFang SC;
						font-weight: 500;
						line-height: 16rpx;
						color: #FFFFFF;
						opacity: 1;
					}
				}
			}
		}

		.commonitems {
			width: 100%;
			min-height: 212rpx;
			display: flex;
			justify-content: space-around;
			align-items: center;

			.item {
				width: 120rpx;
				height: 100%;
				display: flex;
				justify-content: center;
				align-items: center;
				flex-flow: column;

				.item_icon {
					width: 112rpx;
					height: 112rpx;
				}

				.item_icons {
					width: 79rpx;
					height: 65rpx;
				}

				text {
					margin-top: 14rpx;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 25rpx;
					color: #333333;
					opacity: 1;
				}
			}
		}

		.changitems {
			width: 100%;
			height: 180rpx;
			display: flex;
			justify-content: space-around;
			align-items: center;

			.item {
				width: 120rpx;
				height: 100%;
				display: flex;
				justify-content: center;
				align-items: center;
				flex-flow: column;

				.item_icon {
					width: 112rpx;
					height: 112rpx;
				}

				.item_icons {
					width: 79rpx;
					height: 65rpx;
				}

				text {
					margin-top: 14rpx;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 500;
					line-height: 25rpx;
					color: #333333;
					opacity: 1;
				}
			}
		}
	}
</style>
