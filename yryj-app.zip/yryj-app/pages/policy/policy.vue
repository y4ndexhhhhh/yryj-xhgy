<template>
<!--pages/policy/policy.wxml-->
<view class="containe">
  <navigator v-for="(item, index) in policylist" :key="index" open-type="navigate" :url="'/pages/detail/detail?article_id=' + item.article_id">
    <view class="policy_containe">
      <view class="policy_image">
        <image :src="item.cover_img"></image>
      </view>
      <view class="content">
        <view class="policy_title_containe">
          {{item.title}}</view>
        <view class="box">
          <view class="policy_read">
            <view>阅读量：</view>
            <text class="nums">{{item.read_num}}</text>
          </view>
          <view class="polic_make_time">
            <text>发布时间：</text>
            <view class="time">{{item.create_time}}</view>
          </view>
        </view>
      </view>
    </view>
  </navigator>
</view>
</template>

<script>
// pages/policy/policy.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      policylist: [],
      page: 0,
      list: ''
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getArticleList();
  },

  // 监听用户上拉触底事件。
  onReachBottom() {
    var page = this.page + 1; //获取当前页数并+1

    this.setData({
      page: page //更新当前页数

    });
    this.getArticleList();
  },

  // 监听用户下拉刷新时间
  onPullDownRefresh() {
    // 重置数组
    this.setData({
      policylist: []
    }); // 重置页码

    var page = 0;
    this.setData({
      page: page //更新当前页数

    }); // 重新发送请求

    this.getArticleList();
  },

  methods: {
    // 获取政策数据
    getArticleList() {
      var that = this;
      var data = {};
      data["type"] = 11;
      data["page"] = that.page;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'article/getArticleList',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {
            let list = res.data.data;

            if (that.page == 0) {
              that.setData({
                policylist: list
              });
            } else {
              //获取下拉刷新之前的list数据
              let old_data = that.policylist; //arr  代表page+1  新数据

              that.setData({
                policylist: old_data.concat(list)
              });
            }
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none'
            });
            uni.stopPullDownRefresh();
          }
        }

      });
    },

    // 跳转到详情页
    godetail() {
      uni.navigateTo({
        url: '/pages/detail/detail?article_id' + this.article_id
      });
    }

  }
};
</script>
<style>
page {
  height: 100%;
}

.containe {
  height: 100%;
}

.policy_containe {
  display: flex;
  padding: 20rpx;
  border-bottom: 1px solid #eee;

}

.policy_image {
  flex: 2;
  width: 90px;
  height: 90px;
  padding: 10rpx;
}

.policy_image image {
  width: 100%;
  height: 100%;

  border-radius: 2px;

}

.policy_title_containe {
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;

}

.content {
  flex: 5;
}

.policy_read {
  display: flex;

  font-size: 22rpx;

}

.nums {
  display: flex;
  flex-direction: column;
  margin-left: 50rpx;
}

.polic_make_time {
  display: flex;
  margin-top: 15rpx;
  font-size: 22rpx;
}

.box {
  position: absolute;
  margin-top: 30rpx;
}

.time {
  display: flex;
  flex-direction: column;
  margin-left: 30rpx;
}
</style>