<template>
<!--pages/viptreaty/viptreaty.wxml-->
<view class="content">
  <!-- <web-view :src="type == 0 ? '/static/images/404a81efe6be6dbb819e89707104367.png' : '/static/images/hezuorenxieyi.png'">
    <cover-view class="tool-bar">
      <cover-view class="boeder">
        <cover-view class="btns" @tap="goBtn">邮寄合同</cover-view>
      </cover-view>
    </cover-view>
  </web-view> -->
  <image :src="type == 0 ? '/static/images/404a81efe6be6dbb819e89707104367.png' : '/static/images/hezuorenxieyi.png'" mode="widthFix"></image>

  <!-- <cover-view class='btns' bindtap="goBtn">邮寄合同</cover-view> -->

</view>
</template>

<script>
// pages/treaty/treaty.js
var sha_1 = require("../../utils/sha_1.js");
const app = getApp();

export default {
  data() {
    return {
      stroge: true,
      status: '',
      uid: '',
      src: '',
      treaty_list: [],
      id: 1,
      url: '',
      rank: 0,
	  type: null,
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
	  console.log(e.type,"PPPPPP")
    this.setData({
      url: e.url,
      uid: e.uid,
	  type: e.type
    });
    this.getstroge(); //this.treaty()
	uni.setNavigationBarTitle({ title: this.type == 0 ? "会员公约" :"合伙人公约" });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {},

  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');

      if (stroge == '') {
        that.setData({
          stroge: false
        });
      } else {
        that.setData({
          //stroge: stroge,
          uid: stroge.uid,
          rank: stroge.rank
        });
      }
    },

    // 数据请求
    treaty() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'express/user_xieyi',
        method: "POSt",
        data: {
          data: aesData
        },

        success(res) {
          uni.showLoading({
            title: '加载中',
            icon: 'loading',
            duration: 500
          });

          if (res.data.code == 'ok') {
            that.setData({
              treaty_list: res.data.data
            });
          } else {
            return false;
          }
        }

      });
    },

    goBtn() {
      var that = this;
      uni.navigateTo({
        url: '/pages/mail/mail?uid=' + that.uid + '&rank'+that.rank
      });
    }

  }
};
</script>
<style>
/* pages/viptreaty/viptreaty.wxss */
.content{
	width: 750rpx;
	height: 100vh;
	padding: 0 30rpx;
	box-sizing: border-box;
}
.btns {
  width: 60%;
  line-height: 40px;
  background: #007bff;
  border-radius: 5px;
  text-align: center;
  color: #eee;
  margin-left: 20%;

}

.boeder {}

.tool-bar {
  position: absolute;
  padding: 3px 0;
  bottom: 0px;
  border: 0.5px solid #999;
  width: 100%;
  background: #eee;
  /* color: rgb(8, 0, 0);
  position: fixed;
  bottom: 13%;
  right: 0rpx;
  width: 136rpx;
  height: 236rpx;
  border-radius: 8rpx; */
  z-index: 999999;
  /*box-shadow: 0px 0px 15px 4px  rgba(0,0,0,0.15);*/
}
</style>