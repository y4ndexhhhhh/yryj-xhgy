<template>
<!--pages/detail/detail.wxml-->
<view class="content">
  <view class="content_title">{{title}}</view>
  <view class="box">
    <view class="content_url" @tap="gourl">原文链接:
      <image src="/static/images/banner/newsurl.png" @tap="gonewsurl"></image>
      <!-- <view  style="color:blue">{{link_url}}</view> -->
    </view>

    <!-- <navigator open-type="navigate" url="">原文链接:</navigator> -->
    <view class="content_from">来源:{{from_to}}</view>
  </view>
  <rich-text :nodes="content"></rich-text>
</view>
</template>

<script>
// pages/detail/detail.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      content: '',
      title: '',
      link_url: '',
      from_to: ''
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    if (e.article_id != undefined) {
      this.getpolicy(e.article_id);
    }
  },
  methods: {
    // 获取政策详情数据
    getpolicy(article_id) {
      var that = this;
      var data = {};
      data["article_id"] = article_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'article/getArticleDetails',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {
            that.setData({
              content: res.data.data.content,
              title: res.data.data.title,
              link_url: res.data.data.link_url,
              from_to: res.data.data.from_to
            });
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none'
            });
          }
        }

      });
    },

    // 原文链接跳转
    gourl() {
      uni.navigateTo({
        url: '/pages/bannerurl/bannerurl?url=' + this.link_url
      });
    }

  }
};
</script>
<style>
/* pages/detail/detail.wxss */
.content {
  padding: 32rpx;
}

.content_title {
  font-size: 30px;
  font-weight: bold;
  text-align: center;
  padding: 12rpx;
}

.content_url {
  flex: 2;

}

.content_url image {
  width: 40rpx;
  height: 30rpx;
}

.content_from {
  flex: 3;

}

.box {
  display: flex;
  padding: 20rpx;
  text-align: center;
}
</style>