<template>
<!--pages/log/log.wxml-->
<view class="content">
	<view class="logoBox">
		 <image src="/static/images/my/logo.png" mode="" class="logos"></image>
	</view>
	<view class="myContent">
		<view class="itemsText">
			<image src="/static/images/my/phone.png" mode="" class="icon"></image>
			<view class="line"></view>
			<input type="number" v-model="phone"  class="input" placeholder-class="deflut" placeholder="请输入手机号" />
			<view class="timer" >
				<text v-if="disabled">{{codename}}s后重新获取</text>
				<view class="timerBox" @tap="getVerificationCode"  v-else>
					<text>获取验证码</text>
				</view>
			</view>
		</view>
		<view class="itemsText">
			<image src="/static/images/my/yaochi.png" style="width: 35rpx;height: 41rpx;" mode="aspectFit" class="icon"></image>
			<view class="line"></view>
			<input type="number" v-model="pascode"  @blur="phoneOnBlur" class="input" placeholder-class="deflut" placeholder="请输入验证码" />
			<view class="timer" >
			</view>
		</view>
		<view class="itemsText">
			<image src="/static/images/my/password.png" style="width: 35rpx;height: 44rpx;" mode="" class="icon"></image>
			<view class="line"></view>
			<input type="password" v-model="password"  class="input"  placeholder-class="deflut" style="width: 400rpx;" placeholder="请输入密码" />
		</view>
		<view class="itemsText">
			<image src="/static/images/my/password.png" style="width: 35rpx;height: 44rpx;" mode="" class="icon"></image>
			<view class="line"></view>
			<input type="password" v-model="passwords"  class="input"  placeholder-class="deflut" style="width: 400rpx;" placeholder="请再次输入密码" />
		</view>
	</view>
	<view class="agreetext" style="text-align: left; ">
		<text style="color: #AAAAAA;"  @tap.stop="login">密码由6-16字母和数字组成</text>
	</view>
	<view class="btn" @click="formSubmit">
		<text>找回密码</text>
	</view>
	
	<view class="agreetext" style="margin-top: 20rpx;">
		<text><p></p><p>如手机号已停止使用</p><p>可选择人工通道</p><p @click="call400">400-086-0951</p></text>
	</view>
  <!-- <view class="login">
    <form @submit="formSubmit">
      <view class="logo">
        <input name="phone" type="number" placeholder="请输入手机号" maxlength="11" @input="getPhoneValue" :value="phone"></input>
        <button class="text" @tap="getVerificationCode" :disabled="disabled">{{codename}}</button>
      </view>
      <input name="pascode" type="number" @blur="phoneOnBlur" placeholder="请输入验证码" @input="getPascodeValue" :value="pascode"></input>
      <input type="password" name="password" @input="getPasswordValue" :value="password" placeholder="请输入密码"></input>
      <input type="password" name="passwords" @input="getPasswordValues" :value="passwords" placeholder="确认密码"></input>
      <view class="prompt"></view>
      <button form-type="submit" class="btn">修改密码</button>
    </form>
  </view> -->
</view>
</template>

<script>
// pages/log/log.js
const sha_1 = require("../../utils/sha_1.js");
const app = getApp();

export default {
  data() {
    return {
      phone: "",
      //手机号
      password: '',
      //密码
      passwords: '',
      pascode: '',
      //验证码
      codename: '',
      disabled: false,
      code_type: 1,
      lock: false
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},
  methods: {
    //获取input输入框的值
    getPhoneValue: function (e) {
      this.setData({
        phone: e.detail.value
      });
    },
    getPascodeValue: function (e) {
      this.setData({
        pascode: e.detail.value
      });
    },
    getPasswordValue: function (e) {
      this.setData({
        password: e.detail.value
      });
    },
    getPasswordValues: function (e) {
      this.setData({
        passwords: e.detail.value
      });
    },

    /*---获取手机验证码---var myreg = /^1[3456789]\d{9}$/;*/
   /*---获取手机验证码---*/
   getCode() {
     var a = this.phone;
   
     var _this = this;
   
     var myreg = /^1[3456789]\d{9}$/;
     if (this.phone == "") {
       uni.showToast({
         title: '手机号不能为空',
         icon: 'none',
         duration: 1000
       }); // return false;
     } else if (!myreg.test(this.phone)) {
       uni.showToast({
         title: '请输入正确的手机号',
         icon: 'none',
         duration: 1000
       }); // return false;
     } else {
   	  let that = this;
   	  that.$request({
   	  	url: 'login/sms_re_pass',
   	  	data: {
   	  		phone: this.phone,
   	  	    code_type: '1'
   	  	},
   	  	method: 'post'
   	  }).then(res => {
   	  	if(res.statusCode == 200){
   	  	   that.getTimer();
   		   uni.showToast({
   		   	title:res.data.msg,
   		   	icon:'none'
   		   })
   	  	}
   	    
   	  }).catch(err => {
   	  	console.error('登录异常', err);
   	  })
     }
   },
    getTimer() {
    	let that = this;
    	if (that.phone == '') {
    		uni.showToast({
    			title: '请输入手机号',
    			icon: 'none'
    		})
    		return;
    	}
    	let count = 60;
    	that.disabled = true;
    	that.codename = count
    	// that.getMsg();
    
    	let timer = setInterval(res => {
    		count--;
    		that.codename = count;
    		if (count == 0) {
    			clearInterval(timer);
    			that.disabled =false;
    		}
    	}, 1000)
    }, 
    getVerificationCode() {
      this.getCode();
    },

    /*验证码失去焦点*/
    phoneOnBlur() {
      if (this.pascode === '') {
        uni.showToast({
          title: '验证码为不能空'
        });
        return false;
      } else {
        uni.request({
          url: app.globalData.url + 'login/retrieve_pass',
          method: "POST",
          data: {
            phone: this.phone,
            code: this.pascode
          },

          success(res) {
            if (!res.data.code == 'ok') {
              uni.showToast({
                title: '验证码不正确！'
              });
              return false;
            }
          }

        });
      }
    },

    /*---注册事件---*/
    formSubmit(e) {
      var passwrod = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$/;

      if (this.password == '') {
        uni.showToast({
          title: '密码不能为空！'
        });
        return false;
      }

      if (this.passwords == '') {
        uni.showToast({
          title: '密码不能为空！'
        });
        return false;
      }
	  let that = this;
      var data = {};
      data["phone"] = that.phone;
      data["code"] = that.pascode;
      data["pass_word"] = that.password;
      data["pass_words"] = that.passwords;
      var arr = {
      	data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + '/login/set_password',
        method: "POST",
        data:{
		   data: aesData
		},
        success(res) {
          if (res.data.code == 0) {
			  uni.showToast({
			  	title:res.data.msg,
				icon:'none'
			  })
			  uni.navigateBack()
          } else {
            uni.showModal({
              title: '修改密码',
              content: res.data.msg
            });
          }
        }

      });
    },

    /*---跳转到登录---*/
    login() {
      uni.redirectTo({
        url: '/pages/login/login'
      });
    },
	
	call400(e){
		console.log('callphone')
		uni.makePhoneCall({
			phoneNumber: '4000860951'
		})
	}

  }
};
</script>
<style lang="scss" scoped>
.content{
		width: 100%;
		height: 100%;
		background-color: #FFFFFF;
		.logoBox{
			width: 100%;
			height: 140rpx;
			margin-top: 50rpx;
			margin-bottom: 110rpx;
			.logos{
				margin: 0 auto;
				display: block;
				width: 120rpx;
				height: 120rpx;
			}
		}
		.myContent{
			width: 100%;
			height: auto;
			.itemsText{
				// display: flex;
				margin: 0 auto;
				width: 687rpx;
				height: 120rpx;
				border-bottom: 1rpx solid #BEBEBE;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				padding: 0 25rpx;
				box-sizing: border-box;
				.icon{
					width: 33rpx;
					height: 50rpx;
					// background-color: #f40;
				}
				.line{
					width: 0px;
					height: 40rpx;
					border: 1rpx solid #BEBEBE;
					opacity: 1;
					margin: 0 30rpx;
				}
				.deflut{
					width: 330rpx;
					height: 50rpx;
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 50rpx;
					color: #B8B8B8;
					opacity: 1;
				}
				.input{
					width: 330rpx;
					height: 50rpx;
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 50rpx;
					color: #333;
					opacity: 1;
				}
				.timer{
					width: 206rpx;
					height: 72rpx;
					display: flex;
					justify-content: flex-end;
					align-items: center;
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					// line-height: 24px;
					color: #B8B8B8;
					opacity: 1;
					.timerBox{
						width: 206rpx;
						height: 72rpx;
						background: #4F74E8;
						opacity: 1;
						border-radius: 36rpx;
						display: flex;
						justify-content: center;
						align-items: center;
						text{
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 400;
							// line-height: 24px;
							color: #FFFFFF;
							opacity: 1;
						}
					}
					
				}
			}
		}
		.btn{
			width: 686rpx;
			height: 120rpx;
			background: #4F74E8;
			opacity: 1;
			border-radius: 60rpx;
			margin: 80rpx auto  0;
			text-align: center;
			text{
				font-size: 44rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 120rpx;
				color: #FFFFFF;
				opacity: 1;
			}
		}
		.agreetext{
			width:686rpx;
			height: 40rpx;
			// background-color: #f40;
			margin: 0 auto;
			// text-align: left;
			text-align: center;
			text{
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 40rpx;
				color: #333;
				opacity: 1;
			}
		}
	    .authorization{
			width:100%;
			height: auto;
			margin-top: 55rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			flex-flow: column;
			.imgs{
				width: 108rpx;
				height: 108rpx;
				// background-color: #FFFF00;
			}
			.authtext{
				margin-top: 20rpx;
				width: 144rpx;
				height: 34rpx;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
			}
		}
	}
</style>