<template>
	<view class="content">
		<!--pages/setups/setups.wxml-->
		<!-- <view> -->
		<view class="" v-if="type == 1">
			<view class="itemsBox">
				<view class="itemsLeft">
					<text>设置支付密码</text>
				</view>
				<view class="itemsRight">
					<input type="password" v-model="password" placeholder="请输入6位数字支付密码" class="input" placeholder-class="deful" />
				</view>
			</view>
			<view class="itemsBox">
				<view class="itemsLeft">
					<text>确认支付密码</text>
				</view>
				<view class="itemsRight">
					<input type="password" v-model="passwords" placeholder="请再次输入6位数字支付密码" class="input" placeholder-class="deful" />
				</view>
			</view>
		</view>
		<view class="" v-if="type == 2">
			<view class="itemsBox">
				<view class="itemsLeft">
					<text>原支付密码</text>
				</view>
				<view class="itemsRight">
					<input type="text" v-model="password" placeholder="请输入6位数字支付密码" class="input" placeholder-class="deful" />
				</view>
			</view>
			<view class="itemsBox">
				<view class="itemsLeft">
					<text>新支付密码</text>
				</view>
				<view class="itemsRight">
					<input type="text" v-model="newPasword" placeholder="请再次输入6位数字支付密码" class="input" placeholder-class="deful" />
				</view>
			</view>
			<view class="itemsBox">
				<view class="itemsLeft">
					<text>确认新支付密码</text>
				</view>
				<view class="itemsRight">
					<input type="text" v-model="newPasswords" placeholder="请再次输入6位数字支付密码" class="input" placeholder-class="deful" />
				</view>
			</view>
		</view>
		<view class="" v-if="type == 3">
			<view class="itemsBox">
				<view class="itemsLeft">
					<text>手机号</text>
				</view>
				<view class="itemsRight">
					<input type="text" v-model="phone" placeholder="请输入绑定的手机号" class="input" placeholder-class="deful" />
				</view>
			</view>
			<view class="itemsBox">
				<view class="itemsLeft">
					<text>验证码</text>
				</view>
				<view class="itemsRight">
					<input type="text" v-model="codeNum" placeholder="请输入验证码" class="input" placeholder-class="deful" />
				    
					<view class="yancode" style="background-color: none;color: #666;" v-if="disabled">
				    	<text>{{codename}}s重新获取</text>
				    </view>
					<view class="yancode" v-else @click="getCode">
						<text>获取验证码</text>
					</view>
				</view>
			</view>
			<view class="itemsBox">
				<view class="itemsLeft">
					<text>重置支付密码</text>
				</view>
				<view class="itemsRight">
					<input type="text" v-model="findPassword" placeholder="请再次输入6位数字支付密码" class="input" placeholder-class="deful" />
				</view>
			</view>
		</view>
		<!-- <view class="passwordf">
    <text>设置支付密码：</text>
    <input type="password" name="password" @input="passwordFun" :value="password" placeholder="请输入6位数字支付密码" placeholder-class="placeholder"></input>
  </view>
  <view class="passwordf">
    <text>设置支付密码：</text>
    <input type="password" name="passwords" @blur="phoneOnBlur" :value="passwords" placeholder="再次请输入6位数字支付密码" placeholder-class="placeholder"></input>
  </view> -->

		<!-- </view>
<view class="btn" @tap.stop="passwrod">确认</view> -->
 <mybottom name="确认" @sublimt='passwrod'></mybottom>
	</view>
</template>

<script>
	// pages/setups/setups.js
	const app = getApp();
	var util = require("../../utils/util.js"),
		sha_1 = require("../../utils/sha_1.js");

	export default {
		data() {
			return {
				stroge: "",
				password: '',
			    passwords: "",
				
				newPasword:'', // 新密码
				newPasswords:'', // 确认新密码

				phone:'', // 手机号
				codeNum:'',// 验证码
				findPassword:'', // 重置支付密码
				type: 1,
				codename:'',
				disabled:false
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			console.log(options)
			this.type = options.type;
			uni.setNavigationBarTitle({
			  title: options.title
			});
			this.getstroge();
		},
		methods: {
			//获取本地数据
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				that.setData({
					stroge: stroge
				});
			},
			/*确认*/
			passwrod() {
				var that = this;
				
				var data = {};
				var password = that.passwords;
				var stroge = that.stroge;
				data["uid"] = stroge.uid;
				var seturl = ''
				if(that.type == 1){
					data['password'] = password;
					seturl = 'pay/pay_pass';
					if(that.password == '' ){
						uni.showToast({
							icon:'none',
							title:'请输入支付密码'
						})
						return false;
					}
					if(that.passwords == ''){
						uni.showToast({
							icon:'none',
							title:'请再次输入支付密码'
						})
						return false;
					}
					if(that.password != that.passwords){
						uni.showToast({
							icon:'none',
							title:'两次输入支付密码不一致'
						})
						return false;
					}
				}else if(that.type == 2){
					data['password'] = that.password;
					data['passwords'] = that.newPasword;
					data['passwords_again'] = that.newPasswords;
					seturl = 'pay/save_pass'
				}else if(that.type == 3){
					data['phone'] = that.phone;
					data['code'] = that.codeNum;
					data['pay_pass'] = that.findPassword;
					seturl = 'pay/check_save_pass'
				}
				
				var arr = {
					data: data
				};
				var jsonStr = JSON.stringify(arr);
				var aesData = sha_1.Encrypt(jsonStr);
				uni.request({
					url: app.globalData.url + seturl,
					method: "POST",
					data: {
						data: aesData
					},
					success(res) {
						console.log(res)
						if (res.data.code == 'ok') {
							uni.showToast({
								title: '密码设置成功'
							});
							uni.navigateBack()
							that.requid();
						}
					},fail: (err) => {
						console.log(err)
					}

				});
			},
            /*---获取手机验证码---*/
            getCode() {
              var a = this.phone;
            
              var _this = this;
            
              var myreg = /^1[3456789]\d{9}$/;
               console.log(a)
              if (this.phone == "") {
                uni.showToast({
                  title: '手机号不能为空',
                  icon: 'none',
                  duration: 1000
                }); // return false;
              } else if (!myreg.test(this.phone)) {
                uni.showToast({
                  title: '请输入正确的手机号',
                  icon: 'none',
                  duration: 1000
                }); // return false;
              } else {
            	  let that = this;
            	  that.$request({
            	  	url: 'login/sms_re_pass',
            	  	data: {
            	  		phone: this.phone,
            	  	    code_type: 2,
            	  	},
            	  	method: 'post'
            	  }).then(res => {
            	  	console.log(res)
            	  	if(res.statusCode == 200){
            	  	   that.getTimer();
            		   uni.showToast({
            		   	title:res.data.msg,
            		   	icon:'none'
            		   })
            	  	}
            	    
            	  }).catch(err => {
            	  	console.error('登录异常', err);
            	  })
              }
            },
             getTimer() {
             	let that = this;
             	if (that.phone == '') {
             		uni.showToast({
             			title: '请输入手机号',
             			icon: 'none'
             		})
             		return;
             	}
             	let count = 60;
             	that.disabled = true;
             	that.codename = count
             	// that.getMsg();
             
             	let timer = setInterval(res => {
             		count--;
             		that.codename = count;
             		if (count == 0) {
             			clearInterval(timer);
             			that.disabled =false;
             		}
             	}, 1000)
             },
			/*重新存储uid*/
			requid() {
				uni.request({
					url: app.globalData.url + 'users/userinfo',
					method: "POST",
					data: {
						uid: this.stroge.uid
					},

					success(res) {
						uni.setStorageSync('key', res.data.data);
					}

				});
			}

		}
	};
</script>
<style lang="scss" scoped>
	/* pages/setups/setups.wxss */
	page {
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
	}
    .content{
		width: 100%;
		height: 100vh;
		background-color: #F8F9FF;
	}
	.itemsBox {
		width: 100%;
		height: 120rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #FFFFFF;
		padding: 0 30rpx;
		box-sizing: border-box;
		border-bottom: 1rpx solid #F8F9FF;

		.itemsLeft {
			flex: 1;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.icons {
				width: 52rpx;
				height: 52rpx;
				background-color: #f40;
			}

			text {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				color: #333333;
				opacity: 1;
				margin-left: 20rpx;
			}
		}

		.itemsRight {
			flex: 2;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.input {
				width: 100%;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 24rpx;
				color: #333333;
				opacity: 1;
				// text-align: right;
			}

			.deful {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				color: #DBDBDB;
				opacity: 1;
			}
             .yancode{
				 width: 240rpx;
				 height: 60rpx;
				 background: #4E73E8;
				 opacity: 1;
				 border-radius: 30rpx;
				 padding: 0 15rpx;
				 text-align: center;
				 text{
					 font-size: 24rpx;
					 font-family: PingFang SC;
					 font-weight: 500;
					 line-height: 60rpx;
					 color: #FFFCFC;
					 opacity: 1;
				 }
			 }
			.avatar {
				width: 60rpx;
				height: 60rpx;
				background: #DBDBDB;
				border-radius: 50%;
				opacity: 1;
				margin-right: 10rpx;
			}

			.arrowRignth {
				width: 20rpx;
				height: 28rpx;
				background-color: #f40;
			}
		}
	}
</style>
