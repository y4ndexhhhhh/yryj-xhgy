<template>
<!--pages/myadd/myadd.wxml-->
<view class="conter" v-if="status==1">
  <view class="wrap">
    <form @submit="formSubmit">
      <view class="input_wrap">
        <text>姓名：</text>
        <input name="username" @input="user" :value="stroge.real_name" type="text" placeholder="请输入您的姓名(必填)"></input>
      </view>
      <view class="input_wrap">
        <text>手机号:</text>
        <input name="phone" type="number" placeholder="请输入手机号(必填)" maxlength="11" @input="phone" :value="stroge.phone"></input>
      </view>
      <view class="input_wrap">
        <text>身份证号：</text>
        <input name="codee" @input="id_cardFun" :value="stroge.id_card" type="text" placeholder="请输入身份证(必填)"></input>
      </view>
      <view class="input_wrap">
        <text>所在地区：</text>
        <picker mode="region" @change="bindRegionChange" :value="region" :custom-item="customItem" style="width:50%;">
          <view class="picker" v-if="areas_address">
            {{areas_address}}
          </view>
          <view class="picker" v-else>
            {{region[0]}}{{region[1]}}{{region[2]}}
          </view>
         
        </picker>
      </view>
      <view class="input_wrap">
        <text>详细地址：</text>
        <input name="adders" @input="adder" :value="detailed_address" type="text" placeholder="如：县、乡、村、街道、单元" style="text-align:left;"></input>
      </view>
        <button class="btns" form-type="submit">确认</button>
    </form>
  </view>
</view>
</template>

<script>
// pages/myadd/myadd.js
const app = getApp();

export default {
  data() {
    return {
      stroge: {},
      //本地缓存数据
      username: "",
      phone: "",
      id_card: "",
      adders: "",
      join_status: '',
      adders_flag: false,
      flag: 1,
      region: ['选择省', '选择市', '选择区'],
      time: '',
      checkpass: false,
      status: 1,
      storage_address: "",
      areas_address: "",
      detailed_address: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.reqstatu();
    this.getstroge();
  },

  onShow() {
    this.getstroge();
  },

  methods: {
    /*获取本地数据*/
    getstroge() {
      const stroge = uni.getStorageSync('key');
      this.setData({
        stroge: stroge,
        storage_address: stroge.address
      });
      const siptes = this.storage_address.split('-');
      this.setData({
        areas_address: siptes[0],
        detailed_address: siptes[1]
      });
    },

    /*姓名 */
    user(e) {
      this.setData({
        username: e.detail.value
      });
    },

    /*身份证*/
    id_cardFun(e) {
      this.setData({
        id_card: e.detail.value
      });
    },

    bindRegionChange: function (e) {
      this.setData({
        region: e.detail.value,
        adders_flag: true
      });
    },

    /*详细地址*/
    adder(e) {
      var that = this;
      that.setData({
        adders: e.detail.value
      });
    },

    /*--form表单提交数据--*/
    formSubmit(e) {
      var that = this;
      var user = that.username;
      var phone = that.phone;
      var ader = that.region.toString();
      var id_card = that.id_card;
      var addes = that.adders;
      var flag = that.flag;

      if (user == '' && phone == '' && ader == '选择省,选择市,选择区' && addes == '' && id_card == '') {
        //说明用户没有点击输入，直接跳转到支付类型选择界面
        that.resplay();
      } else {
        if (ader == '选择省,选择市,选择区') {
          //用户没有点击所在地区---获取以前的原始数据
          ader = that.areas_address;
        }

        if (addes == '') {
          //用户没有点击详细地址---获取以前的原始数据
          addes = that.detailed_address;
        }

        if (id_card != '') {
          uni.request({
            url: app.globalData.url + 'partner/id_cord',
            method: "POST",
            data: {
              uid: this.stroge.uid,
              id_card: id_card
            },
            success: res => {
              if (res.data.code != 'ok') {
                that.setData({
                  checkpass: false
                });
                uni.showToast({
                  title: res.data.msg,
                  icon: 'none'
                });
              } else {
                that.setData({
                  checkpass: true
                });
              }
            }
          });
        } else {
          that.setData({
            checkpass: true
          });
        }

        if (!that.checkpass) {
          //延时0.5秒  --  再去判断该值
          return;
        }

        var adder = `${ader}-${addes}`;
        uni.request({
          url: app.globalData.url + 'users/seve_img',
          method: "POST",
          data: {
            uid: this.stroge.uid,
            phone: phone,
            real_name: user,
            id_card: id_card,
            address: adder,
            flag: flag
          },

          success(res) {
            const stoges = res.data.data;

            if (res.data.code == 'ok') {
              uni.setStorageSync('key', stoges);
              uni.showModal({
                title: '编辑实名认证',
                content: '编辑成功',
                success: res => {
                  that.resplay();
                }
              });
            } else {
              uni.showToast({
                title: res.data.msg
              });
            }
          }

        });
      }
    },

    resplay() {
      uni.navigateTo({
        url: '/pages/aplay/aplay?oid=1'
      });
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/myadd/myadd.wxss */
.formtable {
  margin: auto;
  width: 80%;
  padding: 20px 10px 0 10px;
}
form input {
  width: 70%;
  border-bottom: 1px solid #eee;
}

.picker {
  width: 140%;
  border-bottom: 1px solid #eee;
}

.wrap {
  padding: 20rpx;
  font-size: 14px;
  color: #333;
}
.input_wrap{
display: flex;
width: 100%;
padding: 30rpx 0;
}
.input_wrap text{
width: 80px;
}
.btn{
display: flex;
justify-content: center;
text-align: center;
margin-top: 40rpx;
 line-height: 60rpx;
}

.btns {
width: 60%;
color: #fff;
background-color: #107BFD;
border-radius: 12px;
display: flex;
justify-content: center;
}

</style>