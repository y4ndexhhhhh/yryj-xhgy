<template>
<!--pages/paytype/paytype.wxml-->
<view class="conter" v-if="status==1">
  <view class="aoder">
    <view class="wxaplay">付款方式</view>
    <radio-group @change="radioChange">
      <label v-for="(item, index) in items" :key="index" class="weui-cell">
        <view class="weui-cell__hd">
          <image :src="item.img"></image>
          <view class="weui-cell__bd">{{item.name}}</view>
          <radio :value="item.vname" :disabled="item.disabled" :checked="item.checked"></radio>
        </view>

      </label>
    </radio-group>
  </view>
  <view class="label1" v-if="oid == 4">
    <text class="text1">共：{{friend_num}} 人</text>
  </view>
  <radio-group class="radig" @change="checkboxChange">
    <radio class="radios" value="3"></radio>
    我已阅读并同意<text class="text" @tap.stop="privacy">《隐私条例》</text>
    <text class="text" @tap.stop="privacy_yl" v-if="url && paytype == 'ylpay'">和《签约协议》</text>
  </radio-group>
  <button class="buttons" @tap.stop="aplay" :disabled="disabled">{{pay_name}}</button>
  <view :class="'zan-dialog ' + ( showDialog ? 'zan-dialog--show' : '' )">
    <view class="zan-dialog__mask"></view>
    <view class="zan-dialog__container">
      <view class="title">温馨提示</view>
        <view class="content">{{content}}</view>
      <view class="button">
        <view class="btn" plain @tap="toggleDialog">知道了</view>
      </view>
    </view>
  </view>
</view>
</template>

<script>
// pages/paytype/paytype.js
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      current: 0,
      equity_money: 0,
      pay_name: '确认',
      disabled: false,
      ordie: '',
      code: '',
      uid: '',
      openid: '',
      order_id: '',
      lock: false,
      items: [{
        vname: 'wxpay',
        name: '加入会员',
        img: "/static/images/banner/wxaplay.png",
        checked: "true"
      }, {
        vname: 'ylpay',
        name: '0元加入',
        img: "/static/images/banner/ylzf01.jpg",
		disabled: true
      }],
      paytype: 'wxpay',
      ordie: '',
      oid: 0,
      getest: '',
      showDialog: false,
      content: '',
      url: '',
      status: 1,
      friend_num: 0,
      staff: '',
      rank: 0,
      time: '',
      content_text: '智能合约是申请援助的必要条件，合约中内置了智能二维码，用于验证你的就医信息真实性，同时合约也将做为您参与“医补计划”的法律文书，保障行使合法权益。'
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();
    this.unionAgreement();

    if (e.oid == undefined) {
      uni.switchTab({
        url: '/pages/index/index'
      });
    } else {
      this.setData({
        oid: e.oid
      });

      if (e.oid == 9) {
        //只有是家人加入才进行本地数据的获取
        this.getstrogeFamilyData();
      }

      if (e.oid == 4) {
        //只有是员工加入才进行本地数据的获取
        this.setData({
          friend_num: e.friend_num
        });
        this.getstafflist();
      }
    }

    if (e.uid != undefined) {
      this.setData({
        uid: e.uid
      });
    } else {
      this.getstroge();
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');

      if (stroge.uid != undefined) {
        that.setData({
          uid: stroge.uid,
          openid: '',
          rank: stroge.rank
        });
      }
    },

    // 支付
    aplay() {
      var that = this;

      if (that.ordie === '') {
        uni.showToast({
          title: '请勾选隐私条例',
          icon: 'none'
        });
        return false;
      } else {
        //  按钮节流
        that.reduceAsk();

        if (that.paytype == 'ylpay') {
          that.getylaplay();
        } else if (that.paytype == 'wxpay') {
          uni.navigateTo({
            url: '/pages/stotails/stotails?oid=' + that.oid + '&friend_num=' + that.friend_num
          });
        } else {
          uni.switchTab({
            url: '/pages/index/index'
          });
        }
      }
    },

    // 请求银联支付事件
    getylaplay() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'union_pay/getUserBanknoInfo',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {
            that.postaply();
          } else {
            uni.showModal({
              title: '提示',
              content: res.data.msg,

              success(res) {
                uni.navigateTo({
                  url: '/pages/bind_bank/bind_bank?oid=' + that.oid
                });
              }

            });
          }
        }

      });
    },

    //获取家人本地数据
    getstrogeFamilyData() {
      var that = this;
      const getest = uni.getStorageSync('test');
      that.setData({
        getest: getest
      });
    },

    // 获取员工本地数据
    getstafflist() {
      var that = this;
      const staff = uni.getStorageSync('mystaff');
      that.setData({
        staff: staff
      });
    },

    // 唤起银联支付事件
    postaply() {
      var that = this;
      var uid = that.uid;

      if (uid == '') {
        uni.showToast({
          title: '用户信息失败，请重新登录！',
          icon: 'none'
        });
        return;
      }

      var data = {};
      var oid = that.oid;
      var type = oid;

      if (oid == 3) {
        var type = 1;
      } else if (oid == 9) {
        if (that.getest == '') {
          uni.showToast({
            title: '请先添加家人信息',
            icon: 'none'
          });
        }

        data['cord'] = that.getest; //家人数据
      } else if (oid == 4) {
        if (that.staff == '') {
          uni.showToast({
            title: '请先添加员工信息',
            icon: 'none'
          });
        }

        data['cord'] = that.staff; //员工数据
      }

      data["type"] = type;
      data["uid"] = uid;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'union_pay/unionPay',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {
            var seach_data = {};
            var timerTem = that.time;
            seach_data["order_id"] = res.data.data;
            seach_data["uid"] = uid;
            var seach_arr = {
              data: seach_data
            };
            var seach_jsonStr = JSON.stringify(seach_arr);
            var seach_aesData = sha_1.Encrypt(seach_jsonStr);
            var timerTem = setInterval(function () {
              uni.request({
                url: app.globalData.url + 'union_pay/getUnionPayResult',
                method: 'POST',
                data: {
                  data: seach_aesData
                },

                success(res) {
                  if (res.data.code == 200) {
                    if (res.data.status_order == 1) {
                      clearInterval(timerTem);
                      that.returnmsg();
                    }

                    if (res.data.status_order == 2) {
                      if (res.data.status_code != '') {
                        uni.showToast({
                          title: res.data.msg,
                          icon: 'none',
                          duration: 4000
                        });
                        that.setData({
                          pay_name: res.data.msg,
                          disabled: true
                        });
                        clearInterval(timerTem);
                      }
                    }
                  } else {
                    uni.showToast({
                      title: res.data.msg,
                      icon: 'none'
                    });
                    return;
                  }
                }

              });
            }, 2000);
          } else {
            uni.showToast({
              title: '加入失败'
            });
            return;
          }
        }

      });
    },

    /*按钮节流*/
    reduceAsk() {
      var _this = this;

      if (!_this.lock) {
        _this.setData({
          lock: true
        });

        var num = 6; //6秒后可以再次点击

        var timer = setInterval(function () {
          num--;

          if (num <= 0) {
            clearInterval(timer);

            _this.setData({
              pay_name: '确认',
              disabled: false
            });
          } else {
            _this.setData({
              pay_name: num + "s" + ' 等待中...',
              disabled: true
            });
          }
        }, 1000);
        setTimeout(function () {
          _this.lock = false;
        }, 5000);
      }
    },

    /*选择支付方式*/
    radioChange(e) {
      if (e.detail.value == 'ylpay') {
        this.setData({
          showDialog: true,
          pay_name: '确认',
          disabled: false
        });
      } else {
        this.setData({
          showDialog: false
        });
      }

      this.setData({
        paytype: e.detail.value
      });
    },

    /*---勾选隐私条例---*/
    checkboxChange(e) {
      this.setData({
        ordie: e.detail.value
      });
    },

    /*---隐私条例---*/
    privacy() {
      uni.navigateTo({
        url: '/pages/privacy/privacy'
      });
    },

    /*---银联隐私条例---*/
    privacy_yl() {
      uni.navigateTo({
        url: '/pages/bannerurl/bannerurl?url=' + this.url
      });
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    },

    // 提示框事件
    toggleDialog() {
      this.setData({
        showDialog: !this.showDialog
      });
    },

    // 提示框内容
    unionAgreement() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'users/unionAgreement',
        method: "POSt",

        success(res) {
          if (res.data.code == 200) {
            that.setData({
              url: res.data.data.url,
              content: res.data.data.content
            });
          }
        }

      });
    },

    // 返回用户的结果
    returnmsg() {
      var that = this;
      var type = that.oid;

      if (type == 9) {
        var content = '您已成功为您的家人加入医补计划';
      } else if (type == 4) {
        var content = '您已成功为您的员工加入医补计划';
      } else {
        var content = '您已成功加入医补计划';
      }

      uni.showModal({
        title: '提示',
        content: content,

        success(res) {
          //清除缓存
          if (that.oid == 9) {
            uni.removeStorageSync('test');
          }

          if (that.oid == 4) {
            uni.removeStorageSync('mystaff');
          }

          uni.showModal({
            title: '合约邮寄',
            content: that.content_text,

            // 邮寄合同
            success(res) {
              uni.navigateTo({
                url: '/pages/mail/mail?uid=' + that.uid + that.rank
              });
            }

          });
        }

      });
    }

  }
};
</script>
<style>
page {
  background-color: #F4F4F4;
}

.radig {
  margin: 30px;
  font-size: 12px;
  color: #333;
}

.text {
  color: #0B3FFF;
}

.aoder {
  padding: 8px 20px;
  background-color: #fff;
  margin-top: 20px;
  box-shadow: 0 0 5px #ccc;
}

.aoder image {
  width: 20px;
  height: 20px;
  vertical-align: middle;
}

.aoder view {
  /* border-bottom: 1px solid #ccc; */
  padding: 8px 0;
}

.wxaplay {
  padding: 8px 0;
  border-bottom: 1px solid #ccc;
}

.buttons {
  margin: 100px auto 20px;
  width: 686rpx;
  height: 90rpx;
  line-height: 90rpx;
  background: #FFAC38;
  text-align: center;
  color: #fff;
  font-weight: 600;
  border-radius: 50rpx;

}

.weui-cell__hd {
  display: flex;
  align-items: center;
}

.weui-cell__bd {
  flex: 1;
  margin-left: 10px;
}
.zan-dialog__mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 10;
  background: #000;
  opacity: 0.5;
  display: none;
}

.zan-dialog__container {
  position: fixed;
  bottom: 40%;
  width: 90vw;
  margin-left: 40rpx;
  height: 440rpx;
  background: #f8f8f8;
  transform: translateY(300%);
  transition: all 0.4s ease;
  z-index: 12;
  border-radius: 20rpx;
  font-size: 18px;
}

.zan-dialog--show .zan-dialog__container {
  transform: translateY(0);
}

.zan-dialog--show .zan-dialog__mask {
  display: block;
}

.button {
  font-weight: 200;
  text-align: center;
  font-weight: 200;
  width: 100%;
  position: relative;
  padding: 20rpx 0;
  height: 4vh;
  top:15%;
}
.label1 {
  padding: 16px 0;
  margin-left: 10rpx;
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  box-sizing: border-box;
  box-shadow: 0 0 4px #ccc;
}
.text1 {
  color: #000;
  line-height: 70rpx;
  font-size: 14px;
  padding: 0 10px;
}
.btn {
  border-radius: 8px;
  border: 1rpx solid #999;
  background-color: blue;
  color: #fff;
  position: absolute;
  width: 50%;
  left: 50%;
  transform: translate(-50%, 0);
}
.title {
  padding: 10rpx;
  text-align: center;
}

.content {
  color: #999;
  padding: 0 30rpx;
  font-size: 16px;
}

</style>