<template>
<!--pages/partnership/partnership.wxml-->
<view class="conter" v-if="status==1">
  <view class="title">请选择合伙人类型：</view>
  <form @submit="formSubmit">
    <radio-group class="radio-group" @change="radioChange">
      <view v-for="(item, index) in items" :key="index" :hidden="!item.show" class="list">
        <label class="label">{{item.name}}</label>
        <radio class="radio" :value="item.value"></radio>
      </view>
    </radio-group>
    <radio-group class="radig" @change="checkboxChange">
      <radio class="radios" value="3"></radio>

      我已阅读并同意<text class="text" @tap.stop="agreement">《合伙人计划》</text>

    </radio-group>
    <button form-type="submit">申请加入</button>
  </form>

</view>
</template>

<script>
// pages/partnership/partnership.js
const app = getApp();

export default {
  data() {
    return {
      items: [{
        name: '注册合伙人',
        value: '10',
        show: true
      }, {
        name: '天使合伙人',
        value: '15',
        checked: 'true',
        show: true
      }],
      radio: '',
      check: '',
      status: 1,
      rank: 0
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      rank: options.rank
    });
    this.reqstatu();
  },

  onShow() {
    if (this.rank == 2) {
      this.items[1].show = false;
      this.setData({
        items: this.items
      });
    }

    if (this.rank == 3) {
      this.items[0].show = false;
      this.setData({
        items: this.items
      });
    }
  },

  methods: {
    radioChange(e) {
      this.setData({
        radio: e.detail.value
      });
    },

    checkboxChange(e) {
      this.setData({
        check: e.detail.value
      });
    },

    formSubmit(e) {
      const radis = this.radio;
      const check = this.check;

      if (radis === '') {
        uni.showToast({
          title: '请选择合伙类型'
        });
        return false;
      }

      if (check === '') {
        uni.showToast({
          title: '请勾选合伙人计划',
          icon: 'none'
        });
        return false;
      }

      if (radis == 10) {
        uni.navigateTo({
          url: '/pages/staff/staff?id=10'
        });
      } else {
        uni.navigateTo({
          url: '/pages/pecialist/pecialist?id=15'
        });
      }
    },

    /*---合伙人协议---*/
    agreement() {
      uni.navigateTo({
        url: '/pages/autobiog/autobiog'
      });
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/partnership/partnership.wxss */

.conter .title {
  margin: 30px 20px;
  color: #333;

}

.radio-group {
  border-radius: 5px;
  margin: 10px 5px;
  background: #F8F8FF;

}

.list {
  margin-top: 20px;
  height: 32px;
}

.radio {
  float: right;
  transform: scale(0.8);
}

.label {
  padding: 0 0 0 15px;
  font-size: 14px;
  color: #333;
}

.radig {

  margin: 30px 20px;
  font-size: 12px;
  color: #333;
}

.radios {
  transform: scale(0.8);
}

.text {
  color: #0B3FFF;
}

button {
  margin-top: 80px;
  color: #fff;
  width: 60%;
  background-color: #0B3FFF;
}
</style>