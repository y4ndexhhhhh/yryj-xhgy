<template>
<view>
<form @submit="formSubmit" v-if="status==1">
  <view class="head_wrap">
    <view class="head_title">申请码</view>
  </view>
  <view class="form_content">
    <view class="content">
      <!-- <block wx:for="{{Length}}" wx:key="item"> -->
        <!-- <input class='iptbox' value="{{Value.length>=index+1?Value[index]:''}}" catchtap='Tap'></input> -->
         <view v-if="code==''">请先扫描纸质合约，获取申请码
         </view>
         <view v-else>{{code}}
          <view class="tip" v-if="ele_card_pass_flag==2">提示：
            请先扫描纸质合约，录入医保信息
          </view>
         </view>
          
      
      <!-- </block> -->
    </view>
    <!-- <input name="number" number="{{true}}" class='ipt' maxlength="{{Length}}" focus="{{isFocus}}"
      bindinput="Focus"></input> -->
    <view>
    </view>
  </view>
  <view class="footer_title">
    <view class="footer_content">{{text}}</view>
  </view>
  <view class="see_code_wrap" @tap="scan_code">
    <view class="see_code">
      <image src="/static/images/banner/erweima.png"></image>
    </view>
    <view class="see_code_title">点击识别二维码</view>
  </view>
  <button class="btn-area" form-type="submit" v-if="ele_card_pass_flag==1">下一步</button>
</form>
</view>
</template>

<script>
// pages/apply_help/apply_help.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      Length: 8,
      //输入框个数 
      isFocus: true,
      //聚焦 
      Value: '',
      //输入的内容 
      ispassword: true,
      //是否密文显示 true为密文， false为明文。
      text: '智能合约申请码获取办法请扫描纸质“会员公约” 最后一页的二维码。',
      uid: 0,
      flag: 1,
      status: 1,
      code: '',
      ele_card_pass_flag: 2
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();
    this.setData({
      uid: e.uid,
      ele_card_pass_flag: e.ele_card_pass_flag
    });

    if (e.code != 'undefined' && e.code != '') {
      this.setData({
        code: e.code
      });
    }
  },
  methods: {
    Focus(e) {
      var that = this;
      var inputValue = e.detail.value;
      that.setData({
        Value: inputValue
      });
    },

    Tap() {
      var that = this;
      that.setData({
        isFocus: true
      });
    },

    formSubmit(e) {
      var that = this;

      if (that.code == "") {
        uni.showToast({
          title: '请先扫描纸质合约',
          icon: 'none',
          duration: 2000
        });
        return false;
      } else {
        var data = {};
        data["uid"] = that.uid;
        data["code"] = that.code;
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.api_url + 'h5/proposers/proposersCase',
          method: 'POST',
          data: {
            data: aesData
          },

          success(res) {
            if (res.data.code == 200) {
              uni.setStorageSync("case_id", res.data.case_id);
              uni.removeStorageSync('result');
              uni.navigateTo({
                url: '/pages/upload_apply/upload_apply?uid=' + that.uid + '&case_id=' + res.data.case_id
              });
            } else {
              uni.showToast({
                title: res.data.msg,
                icon: 'none'
              });
            }
          }

        });
      }
    },

    // 扫码得到的值
    scan_code() {
      var that = this;
      uni.scanCode({
        success(res) {
          const url = res.result;
          var url_tmp = url.split('?');
          var request_url = url_tmp[0];
          var param = url_tmp[1].split('=');

          if (request_url != '' && param != '') {
            uni.navigateTo({
              url: '/pages/new_html/new_html?request_url=' + request_url + '&code=' + param[1]
            });
          } else {
            uni.showToast({
              title: '扫描失败请重新扫描',
              icon: 'none'
            });
          }
        }

      });
    },

    // 屏蔽
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
.form_content{
  margin-top: 50rpx;
}
.content {
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 20rpx;
}
.iptbox {
  width: 80rpx;
  height: 80rpx;
  border: 1rpx solid #ddd;
  border-radius: 20rpx;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.ipt {
  width: 0;
  height: 0;
}

.btn-area {
  margin-top: 70rpx;
  width: 60%;
  background-color: #007bff;
  color: white;
}
.head_wrap {
  height: 60px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.head_title{
  font-size: 18px;
  color: #7e8a9d;
}
.footer_title{
  text-align: center;
  display: flex;
  justify-content: center;
    
}
.footer_content{
    color: #7e8a9d;
    margin: 50rpx;
}
.see_code{
display: flex;
justify-content: center;
padding: 20rpx;
}
.see_code image{
  width: 100px;
  height: 100px;
}
.see_code_title{
  display: flex;
  justify-content: center;
  font-size: 20px;
  font-weight: bold;
}
.tip{
  margin-top: 20rpx;
}


</style>