<template>
	<view>
		<!--pages/contribution/contribution.wxml-->
		<view class="ait" v-if="status==1">
			<view class="gxz_num">
				<text>贡献值数量</text>
				<input type="text" name="nubmers" @input="gxznum" :value="gxz_defaul_val" placeholder="请输入贡献值数量"></input>
			</view>
			<view class="price">每股{{unit_price}}元人民币</view>
			<view class="gxz_num">
				<text>分红权数</text>
				<input @input="fhnum" :value="fh_defaul_val" placeholder="请输入分红权数量"></input>
			</view>
			<view class="all">
				<text>计算结果:</text>
				<view class="nubmer">
					<view class="number1">扣除贡献值数量:
						<text style="color:red;">{{gxz_num}}</text>
					</view>
					<view class="number2">获得分红权数量:
						<text style="color:green;">{{fh_num}}</text>
					</view>
				</view>
			</view>

		</view>
		<radio-group class="radig" @change="checkboxChange">
			<radio class="radios" value="3"></radio>
			我已阅读并同意
			<text class="text" @tap.stop="privacy">《亿人一家服务平台隐私条例》</text>
		</radio-group>
		<view class="btn" @tap.stop="btns">
			立即兑换 {{fh_num}} 股
		</view>
		<view class="modalDlg" v-if="showModal">
			<view class="close_mask" @tap="close_mask">x</view>
			<view class="title">支付密码</view>
			<input class="showmode" type="password" name="shouw" @input="shouwFun" :value="shouw" placeholder="请输入支付密码"></input>
			<view class="showv" @tap.stop="btnshow">确定</view>
		</view>
		<view class="mask" catchtouchmove="preventTouchMove" v-if="showModal"></view>
	</view>
</template>

<script>
	// pages/contribution/contribution.js
	const app = getApp();
	var sha_1 = require("../../utils/sha_1.js");

	export default {
		data() {
			return {
				stroge: '',
				ordie: '',
				shouw: "",
				hidde: true,
				isshow: false,
				gxz_nums: '',
				fh_num: '0',
				gxz_defaul_val: '',
				fh_defaul_val: '',
				showModal: false,
				unit_price: 0,
				status: 1,
				gxz_num: "0"
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			this.reqstatu();
			this.getstroge();
		},
		methods: {
			//获取本地数据
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				that.setData({
					stroge: stroge,
					unit_price: stroge.unit_price
				});
			},

			/*---同意协议---*/
			checkboxChange(e) {
				this.setData({
					ordie: e.detail.value
				});
			},

			gxznum(e) {
				this.setData({
					fh_defaul_val: ''
				});
				this.setData({
					fh_num: Math.floor(e.detail.value / this.unit_price)
				});
				this.setData({
					gxz_num: Math.round(this.fh_num * this.unit_price * 100) / 100
				});
			},

			fhnum(e) {
				this.setData({
					gxz_defaul_val: ''
				});
				this.setData({
					gxz_num: Math.round(e.detail.value * this.unit_price * 100) / 100
				});
				this.setData({
					fh_num: Math.floor(this.gxz_num / this.unit_price)
				});
			},

			shouwFun(e) {
				this.setData({
					shouw: e.detail.value
				});
			},

			/*---隐私条例---*/
			privacy() {
				uni.navigateTo({
					url: '/pages/privacy/privacy'
				});
			},

			/*输入密码确定*/
			btnshow() {
				var that = this;

				if (that.shouw == '') {
					uni.showToast({
						title: '密码不能为空',
						icon: 'none'
					});
					return false;
				} else {
					that.setData({
						hidde: true
					});
					var data = {};
					var nubmers = that.gxz_num;
					var shares = that.fh_num;
					var stroge = that.stroge;
					data["uid"] = stroge.uid;
					data['devote_value'] = nubmers;
					data['shares'] = shares;
					data['pay_pass'] = that.shouw;
					var arr = {
						data: data
					};
					var jsonStr = JSON.stringify(arr);
					var aesData = sha_1.Encrypt(jsonStr);
					uni.request({
						url: app.globalData.url + 'partner/convert_bonus',
						method: "POST",
						data: {
							data: aesData
						},

						success(res) {
							if (res.data.code == 'ok') {
								that.setData({
									showModal: false
								});
								uni.showToast({
									title: '兑换成功',
									icon: 'none'
								})
								uni.redirectTo({
									url: '/pages/money/money?uid=' + that.stroge.uid
								});
							} else {
								uni.showToast({
									title: res.data.msg,
									icon: 'none'
								});
								that.setData({
									hidde: false
								});
							}
						}

					});
				}
			},

			/*立即兑换*/
			btns() {
				var that = this;

				if (that.gxz_num == '' || that.gxz_num == undefined) {
					uni.showToast({
						title: '请输入正确的贡献值数量',
						icon: 'none'
					});
					return false;
				} else if (that.ordie == '') {
					uni.showToast({
						title: '请勾选隐私条例',
						icon: 'none'
					});
					return false;
				} else if (that.nubmers > that.stroge.devote_value) {
					uni.showToast({
						title: '贡献值不足',
						icon: "none"
					});
					return false;
				} else {
					if (that.issetpay == 2) {
						uni.showToast({
							title: '未设置支付密码',
							icon: 'none'
						})
						uni.navigateTo({
							url: '/pages/setups/setups?type=1'
						});
					} else {
						this.setData({
							showModal: true
						});
					}
				}
			},

			/*重新存储uid*/
			requid() {
				uni.request({
					url: app.globalData.url + 'users/userinfo',
					method: "POST",
					data: {
						uid: this.stroge.uid
					},

					success(res) {
						uni.setStorageSync('key', res.data.data);
					}

				});
			},

			hideMask: function() {
				this.setData({
					showModal: false
				});
			},
			preventTouchMove: function() {},
			close_mask: function() {
				this.setData({
					showModal: false
				});
			},

			reqstatu() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'shield/getShield',
					method: "POSt",
					data: {
						version_code: app.globalData.version_code
					},

					success(res) {
						that.setData({
							status: res.data.data.status
						});
					}

				});
			}

		}
	};
</script>
<style>
	page {
		font-size: 14px;
		color: #333;
		background-color: #F4F4F4;
	}

	input {
		border-bottom: 1px solid #eee;
		padding: 8px 0 10px;
		margin-top: 30px;
		background-color: #E8E8E8;
		border-radius: 8px;
		text-align: center;

	}

	.ait {
		padding: 10px 15px;
		background-color: #fff;
	}

	.nubmer {
		display: flex;
		margin-top: 20px;
		width: 100%;
		padding: 4px 8px;
		justify-content: space-around;
	}

	.all {
		margin-top: 16px;
	}

	.number2 {
		margin-right: 40px;

	}

	.radig {
		margin-top: 20px;
		margin-left: 20rpx;
		font-size: 12px;
		color: #333;
	}

	.text {
		color: #0B3FFF;
	}

	.radios {
		transform: scale(0.8)
	}

	.btns {
		width: 60%;
		line-height: 35px;
		background-color: #fff;
		margin: 200px auto 20px;
		border-radius: 20px;
		text-align: center;
		box-shadow: 0 0 8px #eee;
	}

	.shouw {
		position: absolute;
		top: 250px;
		left: 50%;
		margin-left: -120px;
		width: 200px;
		padding: 20px;
		border-radius: 8px;
		border: 1px solid #eee;
		text-align: center;
		background-color: #ffff;
		justify-content: space-around
	}

	.title {

		font-size: 22px;

	}

	.showv {
		margin: 10px auto 0;
		width: 18vw;
		padding: 6px 10px;
		border-radius: 6px;
		border: 1px solid #eee;
		text-align: center;
		background-color: blue;
		color: #eee;

	}

	.btn {

		margin: 60px auto;
		text-align: center;
		color: #FFFFFF;
		width: 686rpx;
		height: 120rpx;
		line-height: 120rpx;
		background: #FFAC38;
		opacity: 1;
		border-radius: 60rpx;


		font-size: 44rpx;
		font-family: PingFang SC;
		font-weight: 500;
		/* line-height: px; */
		color: #FFFFFF;
		opacity: 1;
	}

	.modalDlg {
		width: 580rpx;
		height: 450rpx;
		position: fixed;
		top: 50%;
		left: 0;
		z-index: 9999;
		margin: -370rpx 85rpx;
		background-color: #fff;
		border-radius: 36rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.mask {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		background: #000;
		z-index: 9000;
		opacity: 0.7;
	}

	.close_mask {
		color: #000;
		position: relative;
		left: 42%;
		/* top: -82%; */
		font-size: 32rpx;
		padding: 8px 10px;

	}


	.gxz_num {
		display: flex;
		/* margin:; */
		width: 90%;
		/* background-color: #f40; */
		padding: 10px 0px;
		/* box-shadow: 0 0 10px 0 #ccc; */
		border-radius: 10px;
		justify-content: flex-start;
	}

	.gxz_num input {
		width: 70%;
		margin-left: 12px;
		margin-top: 1px;
	}

	.gxz_num text {
		margin-top: 10px;
	}

	.price {
		margin-top: 12px;
		float: right;
		margin-bottom: 20px;
	}
</style>
