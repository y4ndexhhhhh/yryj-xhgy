<template>
<!--pages/map/map.wxml-->
<view class="conter">
  <view class="head">
    推荐合计 一类<text class="green">{{zhitui_total}}</text>+二类<text class="red">{{jiantui_B_total}}</text>
  </view>
  <view class="contes">
    <view class="contesTop">
      <view class="leftcont active">一类</view>
      <view>
        <view class="contesright">
          <view class="top">会员数量</view>
          <view class="top">专员数量</view>
          <view class="top">普合数量</view>
        </view>
        <view class="contesright">
          <view>{{zhitui_A.member}}</view>
          <view>{{zhitui_A.attache}}</view>
          <view>{{zhitui_A.partner}}</view>
        </view>
        <view class="contesright">
          <view class="ordie end" @tap.stop="onordie">详情</view>
          <view class="ordie end" @tap.stop="onordies">详情</view>
          <view class="ordie end" @tap.stop="onordiess">详情</view>
        </view>
      </view>
    </view>
    <view class="contesTop">
      <view class="leftcont common">二类</view>
      <view>
        <view class="contesright">
          <view class="top">会员数量</view>
          <view class="top">专员数量</view>
          <view class="top">普合数量</view>
        </view>
        <view class="contesright">
          <view>{{jiantui_B.member}}</view>
          <view>{{jiantui_B.attache}}</view>
          <view>{{jiantui_B.partner}}</view>
        </view>
      </view>
    </view>
    <!-- <view class='contesTop'>
             <view class='leftcont common'>三类</view>
             <view>
                 <view class='contesright'>
                     <view class='top end'>会员数量</view>
                     <view class='top end'>专员数量</view>
                     <view class='top end'>普合数量</view>
                 </view>
                 <view class='contesright'>
                     <view>{{jiantui_C.member}}</view>
                     <view>{{jiantui_C.attache}}</view>
                     <view>{{jiantui_C.partner}}</view>
                 </view>
             </view>
         </view> -->
  </view>
  <view class="herf">
    <view>注：</view>
    <view>
      <image :src="image_url"></image>
    </view>
  </view>
</view>
</template>

<script>
// pages/map/map.js
const app = getApp();

export default {
  data() {
    return {
      stroge: "",
      zhitui_total: "",
      jiantui_B_total: "",
      jiantui_C_total: "",
      zhitui_A: "",
      jiantui_B: "",
      image_url: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getstroge();
    this.reqocse();
  },
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    /*----获取数据---*/
    reqocse() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'hhr/tuijian_list',
        method: "POST",
        data: {
          uid: this.stroge.uid
        },

        success(res) {
          that.setData({
            zhitui_total: res.data.data.zhitui_total,
            jiantui_B_total: res.data.data.jiantui_B_total,
            jiantui_C_total: res.data.data.jiantui_C_total,
            zhitui_A: res.data.data.zhitui_A,
            jiantui_B: res.data.data.jiantui_B,
            // jiantui_C: res.data.data.jiantui_C,
            image_url: res.data.image_url
          });
        }

      });
    },

    /*---点击详情---*/
    onordie() {
      uni.navigateTo({
        url: '/pages/ordie/ordie?type=1'
      });
    },

    onordies() {
      uni.navigateTo({
        url: '/pages/ordie/ordie?type=3'
      });
    },

    onordiess() {
      uni.navigateTo({
        url: '/pages/ordie/ordie?type=2'
      });
    }

  }
};
</script>
<style>
/* pages/map/map.wxss */
.head {
  font-size: 13px;
  color: #333;
  line-height: 50px;
  text-indent: 20px;
}

.head .green {
  color: green;
}

.head .red {
  color: red;
}

.contesTop {
  display: flex;
}

.leftcont {
  width: 20%;
  text-align: center;
  line-height: 90px;
  border-right: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  border-left: 1px solid #ccc;
}

.active {
  border-top: 1px solid #ccc;
}

.common {
  line-height: 60px;
}

.contesright {
  display: flex;

}

.contesright view {
  width: 98px;
  line-height: 30px;
  text-align: center;
  border-right: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
}

.top {
  border-top: 1px solid #ccc;
}

.end {
  border-top: none;
}

.herf {
  width: 90%;
  margin: 20px auto;
  font-size: 14px;
  color: #333;
  font-weight: bold;
}

.herf view {
  margin-top: 10px;
}

.herf image {
  width: 100%;
  height: 320px;
}
</style>