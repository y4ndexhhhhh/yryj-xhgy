<template>
<!--pages/limit/limit.wxml-->
<view class="conter" v-if="status==1">
  <view class="head">
    <image src="/static/images/banner/xianshihuodong.png"></image>
  </view>
  <view class="title">
    1、52度皇驾贡酒20陈酿 4瓶（淘宝旗舰店4x498=1992元）。
  </view>
  <view class="title">
    2、名师课程（线上+线下）价值1280元
  </view>
  <view class="title">
    3、推荐合伙人数量>3000位，每推荐一位赠送2个亿积分。
  </view>
  <view class="title">
    4、此活动属于显示优惠政策，根据项目发展，随时可能取消。
  </view>
  <view class="title">
    5、更多详尽政策请阅览《合伙人计划》
  </view>
  <view class="title">
    注：亿积分是“亿人一家”的一项综合信用评估体系，可用于兑换等待期、兑换合伙人资质、兑换分红股。
  </view>
  <button class="share" open-type="share">立即推荐</button>
</view>
</template>

<script>
// pages/limit/limit.js
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      stroge: '',
      status: ''
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getstroge();
    this.reqstatu();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    var data = {};
    data["uid"] = that.stroge.uid;
    data['type'] = 1;
    var arr = {
      data: data
    };
    var jsonStr = JSON.stringify(arr);
    var aesData = sha_1.Encrypt(jsonStr);
    uni.request({
      url: app.globalData.url + 'partner/share_award',
      method: "POST",
      data: {
        data: aesData
      },

      success(res) {}

    });
    return {
      title: '限时活动',
      //desc: '分享页面的内容',
      path: '/pages/index/index?tuid=' + that.stroge.uid // 路径，传递参数到指定页面。

    };
  },
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/limit/limit.wxss */
.head image {
  width: 100%;
  height: 184px;
}

.title {
  margin-top: 12px;
  padding: 0 14px;
  font-size: 14px;
  font-weight: bold;
  text-align: justify;
}

.share {
  margin-top: 40px;
  width: 80%;
  color: #fff;
  background-color: #0B3FFF;
}
</style>