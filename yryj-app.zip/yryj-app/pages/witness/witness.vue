<template>
<view>
<!--pages/witness/witness.wxml-->
<!-- <Tabs tabs="{{tabs}}" bindtabschenge="handletabschenge"> -->
<!-- <block wx:if="{{tabs[0].isActive}}"> -->
 <!-- <scroll-view scroll-y="true" style="height: 700px;" >   -->
<view class="witness_wrap" v-if="status==1">
  <view class="witness_title">
    <view class="title_head">温馨提示:</view>
    <view class="title_content">您在申请援助时，至少邀请10位见证也可以全部邀请来共同见证您的援助！</view>
  </view>
  <view class="invited_title_head">共有好友{{zt_count}}人</view>
  <view class="invite_witness">已邀请见证{{certifier_num}}人</view>
</view>
<view v-for="(item, index) in witness_list" :key="index" class="inviter_wrap" v-if="status==1">
  <view :class="'inviter_continer ' + (item.checked?'checkbox checked':'checkbox')" @tap="checkbox" :data-index="index">
    <view class="continer_left">
      <image mode="widthFix" src="/static/images/banner/nv.jpg"></image>
    </view>
    <view class="continer_center">
      <view class="center_usermsg">
        <view class="center_uesrname">{{item.real_name}}</view>
        <view class="center_userphone">{{item.phone}}</view>
      </view>
      <view class="center_jointime">
        <view class="jiontime_title">加入时间</view>
        <view class="jiontime_time">{{item.join_time}}</view>
      </view>
    </view>
    <view class="continer_right">
      <!-- <view class="choose">
              <image mode="widthFix" wx:if="{{item.checked == true}}" src="/images/banner/gou.png"></image>
            </view> -->
      <view class="vip_icon">
        <image mode="widthFix" v-if="item.rank == 1" src="/static/images/banner/huiyuan.png"></image>
        <image mode="widthFix" v-else src="/static/images/banner/zhuanyuan.png"></image>
      </view>
    </view>
    <view class="witness_btn" @tap="invited" v-if="item.status == null" :data-friend_uid="item.to_friend_uid" :data-index="index">{{fulfill}}</view>
    <view class="witness_btn" v-else>已邀请</view>
  </view>
</view>
 <!-- </scroll-view>   -->
<!-- </block> -->
<block v-if="tabs[1].isActive">
  <view v-for="(item, index) in witnesser_list" :key="index" class="witness_list">
    <view class="witness_name">{{item.name}}</view>
    <view class="witness_realname">{{item.real_name}}</view>
  </view>
</block>
<!-- </Tabs> -->
</view>
</template>

<script>
// pages/witness/witness.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");
import Tabs from "../conponent/Tabs/Tabs";

export default {
  data() {
    return {
      tabs: [{
        id: 1,
        value: "证明人",
        isActive: true,
        countnum: 0
      } // {
      //   id: 2,
      //   value: "证明人列表",
      //   isActive: false
      // }
      ],
      checkValue: [],
      uid: 0,
      page: 0,
      witness_list: [],
      case_id: 0,
      fulfill: '邀请',
      list: [],
      witnesser_list: [],
      certifier_num: 0,
      zt_count: 0,
      limit_num: 0,
      index: 0,
      status: 1,
      one_flag: "",
      type: ""
    };
  },

  components: {
    Tabs
  },
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();
    this.setData({
      uid: e.uid,
      case_id: e.case_id
    });
    this.get_witness_data(); // this.reg_certifier_num()
  },

  onShow() {},

  // 监听用户上拉触底事件。
  onReachBottom() {
    var page = this.page + 1; //获取当前页数并+1

    this.setData({
      page: page //更新当前页数

    });
    this.get_witness_data();
  },

  // 监听用户下拉刷新时间
  onPullDownRefresh() {
    // 重置数组
    this.setData({
      witness_list: []
    }); // 重置页码

    var page = 0;
    this.setData({
      page: page //更新当前页数

    }); // 重新发送请求

    this.get_witness_data();
  },

  methods: {
    // 获取证明人数据
    get_witness_data() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      data["page"] = that.page;
      data["case_id"] = that.case_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.api_url + 'h5/proposers/getFriendList',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {
            let arr = res.data.data;
            that.setData({
              witness_list: arr,
              certifier_num: res.data.certifier_num,
              zt_count: res.data.zt_count,
              limit_num: res.data.limit_num
            });
            that.tabs[0].countnum = "(" + that.zt_count + '人' + ")";
            that.setData({
              tabs: that.tabs
            });
            that.reg_certifier_num();

            if (that.page == 0) {
              let list = arr;
              that.setData({
                list: list
              });
            } else {
              //获取下拉刷新之前的list数据
              let old_data = that.list; //arr  代表page+1  新数据

              that.setData({
                witness_list: old_data.concat(arr)
              });
            }
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none'
            });
          }

          uni.stopPullDownRefresh();
        }

      });
    },

    checkbox: function (e) {
      var index = e.currentTarget.dataset.index; //获取当前点击的下标

      var witness_list = this.witness_list; //选项集合

      witness_list[index].checked = !witness_list[index].checked; //改变当前选中的checked值

      this.setData({
        witness_list: witness_list
      });
    },

    handletabschenge(e) {
      // 获取被点击标题的索引
      const {
        index
      } = e.detail; // 修改原数组

      let {
        tabs
      } = this; // tabs.forEach((v, i) => i == index ? v.isActive = true : v.isActive = false)

      for (var k = 0, length = tabs.length; k < length; k++) {
        if (index == k) {
          tabs[k]['isActive'] = true;
          this.setData({
            one_flag: tabs[k]['id'],
            type: tabs[k]['id']
          });
        } else {
          tabs[k]['isActive'] = false;
        }
      } // 赋值到data中


      this.setData({
        tabs
      });
      const that = this; // 重新赋值

      this.setData({
        page: 0
      });
      this.get_witnesslist_data();
    },

    // 获取证明人列表数据
    get_witnesslist_data() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      data["page"] = that.page;
      data["case_id"] = that.case_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.api_url + 'h5/proposers/getCaseCertifierUser',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {
            that.setData({
              witnesser_list: res.data.data
            });
          } else {
            uni.showToast({
              title: res.data.msg
            });
          }
        }

      });
    },

    // 邀请事件
    invited(e) {
      var that = this;
      let limit_num = that.limit_num;

      if (that.certifier_num >= limit_num) {
        var data = {};
        data["uid"] = that.uid;
        data["case_id"] = that.case_id;
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.api_url + 'h5/proposers/updateCaseStep',
          method: 'POST',
          data: {
            data: aesData
          },

          success(res) {//不作处理
          }

        });
        uni.showModal({
          title: '提示',
          content: '您已经成功邀请10位证明人,请进行下一步',

          success(res) {
            if (res.confirm) {
              uni.navigateTo({
                url: '/pages/apply_help_msg/apply_help_msg?uid=' + that.uid + '&case_id=' + that.case_id
              });
            }
          }

        });
      } else {
        let index = e.currentTarget.dataset.index;
        let friend_uid = e.currentTarget.dataset.friend_uid;
        var data = {};
        data["uid"] = that.uid;
        data["page"] = that.page;
        data["case_id"] = that.case_id;
        data["to_friend_uid"] = friend_uid;
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.api_url + 'h5/proposers/sendInvite',
          method: 'POST',
          data: {
            data: aesData
          },

          success(res) {
            if (res.data.code == 200) {
              // 局部刷新开始
              let old_witness_arr = that.witness_list;
              let certifier_num = that.certifier_num;
              let limit_num = that.limit_num;
              let num = certifier_num + 1;
              old_witness_arr[index]['status'] = 2;
              that.setData({
                witness_list: old_witness_arr,
                certifier_num: num
              });

              if (num >= limit_num) {
                that.reg_certifier_num();
              } // 局部刷新结束
              // wx.showToast({
              //   title: res.data.msg,
              //   icon: 'none',
              //   duration: 2000
              // })

            } else {
              uni.showToast({
                title: res.data.msg
              });
            }
          }

        });
      }
    },

    // 校验用户是否已经邀请了10位
    reg_certifier_num() {
      let that = this;
      let limit_num = that.limit_num;

      if (that.certifier_num >= limit_num) {
        var data = {};
        data["uid"] = that.uid;
        data["case_id"] = that.case_id;
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.api_url + 'h5/proposers/updateCaseStep',
          method: 'POST',
          data: {
            data: aesData
          },

          success(res) {//不作处理
          }

        });
        uni.showModal({
          title: '提示',
          content: '您已经成功邀请10位证明人,请进行下一步',

          success(res) {
            if (res.confirm) {
              uni.navigateTo({
                url: '/pages/apply_help_msg/apply_help_msg?uid=' + that.uid + '&case_id=' + that.case_id
              });
            }
          }

        });
      }
    },

    // 屏蔽
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/witness/witness.wxss */
.witness_wrap {
  padding: 20rpx 10rpx;
}

.invite_witness {
  font-size: 20px;
  font-weight: bold;
}

.witness_list {
  border-bottom: 1rpx solid #eee;
  padding: 20rpx;
  display: flex;
}

.witness_realname {
  margin-left: auto;
}

.inviter_wrap {
  padding: 20rpx;
}

.inviter_continer {
  border: 1rpx solid #eee;
  border-radius: 10px;
  box-shadow: 2px 2px 2px #eee;
  display: flex;
  align-items: center;
}

.continer_left {
  display: flex;
  align-items: center;
  padding: 10rpx;
  width: 60px;
  height: 60px;
}

.continer_left image {
  width: 60px;
  height: 60px;
  border-radius: 8px;
}
.invited_title_head{
  font-size: 18px;
  padding: 10rpx 0;
  font-weight: bold;
  
}
.continer_center {
  flex: 2;
  margin-left: 10rpx;
}

.center_usermsg {
  display: flex;
  padding: 10rpx 0;
}

.center_uesrname {
  font-size: 18px;
  font-weight: 700;
  width: 60px;
}

.center_userphone {
  margin-left: 10rpx;
  font-size: 14px;
}

.center_jointime {
  display: flex;
  font-size: 14px;
  color: #999;
}

.jiontime_title {
  width: 60px;
}

.jiontime_time {
  margin-left: 10rpx;
}

.continer_right {
  flex: 1;
  display: flex;
}

.choose {
  width: 20px;
  height: 20px;
}

.choose image {
  width: 20px;
  height: 20px;
}

.vip_icon {
  width: 30px;
  height: 30px;
  margin-left: 10px;
}

.vip_icon image {
  width: 30px;
  height: 30px;
}

.active {
  border: 1rpx solid #6495ED;
  box-shadow: 2px 2px 2px #6495ED;
}

.witness_title {
  padding: 10rpx;
}

.title_head {
  font-size: 19px;
  font-weight: bold;
}

.title_content {
  padding: 10rpx 0;
  color: #999;
  text-indent: 2em;
}

.witness_btn {
  margin-right: 10rpx;
  border: 1rpx solid #eee;
  border-radius: 8px;
  background-color: #3eace2;
  text-align: center;
  color: #fff;
  padding: 10rpx;
}

.witness_btns {
  margin-right: 10rpx;
  border: 1rpx solid #eee;
  border-radius: 8px;
  background-color: #999;
  text-align: center;
  color: #fff;
  padding: 10rpx;
}

.checkbox-con {
  margin: 50rpx auto;
  text-align: center;
  position: relative;
}

.checkbox-group view {
  float: left;
  width: 50%;
  display: flex;
  flex-direction: column;
  padding: 0 20rpx 40rpx;
  box-sizing: border-box;
}




/* .checkbox-group{
 display: flex;
 flex-direction: row;
} */
.checked {
  color: #3eace2;
  background: rgba(49, 165, 253, 0.08);
  border: 1rpx solid #3eace2;
  box-shadow: 2px 2px 2px #3eace2;
}

</style>