<template>
<!--pages/help_publicity/help_publicity.wxml-->
<view class="box" v-if="status==1">
<view class="publicity_wrap">
  <view class="publicity_head">
    <view class="head_title">
      申请人信息
    </view>
  </view>
  <view class="wrap">
    <view class="title">姓名</view>
    <view class="wrap_num">{{real_name}}</view>
  </view>
  <view class="wrap">
    <view class="title">加入时间</view>
    <view class="wrap_num">{{join_time}}</view>
  </view>

  <view class="wrap">
    <view class="title">援助金额</view>
    <view class="wrap_num">{{help_amount}}元</view>
  </view>
</view>
<view class="thanks_letter_video">
  <view class="thank_title">感谢信视频</view>
  <video class="myVideo" :src="url + '' + video_url" show-play-btn="true" show-center-play-btn="true" controls></video>
</view>
<view class="wrap_btn">
  <button class="content_btn" open-type="share">分享好友</button>
</view>
</view>
</template>

<script>
// pages/old_help_publicity/old_help_publicity.js
const app = getApp();

export default {
  data() {
    return {
      old_publicity_list: [],
      url: 'http://tanks.wysyt.com/',
      uid: 0,
      case_id: 0,
      join_time: '',
      real_name: '',
      help_amount: 0,
      video_url: '',
      status: 1,
      share_url: ''
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.reqstatu();
    this.setData({
      old_publicity_list: JSON.parse(options.result),
      share_url: options.share_url
    });
    this.aaa();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    var tuid = that.uid;

    if (tuid == 0) {
      uni.showModal({
        title: '启奏陛下',
        content: '请先进行登录',
        success: res => {
          uni.switchTab({
            url: '/pages/my/my'
          });
        }
      });
      return;
    } else {
      return {
        title: '来自好友的一份感谢信，我想对你......',
        //desc: '感谢亿人一家这个大家庭',
        imageUrl: that.share_url,
        path: '/pages/help_publicity_list/help_publicity_list?tuid=' + tuid + '&flag=1' // 路径，传递参数到指定页面。

      };
    }
  },
  methods: {
    aaa() {
      let old_publicity_list = this.old_publicity_list;
      this.setData({
        uid: old_publicity_list.uid,
        case_id: old_publicity_list.case_id,
        join_time: old_publicity_list.join_time,
        real_name: old_publicity_list.real_name,
        help_amount: old_publicity_list.help_amount,
        video_url: old_publicity_list.video_url
      });
    },

    // 屏蔽
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/old_help_publicity/old_help_publicity.wxss */
.publicity_wrap {
  padding: 10rpx;
  border: 1rpx solid #eee;
  box-shadow: 2px 2px 2px 2px #eee;
  border-radius: 8px;
}
.publicity_head {
  text-align: center;
  padding: 20rpx 0;
}
.head_title {
  font-size: 18px;
  font-weight: bold;
}

.wrap {
  padding: 10rpx;
  display: flex;
}

.wrap_num {
  font-size: 16px;
  display: flex;
}
.title {
  width: 100px;
}
.thanks_letter_video {
  position: absolute;
  top: 30%;
}
.myVideo {
  height: 22vh;
  width: 90vw;
  display: inline-block;
  overflow: hidden;
  border-radius: 8px;
  margin: 25rpx;
  box-shadow: 2px 2px 2px #999;
}

.thank_title {
  font-size: 20px;
  font-weight: bold;
  color: #333;
  text-align: center;
}
.wrap_btn {
float: right;
margin: 10rpx;
}
.content_btn {
    border: 1rpx solid #999;
    border-radius: 10px;
    font-size: 13px;
    font-weight: 300;
}
</style>