<template>
<!--pages/apply_bill/apply_bill.wxml-->
<view class="hospital_bill_contener" v-if="status==1">
  <view class="head_title">住院单上传</view>
  <view class="up_bill_wrap" @tap="chooseImageUpload">
    <view class="up_block">
      <image src="/static/images/banner/up.png"></image>
      <view class="head_title">住院单上传</view>
    </view>
  
  </view>
  <view class="hospital_bill">
    <image :src="hospital_img"></image>
  </view>
  <button class="btn-area" @tap="next_help">下一步</button>
</view>
</template>

<script>
// pages/apply_bill/apply_bill.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      uid: 0,
      token: '',
      hospital_img: '',
      bill_img: '',
      case_id: 0,
      status: 1
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();
    this.setData({
      uid: e.uid,
      case_id: e.case_id
    });
  },
  methods: {
    // 上传图片
    chooseImageUpload() {
      var that = this;
      uni.chooseImage({
        count: 1,
        success: res => {
          var src = res.tempFilePaths;

          if (src) {
            var that = this;
            uni.request({
              url: app.globalData.url + 'users/getqntoken',
              method: "POST",

              success(res) {
                that.setData({
                  hospital_img: src,
                  token: res.data.data
                });
                that.uploadQiniu(src);
              }

            });
          }
        }
      });
    },

    /**
    * 图片上传七牛云
    */
    uploadQiniu(tempFilePaths) {
      var that = this;
      let token = that.token;

      if (token != '') {
        uni.uploadFile({
          url: 'https://upload-z2.qiniup.com',
          name: 'file',
          filePath: tempFilePaths[0],
          header: {
            "Content-Type": "multipart/form-data"
          },
          formData: {
            token: token
          },
          success: function (res) {
            if (res.statusCode == 200) {
              let respones_data = JSON.parse(res.data);
              var qiniu_key = respones_data.key;
              that.setData({
                bill_img: qiniu_key
              });
            }
          }
        });
      } else {
        uni.showModal({
          title: '启奏陛下',
          content: '图片上传失败，请稍后重试'
        });
      }
    },

    next_help() {
      var that = this;

      if (that.bill_img == '') {
        uni.showToast({
          title: '请上传您的住院单',
          icon: 'none'
        });
      } else {
        var data = {};
        data["uid"] = that.uid;
        data["case_id"] = that.case_id;
        data["hospital_prove"] = that.bill_img;
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.api_url + 'h5/proposers/saveHospitalProve',
          method: "POST",
          data: {
            data: aesData
          },

          success(res) {
            if (res.data.code == 200) {
              uni.navigateTo({
                url: '/pages/witness/witness?uid=' + that.uid + '&case_id=' + that.case_id
              }); //刷新当前页面
              //that.onShow()
            } else {
              uni.showToast({
                title: res.data.msg,
                icon: 'none'
              });
            }
          }

        });
      }
    },

    // 屏蔽
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/apply_bill/apply_bill.wxss */
.hospital_bill_contener{
  padding: 10rpx;
}
.head_title{
  padding: 20rpx;
}
.up_bill_wrap{

}
.up_block image {
  width: 100%;
  height: 60%;
}
.up_block{
width: 100px;
height: 100px;
border: 1rpx dotted #333;
}
.hospital_bill{
  margin-top: 20rpx;
  width: 100%;
  height: 200px;
}
.hospital_bill image{
  width: 100%;
  height: 100%;
}
.btn-area {
  margin-top: 100px;
  width: 60%;
  background-color: #007bff;
  color: white;
}
</style>