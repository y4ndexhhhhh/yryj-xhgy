<template>
<view>
<!--pages/giftbag/giftbag.wxml-->
<view class="conter">
  <view>
    <!-- <swiper class="gifbag" indicator-dots='true' indicator-color='#000' indicator-active-color='#fff' autoplay='true'>
      <block wx:for="{{mgUrls}}" wx:key='index'>
        <swiper-item>
          <image class="gifbag" data-id='{{index}}' src='{{item}}' catchtap="previewImg"></image>
        </swiper-item>
      </block>
    </swiper> -->
    <image class="gifbag" :src="image_url" @tap.stop="previewImg"></image>
  </view>
  <view class="onadder">{{des}}</view>
  <view class="price">天使专员：
    <text>￥{{price}}</text>
  </view>
  <radio-group class="radig" @change="checkboxChange">
    <radio class="radios" value="3"></radio>
    我已阅读并同意
    <text class="text" @tap.stop="agreement">《合伙人计划》</text>
  </radio-group>
  <!-- <view class='buttons' catchtap="buttons">确定认购</view> -->
  <button class="buttons" @click.stop="buttons" :disabled="disabled">{{pay_name}}</button>
</view>

<view class="hress" :hidden="hidden">
  <view class="titlse">核对收货信息：</view>
  <form class="form" @submit="addressForm">0
    <view>姓名：
      <input type="text" name="relev_name" :value="ifno.real_name"></input>
    </view>
    <view>手机号：
      <input type="text" name="phone" :value="ifno.phone"></input>
    </view>
    <view>收货地址：
      <input type="text" name="relev_adder" :value="ifno.address"></input>
    </view>
    <view class="bents">
      <!-- <text catchtap='updata'>修改</text> -->
      <button form-type="submit" type="primary">确定</button>
    </view>
  </form>
</view>
<view class="ifno" :hidden="ishow">
  <view>收货地址：</view>
  <view>
    <text>真实姓名：</text>
    <input type="text" name="relev_name" @input="onusername" :value="relev_name" placeholder="请输入真实姓名"></input>
  </view>
  <view>
    <text>手机号码：</text>
    <input type="text" name="phone" @input="onphone" :value="phone" placeholder="请输入手机号码"></input>
  </view>
  <view>
    <text>所在城市：</text>
    <input type="text" name="adder" @input="onadder" :value="adder" placeholder="请输入所在城市"></input>
  </view>
  <view>
    <text>详细地址：</text>
    <input type="text" name="adderrs" @input="onadderrs" :value="adderrs" placeholder="请输入详细地址"></input>
  </view>
  <view class="butons">
    <text @tap.stop="onsubmit">确定</text>
  </view>
</view>
</view>
</template>

<script>
// pages/giftbag/giftbag.js
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      gifbag: {},
      mgUrls: [],
      name: '',
      des: '',
      price: '',
      image_url: '',
      indicatorDots: true,
      //小点
      indicatorColor: "white",
      //指示点颜色
      activeColor: "coral",
      //当前选中的指示点颜色
      autoplay: true,
      //是否自动轮播
      interval: 3000,
      //间隔时间
      relev_name: "",
      phone: '',
      adder: '',
      adderrs: '',
      type: '',
      order_flag: '',
      ordie: '',
      stroge: {},
      ifno: {},
      hidden: true,
      ishow: true,
      pay_name: '确认认购',
      disabled: false,
      code: "",
      order_id: "",
      lock: false
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.setData({
      type: e.type,
      order_flag: e.order_flag,
      name: e.name,
      des: e.des,
      price: e.price,
      image_url: e.image_url
    });
    this.getstroge();
    this.getstrogecode(); // this.giftbag();
  },
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    getstrogecode() {
      var that = this;
      const code = uni.getStorageSync('code');
      that.setData({
        code: code
      });
    },

    /*---同意协议---*/
    checkboxChange(e) {
      this.setData({
        ordie: e.detail.value
      });
    },

    // 获取礼包内容
    giftbag() {
      var that = this;
      var data = {};
      data["type"] = 1;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'gift_info/getGiftData',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          that.setData({
            gifbag: res.data.data,
            mgUrls: res.data.data.image_url_json
          });
        }

      });
    },

    /*确定认购*/
    buttons() {
      var that = this;

      if (that.ordie == '') {
        uni.showToast({
          title: '请勾选合伙人计划',
          icon: 'none'
        });
        return false;
      } else {
        that.reqifno();
      }
    },

    /*---认购---*/
    exchange(money) {
      // 登录
      uni.login({
        success: res => {
          this.setData({
            code: res.code
          });
        }
      });
      var that = this;
      // that.reduceAsk();
      var data = {};
      data["uid"] = that.stroge.uid;
      data["type"] = that.type;
      data["order_flag"] = that.order_flag;
      data['amount'] = that.price;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'partner/hhr_order',
        method: "POST",
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            that.setData({
              order_id: res.data.data.order_id
            });
            var data = {};
            // data["code"] = that.code;
            data["total_fee"] = 300;
            data['order_id'] = that.order_id;
            var arr = {
              data: data
            };
            var jsonStr = JSON.stringify(arr);
            var aesData = sha_1.Encrypt(jsonStr);
            uni.request({
              url: app.globalData.url + 'join_project/wx_pay',
              //线上
              //url: app.url + 'notify/local_notify',//线下
              method: "POST",
              data: {
                data: aesData
              },

              success(res) {
                // if (res.data.code == 'ok') {
                  const parameter = res.data;
                  uni.requestPayment({
                    provider: 'wxpay',
                    orderInfo: parameter, //微信、支付宝订单数据
                    success: function (res) {
                      // uni.showModal({
                      //   title: '支付',
                      //   content: '支付成功！',
                      //   success: res => {
                      //     if (res.confirm) {
                      //       that.requid();
                      //       uni.switchTab({
                      //         url: '/pages/index/index'
                      //       });
                      //     }
                      //   }
                      // });
                    }
                  });
                // }
              }

            });
          }
        }

      });
    },

    reqifno() {
      var that = this;
      that.exchange();
    },

    /*---获取收货信息---*/
    reqifno_back() {
      var that = this;

      if (that.stroge.join_status == 1 && that.stroge.real_status == 1) {
        that.setData({
          ifno: that.stroge,
          hidden: false
        });
      } else {
        uni.request({
          url: app.globalData.url + 'partner/delivery_address',
          method: "POST",
          data: {
            uid: that.stroge.uid
          },

          success(res) {
            if (res.data.code == 'ok') {
              that.setData({
                ifno: res.data.data,
                hidden: false
              });
            } else {
              that.setData({
                ishow: false
              });
            }
          }

        });
      }
    },

    /*---确定收货地址---*/
    addressForm(e) {
      var that = this;
      var real_name = e.detail.value.relev_name;
      var phone = e.detail.value.phone;
      var relev_adder = e.detail.value.relev_adder;

      if (real_name === '') {
        uni.showToast({
          title: '姓名不能为空'
        });
        return false;
      }

      if (phone === '') {
        uni.showToast({
          title: '手机号不能为空'
        });
        return false;
      }

      if (relev_adder === '') {
        uni.showToast({
          title: '详细地址不能为空'
        });
        return false;
      }

      uni.request({
        url: app.globalData.url + 'partner/save_address',
        method: "POST",
        data: {
          uid: that.stroge.uid,
          real_name: real_name,
          phone: phone,
          address: relev_adder
        },

        success(res) {
          if (res.data.code == 'ok') {
            uni.showToast({
              title: '收货信息提交成功'
            });
            that.exchange();
          }
        }

      });
    },

    /*---收货地址取消---*/
    updata() {
      this.setData({
        hidden: true,
        ishow: false
      });
    },

    /*---input框中的value值---*/
    onusername(e) {
      this.setData({
        relev_name: e.detail.value
      });
    },

    onphone(e) {
      this.setData({
        phone: e.detail.value
      });
    },

    onadder(e) {
      this.setData({
        adder: e.detail.value
      });
    },

    onadderrs(e) {
      this.setData({
        adderrs: e.detail.value
      });
    },

    /*---收货地址确定---*/
    onsubmit() {
      var that = this;

      if (that.relev_name === '') {
        uni.showToast({
          title: '姓名不能为空',
          icon: 'none'
        });
        return false;
      }

      if (that.phone === '') {
        uni.showToast({
          title: '手机号不能为空',
          icon: 'none'
        });
        return false;
      }

      if (that.adder === '') {
        uni.showToast({
          title: '城市不能为空',
          icon: 'none'
        });
        return false;
      }

      if (that.adderrs === '') {
        uni.showToast({
          title: '详细地址不能为空',
          icon: 'none'
        });
        return false;
      }

      const adder = that.adder;
      const adders = that.adderrs;
      uni.request({
        url: app.globalData.url + 'partner/save_address',
        method: "POST",
        data: {
          uid: that.stroge.uid,
          real_name: that.relev_name,
          phone: that.phone,
          address: `${adder}-${adders}`
        },

        success(res) {
          if (res.data.code == 'ok') {
            uni.showToast({
              title: '收货信息提交成功',
              icon: 'none'
            });
            that.exchange();
          }
        }

      });
    },

    /*---合伙人协议---*/
    agreement() {
      uni.navigateTo({
        url: '/pages/autobiog/autobiog'
      });
    },

    /*图片放大*/
    previewImg(e) {
      let that = this;
      uni.previewImage({
        current: e.currentTarget.dataset.id,
        //当前图片地址
        urls: that.mgUrls //所有要预览的图片的地址集合 数组形式

      });
    },

    //更新缓存
    requid() {
      uni.request({
        url: app.globalData.url + 'users/userinfo',
        method: "POST",
        data: {
          uid: this.stroge.uid
        },

        success(res) {
          uni.setStorageSync('key', res.data.data);
        }

      });
    },

    /*按钮节流*/
    reduceAsk() {
      var _this = this;

      if (!_this.lock) {
        _this.setData({
          lock: true
        });

        var num = 6;
        var timer = setInterval(function () {
          num--;

          if (num <= 0) {
            clearInterval(timer);

            _this.setData({
              pay_name: '确认认购',
              disabled: false
            });
          } else {
            _this.setData({
              pay_name: num + "s" + ' 等待中...',
              disabled: true
            });
          }
        }, 1000);
        setTimeout(function () {
          _this.lock = false;
        }, 5000);
      }
    }

  }
};
</script>
<style>
/* pages/giftbag/giftbag.wxss */
/* banner */
.conter {
  position: relative;
}

.gifbag {
  width: 100%;
  height: 200px;
}

.onadder {
  margin: 20px 20px;
  color: #333;
  font-size: 16px;
}

.price {
  margin: 20px 0 20px 20px;
  color: #333;
  font-size: 14px;
}

.price text {
  color: red;
}

.orders {
  width: 90%;
  margin: auto;
  font-size: 14px;
  color: #333;
  margin-bottom: 80px;
}

.aoder {
  padding: 8px 20px;
  background-color: #fff;
  margin-top: 20px;
  box-shadow: 0 0 5px #ccc;
}

.radig {
  margin: 30px;
  font-size: 12px;
  color: #333;
}

.text {
  color: #0B3FFF;
}

.buttons {
  margin: 100px auto;
  width: 60%;
  line-height: 40px;
  background-color: #0B3FFF;
  text-align: center;
  color: #ffff;
  border-radius: 10px;
}

.hress {
  position: absolute;
  bottom: 0;
  left: 50%;
  margin-left: -160px;
  padding: 40px 20px;
  width: 280px;
  border-radius: 10px;
  background-color: #fff;
  border: 1px solid #eee;
}

.hress view+view {
  margin-top: 20px;
}

.bents {
  display: flex;
  justify-content: space-around;
}

.titlse {
  margin-bottom: 10px;
}

.form view {
  display: flex
}

.form view input {
  border-bottom: 1px solid #eee;
}

.ifno {
  position: absolute;
  bottom: 0;
  left: 50%;
  margin-left: -170px;
  padding: 20px;
  width: 300px;
  background: #fff;
  border-radius: 10px;
  border: 1px solid #eee;
}

.ifno view {
  display: flex;
  padding: 10px 0;
}

.ifno view input {
  width: 220px;
  border-bottom: 1px solid #eee;
}

.butons text {
  padding: 5px 8px;
  margin-left: 90px;
  border: 1px solid #eee;
}
</style>