<template>
<!--pages/apply_help_msg/apply_help_msg.wxml-->
<view class="msg_wrap" v-if="status==1">
  <view class="msg_head">
    <view class="title">审核状态</view>
    <view class="msg_status" v-if="cose_status == 2">审核中,请录制感谢信</view>
    <view class="msg_status" v-else-if="cose_status == 1">公示中</view>
    <view class="msg_status" v-else-if="cose_status == 5">公示已结束</view>
    <view class="msg_status" v-else-if="cose_status == 3">审核不通过</view>
  </view>
  <view class="msg_btn" v-if="cose_status == 1">
    <view class="btns" @tap="go_publicity">查看公示</view>
  </view>
  <view class="msg_btn" v-if="cose_status == 2">
    <view class="text">
      <view class="title">录制指导:</view>
      <view class="content_text">我是xxx(姓名),在亿人一家参与医补计划期间,于xxx(时间)患xxx病，通过线上申请得到了亿人一家的援助,感谢亿人一家这个大平台</view>
    </view>
    <view class="btn" @tap="takePhoto" v-if="is_thanks_letter==0">点我录制感谢信</view>
    <view class="thanks_letter_video" v-else>
      <view class="thank_title">感谢信视频</view>
      <video class="myVideo" :src="url + '' + video_url" show-center-play-btn="true" show-play-btn="true" controls></video>
    </view>
  </view>
  <view class="box" v-if="cose_status == 3">
    <view class="msg_title">审核理由</view>
    <view class="msg_text" v-if="desc!='null'">{{desc}}</view>
    <view class="msg_text" v-else>系统暂未填写，请联系客服</view>
  </view>
</view>
</template>

<script>
// pages/apply_help_msg/apply_help_msg.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      cose_status: 2,
      desc: '',
      uid: 0,
      token: '',
      thank_letter: '',
      letter_video: '',
      is_thanks_letter: 0,
      video_url: '',
      case_id: 0,
      url: 'http://tanks.wysyt.com/',
      status: 1
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();

    if (e != undefined) {
      this.setData({
        uid: e.uid,
        cose_status: e.cose_status,
        desc: e.desc,
        is_thanks_letter: e.is_thanks_letter,
        video_url: e.video_url,
        case_id: e.case_id
      });
    } else {}

    if (e.uid == undefined) {
      let stroge = uni.getStorageSync('key');
      this.setData({
        uid: stroge.uid
      });
    }

    this.get_check_status();
  },
  methods: {
    // 获取审核状态
    get_check_status() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      data["case_id"] = that.case_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.api_url + 'h5/proposers/saveHospitalProve',
        method: "POST",
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {}
        }

      });
    },

    // 调用摄像头进行拍摄
    takePhoto() {
      var that = this;
      uni.chooseVideo({
        sourceType: ['album', 'camera'],
        maxDuration: 60,
        camera: 'back',

        success(res) {
          if (res.size > 20 * 1024 * 1024) {
            uni.showModal({
              content: '请上传小于20M的视频文件，您当前要上传的文件大小为' + (res.size / (1024 * 1024)).toFixed(2) + "M"
            });
            return;
          }

          var src = res.tempFilePath;
          uni.request({
            url: app.globalData.url + 'users/getTanksQiniutoken',
            method: "POST",

            success(res) {
              that.setData({
                thank_letter: src,
                token: res.data.data
              });
              that.uploadQiniu(src);
            }

          });
        }

      });
    },

    /**
    * 图片上传七牛云
    */
    uploadQiniu(tempFilePaths) {
      var that = this;
      let token = that.token;

      if (token != '') {
        uni.uploadFile({
          url: 'https://upload-z2.qiniup.com',
          name: 'file',
          filePath: tempFilePaths,
          header: {
            "Content-Type": "multipart/form-data"
          },
          formData: {
            token: token
          },
          success: function (res) {
            if (res.statusCode == 200) {
              let respones_data = JSON.parse(res.data);
              var qiniu_key = respones_data.key;
              var data = {};
              data["uid"] = that.uid;
              data["case_id"] = that.case_id;
              data["video_url"] = qiniu_key;
              var arr = {
                data: data
              };
              var jsonStr = JSON.stringify(arr);
              var aesData = sha_1.Encrypt(jsonStr);
              uni.request({
                url: app.globalData.api_url + '/h5/proposers/saveTanksLetters',
                method: "POST",
                data: {
                  data: aesData
                },

                success(res) {
                  if (res.data.code == 200) {
                    uni.showToast({
                      title: res.data.msg,
                      icon: 'none'
                    });
                    that.setData({
                      is_thanks_letter: 1,
                      video_url: qiniu_key
                    });
                  } else {
                    uni.showToast({
                      title: res.data.msg,
                      icon: 'none'
                    });
                  }
                }

              });
            }
          }
        });
      } else {
        uni.showModal({
          title: '启奏陛下',
          content: '视频上传失败，请稍后重试'
        });
      }
    },

    // 查看公示事件
    go_publicity() {
      uni.navigateTo({
        url: '/pages/help_publicity_list/help_publicity_list?uid=' + this.uid
      });
    },

    // 屏蔽
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/apply_help_msg/apply_help_msg.wxss */
.msg_wrap {
  padding: 10rpx;
}

.msg_head {
  border: 1rpx solid #eee;
  border-radius: 8px;
  box-shadow: 2px 2px 2px #eee;
  display: flex;
}

.title {
  padding: 10rpx;
  font-size: 18px;
  font-weight: 700;
}

.msg_status {
  margin-left: auto;
  padding: 10rpx;
  color: #00CD00;
}

.msg_btn {
  color: #fff;
}

.btn {
  position: fixed;
  bottom: 50%;
  left: 22%;
  width: 50%;
  text-align: center;
  border: 1rpx solid #eee;
  border-radius: 8px;
  box-shadow: 1px 1px 1px cornflowerblue;
  padding: 20rpx;
  background-color: cornflowerblue;
}

.box {
  position: absolute;
  top: 50%;
  width: 100%;
}

.msg_title {
  font-size: 18px;
  font-weight: bold;
  padding: 10rpx;
}

.msg_text {
  width: 90%;
  height: 100px;
  text-indent: 2em;
  border: 1rpx solid #eee;
  border-radius: 8px;
  box-shadow: 2px 2px 2px #eee;
  margin: 20rpx;
}

.conse image {
  width: 90vw;
  display: inline-block;
  overflow: hidden;
}

.myVideo {
  height: 22vh;
  width: 90vw;
  display: inline-block;
  overflow: hidden;
  border-radius: 8px;
  margin: 25rpx;
  box-shadow: 2px 2px 2px #999;
}

.thank_title {
  font-size: 20px;
  font-weight: bold;
  color: #333;
  text-align: center;
}

.thanks_letter_video {
  position: absolute;
  top: 42%;
}
.btns {
  position: fixed;
  bottom: 40%;
  left: 22%;
  width: 50%;
  text-align: center;
  border: 1rpx solid #eee;
  border-radius: 8px;
  box-shadow: 1px 1px 1px cornflowerblue;
  padding: 20rpx;
  background-color: cornflowerblue;
}
.text{
  border: 1rpx solid #999;
  color: #333;
  padding: 10rpx;
  margin-top: 50px;
  border-radius: 8px;
  box-shadow: 2px 2px 2px #eee;
}
.content_text{
  text-indent: 2em;
  padding:0 10rpx;
}
</style>