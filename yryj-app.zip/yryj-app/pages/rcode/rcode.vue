<template>
<!--pages/rcode/rcode.wxml-->
<view class="conter">
  <view class="wrap">
    <image :src="qrcode + '' + uid"></image>
  </view>
</view>
</template>

<script>
// pages/rcode/rcode.js
const app = getApp();

export default {
  data() {
    return {
      qrcode: app.globalData.url + '/hhr/create_qrcode?uid=',
      uid: ''
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    // this.setData({
    //   uid: e.uid
    // })
    this.getstroge();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        uid: stroge.uid
      });
    }

  }
};
</script>
<style>
/* pages/rcode/rcode.wxss */
.conter {
  text-align: center;
}

.wrap {
  margin: 140px auto 20px;
  width: 60%;
  height: 180px;
}

.wrap image {
  width: 100%;
  height: 100%;
}
</style>