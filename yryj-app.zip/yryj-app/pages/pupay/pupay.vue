<template>
<!--pages/pupay/pupay.wxml-->
<view class="conter" v-if="status==1">
  <view class="putop">
    <view class="conpany">
      注册合伙人：
    </view>
    <view>
      支付金额：
      <text class="money">{{money}}</text>
    </view>
    <view class="gufen">
      认购股份:
      <input type="text" @input="shares" :placeholder="'最低' + min_stock + '股'"></input>
    </view>
    <view class="title">每股{{unit}}元人民币</view>
  </view>
  <radio-group class="radig" @change="checkboxChange">
    <radio class="radios" value="3"></radio>
    我已阅读并同意<text class="text" @tap.stop="agreement">《合伙人计划》</text>
  </radio-group>
  <!-- <view class='buttons' catchtap="buttons">确认支付</view> -->
  <button class="buttons" @tap.stop="buttons" :disabled="disabled">{{pay_name}}</button>
</view>
</template>

<script>
// pages/pupay/pupay.js
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      stroge: {},
      ordie: '',
      type: '',
      order_flag: '',
      unit: "",
      min_stock: "",
      share: '',
      money: 0,
      code: '',
      order_id: '',
      code: '',
      pay_name: '确认支付',
      disabled: false,
      status: 1,
      lock: false
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();
    this.setData({
      type: e.type,
      order_flag: e.order,
      unit: e.unit,
      min_stock: e.min_stock
    });
    this.getstroge();
    this.getstrogecode();
  },

  onShow() {},

  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    getstrogecode() {
      var that = this;
      const code = uni.getStorageSync('code');
      that.setData({
        code: code
      });
    },

    /*---亿积分兑换---*/
    exchange(money) {
      var that = this;
      // that.reduceAsk();
      var data = {};
      data["uid"] = that.stroge.uid;
      data["type"] = that.type;
      data["order_flag"] = that.order_flag;
      data['amount'] = money;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'partner/hhr_order',
        method: "POST",
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            that.setData({
              order_id: res.data.data.order_id
            });
            var data = {};
            // data["code"] = that.code;
            data["total_fee"] = money;
            data['order_id'] = that.order_id;
            var arr = {
              data: data
            };
			console.log(that.order_id,"data")
            var jsonStr = JSON.stringify(arr);
            var aesData = sha_1.Encrypt(jsonStr);
            uni.request({
              url: app.globalData.url + 'join_project/wx_pay',
              // url: app.url + 'notify/local_notify',
              method: "POST",
              data: {
                data: aesData
              },

              success(res) {
                // if (res.data.code == 'ok') {
                  const parameter = res.data;
                  uni.requestPayment({
                    provider: 'wxpay',
                    orderInfo: parameter, //微信、支付宝订单数据
                    success: function (res) {
                      // uni.showModal({
                      //   title: '支付',
                      //   content: '支付成功！',
                      //   success(res) {
                      //     if (res.confirm) {
                      //       uni.switchTab({
                      //         url: '/pages/index/index'
                      //       });
                      //     }
                      //   }

                      // });
                    }
                  });
                // }
              }

            });
          }
        }

      });
    },

    shares(e) {
      this.setData({
        share: e.detail.value
      });
    },

    /*---同意协议---*/
    checkboxChange(e) {
      this.setData({
        ordie: e.detail.value
      });
    },

    /*---支付---*/
    buttons() {
      var that = this;

      if (that.share == '') {
        uni.showToast({
          title: '请输入认购股数'
        });
        return false;
      } else if (that.share < this.min_stock) {
        uni.showToast({
          title: '不能小于' + this.min_stock
        });
        return false;
      }

      if (that.ordie == '') {
        uni.showToast({
          title: '请勾选会员公约'
        });
        return false;
      } else {
        // 登录
        uni.login({
          success: res => {
            this.setData({
              code: res.code
            });
          }
        });
        const money = Math.round(that.share * that.unit);
        that.setData({
          money: money
        });
        that.exchange(money);
      }
    },

    /*---合伙人协议---*/
    agreement() {
      uni.navigateTo({
        url: '/pages/autobiog/autobiog'
      });
    },

    /*按钮节流*/
    reduceAsk() {
      var _this = this;

      if (!_this.lock) {
        _this.setData({
          lock: true
        });

        var num = 6;
        var timer = setInterval(function () {
          num--;

          if (num <= 0) {
            clearInterval(timer);

            _this.setData({
              pay_name: '确认支付',
              disabled: false
            });
          } else {
            _this.setData({
              pay_name: num + "s" + ' 等待中...',
              disabled: true
            });
          }
        }, 1000);
        setTimeout(function () {
          _this.lock = false;
        }, 5000);
      }
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/pupay/pupay.wxss */
page {
  background-color: #F4F4F4;
}

.putop {
  padding: 30px 15px;
  background-color: #fff;
}

.putop .money {
  color: #FF9797;
}

.conpany {
  margin-bottom: 10px;
}

.gufen {
  display: flex;
  margin-top: 20px;
}

.gufen input {
  width: 250px;
  margin-left: 12px;
  border-bottom: 1px solid #eee;
}

.title {
  margin-top: 20px;
  font-size: 12px;
  color: #999;
  line-height: 20px;
}

.radig {
  margin: 30px;
  font-size: 12px;
  color: #333;
}

.text {
  color: #0B3FFF;
}

.buttons {
  margin: 200px auto;
  width: 60%;
  line-height: 40px;
  background-color: #0B3FFF;
  text-align: center;
  color: #ffff;
  border-radius: 10px;
}
</style>