<template>
	<!--pages/rqcode/rqcode.wxml-->
	<view class="content">
		<view class="boxslist">
			<image src="../../static/images/my/bg.png" style="width: 100%" mode="widthFix"></image>
			<view class="boxtext">
				<!-- <image src="/static/images/my/downUP.png" mode="aspectFit" class="codeImgs" @click="getBig"></image> -->
				<view class="items">
					<text>我的邀请码:</text>
					<text>{{stroge.uid}}</text>
					<view class="sgins" @click="copy">
						<text>复制</text>
					</view>
				</view>
				<view class="btnBox" @click="onShare">
					<text>立即邀请</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// pages/share/share.js
	const app = getApp();
	var util = require("../../utils/util.js"),
		sha_1 = require("../../utils/sha_1.js");
	import appShare, {
		closeShare
	} from "@/js_sdk/zhouWei-APPshare/plugins/share/index.js"
	export default {
		data() {
			return {
				uid: '',
				stroge: ""
			};
		},

		components: {},
		props: {},
		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			this.getstroge();
		},


		methods: {
			getBig() {
				console.log('1111')
				uni.previewImage({
					current:0, //预览图片的下标
					urls:['/static/images/my/downUP.png']
				});
			},
			copy() {
				uni.setClipboardData({
					data: this.stroge.uid,
					success: function() {
						uni.showToast({
							title: '复制成功',
							icon: 'none'
						})
					}
				});
			},
			onShare() {
				let shareData = {
					shareUrl: "https://app01.wysyt.com/index/activity/yaoqinghan.html?uid=" + `${this.stroge.uid}`, // 分享地址
					shareTitle: "亿人一家", // 分享标题
					shareContent: "亿人计划——利用互联网强大的网络协同效应，有效解决社会大量人群因病致贫/返贫这一痛点问题而搭建的服务版块，极大降低社会成本及每个参与者的成本。旨在用互联网的方式解决参与会员因意外或疾病而发生的需要个人承担部分的医疗费用问题。", //分享描述
					shareImg: "https://swsdl.vivo.com.cn/appstore/developer/icon/20180810/201808101152462406707.jpg", // 分享 图片网络连接
				};
				// 调用
				let shareObj = appShare(shareData, res => {
					// 分享成功后关闭弹窗
					// 第一种关闭弹窗的方式
					closeShare();
				});
				setTimeout(() => {
					// 第二种关闭弹窗的方式
					shareObj.close();
				}, 5000);
			},
			//获取本地数据
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				that.setData({
					stroge: stroge
				});
			}

		}
	};
</script>
<style lang="scss" scoped>
	page {
		width: 100%;
		height: 100vh;
	}

	.content {
		width: 100%;
		height: 100vh;
		display: flex;
		justify-content: center;
		align-items: flex-start;

		.boxslist {
			width: 100%;
			height: auto;

			.bgImgs {
				width: 100%;
				height: 100%;
			}

			.boxtext {
				width: 100%;
				min-height: 300rpx;
				// background-color: #FFFFFF;
				bottom: -460rpx;
				position: absolute;
				left: 0;

				.codeImgs {
					width: 140rpx;
					height: 140rpx;
					// background-color: #f40;
					margin: 0 auto;
					display: block;
				}

				.items {
					width: 100%;
					height: 60rpx;
					display: flex;
					justify-content: center;
					align-items: center;

					text {
						font-size: 32rpx;
						font-family: PingFang SC;
						font-weight: 400;
						// line-height: 24px;
						color: #FFFFFF;
						opacity: 1;
						margin-right: 15rpx;
					}

					.sgins {
						width: 100rpx;
						height: 52rpx;
						border: 2rpx solid #FFFFFF;
						opacity: 1;
						border-radius: 26rpx;
						text-align: center;

						text {
							font-size: 32rpx;
							font-family: PingFang SC;
							font-weight: 400;
							line-height: 52rpx;
							color: #FFFFFF;
							opacity: 1;
						}
					}
				}

				.btnBox {
					width: 686rpx;
					height: 120rpx;
					margin: 50rpx auto 0;
					background: #FFFFFF;
					opacity: 1;
					border-radius: 60rpx;
					display: flex;
					justify-content: center;
					align-items: center;

					text {
						font-size: 44rpx;
						font-family: PingFang SC;
						font-weight: bold;
						line-height: 44rpx;
						color: #FD4430;
						opacity: 1;
					}
				}
			}
		}

	}
</style>
