<template>
<!--pages/msg/msg.wxml-->
<view class="containe">
  <navigator v-for="(item, index) in messagelist" :key="index" open-type="navigate" :url="'/pages/msgdetail/msgdetail?message_id=' + item.message_id">
    <view class="policy_containe">
      <view class="content">
        <view class="policy_title_containe">{{item.title}}</view>
        <view class="box">
          <view class="policy_read">
            <view v-if="item.is_read ==1">已读</view>
            <view v-else>未读</view>
          </view>
          <view class="polic_make_time">
            <text>推送时间：</text>
            <view class="time">{{item.add_time}}</view>
          </view>
        </view>
      </view>
    </view>
  </navigator>
</view>
</template>

<script>
// pages/msg/msg.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      page: 0,
      messagelist: [],
      list: '',
      uid: 0,
      stroge: false
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getstroge();
    this.getmessagelistList();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  // 监听用户上拉触底事件。
  onReachBottom() {
    var page = this.page + 1; //获取当前页数并+1

    this.setData({
      page: page //更新当前页数

    });
    this.getmessagelistList();
  },

  // 监听用户下拉刷新时间
  onPullDownRefresh() {
    // 重置数组
    this.setData({
      messagelist: []
    }); // 重置页码

    var page = 0;
    this.setData({
      page: page //更新当前页数

    }); // 重新发送请求

    this.getmessagelistList();
  },

  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');

      if (stroge == '') {
        that.setData({
          stroge: false
        });
      } else {
        that.setData({
          stroge: stroge,
          uid: stroge.uid
        });
      }
    },

    // 获取消息数据
    getmessagelistList() {
      var that = this;
      var data = {};
      data["uid"] = that.stroge.uid;
      data["page"] = that.page;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'message_info/getMessageList',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            let list = res.data.data;

            if (that.page == 0) {
              that.setData({
                messagelist: list
              });
            } else {
              //获取下拉刷新之前的list数据
              let old_data = that.messagelist; //arr  代表page+1  新数据

              that.setData({
                messagelist: old_data.concat(list)
              });
            }
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none'
            });
            uni.stopPullDownRefresh();
          }
        }

      });
    }

  }
};
</script>
<style>
page {
  height: 100%;
}

.containe {
  height: 100%;

}

.policy_containe {
  padding: 20rpx;
  border-bottom: 1px solid #eee;
}

.policy_title_containe {
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;

}

.policy_read {
  display: flex;
  font-size: 22rpx;
}

.nums {
  display: flex;
  flex-direction: column;
  margin-left: 50rpx;
}

.polic_make_time {
  display: flex;
  font-size: 22rpx;
  margin-left: auto;
}

.box {
  display: flex;
  margin-top: 30rpx;
}

</style>