<template>
<!--pages/autobiog/autobiog.wxml-->
<web-view src="https://app01.wysyt.com/xcxapi/service/faq_article.html?id=50"></web-view>
</template>

<script>

export default {
  data() {
    return {};
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},
  methods: {}
};
</script>
<style>
/* pages/autobiog/autobiog.wxss */
</style>