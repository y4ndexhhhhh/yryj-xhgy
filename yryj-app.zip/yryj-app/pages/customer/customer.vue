<template>
	<!--pages/customer/customer.wxml-->
	<view class="conter">
		<!-- <scroll-view scroll-y="true" style="height:1000px;"> -->
		<!--  <view v-if="status==1">
    <view v-for="(item, index) in msg" :key="index" class="head" @click="onhead(index)" >
      <view>{{item.msg}}</view>
      <view class="lg"></view>
    </view>
  </view> -->
		<!--  <view v-else class="head">
    <view class="head" @tap.stop="yirenyija">
      <view>什么是亿人一家？</view>
      <view class="lg"></view>
    </view>
    <view class="head" @tap.stop="yijifen">
      <view>什么是亿积分？</view>
      <view class="lg"></view>
    </view>
  </view> -->
		<!--  <view class="kefubtn">
    <button class="cs_button" open-type="contact" session-from="weapp" :hidden="!floorstatus">
      <image class="cs_image" src="/static/images/banner/33.png"></image>
      <view class="kefu">在线客服</view>
    </button>
  </view> -->
		<!-- </scroll-view> -->
		<view class="itemsBox" v-for="(item,index) in msg" v-if="status==1"  @click="onhead(index,item.msg)">
			<view class="itemLeft">
				<text>{{index+1}}:{{item.msg}}</text>
			</view>
			<view class="itemRight">
				<image src="/static/images/my/arrow_right.png" mode="" class="imgs"></image>
			</view>
		</view>
	<!-- 
		<view class="radioBox">
			<image src="" mode="" class="img"></image>
		</view> -->
	</view>
</template>

<script>
	// pages/customer/customer.js
	const app = getApp();

	export default {
		data() {
			return {
				msg: [{
					msg: '什么是亿人一家？'
				}, {
					msg: '什么是“医补计划”？'
				}, {
					msg: '加入“医补计划”的条件？'
				}, {
					msg: '申请援助需要满足那些条件？'
				}, {
					msg: '什么是增值积分？'
				}, {
					msg: '如何长期享受医补计划？'
				}, {
					msg: '智能合约是什么？'
				}],
				status: '',
				floorstatus: true
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			this.reqstatu();
		},
		methods: {
			onhead(prop,val) {
				let id = prop;
				uni.navigateTo({
					url: '/pages/cust/cust?id=' + `${id}`+ "&val=" + `${val}`
				});
			},

			reqstatu() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'shield/getShield',
					method: "POSt",
					data: {
						version_code: app.globalData.version_code
					},
					success(res) {
						console.log(res)
						that.setData({
							status: res.data.data.status
						});
					}

				});
			},

			yirenyija() {
				uni.navigateTo({
					url: '/pages/compan/compan'
				});
			},

			yijifen() {
				uni.navigateTo({
					url: '/pages/ceshi/ceshi'
				});
			} // // 获取滚动条当前位置
			// onPageScroll: function (e) {
			//   console.log(e)
			//   if (e.scrollTop > 100) {
			//     this.setData({
			//       floorstatus: true
			//     });
			//   } else {
			//     this.setData({
			//       floorstatus: false
			//     });
			//   }
			// },


		}
	};
</script>
<style lang="scss" scoped>
	/* pages/customer/customer.wxss */

	.itemsBox{
		width: 100%;
		height: 118rpx;
		background-color: #FFFFFF;
		border-top: 2rpx solid #EFEFEF;
		padding: 0 30rpx;
		box-sizing: border-box;
		display: flex;
		justify-content: space-between;
		align-items: center;
		.itemLeft{
			width: 630rpx;
			height: 118rpx;
			// background-color: #F0AD4E;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			text{
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 24rpx;
				color: #333333;
				opacity: 1;
			}
		}
		.itemRight{
			width: 40rpx;
			height: 110rpx;
		    display: flex;
			justify-content: flex-end;
			align-items: center;
			.imgs{
				width: 12rpx;
				height: 24rpx;
			    // background-color: #f40;
			}
		}
	}
	.radioBox{
		width: 120rpx;
		height: 120rpx;
		background: #6386FA;
		border-radius: 50%;
		opacity: 1;
		position: fixed;
		right: 50rpx;
		bottom: 100rpx;
	    display: flex;
		justify-content: center;
		align-items: center;
		.img{
			width: 78rpx;
			height: 78rpx;
				margin: 0 auto;
			background-color: #f40;
		}
	}
</style>
