<template>
<!--pages/mdsucerr/mdsucerr.wxml-->
<!-- 展示部分 -->
<view class="myadds">
  <view>真实姓名：{{stroge.real_name}}</view>
  <view>联系方式：{{stroge.phone}}</view>
  <view>身份证号：{{stroge.id_card}}</view>
<!--  <view>所在地区：{{b}}</view> -->
  <view>详细地址：{{a}}</view>
  <!-- <button class='share' catchtap="onshar">修改资料</button> -->
</view>
</template>

<script>

export default {
  data() {
    return {
      stroge: {},
      //本地缓存数据
      a: '',
      b: '',
      hinder: false
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getstroge();
  },

  onShow() {
    this.onLoad();
  },

  methods: {
    getstroge() {
      const stroge = uni.getStorageSync('key');
	  console.log(stroge)
      this.setData({
        stroge: stroge,
        a: stroge.address
      });

      if (stroge.real_status == 2) {
        this.setData({
          hinder: true
        });
      }

      const siptes = this.a.split('-');
      this.setData({
        a: siptes[0],
        b: siptes[1]
      });
    },

    /*---修改资料---*/
    onshar() {
      uni.navigateTo({
        url: '/pages/edit/edit'
      });
    }

  }
};
</script>
<style>
/* pages/mdsucerr/mdsucerr.wxss */
/* 展示部分 */
.myadds {
  width: 80%;
  margin: 50px auto;
  text-align: center;
}

.myadds view {
  margin-top: 30px;
  text-align: left;
  color: #333;
  font-size: 14px;
}

.share {
  margin-top: 60px;
  width: 80%;
  color: #fff;
  background-color: #0B3FFF;
}
</style>