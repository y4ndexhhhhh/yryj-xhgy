<template>
<!--pages/equity/equity.wxml-->
<view class="wrap">
  <view class="pageBox pageOne">
    <view class="list">
      <swiper indicator-dots="true" indicator-color="#000" indicator-active-color="#fff" autoplay="true" :current="current" @change="swiperChange">
        <block :key="index">
          <swiper-item @tap="swiperclick">
            <image src="/static/images/banner/share2.jpg"></image>
          </swiper-item>
          <swiper-item @tap="swiperclick">
            <image src="/static/images/banner/share1.jpg"></image>
          </swiper-item>
          <swiper-item @tap="swiperclick">
            <image src="/static/images/banner/share.jpg"></image>
          </swiper-item>
        </block>
      </swiper>
    </view>
  </view>
  <view class="text_wrap">
    <view class="text_title">
      <text>权益说明</text>
    </view>
    <view class="text_content">
      <view>1、首次充值10元或签订银联代收协议即可成为“医补计划”会员，会员根据系统机制正当享有获得援助的权益。</view>
      <view class="item">2、购买10元/月VIP会员，可享受“医补计划”单月免续费、单月免费制做“电子自传”权益。</view>
      <view>3、购买89元/年VIP会员，可享受“医补计划”全年免续费权益、全年电子自传免费制做、全年免费“太极瑜伽”学习的权益。</view>
    </view>
  </view>
  <view class="btn">
    <!-- <view class='btns' catchtap="aplay" disabled='{{disabled}}'>购买权益</view> -->
    <button class="btns" @tap.stop="aplay" :disabled="disabled">{{pay_name}}</button>
  </view>
</view>
</template>

<script>
// pages/equity/equity.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      showModal: false,
      current: 0,
      equity_money: 0,
      pay_name: '购买权益',
      disabled: false,
      ordie: '',
      code: '',
      uid: '',
      openid: '',
      order_id: '',
      lock: false,
      shouw: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    if (e.uid != undefined) {
      this.setData({
        uid: e.uid,
        openid: ''
      });
    } else {
      this.getstroge();
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');

      if (stroge.uid != undefined) {
        that.setData({
          uid: stroge.uid,
          openid: ''
        });
      }
    },

    shouwFun(e) {
      this.setData({
        shouw: e.detail.value
      });
    },

    hideMask: function () {
      this.setData({
        showModal: false
      });
    },
    preventTouchMove: function () {},
    close_mask: function () {
      this.setData({
        showModal: false
      });
    },

    swiperChange(e) {
      this.setData({
        current: e.detail.current
      });
    },

    // 微信支付
    aplay() {
      var that = this;

      if (that.current == 0 || that.current == 1) {
        that.setData({
          equity_money: 10
        });
      } else {
        that.setData({
          equity_money: 89
        });
      }

      uni.navigateTo({
        url: '/pages/paytype/paytype?uid=' + this.uid + '&money=' + that.equity_money
      });
    },

    //向服务器下单
    makeOrder() {
      var that = this;
      var equity_money = that.equity_money;

      if (equity_money) {
        var data = {};
        data["uid"] = that.uid;
        data['amount'] = equity_money;
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.url + 'join_project/recharge',
          method: "POST",
          data: {
            data: aesData
          },
          success: res => {
            if (res.data.code == 'ok') {
              that.wakeWxPay(res.data.data.order_id);
            } else {
              uni.showToast({
                title: '订单生成失败，请重试',
                icon: 'none'
              });
            }
          }
        });
      } else {
        uni.showToast({
          title: '充值金额获取失败，请重试',
          icon: 'none'
        });
      }
    },

    //唤醒微信支付
    wakeWxPay(order_id) {
      var that = this;
      uni.login({
        success: res => {
          var data = {};
          data["code"] = res.code;
          data["uid"] = that.uid;
          data['order_id'] = order_id;
          var arr = {
            data: data
          };
          var jsonStr = JSON.stringify(arr);
          var aesData = sha_1.Encrypt(jsonStr);
          uni.request({
            // url: app.url + 'join_project/xcx_wx_pay',
            url: app.globalData.url + 'join_project/xcx_pay',
            method: "POST",
            data: {
              data: aesData
            },
            success: res => {
              if (res.data.code == 'ok') {
                const parameter = res.data.data;
                uni.requestPayment({
                  timeStamp: parameter.timeStamp,
                  nonceStr: parameter.nonceStr,
                  package: parameter.package,
                  signType: parameter.signType,
                  paySign: parameter.paySign,
                  success: res => {
                    uni.showModal({
                      title: '支付',
                      content: '支付成功',
                      success: res => {
                        uni.navigateBack({
                          //返回
                          delta: 1
                        });
                      }
                    });
                  }
                });
              }
            }
          });
        }
      });
    },

    /*按钮节流*/
    reduceAsk() {
      var _this = this;

      if (!_this.lock) {
        _this.setData({
          lock: true
        });

        var num = 6; //6秒后可以再次点击

        var timer = setInterval(function () {
          num--;

          if (num <= 0) {
            clearInterval(timer);

            _this.setData({
              pay_name: '购买权益',
              disabled: false
            });
          } else {
            _this.setData({
              pay_name: num + "s" + ' 等待中...',
              disabled: true
            });
          }
        }, 1000);
        setTimeout(function () {
          _this.lock = false;
        }, 5000);
      }
    }

  }
};
</script>
<style>
/* pages/treaty/treaty.wxss */
page {
  height: 100%;
}



.btns {
  background: #007bff;
  color: #eee;
  border-radius: 10px;
  line-height: 40px;
  width: 60%;
}

.pageOne swiper {
  width: 750rpx;
  height: 800rpx;
}

.pageOne swiper-item {
  padding-top: 50rpx;
}

.pageOne image {
  width: 80%;
  height: 90%;
  display: flex;
  justify-content: space-around;
  margin-left: 40px;
}

.pageOne image.active {
  transform: scale(1.14);
  transition: all .2s ease-in 0s;
}

.btn {
  position: fixed;
  bottom: 0;
  left: 0;
  padding: 10rpx;

  text-align: center;
  width: 100%;
  border-top: 1rpx solid #ccc;
}

.text_wrap {
  font-size: 27rpx;
  padding: 1rpx;
}

.text_content {
  line-height: 1.3rem;
}
</style>