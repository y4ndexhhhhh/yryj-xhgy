<template>
<!--pages/cust/cust.wxml-->
	<view>
		<page-meta>
		    <navigation-bar :title="title" :backgroundColor="'#0B3FFF'" :front-color="'#ffffff'"></navigation-bar>
		  </page-meta>
		<text class="text" v-if="arrList.length > 0">{{arrList[id]}}</text>
	</view>
<!-- <web-view :src="'https://app01.wysyt.com/xcxapi/service/faq_article.html?id='+id"></web-view> -->
</template>

<script>
 
export default {
  data() {
    return {
      id: '',
	  title: "",
	  arrList: [
		  ` 亿人一家是拓元科技搭建并运维的一个云端服务平台，专注于解决社会突出痛点问题，包括但不限于疾病、住房、债务、养老等。
			平台共分为以下六个基础服务板块。
			医补计划：打通医保最后一公里，实现医有所保。
			大爱行动：探索公益与商业的深度融合，实现人人公益。
			健康银行：解决医院资源发展不均衡问题，实现病有所医。
			数字超市：寻求消费购买力不足原由，实现免费购物。
			时空隧道：解决互联网无法承载价值难题，实现碎片时间有效转化价值。
			个人定义：解决供给需求不对称，实现按需生产。`,
		  ` 医补计划是一项针对会员因病就医产生的医疗费用差额援助计划。 
			一、会员累计签到90次援助医保自付部分；
			二、会员累计签到180次援助医疗自费部分。`,
		  ` 医补计划”是一项面向全民开放的医疗互助计划，凡是具有中华人民共和国国籍的中国公民均可参与，没有年龄限制、没有行业限制、没有健康限制，可带病加入。

			温馨提示：由于医补计划是建立在国家医保基础上的援助，援助申请目前只针对具有中国医保的公民。港澳台由于医保政策的差异暂未纳入到加入范畴。`,
		  ` 1、因病产生的医疗费用符合医保报销条件但未被全额报销的。
			2、完成实名加入会员且累计签到大于90次小于想180次的，患病住院可申请医保自付费用援助。大于180次的可申请医疗自费费用援助。
			3、持有中华人民共和国社会保障卡的。
			4、持有亿人一家智能合约的。`,
		  ` 增值积分是系统内部限量发行和流通的一种锚定在系统总收益基础上的加密数字积分，由于其数量限定，所以随着系统总收益的不断增加单位积分的价格就会逐步增加，总趋势呈单边上扬的增长曲线。随着系统其他服务板块的陆续开放会涉及到它的广泛应用。 
		  
			用途：当前可直接用于兑换、兑换合伙人资质、兑换期权、兑换现金。
			
			获取办法：当前系统推出限时活动，合伙人（天使合伙人、注册合伙人）每成功推荐一位新会员奖励1个增值积分；推荐一个新合伙人加入，奖励10个增值积分。
			
			温馨提示：
				一、增值积分的首期发行总量为100万个，单位价格为10元。
				二、增值积分只能通过做任务获取，不能用现金购买。
				三、增值积分仅支持系统回购，不支持会员互相转让。 `,
		  ` 1、为了保证援助的持续性和公平性，系统设定会员个人账户余额需≥100积分。
			2、个人帐户余额不足以当期划扣且在72小时内仍未处理的，会员援助会受影响、等待期归零。需重新计算等待期，原会员资格保留。`,
		  ` 一、智能合约是系统内置了动态二维码的纸质协议，是会员申请援助的必要条件，会员在申请援助时需要在线扫码与系统审核后台建立连接，根据提示输入相关信息再经加密后供后端审核人员核实就医信息的真实性。
			二、智能合约同时也作为会员加入“医补计划”的纸质法律文书，保障会员享有正当权益。`
		 
	  ]
    };
  },
  
  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
	console.log(e,"KKKK")
	this.id = e.id;
	this.title = e.val;
	// this.reqstatu(this.id)
  },
  methods: {
	  reqstatu(id) {
	  	var that = this;
	  	uni.request({
	  		url:'https://app01.wysyt.com/xcxapi/service/faq_article.html?id='+id ,
	  		method: "get",
	  		data: {
	  			
	  		},
	  		success(res) {
	  			that.setData({
	  				// status: res.data.data.status
	  			});
	  		}
	  
	  	});
	  },
  }
};
</script>
<style scoped>
/* pages/cust/cust.wxss */
.text {
	width: 90%;
	margin: auto;
	display: block;
	margin-top: 30rpx;
	line-height: 80rpx;
}
</style>