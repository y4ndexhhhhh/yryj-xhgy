<template>
<!--pages/rqcode/rqcode.wxml-->
<view class="conter">
  <view class="back">
    <image src="/static/images/banner/back.png"></image>
  </view>
  <view class="down">
    <h1>奖励规则</h1>
    <view class="conin">
      <view>1、每成功邀请一位新人加入，你和他
        （她）各获得一个亿积分奖励。</view>
      <view>注：一个亿积分可以冲抵一天等待期</view>
    </view>
    <button class="share" open-type="share">立即推荐</button>
  </view>

</view>
</template>

<script>
// pages/share/share.js
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      uid: '',
      stroge: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getstroge();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    var data = {};
    data["uid"] = that.stroge.uid;
    data['type'] = 3;
    var arr = {
      data: data
    };
    var jsonStr = JSON.stringify(arr);
    var aesData = sha_1.Encrypt(jsonStr);
    uni.request({
      url: app.globalData.url + 'partner/share_award',
      method: "POST",
      data: {
        data: aesData
      },

      success(res) {}

    });
    return {
      title: '分享有礼',
      //desc: '分享页面的内容',
      path: '/pages/index/index?tuid=' + that.stroge.uid // 路径，传递参数到指定页面。

    };
  },
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    }

  }
};
</script>
<style>
/* pages/share/share.wxss */
.back {
  width: 100%;
  height: 50vh;
}

.back image {
  width: 100%;
  height: 100%;
}

.down {
  padding-top: 30px;
  width: 100%;
  height: 50vh;
  text-align: center;
  background-color: #1677F5;
}

.down h1 {
  color: #fff;
  font-size: 18px;
}

.conin {
  margin: auto;
  width: 70%;
  padding: 20px;
  background-color: #55CFF7;
  opacity: .8;
  border-radius: 10px;
}

.conin view {
  color: #fff;
  font-size: 14px;
  text-align: left;
}

.conin view+view {
  margin-top: 20px;
}

.share {
  margin-top: 30px;
  width: 80%;
  color: #fff;
  background-color: #0B3FFF;
}
</style>