<template>
<!--pages/bank_detail/bank_detail.wxml-->
<view class="card-contine" v-if="status==1">
  <view class="card-wrap">
    <view class="bank_msg_image">
      <image :src="bankimg"></image>
    </view>
    <view class="card-num">{{bank_num}}</view>
  </view>
  <view class="bank_function">
    <view class="bank_row" @tap="Deduction_method">
      <view class="icon">
        <image src="/static/images/banner/lie.png"></image>
      </view>
      <view class="bank_function_title">扣款顺序</view>
      <view class="lg"></view>
    </view>
    <view class="bank_row" @tap="card_install" v-if="termina_btn_status==1">
      <view class="icon">
        <image src="/static/images/banner/shezhi.png"></image>
      </view>
      <view class="bank_function_title">解除绑定</view>
      <view class="lg"></view>
    </view>
  </view>
</view>
</template>

<script>
// pages/bank_detail/bank_detail.js
var sha_1 = require("../../utils/sha_1.js");
const app = getApp();

export default {
  data() {
    return {
      uid: 0,
      sign_id: 0,
      bank_text: '当日限额50000',
      bankimg_list: [],
      bankimg: '',
      bank_num: 0,
      text: '您是否进行解绑操作？',
      status: 1,
      termina_btn_status: 1,
      bank_type: ""
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();

    if (e.sign_id == undefined || e.bank_type == undefined || e.acc_no == '') {
      uni.navigateTo({
        url: '/pages/money/money'
      });
      return;
    }

    this.setData({
      sign_id: e.sign_id,
      bank_type: e.bank_type,
      bank_num: e.acc_no
    });
    this.getstroge();
  },
  methods: {
    getstroge() {
      const stroge = uni.getStorageSync('key');
      const stroge_bankimg_list = uni.getStorageSync('bankimg_list');

      if (stroge_bankimg_list) {
        stroge_bankimg_list.forEach(v => {
          if (this.bank_type == v.type) {
            this.setData({
              bankimg: v.img
            });
          }
        });
      }

      this.setData({
        uid: stroge.uid
      });
    },

    // 扣款顺序事件
    Deduction_method() {
      uni.showToast({
        title: '该功能暂未开放，敬请期待，感谢您的理解！',
        icon: 'none'
      });
    },

    // 卡解绑的事件
    card_install() {
      var that = this;
      uni.showModal({
        title: '提示',
        content: that.text,

        success(res) {
          if (res.confirm) {
            var data = {};
            data["uid"] = that.uid;
            data["sign_id"] = that.sign_id;
            var arr = {
              data: data
            };
            var jsonStr = JSON.stringify(arr);
            var aesData = sha_1.Encrypt(jsonStr);
            uni.request({
              url: app.globalData.url + 'union_pay/unionTermination',
              method: 'POST',
              data: {
                data: aesData
              },

              success(res) {
                if (res.data.code == 200) {
                  uni.showToast({
                    title: res.data.msg,
                    duration: 3000,
                    success: function () {
                      setTimeout(function () {
                        uni.navigateTo({
                          url: '/pages/money/money'
                        });
                      }, 3000); //延迟时间
                    }
                  });
                } else {
                  uni.showToast({
                    title: res.data.msg
                  });
                }
              }

            });
          }
        }

      });
    },

    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status,
            termina_btn_status: res.data.data.termina_btn_status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/bank_detail/bank_detail.wxss */
.card-contine {
  padding: 20rpx;
}

.card-wrap {
  height: 100px;
  border-radius: 12px;
  box-shadow: 1px 1px 12px #ccc;
}

.bank_msg_image {
  padding: 10rpx;
  display: flex;
}

.bank_msg_image image {
  width: 200px;
  height: 50px;
}

.card-num {
  padding: 20rpx;
}

.bank_function {
  padding: 40rpx 0;
}

.bank_row {
  display: flex;
  border-bottom: 1rpx solid #eee
}

.icon {
  display: flex;
  align-items: center;
  padding: 20rpx;
}

.icon image {
  width: 15px;
  height: 15px;
}

.bank_function_title {
  padding: 20rpx 10rpx;
  font-size: 15px;
  color: #999;
}

.lg {
  width: 8px;
  height: 8px;
  border-top: 2px solid#999;
  border-right: 2px solid #999;
  position: absolute;
  right: 10%;
  transform: rotate(45deg);
  margin-top: 30rpx;
}
</style>