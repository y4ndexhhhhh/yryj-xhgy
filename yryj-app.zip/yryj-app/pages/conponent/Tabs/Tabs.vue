<template>
<view class="tabs">
  <view class="tabs_title">
    <view v-for="(item, index) in tabs" :key="index" :class="'tabs_item ' + (item.isActive?'active':'')" @tap="chengetap" :data-index="index">{{item.value}}{{item.countnum}}</view>
  </view>
  <view class="tabs_con">
    <slot></slot>
  </view>
</view>
</template>

<script>

export default {
  data() {
    return {};
  },

  components: {},
  props: {
    tabs: {
      type: Array,
      default: []
    }
  },
  methods: {
    // 定义点击事件
    chengetap(e) {
      const {
        index
      } = e.currentTarget.dataset; // 触发父组件点击事件

      this.$emit("tabschenge", {
        detail: {
          index
        }
      });
    }

  }
};
</script>
<style>
/* pages/conponent/Tabs/Tbas.wxss */
.tabs {}

.tabs_title {
  display: flex;

}

.tabs_item {
  display: flex;
  justify-content: center;
  align-items: center;
  flex: 1;
  padding: 15rpx 0;
}

.active {
  color: #333;
  border-bottom: 5rpx solid blue;
}

.tabs_con {
  width: 100%;
}
</style>