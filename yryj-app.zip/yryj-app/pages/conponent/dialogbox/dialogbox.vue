<template>
<!--pages/conponent/dialogbox/dialogbox.wxml-->
<view :class="'zan-dialog ' + ( showDialog ? 'zan-dialog--show' : '' )">
  <!-- 如果想点击弹窗外不隐藏，取消bindtap点击事件即可 -->
  <view class="zan-dialog__mask" @tap="toggleDialog"></view>
  <view class="zan-dialog__container">
    <view style="padding:100rpx;">此处是填充的布局代码</view>
  </view>
  <view>
    <slot></slot>
  </view>
</view>
</template>

<script>

export default {
  data() {
    return {
      showDialog: false
    };
  },

  components: {},
  props: {},
  methods: {}
};
</script>
<style>
/* pages/conponent/dialogbox/dialogbox.wxss */
.zan-dialog__mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 10;
  background: rgba(0, 0, 0, 0);
  display: none;
}

.zan-dialog__container {
  position: fixed;
  bottom: 400rpx;
  width: 650rpx;
  height: 350rpx;
  margin-left: 50rpx;
  background: #f8f8f8;
  transform: translateY(300%);
  transition: all 0.4s ease;
  z-index: 12;
  border-radius: 20rpx;
  box-shadow: 0px 3px 3px 2px gainsboro;
}

.zan-dialog--show .zan-dialog__container {
  transform: translateY(0);
}

.zan-dialog--show .zan-dialog__mask {
  display: block;
}
</style>