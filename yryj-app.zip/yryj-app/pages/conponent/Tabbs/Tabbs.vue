<template>
<view class="tabbs">
  <view class="tabbs_title">
    <view v-for="(item, index) in tabbs" :key="index" :class="'tabbs_item ' + (item.isActive?'active':'')" @tap="chengetap" :data-index="index">{{item.value}}({{item.countnum}})人</view>
  </view>
  <view class="tabbs_con">
    <slot></slot>
  </view>
</view>
</template>

<script>

export default {
  data() {
    return {};
  },

  components: {},
  props: {
    tabbs: {
      type: Array,
      default: []
    }
  },
  methods: {
    chengetap(e) {
      const {
        index
      } = e.currentTarget.dataset; // 触发父组件点击事件

      this.$emit("tabbschenge", {
        detail: {
          index
        }
      });
    }

  }
};
</script>
<style>
/* pages/conponent/Tabbs/Tabbs.wxss */
.tabbs {

  width: 100%
}

.tabbs_title {
  display: flex;
  color: #333;
  background: white;
  float: right;
}

.tabbs_item {
  /* display: flex;
  width: 30%;
  justify-content: center;
  align-items: center;
  flex: 1; */
  padding: 6px 4px;
  margin-right: 4px;
  margin-top: 4px;
  border: 2px solid blue;
  border-radius: 8px;

}

.active {
  color: white;
  background-color: blue;

}

.tabbs_con {
  width: 100%;

}
</style>