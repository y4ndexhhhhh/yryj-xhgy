<template>
<view>
<!--pages/msgdetail/msgdetetail.wxml-->
<view class="emailwrap">
  <view class="content">{{content}}</view>
  <view class="adminer" v-if="type == 1">邀请人:{{real_name}}</view>
</view>
<view v-if="type==1">
  <view style="display:flex;" v-if="prop_status == 0">
    <button @tap.stop="Agree">我知道了</button>
  </view>
  <view class="icon" v-else>
    <image v-if="prop_status == 1" src="/static/images/banner/read.png"></image>
    
  </view>
</view>
<view v-else>
  <button @tap="remove">删除</button>
</view>
</view>
</template>

<script>
// pages/msgdetail/msgdetetail.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      type: 2,
      uid: 0,
      content: '',
      real_name: '',
      message_id: 0,
      prop_status: 0,
      message_id: 0,
      stroge: false
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.getstroge();
    this.getmessage(e.message_id);
    this.setData({
      message_id: e.message_id
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');

      if (stroge == '') {
        that.setData({
          stroge: false
        });
      } else {
        that.setData({
          stroge: stroge,
          uid: stroge.uid
        });
      }
    },

    // 获取邮件数据
    getmessage(message_id) {
      var that = this;
      var data = {};
      data["uid"] = that.stroge.uid;
      data["message_id"] = message_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'message_info/getMessageInfo',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            that.setData({
              content: res.data.data.content,
              type: res.data.data.type,
              real_name: res.data.data.real_name,
              message_id: message_id,
              prop_status: res.data.data.prop_status
            });
          }
        }

      });
    },

    // 删除邮件
    remove() {
      var that = this;
      var data = {};
      var message_id = that.message_id;

      if (message_id == 0) {
        uni.showToast({
          title: '删除失败'
        });
        return;
      }

      data["uid"] = that.stroge.uid;
      data["message_id"] = message_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'message_info/doDelMes',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            uni.showModal({
              title: '启奏陛下',
              content: '是否确认删除此邮件？',
              success: function (res) {
                if (res.confirm) {
                  uni.navigateTo({
                    url: '/pages/msg/msg'
                  });
                }
              }
            });
          }
        }

      });
    },

    // 邮件同意
    Agree() {
      var that = this;
      var data = {};
      data["uid"] = that.stroge.uid;
      data["msg_db_id"] = that.message_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'message_info/doAgree',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            that.setData({
              prop_status: 1
            });
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none'
            });
          }
        }

      });
    },

    // 邮件拒绝
    Refuse() {
      var that = this;
      var data = {};
      data["uid"] = that.stroge.uid;
      data["msg_db_id"] = that.message_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'message_info/doRefuse',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            that.setData({
              prop_status: 2
            });
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none'
            });
          }
        }

      });
    }

  }
};
</script>
<style>
/* pages/msgdetail/msgdetetail.wxss */
.emailwrap{
height: 150px;
margin: 30px 0;
border-top: 1rpx solid #eee;
border-bottom: 1rpx solid #eee;
background: #F0FFFF;
}
.content{
font-size: 18px;
text-indent: 2em;
letter-spacing: 2px;
padding: 6px;
}
.adminer {
float: right;
margin:15px;
}
.btn{
display: flex;
}
button{
width: 30%;
}
.icon{
     width: 70px;
     height: 70px;
     position: fixed;
        top: 26px;
        right: 20px;
        transform: rotate(-30deg);
}
.icon image{
      width: 90px;
      height: 40px;
}
</style>