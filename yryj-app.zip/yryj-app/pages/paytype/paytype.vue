<template>
<!--pages/paytype/paytype.wxml-->
<view class="conter">
  <view class="putop">
    <view>
      充值金额
      <view class="money">{{money}} 元</view>
    </view>
    <view class="title">
      <view>1、首次充值10元或签订银联代收协议即可成为“医补计划”会员，会员根据系统机制正当享有获得援助的权益。</view>
      <view class="item">2、购买10元/月VIP会员，可享受“医补计划”单月免续费、单月免费制做“电子自传”权益。</view>
      <view>3、购买89元/年VIP会员，可享受“医补计划”全年免续费权益、全年电子自传免费制做、全年免费“太极瑜伽”学习的权益。</view>
    </view>
  </view>
  <view class="aoder">
    <view class="wxaplay">付款方式</view>
    <radio-group @change="radioChange">
      <label v-for="(item, index) in items" :key="index" class="weui-cell">
        <view class="weui-cell__hd">
          <image :src="item.img"></image>
          <view class="weui-cell__bd">{{item.name}}</view>
          <radio :value="item.vname" :checked="item.checked"></radio>
        </view>

      </label>
    </radio-group>
  </view>
  <radio-group class="radig" @change="checkboxChange">
    <radio class="radios" value="3"></radio>
    我已阅读并同意<text class="text" @tap.stop="privacy">《隐私条例》</text>
    <text class="text" @tap.stop="privacy_yl" v-if="url && paytype == 'ylpay'">和《签约协议》</text>
  </radio-group>
  <button class="buttons" @tap.stop="aplay" :disabled="disabled">{{pay_name}}</button>
  <view :class="'zan-dialog ' + ( showDialog ? 'zan-dialog--show' : '' )">
    <view class="zan-dialog__mask"></view>
    <view class="zan-dialog__container">
      <view class="title_text">温馨提示</view>
      <view class="content">{{content}}</view>
      <view class="button">
        <view class="btn" plain @tap="toggleDialog">知道了</view>
      </view>
    </view>
  </view>
</view>
</template>

<script>
// pages/paytype/paytype.js
const app = getApp();
var util = require("../../utils/util.js"),
    sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      current: 0,
      equity_money: 0,
      pay_name: '确认充值',
      disabled: false,
      ordie: '',
      code: '',
      uid: '',
      openid: '',
      order_id: '',
      lock: false,
      items: [{
        vname: 'wxpay',
        name: '微信支付',
        img: "/static/images/banner/wxaplay.png",
        checked: "true"
      }, {
        vname: 'ylpay',
        name: '0元加入',
        img: "/static/images/banner/ylzf01.jpg"
      }],
      paytype: 'wxpay',
      money: 10,
      ordie: '',
      join_status: 2,
      showDialog: false,
      content: '',
      url: ''
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.unionAgreement();

    if (e.uid != undefined) {
      this.setData({
        uid: e.uid,
        money: e.money
      });
      this.getstroge();
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');

      if (stroge.uid != undefined) {
        that.setData({
          uid: stroge.uid,
          openid: '',
          join_status: stroge.join_status
        });
      }
    },

    // 微信支付
    aplay() {
      var that = this;

      if (that.ordie === '') {
        uni.showToast({
          title: '请勾选隐私条例',
          icon: 'none'
        });
        return false;
      } else {
        //  按钮节流
        that.reduceAsk();

        if (that.paytype == 'ylpay') {
          if (that.join_status == 1) {
            uni.showToast({
              title: '您已加入，请勿重复加入!',
              icon: 'none'
            });
            return;
          } else {
            uni.navigateTo({
              url: '/pages/bind_bank/bind_bank'
            });
          }
        } else {
          that.makeOrder();
        }
      }
    },

    // 请求银联支付事件
    getylaplay() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'union_pay/getUserBanknoInfo',
        method: 'POST',
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {
            uni.showToast({
              title: res.data.msg,
              icon: 'none'
            });
          } else {
            uni.showModal({
              title: '提示',
              content: res.data.msg,

              success(res) {
                if (res.confirm) {
                  uni.navigateTo({
                    url: '/pages/bind_bank/bind_bank'
                  });
                }
              }

            });
          }
        }

      });
    },

    //向服务器下单
    makeOrder() {
      var that = this;
      var equity_money = that.money;

      if (equity_money) {
        var data = {};
        data["uid"] = that.uid;
        data['amount'] = equity_money;
        var arr = {
          data: data
        };
        var jsonStr = JSON.stringify(arr);
        var aesData = sha_1.Encrypt(jsonStr);
        uni.request({
          url: app.globalData.url + 'join_project/recharge',
          method: "POST",
          data: {
            data: aesData
          },
          success: res => {
            if (res.data.code == 'ok') {
              that.wakeWxPay(res.data.data.order_id);
            } else {
              uni.showToast({
                title: '订单生成失败，请重试',
                icon: 'none'
              });
            }
          }
        });
      } else {
        uni.showToast({
          title: '充值金额获取失败，请重试',
          icon: 'none'
        });
      }
    },

    //唤醒微信支付
    wakeWxPay(order_id) {
      var that = this;
      uni.login({
        success: res => {
          var data = {};
          data["code"] = res.code;
          data["uid"] = that.uid;
          data['order_id'] = order_id;
          var arr = {
            data: data
          };
          var jsonStr = JSON.stringify(arr);
          var aesData = sha_1.Encrypt(jsonStr);
          uni.request({
            // url: app.url + 'join_project/xcx_wx_pay',
            url: app.globalData.url + 'join_project/xcx_pay',
            method: "POST",
            data: {
              data: aesData
            },
            success: res => {
              if (res.data.code == 'ok') {
                const parameter = res.data.data;
                uni.requestPayment({
                  timeStamp: parameter.timeStamp,
                  nonceStr: parameter.nonceStr,
                  package: parameter.package,
                  signType: parameter.signType,
                  paySign: parameter.paySign,
                  success: res => {
                    uni.showModal({
                      title: '支付',
                      content: '支付成功',
                      success: res => {
                        uni.switchTab({
                          url: '/pages/index/index'
                        });
                      }
                    });
                  }
                });
              }
            }
          });
        }
      });
    },

    /*按钮节流*/
    reduceAsk() {
      var _this = this;

      if (!_this.lock) {
        _this.setData({
          lock: true
        });

        var num = 6; //6秒后可以再次点击

        var timer = setInterval(function () {
          num--;

          if (num <= 0) {
            clearInterval(timer);

            _this.setData({
              pay_name: '确认充值',
              disabled: false
            });
          } else {
            _this.setData({
              pay_name: num + "s" + ' 等待中...',
              disabled: true
            });
          }
        }, 1000);
        setTimeout(function () {
          _this.lock = false;
        }, 5000);
      }
    },

    /*选择支付方式*/
    radioChange(e) {
      if (e.detail.value == 'ylpay') {
        this.setData({
          showDialog: true
        });
      } else {
        this.setData({
          showDialog: false
        });
      }

      this.setData({
        paytype: e.detail.value
      });
    },

    /*---勾选隐私条例---*/
    checkboxChange(e) {
      this.setData({
        ordie: e.detail.value
      });
    },

    /*---隐私条例---*/
    privacy() {
      uni.navigateTo({
        url: '/pages/privacy/privacy'
      });
    },

    /*---银联隐私条例---*/
    privacy_yl() {
      uni.navigateTo({
        url: '/pages/bannerurl/bannerurl?url=' + this.url
      });
    },

    // 提示框事件
    toggleDialog() {
      this.setData({
        showDialog: !this.showDialog
      });
    },

    // 提示框内容
    unionAgreement() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'users/unionAgreement',
        method: "POSt",

        success(res) {
          if (res.data.code == 200) {
            that.setData({
              url: res.data.data.url,
              content: res.data.data.content
            });
          }
        }

      });
    }

  }
};
</script>
<style>
page {
  background-color: #F4F4F4;
}

.putop {

  padding: 20px 10px;
  background-color: #fff;
}

.putop .money {
  padding: 6px 0;
  color: #FF9797;
  border-bottom: 1px solid #ccc;
}

.title {
  margin-top: 20px;
  font-size: 12px;
  color: #999;
  line-height: 20px;
}

.radig {
  margin: 50rpx 50rpx;
  font-size: 12px;
  color: #333;
}

.text {
  color: #0B3FFF;
}

.aoder {
  padding: 8px 20px;
  background-color: #fff;
  margin-top: 20px;
  box-shadow: 0 0 5px #ccc;
}

.aoder image {
  width: 20px;
  height: 20px;
  vertical-align: middle;
}

.aoder view {
  /* border-bottom: 1px solid #ccc; */
  padding: 8px 0;
}

.wxaplay {
  padding: 8px 0;
  border-bottom: 1px solid #ccc;
}

.buttons {
  margin: 50px auto 20px;
  width: 60%;
  line-height: 40px;
  background: #007bff;
  text-align: center;
  color: #ffff;
  border-radius: 10px;

}

.weui-cell__hd {
  display: flex;
  align-items: center;
}

.weui-cell__bd {
  flex: 1;
  margin-left: 10px;
}
.zan-dialog__mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 10;
  background: #000;
  opacity: 0.5;
  display: none;
}

.zan-dialog__container {
  position: fixed;
  bottom: 40%;
  width: 90vw;
  margin-left: 40rpx;
  height: 390rpx;
  background: #f8f8f8;
  transform: translateY(300%);
  transition: all 0.4s ease;
  z-index: 12;
  border-radius: 20rpx;
  font-size: 18px;
}

.zan-dialog--show .zan-dialog__container {
  transform: translateY(0);
}

.zan-dialog--show .zan-dialog__mask {
  display: block;
}

.button {
  font-weight: 200;
  text-align: center;
  font-weight: 200;
  width: 100%;
  position: relative;
  padding: 20rpx 0;
  height: 4vh;
  top: 15%;
}

.btn {
  border-radius: 8px;
  border: 1rpx solid #999;
  background-color: blue;
  color: #fff;
  position: absolute;
  width: 50%;
  left: 50%;
  transform: translate(-50%, 0);
}

.title_text{
padding: 10rpx;
text-align: center;
}
.content {
  color: #999;
  padding: 0 30rpx;
  font-size: 16px;
}

</style>