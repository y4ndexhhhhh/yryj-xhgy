<template>
	<view>
		<!--pages/gong/gong.wxml-->
		<view class="conter" v-if="status==1">
			<view style="font-size: 92rpx;font-family: PingFang SC;font-weight: 800;line-height: 24rpx;color: #4B65F1;opacity: 1;">{{stroge.devote_value}}</view>
			<view style="font-size: 36rpx;font-family: SourceHanSansCN-Regular;line-height: 30rpx;color: #333333;opacity: 1;">贡献值余额</view>
		</view>
		<view class="btn" @tap.stop="ex_shares">
			<!-- <image src="/static/images/banner/fenhong.png"></image> -->
			<text>兑换分红股</text>
			<!-- <view class="lg"></view> -->
		</view>
	</view>
</template>

<script>
	// pages/gong/gong.js
	const app = getApp();

	export default {
		data() {
			return {
				stroge: "",
				status: 1
			};
		},

		components: {},
		props: {},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			this.reqstatu();
			this.getstroge();
		},
		methods: {
			//获取本地数据
			getstroge() {
				var that = this;
				const stroge = uni.getStorageSync('key');
				that.setData({
					stroge: stroge
				});
			},

			/*---兑换分红股---*/
			ex_shares() {
				uni.navigateTo({
					url: '/pages/exshares/exshares'
				});
			},

			reqstatu() {
				var that = this;
				uni.request({
					url: app.globalData.url + 'shield/getShield',
					method: "POSt",
					data: {
						version_code: app.globalData.version_code
					},

					success(res) {
						that.setData({
							status: res.data.data.status
						});
					}

				});
			}

		}
	};
</script>
<style>
	/* pages/gong/gong.wxss */
	page {
		background-color: #F4F4F4;
	}

	.conter {
		padding: 30px 0;
		text-align: center;
		font-size: 14px;
		color: #333;
		/* background-color: blue; */
	}

	.conter view {

		margin-top: 30px;
		color: #fff;
	}

	.btn {
		width: 598rpx;
		height: 142rpx;
		background: #6178F3;
		opacity: 1;
		border-radius: 72rpx;
		margin-top: 60rpx;
		line-height: 142rpx;
		margin: 0 auto;
		text-align: center;
		font-size: 44rpx;
		font-family: SourceHanSansCN-Regular;
		/* line-height: 30px; */
		color: #FFFFFF;
		opacity: 1;
	}

	image {
		vertical-align: middle;
		width: 25px;
		height: 25px;
		border-radius: 50%;
	}

	.lg {
		width: 8px;
		height: 8px;
		border-top: 2px solid#999;
		border-right: 2px solid #999;
		right: 10%;
		transform: rotate(45deg);
		margin-top: 15px;
		float: right;
		margin-right: 6px;

	}
</style>
