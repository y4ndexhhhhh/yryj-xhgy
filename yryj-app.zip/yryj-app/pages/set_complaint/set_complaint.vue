<template>
<!--pages/set_complaint/set_complaint.wxml-->
<view class="box" v-if="status==1">
<view class="head_title">上传投诉证据 </view>
<view class="complaint_img_wrap" v-if="img==''" @tap="chooseImg" z>
  <view class="wrap">
    <image src="/static/images/banner/add.png"></image>
  </view>
  <view class="img_titel">上传照片</view>
</view>

<view class="img_wrap" v-else @tap="big_image" data-index="index">
  <view class="remove" @tap="remove">x</view>
  <image mode="widthFix" :src="img"></image>
</view>
<view class="context">
  <textarea maxlength="200" placeholder="请您输入您投诉的原因" @input="get_value">
  </textarea>
  <view class="text_num">{{length}}/200</view>
</view>
<view class="btn_wrap">
  <view class="btn" @tap="set_complaint">确认提交</view>
</view>
</view>
</template>

<script>
// pages/set_complaint/set_complaint.js
const app = getApp();
var sha_1 = require("../../utils/sha_1.js");

export default {
  data() {
    return {
      uid: 0,
      case_id: 0,
      img: '',
      token: '',
      complaint_img: '',
      content: '',
      _img: '',
      status: 1,
      length: 0
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    this.reqstatu();
    this.setData({
      uid: e.uid,
      case_id: e.case_id
    });
  },
  methods: {
    get_value(e) {
      let content = e.detail.value;
      let length = e.detail.value.length;
      this.setData({
        content: content,
        length: length
      });
    },

    // 选择图片
    chooseImg() {
      var that = this;
      uni.chooseImage({
        count: 1,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'],

        success(res) {
          var img = res.tempFilePaths;
          that.setData({
            img: img
          });

          if (img) {
            uni.request({
              url: app.globalData.url + 'users/getqntoken',
              method: "POST",

              success(res) {
                that.setData({
                  complaint_img: img,
                  token: res.data.data
                });
                that.uploadQiniu(img);
              }

            });
          }
        }

      });
    },

    /**
    * 图片上传七牛云
    */
    uploadQiniu(tempFilePaths) {
      var that = this;
      let token = that.token;

      if (token != '') {
        uni.uploadFile({
          url: 'https://upload-z2.qiniup.com',
          name: 'file',
          filePath: tempFilePaths[0],
          header: {
            "Content-Type": "multipart/form-data"
          },
          formData: {
            token: token
          },
          success: function (res) {
            if (res.statusCode == 200) {
              let respones_data = JSON.parse(res.data);
              var qiniu_key = respones_data.key;
              that.setData({
                _img: qiniu_key
              });
            }
          }
        });
      } else {
        uni.showModal({
          title: '启奏陛下',
          content: '图片上传失败，请稍后重试'
        });
      }
    },

    big_image(e) {
      var that = this;
      const current = e.currentTarget.dataset.index;
      const urls = that.img;
      uni.previewImage({
        current,
        urls
      });
    },

    // 删除图片
    remove() {
      this.setData({
        img: ''
      });
    },

    // 提交投诉事件
    set_complaint() {
      var that = this;
      var data = {};
      data["uid"] = that.uid;
      data["case_id"] = that.case_id;
      data["content"] = that.content;
      data["img"] = that._img;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.api_url + 'h5/report/saveReportData',
        method: "POST",
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 200) {
            uni.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 1500,
              mask: true,

              success(data) {
                setTimeout(function () {
                  //要延时执行的代码
                  uni.switchTab({
                    url: '/pages/index/index'
                  });
                }, 1500); //延迟时间
              }

            });
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 1500,
              mask: true,

              success(data) {
                setTimeout(function () {
                  //要延时执行的代码
                  uni.switchTab({
                    url: '/pages/index/index'
                  });
                }, 1500); //延迟时间
              }

            });
          }
        }

      });
    },

    // 屏蔽
    reqstatu() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'shield/getShield',
        method: "POSt",
        data: {
          version_code: app.globalData.version_code
        },

        success(res) {
          that.setData({
            status: res.data.data.status
          });
        }

      });
    }

  }
};
</script>
<style>
/* pages/set_complaint/set_complaint.wxss */
.head_title {
  padding: 20rpx 10rpx;
}

.complaint_img_wrap {
  border: 1rpx solid #eee;
  border-radius: 8px;
  width: 80px;
  height: 80px;
  position: relative;
  left: 40%;
}

.wrap {
  position: absolute;
  left: 40%;
  top: 30%;
  height: 20px;
  width: 20px;
}

.wrap image {
  height: 20px;
  width: 20px;
}

.img_titel {
  position: absolute;
  bottom: 0;
  left: 10%;
}

.context {
  margin-top: 30px;
  border: 1rpx solid #eee;
  width: 300px;
   height: 190px; 
  background-color: #eee;
  position: relative;
  left: 10%;
  padding: 15rpx;
  border-radius: 8px;
}
.btn_wrap {
  position: fixed;
  bottom: 20%;
  left: 40%;
}

.btn {
  border: 1rpx solid #eee;
  border-radius: 8px;
  background-color: blue;
  color: #fff;
  padding: 20rpx;
}

.img_wrap {
  width: 90px;
  height: 80px;
  position: relative;
  left: 40%;
}

.img_wrap image {
  width: 100%;
  height: 80px;
}

.remove {
  color: #999;
  position: fixed;
  z-index: 1001;
  margin-top: -28px;
  right: 10%;
  padding: 13rpx 0;
}

.text_num {
  color: #999;
  position: fixed;
  z-index: 1001;
  padding: 10rpx;
  right: 10%;

}
</style>