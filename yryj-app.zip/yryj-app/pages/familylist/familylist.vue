<template>
<view>
<!--pages/familylist/familylist.wxml-->
<view class="conter">
  <view v-if="!list.length==0">
    <view v-for="(item, index) in list" :key="index" class="list">
      <view class="listtop">
        <view class="left">
          <view>签到次数</view>
          <!-- <view>{{item.join_time}}</view> -->
		  <view>{{item.qiandaocishu}}</view>
        </view>
        <view class="right">
          <view>健康积分</view>
          <!-- <view>{{item.amount}}</view> -->
		  <view>{{item.jiankangjifen}}</view>
        </view>
      </view>
      <view class="listtop">
        <view>姓名：{{item.name}}</view>
        <view v-if="item.relev_name == null">亲属关系:暂无</view>
        <view v-else>亲属关系：{{item.relev_name}}</view>
      </view>
      <view class="listtops">
        <view>身份证号：{{item.id_card}}</view>
        <view class="btn" v-if="item.id_card != '***********'" @tap.stop="deleta" :data-id="item.id">解绑</view> 
        <view class="btns" v-else @tap.stop="go_detail" :data-id="item.id" :data-name="item.name">完善信息</view>
      </view>
    </view>
  </view>
</view>
<form>
  <view class="modalDlg" v-if="showModal">
    <view class="close_mask" @tap="close_mask">x</view>
    <view class="title">确定解绑</view>
    <input name="phones" @input="onphones" :value="phones" placeholder="请输入被保人的手机号"></input>
    <view class="showmode">
      <view class="showv" @tap.stop="close">取消</view>
      <view class="showv1" @tap.stop="formSubmit">提交</view>
    </view>
  </view>
  <view class="mask" catchtouchmove="preventTouchMove" v-if="showModal"></view>
</form>
</view>
</template>

<script>
// pages/familylist/familylist.js
const app = getApp();

export default {
  data() {
    return {
      stroge: "",
      list: "",
      hidde: true,
      id: '',
      phones: '',
      showModal: false
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    /**---获取uid---*/
    this.getstroge();
    /*---获取数据列表---*/

    this.familuy();
  },
  methods: {
    // onShow(){
    //   this.familuy();
    // },

    /**---获取uid---*/
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    /*---获取家人数据列表---*/
    familuy() {
      var that = this;
      uni.request({
        url: app.globalData.url + 'partner/family_relation',
        method: "POST",
        data: {
          uid: that.stroge.uid,
          page: 0
        },

        success(res) {
			console.log(res)
          if (res.data.code == 'ok') {
            that.setData({
              list: res.data.data
            });
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 1500,

              success(data) {
                setTimeout(function () {
                  //要延时执行的代码
                  uni.navigateTo({
                    url: '/pages/ontinue/ontinue'
                  });
                }, 1500); //延迟时间
              }

            });
          }
        }

      });
    },

    //  前往完善家人信息
    go_detail(e) {
      var name = e.currentTarget.dataset.name;
      var id = e.currentTarget.dataset.id;

      if (name == '' || id == '') {
        uni.navigateBack({
          delta: 1
        });
      }

      uni.navigateTo({
        url: '/pages/addfamily/addfamily?id=' + id + '&name=' + name
      });
    },

    /*---解除---*/
    deleta(e) {
      uni.showToast({
        title: '该功能暂未开放，感谢您的理解',
        icon: 'none'
      }); // const id = e.currentTarget.dataset.id
      // this.setData({
      //   hidde: false,
      //   id: id,
      //   showModal: true
      // })
    },

    /*弹窗input值*/
    onphones(e) {
      this.setData({
        phones: e.detail.value
      });
    },

    /*---取消---*/
    close() {
      this.setData({
        showModal: false
      });
    },

    /*确定*/
    formSubmit(e) {
      var that = this;
      uni.request({
        url: app.globalData.url + 'partner/family_unbind',
        method: 'POST',
        data: {
          uid: that.stroge.uid,
          id: that.id,
          phone: that.phones
        },

        success(res) {
          if (res.data.code == 'ok') {
            const ph = res.data.data.phone;
            const paw = res.data.data.paw;
            const msg = res.data.data.msg;
            uni.showModal({
              title: '解除成功！',
              content: `手机号：${ph} 初始密码：${paw}`,

              success(res) {
                if (res.confirm) {
                  that.setData({
                    hidde: true
                  });
                  that.familuy();
                }
              }

            });
          } else {
            const msg = res.data.msg;
            uni.showModal({
              title: '解除失败',
              content: `${msg}`
            });
          }
        }

      });
    },

    close_mask: function () {
      this.setData({
        showModal: false
      });
    },
    hideMask: function () {
      this.setData({
        showModal: false
      });
    },
    preventTouchMove: function () {}
  }
};
</script>
<style>
/* pages/familylist/familylist.wxss */
.conter {
  position: relative;
}

.list {
  margin: 30px auto;
  width: 80%;
  padding: 15px;
  background-color: #eff;
  box-shadow: 0 0 8px #eff;
  border-radius: 10px;
  color: #333;
  font-size: 14px;
}

.listtop {
  display: flex;
  justify-content: space-between;
  text-align: center;
}
.listtops{
display: flex;
margin-top: 20px;
 
}
.listtop+.listtop {
  margin-top: 20px;

}

.left,
.right {
  width: 48%;
}


.btn {
text-align: center;
  padding: 10rpx 0;
  color: #fff;
  width: 100rpx;
  border-radius: 4px;
  background-color: #107BFD;
  margin-left: 20rpx;
}
.btns{
text-align: center;
 padding: 20rpx 5rpx;
 width: 90px;
 color: #fff;
 border-radius: 4px;
 background-color: #107BFD;
 margin-left: 140rpx;
}

.heider {
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -65px;
  margin-left: -35%;
  padding-top: 15px;
  width: 70%;
  height: 130px;
  text-align: center;
  background: #fff;
  border: 1px solid #333;
  box-shadow: 0 0 6px #ccc;
}

.heider view {
  display: flex;
  margin-top: 20px;
}

.heider view {
  text-align: left;
}

.heider view input {
  line-height: 35px;
  border-bottom: 1px solid #ccc;
}

.buttons {
  justify-content: space-around;
}

.btne {
  outline: none;
  border: none;
  background: none;
  font-size: 14px;
}

.modalDlg {
  width: 580rpx;
  height: 450rpx;
  position: fixed;
  top: 50%;
  left: 0;
  z-index: 9999;
  margin: -370rpx 85rpx;
  background-color: #fff;
  border-radius: 36rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.mask {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background: #000;
  z-index: 9000;
  opacity: 0.7;
}

.close_mask {
  color: #000;
  position: relative;
  left: 42%;
  /* top: -82%; */
  font-size: 32rpx;
  padding: 8px 10px;

}

.title {
  font-size: 22px;

}

.showv {

  width: 18vw;
  padding: 6px 10px;
  border-radius: 6px;
  border: 1px solid #eee;
  text-align: center;
  background-color: blue;
  color: #eee;
  display: inline-block;
  margin-right: 6vw;

}

.showv1 {
  margin: 10px auto 0;
  width: 18vw;
  padding: 6px 10px;
  border-radius: 6px;
  border: 1px solid #eee;
  text-align: center;
  background-color: blue;
  color: #eee;
  display: inline-block;
}

.showmode {
  color: #eee;
  margin-top: 6vh;


}

input {
  border: 1px solid #eee;
  padding: 8px 0 10px;
  margin-top: 2vh;
  background-color: #FFFAFA;
  border-radius: 8px;
  text-align: center;

}
</style>