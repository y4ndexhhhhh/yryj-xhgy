<template>
<!--pages/billdetails/billdetails.wxml-->
<view class="body">
  <view class="money">交易金额<view>{{change}}元</view>
  </view>
  <view class="type">交易类型
    <view v-if="type == 1">收入</view>
    <view v-else>支出</view>
  </view>
  <view class="time">交易时间<view>{{time}}</view>
  </view>
  <view class="billnum">交易流水号<view>{{no}}</view>
  </view>
  <view class="msg">备注<view>{{describe}}</view>
  </view>
</view>
</template>

<script>
// pages/billdetails/billdetails.js
var sha_1 = require("../../utils/sha_1.js");
const app = getApp();

export default {
  data() {
    return {
      stroge: '',
      bill_id: 0,
      change: 0,
      type: '',
      time: '',
      no: '',
      describe: ''
    };
  },

  components: {},
  props: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    if (e.id == undefined || e.id == '') {
      uni.switchTab({
        url: '../my/my'
      });
    } else {
      var that = this;
      that.setData({
        bill_id: e.id
      });
    }

    this.getstroge();
    this.reqstatu();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},
  methods: {
    //获取本地数据
    getstroge() {
      var that = this;
      const stroge = uni.getStorageSync('key');
      that.setData({
        stroge: stroge
      });
    },

    // 获取数据
    reqstatu() {
      var that = this;
      var data = {};
      data["id"] = that.bill_id;
      var arr = {
        data: data
      };
      var jsonStr = JSON.stringify(arr);
      var aesData = sha_1.Encrypt(jsonStr);
      uni.request({
        url: app.globalData.url + 'wallet/bill_detail',
        method: "POST",
        data: {
          data: aesData
        },

        success(res) {
          if (res.data.code == 'ok') {
            that.setData({
              change: res.data.data.change,
              describe: res.data.data.describe,
              time: res.data.data.time,
              no: res.data.data.no,
              type: res.data.data.type
            });
          } else {
            uni.showToast({
              title: res.data.msg,
              icon: 'none'
            });
          }
        }

      });
    }

  }
};
</script>
<style>
/* pages/billdetails/billdetails.wxss */
.body {
	width: 100%;
	height: 100vh;
	background-color: #F8F9FF;
}

.money {

  display: flex;
  justify-content: space-between;
  width: 100%;
  height: 120rpx;
  padding: 0 30rpx;
  box-sizing: border-box;
  align-items: center;
  /* padding: 8px 2px; */
  border-bottom: 1px solid #EFEFEF;
  color: red;
  background-color: #FFFFFF;
  
}

.type {
  display: flex;
  justify-content: space-between;
  width: 100%;
  height: 120rpx;
  padding: 0 30rpx;
  box-sizing: border-box;
  align-items: center;
  /* padding: 8px 2px; */
  border-bottom: 1px solid #EFEFEF;
   background-color: #FFFFFF;
}

.time {
  display: flex;
  justify-content: space-between;
 width: 100%;
 height: 120rpx;
 padding: 0 30rpx;
 box-sizing: border-box;
 align-items: center;
  border-bottom: 1px solid #EFEFEF;
   background-color: #FFFFFF;
}

.billnum {
  display: flex;
  justify-content: space-between;
  
 width: 100%;
 height: 120rpx;
 padding: 0 30rpx;
 box-sizing: border-box;
 align-items: center;
  border-bottom: 1px solid #EFEFEF;
   background-color: #FFFFFF;
}

.msg {
  display: flex;
  justify-content: space-between;
 width: 100%;
 height: 120rpx;
 padding: 0 30rpx;
 box-sizing: border-box;
 align-items: center;
  border-bottom: 1px solid #EFEFEF;
  background-color: #FFFFFF;
}
</style>