# uni-news-with-ad

带广告的新闻内容云端一体模板，快速获取不断更新的新闻内容


## 简介

模板使用 [uniCloud](https://uniapp.dcloud.net.cn/uniCloud/README) 开发，Dcloud与三方新闻内容商合作，自动拉取新闻内容

新闻内容覆盖10大类：社会，娱乐，体育，军事，国际，历史，汽车，养生，情感，星座，开发者可自由配置

开发者无需购买服务器（零成本），也不需要关心新闻审核和更新，用户浏览新闻时会展示[信息流广告](https://uniapp.dcloud.io/component/ad)，开发者通过广告获得收入

三方新闻内容拥有优质原创和版权内容，拥有专业内容审核团队做到严格内容把控，无需担心新闻版权以及审核问题


## 页面结构

模板包含2个页面

`news` 新闻列表页面，支持下拉刷新上拉加载，默认每 `5` 条新闻插入一条信息流广告，开发者也可以修改广告展示的密度

`news-detail` 新闻详情页


## 如何使用

1. 导入插件到项目

2. 在项目的 `uniCloud/cloudfunctions/uni-news-with-ad-spider` 目录上点击鼠标右键，上传部署...

3. 在项目的 `pages.json` 文件 `pages` 节点 增加插件的 `news`、`news-detail`、页面配置（拷贝下面的 `pages.json` 配置）

4. 替换页面中的广告位 `adpid`

`pages.json`文件配置

```json
{
	"pages": [
		{
			"path": "uni_modules/uni-news-with-ad/pages/news",
			"style": {
				"navigationBarTitleText": "新闻中心"
			}
		}, {
			"path": "uni_modules/uni-news-with-ad/pages/news-detail",
			"style": {
				"navigationBarTitleText": "新闻详情"
			}
		}
	]
}
```


## 新闻分类配置

前端页面在请求新闻列表时携带新闻分类参数 `cid`，可以选下面表格中支持的值

|值|说明|
|:-|:-|
|shehui|社会|
|bagua|娱乐|
|tiyu|体育|
|mil|军事|
|guoji|国际|
|lishi|历史|
|qiche|汽车|
|yangsheng|养生|
|qinggan|情感|
|xingzuo|星座|


## 如何更换广告位

[信息流广告介绍](https://uniapp.dcloud.io/component/ad)

`news`、`news-detail`、每个页面都包含一个 [ad](https://uniapp.dcloud.net.cn/component/ad) 组件，需要将组件中的广告位 `adpid` 替换为 [uniad](https://uniad.dcloud.net.cn/) 后台申请的广告位

广告示例代码

```html
<ad class="ad" adpid="1111111111" channel="uni-news-with-ad" @error="onaderror"></ad>
// 其中channel参数为新闻特殊标识，务必上报。如漏掉造成的损失开发者自行承担
```

注意：示例中的广告位 adpid `1111111111` 仅适用 HBuilder 基座测试


新闻产品使用许可协议

2021年5月

本许可协议，是数字天堂（北京）网络技术有限公司（以下简称DCloud）对其所拥有著作权的“新闻产品”（以下简称软件），提供的使用许可协议。

您对“软件”的复制、使用、修改及分发受本许可协议的条款的约束，如您不接受本协议，则不能使用、复制、修改本软件。

授权许可范围 a) 授予您永久性的、全球性的、免费的、非独占的、不可撤销的本软件的源码使用许可，您可以使用这些源码制作自己的应用。

b) 您只能在DCloud产品体系内使用本软件及其源码。您不能将源码修改后运行在DCloud产品体系之外的环境，比如客户端脱离uni-app，或服务端脱离uniCloud。

c) DCloud未向您授权商标使用许可。您在根据本软件源码制作自己的应用时，需以自己的名义发布软件，而不是以DCloud名义发布。

d) 本协议不构成代理关系。

DCloud的责任限制 “软件”在提供时不带任何明示或默示的担保。 a) 在任何情况下，DCloud不对任何人因使用“软件”而引发的任何直接或间接损失承担责任，不论因何种原因导致或者基于何种法律理论,即使其曾被建议有此种损失的可能性。

b) DCloud承诺其提供的产品内容属于正版授权，不存在低俗、色情等法律法规禁止的不良信息。

您的责任限制 a) 您需要在授权许可范围内使用软件。

b) 您在分发自己的应用时，不得侵犯DCloud商标和名誉权利。

c) 您不得进行破解、反编译、套壳等侵害DCloud知识产权的行为。您不得利用DCloud系统漏洞谋利或侵害DCloud利益，如您发现DCloud系统漏洞应第一时间通知DCloud。您不得进行攻击DCloud的服务器、网络等妨碍DCloud运营的行为。您不得利用DCloud的产品进行与DCloud争夺开发者的行为。

d) 您可以调取并使用新闻产品内容，但不得修改新闻内容，包括相关的文字、声音、影像、图片等信息。

e) 如您违反本许可协议，需承担因此给DCloud造成的损失。

本协议签订地点为中华人民共和国北京市海淀区。

根据发展，DCloud可能会对本协议进行修改。修改时，DCloud会在产品或者网页中显著的位置发布相关信息以便及时通知到用户。如果您选择继续使用本框架，即表示您同意接受这些修改。

条款结束
