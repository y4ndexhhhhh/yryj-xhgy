<template>
  <view>
    <web-view :src="url"></web-view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        title: "",
        url: ""
      }
    },
    onLoad(e) {
      uni.setNavigationBarTitle({
        title: decodeURIComponent(e.title)
      })
      this.url = decodeURIComponent(e.url);
    },
    onReady() {},
    methods: {}
  }
</script>

<style>
</style>
