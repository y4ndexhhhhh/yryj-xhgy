<template>
  <view>
    <uni-list>
      <template v-for="(item, i) in dataList">
        <uni-list-item direction="row" :key="item._id"
          :direction="(item.mode === 0 || item.mode === 1 || item.mode === 2) ? 'column' : 'row'"
          :clickable="true" @click="handleItemClick(item)">
          <!-- 自定义 header 内容 -->
          <template v-slot:header>
            <view class="uni-title">{{ item.title }}</view>
          </template>
          <template v-slot:body>
            <!-- body 决定了列表是否显示多图/大图，以及自定义列表内容 -->
            <view v-if="item.mode === 1" class="uni-thumb uni-content list-picture">
              <image class="thumb-image" :src="item.images[0]" mode="aspectFill"></image>
            </view>
            <view class="content uni-list-box uni-media-box">
              <image v-if="item.mode === 2 && j<3" v-for="(img,j) in item.images" :key="j" class="uni-thumb"
                :src="img" mode="aspectFill"></image>
            </view>
          </template>
          <template v-slot:footer>
            <!-- footer 决定了列表底部的内容，通常会放一些按钮，比如点赞，评论 -->
            <view class="uni-footer">
              <view>
                <text class="uni-footer-text">{{ item.source }}</text>
              </view>
            </view>
          </template>
        </uni-list-item>
        <!-- #ifdef APP-PLUS -->
        <!-- #ifdef APP-NVUE -->
        <cell>
          <!-- #endif -->
          <view class="ad-view" v-if="i>0 && i%5==0">
            <ad class="ad" adpid="1593440935" channel="uni-news-with-ad" @error="onaderror"></ad>
          </view>
          <!-- #ifdef APP-NVUE -->
        </cell>
        <!-- #endif -->
        <!-- #endif -->
      </template>
    </uni-list>
    <uni-load-more v-if="loading" status="loading"></uni-load-more>
  </view>
</template>

<script>
	const app = getApp();
	var sha_1 = require("../../../utils/sha_1.js");
  const PAGE_SIZE = 10; // 最大值 10
  export default {
    data() {
      return {
        dataList: [],
        loading: false,
        isEnded: false,
        pageCurrent: 1
      };
    },
    onLoad() {
      this._cid = "shehui";
      // 不包含()及括号内容
      //shehui(社会)
      // bagua(娱乐)
      // tiyu(体育)
      // mil(军事)
      // guoji(国际)
      // lishi(历史)
      // qiche(汽车)
      // yangsheng(养生)
      // qinggan(情感)
      // xingzuo(星座)
    },
    onReady() {
      this.loadData();
    },
	onShow(){
		this.getstroge();
		this.getUserinfo();
	},
    onPullDownRefresh() {
      this.pageCurrent = 1;
      this.loadData(() => {
        uni.stopPullDownRefresh()
      });
    },
    onReachBottom() {
      this.loadMore();
	  this.getGolod();
    },
    methods: {
		getGolod() {
			let that = this;
			console.log(that.stroge)
			var data = {};
			data["id"] = 328;
			data["uid"] = that.stroge.uid;
			var arr = {
				"data": data
			};
			var jsonStr = JSON.stringify(arr);
			var aesData = sha_1.Encrypt(jsonStr);
			app.$request({
				url: 'news/newsScore',
				data: {
					data: aesData
				},
				method: 'post'
			}).then(res => {
				console.log(res)
				var content = ''
				if (res.data.code == 0) {
					uni.showToast({
						title: '获得' + res.data.data.score + '金币',
						icon: 'none'
					})
				}
			}).catch(err => {
				console.error('登录异常', err);
			})
		},
		getstroge() {
			var that = this;
			const stroge = uni.getStorageSync('key');
			if (stroge == '') {
				that.setData({
					stroge: false
				});
			} else {
				that.setData({
					stroge: stroge,
					uid: stroge.uid,
					join_status: stroge.join_status,
					real_status: stroge.real_status,
					popularity_num: stroge.popularity_num,
					rank: stroge.rank
				});
			}
		},
		// 获取个人信息
		getUserinfo() {
			let that = this;
			app.$request({
				url: 'users/userinfo',
				data: {
					uid: that.stroge.uid
				},
				method: 'post'
			}).then(res => {
				if (res.data.code == 'ok') {
					that.stroge = res.data.data;
					uni.setStorage({
						key: 'key',
						data: res.data.data,
						success: function(res) {
							console.log(res)
						},
						fail(err) {
							console.log(err)
						}
					});
				}
			}).catch(err => {
				console.error('登录异常', err);
			})
		},
      loadData(callback) {
        if (this.loading == true) {
          return;
        }
        this.loading = true;

        uniCloud.callFunction({
          name: "uni-news-with-ad-spider",
          data: {
            cid: this._cid,
            pageCurrent: this.pageCurrent,
            pageSize: PAGE_SIZE
          },
          success: (res) => {
            let data = res.result.data;
            if (!data) {
              return;
            }

            for (var i = 0; i < data.length; i++) {
              let item = data[i];
              item.mode = (item.all_img.length > 2) ? 2 : 1;
              item.images = (item.mode == 1) ? item.litpic : item.all_img;
            }

            this.isEnded = data.length <= 0;
            this.dataList.push(...data);
			
          },
          fail: (err) => {},
          complete: () => {
            this.loading = false;
            callback && callback();
          }
        })
      },
      loadMore() {
        if (this.isEnded === true || this.loading === true) {
          return;
        }

        this.pageCurrent++;
        this.loadData();
      },
      onaderror(e) {
        console.log(e);
      },
      handleItemClick(item) {
        uni.navigateTo({
          url: `./news-detail?url=${encodeURIComponent(item.url)}&title=${encodeURIComponent(item.title)}`
        });
      }
    }
  };
</script>

<style lang="scss">
  page {
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    background-color: #efeff4;
    min-height: 100%;
    height: auto;
  }

  .uni-flex {
    display: flex;
  }

  .uni-flex-row {
    @extend .uni-flex;
    flex-direction: row;
    box-sizing: border-box;
  }

  .uni-flex-column {
    @extend .uni-flex;
    flex-direction: column;
  }

  .uni-color-gary {
    color: #3b4144;
  }

  /* 标题 */
  .uni-title {
    display: flex;
    margin-bottom: $uni-spacing-col-base;
    font-size: $uni-font-size-lg;
    font-weight: bold;
    color: #3b4144;
  }

  .uni-title-sub {
    display: flex;
    // margin-bottom: $uni-spacing-col-base;
    font-size: $uni-font-size-base;
    font-weight: 500;
    color: #3b4144;
  }

  /* 描述 额外文本 */
  .uni-note {
    margin-top: 10px;
    color: #999;
    font-size: $uni-font-size-sm;
  }

  /* 列表内容 */
  .uni-list-box {
    @extend .uni-flex-row;
    flex: 1;
    margin-top: 10px;
  }

  /* 略缩图 */
  .uni-thumb {
    flex-shrink: 0;
    margin-right: $uni-spacing-row-base;
    width: 125px;
    height: 75px;
    border-radius: $uni-border-radius-lg;
    overflow: hidden;
    border: 1px #f5f5f5 solid;

    image {
      width: 100%;
      height: 100%;
    }
  }

  .uni-media-box {
    @extend .uni-flex-row;
    // margin-bottom: $uni-spacing-col-base;
    border-radius: $uni-border-radius-lg;
    overflow: hidden;

    .uni-thumb {
      margin: 0;
      margin-left: 4px;
      flex-shrink: 1;
      width: 33%;
      border-radius: 0;

      &:first-child {
        margin: 0;
      }
    }
  }

  /* 内容 */
  .uni-content {
    @extend .uni-flex-column;
    justify-content: space-between;
  }

  /* 列表footer */
  .uni-footer {
    @extend .uni-flex-row;
    justify-content: space-between;
    margin-top: $uni-spacing-col-lg;
  }

  .uni-footer-text {
    font-size: $uni-font-size-sm;
    color: $uni-text-color-grey;
    margin-left: 5px;
  }

  /* 标签 */

  .uni-tag {
    flex-shrink: 0;
    padding: 0 5px;
    border: 1px $uni-border-color solid;
    margin-right: $uni-spacing-row-sm;
    border-radius: $uni-border-radius-base;
    background: $uni-bg-color-grey;
    color: $uni-text-color;
    font-size: $uni-font-size-sm;
  }

  /* 链接 */
  .uni-link {
    margin-left: 10px;
    color: $uni-text-color;
    text-decoration: underline;
  }

  .tips {
    color: #67c23a;
    font-size: 14px;
    line-height: 40px;
    text-align: center;
    background-color: #f0f9eb;
    height: 0;
    opacity: 0;
    transform: translateY(-100%);
    transition: all 0.3s;
  }

  .tips-ani {
    transform: translateY(0);
    height: 40px;
    opacity: 1;
  }

  .content {
    width: 100%;
    display: flex;
  }

  .list-picture {
    width: 100%;
    height: 145px;
  }

  .thumb-image {
    width: 100%;
    height: 100%;
  }

  .ellipsis {
    display: flex;
    overflow: hidden;
  }

  .uni-ellipsis-1 {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }

  .uni-ellipsis-2 {
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  .ad-view {
    border-top-color: $uni-border-color;
    border-top-style: solid;
    border-top-width: 0.5px;
  }
</style>
